module.exports = require('./tty.mjs').default;
