import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, f as invalidArgValue, g as outOfRange, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { Buffer } from "./buffer.mjs";
import { t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { m as import_events } from "./chunks/events-KhrHxd6b.mjs";
import { n as channel } from "./chunks/channel-tzh3-Au8.mjs";
import { t as BlockList } from "./chunks/block-list-BgxWsckK.mjs";
import { t as isIP } from "./chunks/ip-DlsRrJdq.mjs";
import { n as decodeErrno, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dgram-host.js
var dgram_host_exports = /* @__PURE__ */ __exportAll({
	Socket: () => Socket$1,
	createSocket: () => createSocket$1,
	default: () => dgram_host_default
});
/** Typed denial is catchable inside the guest; a throwing WIT constructor would trap. */
const createSocket$1 = () => ({
	tag: "err",
	val: {
		name: "Error",
		code: "ERR_JCO_DGRAM_ADAPTER_REQUIRED",
		message: adapterRequiredMessage("node:dgram")
	}
});
const Socket$1 = class Socket {
	constructor() {
		throw new Error(adapterRequiredMessage("node:dgram"));
	}
};
var dgram_host_default = {
	createSocket: createSocket$1,
	Socket: Socket$1
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dgram/errors.js
function socketError(code, message) {
	return codedError(code === "ERR_SOCKET_BAD_BUFFER_SIZE" || code === "ERR_SOCKET_BAD_TYPE" ? new TypeError(message) : new Error(message), code);
}
function notRunning() {
	return socketError("ERR_SOCKET_DGRAM_NOT_RUNNING", "Not running");
}
function alreadyBound() {
	return socketError("ERR_SOCKET_ALREADY_BOUND", "Socket is already bound");
}
function connected() {
	return socketError("ERR_SOCKET_DGRAM_IS_CONNECTED", "Already connected");
}
function notConnected() {
	return socketError("ERR_SOCKET_DGRAM_NOT_CONNECTED", "Not connected");
}
function deprecated(api) {
	throw deprecatedNodeApi(api, "dgram.createSocket() and the public Socket methods");
}
function unsupported(api) {
	throw unsupportedNodeApi(api, "Native file descriptors and shared cluster handles cannot cross a component boundary");
}
function fromHost(error) {
	const result = error.name === "TypeError" ? new TypeError(error.message) : error.name === "RangeError" ? new RangeError(error.message) : new Error(error.message);
	for (const [name, value] of Object.entries({
		code: error.code,
		errno: decodeErrno(error.errno),
		syscall: error.syscall,
		address: error.address,
		port: error.port
	})) if (value !== void 0) Object.defineProperty(result, name, {
		value,
		configurable: true,
		writable: true,
		enumerable: true
	});
	if (error.name !== result.name) Object.defineProperty(result, "name", {
		value: error.name,
		configurable: true,
		writable: true
	});
	if (error.info) {
		const info = { ...error.info };
		Object.defineProperty(result, "info", {
			value: info,
			configurable: true,
			enumerable: true
		});
		for (const key of ["errno", "syscall"]) Object.defineProperty(result, key, {
			get: () => info[key],
			set: (value) => {
				info[key] = value;
			},
			configurable: true,
			enumerable: true
		});
	}
	return result;
}
function validatePort(value, name = "Port", zero = false) {
	if (typeof value !== "number" && typeof value !== "string" || typeof value === "string" && !value.trim() || +value !== +value >>> 0 || +value > 65535 || !zero && +value === 0) throw codedError(/* @__PURE__ */ new RangeError(`${name} should be >${zero ? "=" : ""} 0 and < 65536. Received type ${typeof value} (${String(value)}).`), "ERR_SOCKET_BAD_PORT");
	return +value;
}
function validateString(value, name) {
	if (typeof value !== "string") throw invalidArgType(name, "string", value);
}
function validateNumber(value, name) {
	if (typeof value !== "number") throw invalidArgType(name, "number", value);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dgram/send.js
/**
* Adapted from nodejs/node lib/dgram.js (sliceBuffer, fixBufferList, send),
* v24.20.0, 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT.
* License above. Local changes: typed unknown input and a single
* copied WIT byte list after Node's overload and byte-offset normalization.
*/
function bytes(value) {
	if (typeof value === "string") return Buffer.from(value);
	if (!ArrayBuffer.isView(value)) throw invalidArgType("buffer", [
		"Buffer",
		"TypedArray",
		"DataView",
		"string"
	], value);
	return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
}
function slice(value, offset, length) {
	const buffer = bytes(value);
	const start = offset >>> 0;
	const size = length >>> 0;
	if (start > buffer.byteLength || start + size > buffer.byteLength) throw codedError(/* @__PURE__ */ new RangeError(`"${start > buffer.byteLength ? "offset" : "length"}" is outside of buffer bounds`), "ERR_BUFFER_OUT_OF_BOUNDS");
	return buffer.subarray(start, start + size);
}
function normalizeSend(isConnected, buffer, offset, length, port, address, callback) {
	if (!isConnected) {
		if (address || port && typeof port !== "function") buffer = slice(buffer, offset, length);
		else {
			callback = port;
			port = offset;
			address = length;
		}
	} else {
		if (typeof length === "number") {
			buffer = slice(buffer, offset, length);
			if (typeof port === "function") {
				callback = port;
				port = void 0;
			}
		} else callback = offset;
		if (port || address) throw connected();
	}
	const list = [];
	if (Array.isArray(buffer)) for (let index = 0; index < buffer.length; index++) {
		const value = buffer[index];
		if (typeof value !== "string" && !ArrayBuffer.isView(value)) throw invalidArgType("buffer list arguments", [
			"Buffer",
			"TypedArray",
			"DataView",
			"string"
		], buffer);
		list.push(bytes(value));
	}
	else list.push(bytes(buffer));
	const targetPort = isConnected ? void 0 : validatePort(port);
	if (typeof callback !== "function") callback = void 0;
	if (typeof address === "function") {
		callback = address;
		address = void 0;
	} else if (address != null) validateString(address, "address");
	const data = new Uint8Array(list.reduce((size, part) => size + part.byteLength, 0));
	let position = 0;
	for (const part of list) {
		data.set(part, position);
		position += part.byteLength;
	}
	return {
		data,
		port: targetPort,
		address,
		callback
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dgram/core.js
/**
* Socket lifecycle adapted from nodejs/node lib/dgram.js and lib/internal/dgram.js,
* v24.20.0, 71b8b174857e25106d39b61a9e6f30d927da8b01 (MIT; license above).
* Local adaptations: typed WIT handles replace udp_wrap, callback resources replace
* native callbacks, microtasks replace nextTick, and deprecated internals fail fast.
* Native descriptors/cluster handle adoption are explicitly unsupported.
*/
function createDgram(host) {
	const listeners = /* @__PURE__ */ new Map();
	let nextListener = 1;
	class Listener {
		deliver;
		constructor(deliver) {
			this.deliver = deliver;
		}
		event(event) {
			this.deliver(event);
		}
		[Symbol.dispose]() {}
	}
	const dgramCallbacks = {
		SocketListener: Listener,
		takeSocketListener(id) {
			const listener = listeners.get(id);
			listeners.delete(id);
			return listener;
		}
	};
	const Emitter = import_events.EventEmitter;
	class Socket extends Emitter {
		type;
		#options;
		#handle;
		#listener;
		#closed = false;
		#bindState = "unbound";
		#connectState = "disconnected";
		#queue;
		#ref = true;
		#nextCallback = 1;
		#lookups = /* @__PURE__ */ new Map();
		#sends = /* @__PURE__ */ new Map();
		#removeAbort;
		constructor(type, listener) {
			super();
			const options = typeof type === "object" && type !== null ? type : { type };
			for (const name of ["recvBufferSize", "sendBufferSize"]) {
				const value = options[name];
				if (value) {
					validateNumber(value, `options.${name}`);
					if (!Number.isInteger(value)) throw outOfRange(`options.${name}`, "an integer", value);
					if (value !== value >>> 0) throw outOfRange(`options.${name}`, ">= 0 && <= 4294967295", value);
				}
			}
			for (const name of ["receiveBlockList", "sendBlockList"]) if (options[name] && !BlockList.isBlockList(options[name])) throw invalidArgType(`options.${name}`, "net.BlockList", options[name]);
			if (options.lookup !== void 0 && typeof options.lookup !== "function") throw invalidArgType("lookup", "Function", options.lookup);
			if (options.type !== "udp4" && options.type !== "udp6") throw socketError("ERR_SOCKET_BAD_TYPE", "Bad socket type specified. Valid types are: udp4, udp6");
			this.type = options.type;
			this.#options = {
				type: options.type,
				lookup: options.lookup,
				recvBufferSize: options.recvBufferSize,
				sendBufferSize: options.sendBufferSize,
				receiveBlockList: options.receiveBlockList,
				sendBlockList: options.sendBlockList,
				reuseAddr: options.reuseAddr,
				reusePort: options.reusePort,
				ipv6Only: options.ipv6Only
			};
			if (typeof listener === "function") this.on("message", listener);
			if (options.signal !== void 0) {
				const signal = options.signal;
				if (!signal || typeof signal.aborted !== "boolean" || typeof signal.addEventListener !== "function") throw invalidArgType("options.signal", "AbortSignal", signal);
				const abort = () => {
					if (!this.#closed) this.close();
				};
				if (signal.aborted) abort();
				else {
					signal.addEventListener("abort", abort, { once: true });
					this.#removeAbort = () => signal.removeEventListener("abort", abort);
				}
			}
			const diagnostic = channel("udp.socket");
			if (diagnostic.hasSubscribers) diagnostic.publish({ socket: this });
		}
		#health() {
			if (this.#closed) throw notRunning();
		}
		#ensure() {
			this.#health();
			if (!this.#handle) {
				if (nextListener > 4294967295) throw socketError("ERR_JCO_DGRAM_CALLBACK_LIMIT", "UDP callback registrations exhausted");
				const id = nextListener++;
				listeners.set(id, new Listener((event) => this.#event(event)));
				try {
					this.#handle = callHost(() => host.createSocket({
						type: this.type,
						reuseAddr: !!this.#options.reuseAddr,
						reusePort: !!this.#options.reusePort,
						ipv6Only: !!this.#options.ipv6Only
					}, id), fromHost);
					this.#listener = id;
					if (!this.#ref) this.#handle.setRef(false);
				} catch (error) {
					listeners.delete(id);
					throw error;
				}
			}
			return this.#handle;
		}
		#event(event) {
			if (this.#closed && event.tag !== "sent") return;
			switch (event.tag) {
				case "message": {
					const remote = event.val.remote;
					if (this.#options.receiveBlockList?.check(remote.address, remote.family === "IPv6" ? "ipv6" : "ipv4")) return;
					const message = Buffer.from(event.val.data);
					this.emit("message", message, {
						...remote,
						size: message.length
					});
					break;
				}
				case "error":
					this.emit("error", fromHost(event.val));
					break;
				case "resolved": {
					const callback = this.#lookups.get(event.val.id);
					this.#lookups.delete(event.val.id);
					const result = event.val.result;
					callback?.(result.tag === "err" ? fromHost(result.val) : null, result.tag === "ok" ? result.val : "", this.type === "udp4" ? 4 : 6);
					break;
				}
				case "sent": {
					const callback = this.#sends.get(event.val.id);
					if (!callback) return;
					this.#sends.delete(event.val.id);
					const result = event.val.result;
					try {
						callback?.(result.tag === "err" ? fromHost(result.val) : null, result.tag === "ok" ? result.val : 0);
					} finally {
						if (this.#closed && this.#sends.size === 0) this.#finishClose();
					}
				}
			}
		}
		#lookup(address, callback) {
			const name = address || (this.type === "udp4" ? "127.0.0.1" : "::1");
			const family = this.type === "udp4" ? 4 : 6;
			if (this.#options.lookup) {
				this.#options.lookup(name, family, callback);
				return;
			}
			if (isIP(name) === family) {
				queueMicrotask(() => callback(null, name, family));
				return;
			}
			const id = this.#allocate();
			this.#lookups.set(id, callback);
			try {
				this.#ensure().resolve(name, id);
			} catch (error) {
				this.#lookups.delete(id);
				throw error;
			}
		}
		#allocate() {
			if (this.#nextCallback > 4294967295) throw socketError("ERR_JCO_DGRAM_CALLBACK_LIMIT", "UDP callbacks exhausted");
			return this.#nextCallback++;
		}
		#enqueue(operation) {
			if (!this.#queue) {
				this.#queue = [];
				const failed = () => {
					this.#queue = void 0;
					this.removeListener("listening", ready);
				};
				const ready = () => {
					this.removeListener(import_events.EventEmitter.errorMonitor, failed);
					const pending = this.#queue;
					this.#queue = void 0;
					for (const operation of pending ?? []) operation();
				};
				this.once(import_events.EventEmitter.errorMonitor, failed);
				this.once("listening", ready);
			}
			this.#queue.push(operation);
		}
		#bound() {
			this.#bindState = "bound";
			if (this.#options.recvBufferSize) this.setRecvBufferSize(this.#options.recvBufferSize);
			if (this.#options.sendBufferSize) this.setSendBufferSize(this.#options.sendBufferSize);
		}
		bind(port, address, callback) {
			this.#health();
			if (this.#bindState !== "unbound") throw alreadyBound();
			if (port !== null && typeof port === "object" && ("fd" in port || "recvStart" in port)) unsupported("dgram.Socket.bind(handle/fd)");
			const handle = this.#ensure();
			this.#bindState = "binding";
			const cb = typeof callback === "function" ? callback : typeof address === "function" ? address : typeof port === "function" ? port : void 0;
			if (cb) {
				const remove = () => {
					this.removeListener("error", remove);
					this.removeListener("listening", listening);
				};
				const listening = () => {
					remove();
					cb.call(this);
				};
				this.on("error", remove);
				this.on("listening", listening);
			}
			const options = typeof port === "object" && port !== null ? port : {
				port: typeof port === "function" ? void 0 : port,
				address: typeof address === "string" ? address : void 0
			};
			this.#lookup(options.address || (this.type === "udp4" ? "0.0.0.0" : "::"), (error, ip) => {
				if (this.#closed) return;
				if (!error) try {
					callHost(() => handle.bind(ip, validatePort(options.port || 0, "Port", true)), fromHost);
					this.#bound();
				} catch (failure) {
					error = failure;
				}
				if (error) {
					this.#bindState = "unbound";
					this.emit("error", error);
					return;
				}
				this.emit("listening");
			});
			return this;
		}
		bindSync(options = {}) {
			this.#health();
			if (options === null || typeof options !== "object" || Array.isArray(options)) throw invalidArgType("options", "Object", options);
			if (this.#bindState !== "unbound") throw alreadyBound();
			if ("fd" in options) unsupported("dgram.Socket.bindSync(fd)");
			const port = validatePort(options.port ?? 0, "options.port", true);
			const address = options.address || (this.type === "udp4" ? "0.0.0.0" : "::");
			validateString(address, "options.address");
			if (!isIP(address)) throw invalidArgValue("options.address", address, "must be a numeric IP address; bindSync does not perform DNS resolution");
			const result = callHost(() => this.#ensure().bind(address, port), fromHost);
			this.#bound();
			queueMicrotask(() => {
				if (!this.#closed) this.emit("listening");
			});
			return result;
		}
		connect(port, address, callback) {
			port = validatePort(port);
			if (typeof address === "function") {
				callback = address;
				address = "";
			}
			if (address === void 0) address = "";
			validateString(address, "address");
			if (this.#connectState !== "disconnected") throw connected();
			this.#ensure();
			this.#connectState = "connecting";
			if (this.#bindState === "unbound") this.bind({
				port: 0,
				exclusive: true
			});
			const connect = () => {
				if (callback) this.once("connect", callback);
				this.#lookup(address, (error, ip) => {
					if (this.#closed) return;
					try {
						if (error) throw error;
						this.#checkBlocked(ip);
						callHost(() => this.#ensure().connect(ip, port), fromHost);
						this.#connectState = "connected";
					} catch (failure) {
						this.#connectState = "disconnected";
						queueMicrotask(() => {
							if (callback) {
								this.removeListener("connect", callback);
								callback(failure);
							} else this.emit("error", failure);
						});
						return;
					}
					queueMicrotask(() => {
						if (!this.#closed) this.emit("connect");
					});
				});
			};
			if (this.#bindState !== "bound") this.#enqueue(connect);
			else connect();
		}
		connectSync(port, address) {
			this.#health();
			port = validatePort(port);
			if (this.#connectState !== "disconnected") throw connected();
			address = address || (this.type === "udp4" ? "127.0.0.1" : "::1");
			validateString(address, "address");
			if (!isIP(address)) throw invalidArgValue("address", address, "must be a numeric IP address; connectSync does not perform DNS resolution");
			if (this.#bindState === "unbound") this.bindSync();
			else if (this.#bindState !== "bound") throw alreadyBound();
			this.#checkBlocked(address);
			callHost(() => this.#ensure().connect(address, port), fromHost);
			this.#connectState = "connected";
			queueMicrotask(() => {
				if (!this.#closed) this.emit("connect");
			});
		}
		#checkBlocked(address) {
			if (this.#options.sendBlockList?.check(address, isIP(address) === 6 ? "ipv6" : "ipv4")) throw socketError("ERR_IP_BLOCKED", `IP ${address} is blocked`);
		}
		disconnect() {
			if (this.#connectState !== "connected") throw notConnected();
			callHost(() => this.#ensure().disconnect(), fromHost);
			this.#connectState = "disconnected";
		}
		send(buffer, offset, length, port, address, callback) {
			const connected = this.#connectState === "connected";
			const packet = normalizeSend(connected, buffer, offset, length, port, address, callback);
			this.#health();
			this.#ensure();
			if (this.#bindState === "unbound") this.bind({
				port: 0,
				exclusive: true
			});
			const send = () => {
				const afterLookup = (error, ip) => {
					if (this.#closed) return;
					if (error) {
						queueMicrotask(() => {
							if (packet.callback) packet.callback(error, 0);
							else this.emit("error", error);
						});
						return;
					}
					let id;
					try {
						if (!connected) this.#checkBlocked(ip);
						if (packet.callback) {
							id = this.#allocate();
							this.#sends.set(id, packet.callback);
						}
						callHost(() => this.#ensure().send(packet.data, connected ? void 0 : packet.port, connected ? void 0 : ip, id), fromHost);
					} catch (failure) {
						if (id !== void 0) this.#sends.delete(id);
						if (packet.callback) queueMicrotask(() => packet.callback(failure, 0));
					}
				};
				if (connected) afterLookup(null, "");
				else this.#lookup(packet.address, afterLookup);
			};
			if (this.#bindState !== "bound") this.#enqueue(send);
			else send();
		}
		sendto(buffer, offset, length, port, address, callback) {
			validateNumber(offset, "offset");
			validateNumber(length, "length");
			validateNumber(port, "port");
			validateString(address, "address");
			this.send(buffer, offset, length, port, address, callback);
		}
		close(callback) {
			if (typeof callback === "function") this.on("close", callback);
			if (this.#queue) {
				this.#queue.push(() => this.close());
				return this;
			}
			this.#health();
			this.#handle?.close();
			this.#handle?.[Symbol.dispose]();
			this.#handle = void 0;
			this.#closed = true;
			this.#lookups.clear();
			this.#removeAbort?.();
			if (this.#sends.size === 0) this.#finishClose();
			return this;
		}
		#finishClose() {
			if (this.#listener !== void 0) listeners.delete(this.#listener);
			queueMicrotask(() => this.emit("close"));
		}
		async [Symbol.asyncDispose]() {
			if (this.#closed) return;
			await new Promise((resolve) => this.close(resolve));
		}
		address() {
			this.#health();
			return callHost(() => this.#ensure().address(false), fromHost);
		}
		remoteAddress() {
			this.#health();
			if (this.#connectState !== "connected") throw notConnected();
			return callHost(() => this.#ensure().address(true), fromHost);
		}
		#option(option) {
			callHost(() => this.#ensure().setOption(option), fromHost);
		}
		#query(query) {
			return callHost(() => this.#ensure().query(query), fromHost);
		}
		setBroadcast(flag) {
			this.#option({
				tag: "broadcast",
				val: !!flag
			});
		}
		setTTL(ttl) {
			validateNumber(ttl, "ttl");
			this.#option({
				tag: "ttl",
				val: ttl
			});
			return ttl;
		}
		setMulticastTTL(ttl) {
			validateNumber(ttl, "ttl");
			this.#option({
				tag: "multicast-ttl",
				val: ttl
			});
			return ttl;
		}
		setMulticastLoopback(flag) {
			this.#option({
				tag: "multicast-loopback",
				val: !!flag
			});
			return flag;
		}
		setMulticastInterface(address) {
			this.#health();
			validateString(address, "interfaceAddress");
			this.#option({
				tag: "multicast-interface",
				val: address
			});
		}
		#membership(action, group, source, iface) {
			this.#health();
			if (source !== void 0) {
				validateString(source, "sourceAddress");
				validateString(group, "groupAddress");
			} else if (!group) throw socketError("ERR_MISSING_ARGS", "The \"multicastAddress\" argument must be specified");
			validateString(group, "multicastAddress");
			if (iface !== void 0) validateString(iface, "interfaceAddress");
			callHost(() => this.#ensure().membership(action, group, source, iface), fromHost);
		}
		addMembership(group, iface) {
			this.#membership("add", group, void 0, iface);
		}
		dropMembership(group, iface) {
			this.#membership("drop", group, void 0, iface);
		}
		addSourceSpecificMembership(source, group, iface) {
			validateString(source, "sourceAddress");
			this.#membership("add-source", group, source, iface);
		}
		dropSourceSpecificMembership(source, group, iface) {
			validateString(source, "sourceAddress");
			this.#membership("drop-source", group, source, iface);
		}
		#buffer(size, tag) {
			if (size !== size >>> 0) throw socketError("ERR_SOCKET_BAD_BUFFER_SIZE", "Buffer size must be a positive integer");
			this.#option({
				tag,
				val: size
			});
		}
		setRecvBufferSize(size) {
			this.#buffer(size, "recv-buffer");
		}
		setSendBufferSize(size) {
			this.#buffer(size, "send-buffer");
		}
		getRecvBufferSize() {
			return this.#query("recv-buffer");
		}
		getSendBufferSize() {
			return this.#query("send-buffer");
		}
		getSendQueueSize() {
			return this.#query("send-queue-size");
		}
		getSendQueueCount() {
			return this.#query("send-queue-count");
		}
		ref() {
			this.#ref = true;
			this.#handle?.setRef(true);
			return this;
		}
		unref() {
			this.#ref = false;
			this.#handle?.setRef(false);
			return this;
		}
		_healthCheck() {
			return deprecated("dgram.Socket._healthCheck()");
		}
		_stopReceiving() {
			return deprecated("dgram.Socket._stopReceiving()");
		}
	}
	for (const name of Reflect.ownKeys(Socket.prototype)) if (name !== "constructor") Object.defineProperty(Socket.prototype, name, { enumerable: true });
	for (const name of [
		"_handle",
		"_receiving",
		"_bindState",
		"_queue",
		"_reuseAddr"
	]) Object.defineProperty(Socket.prototype, name, {
		get: () => deprecated(`dgram.Socket.${name}`),
		set: () => deprecated(`dgram.Socket.${name}`)
	});
	function createSocket(type, listener) {
		return new Socket(type, listener);
	}
	function _createSocketHandle() {
		return deprecated("dgram._createSocketHandle()");
	}
	return {
		dgram: {
			_createSocketHandle,
			createSocket,
			Socket
		},
		dgramCallbacks
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dgram.js
const { dgram, dgramCallbacks } = createDgram(dgram_host_exports);
const { Socket, createSocket, _createSocketHandle } = dgram;
//#endregion
export { Socket, _createSocketHandle, createSocket, dgram as default, dgramCallbacks };
