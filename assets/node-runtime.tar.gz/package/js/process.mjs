const env = new Proxy(Object.create(null), {
	get: (target, key) => typeof key === "string" ? target[key] : void 0,
	set: (target, key, value) => {
		if (typeof key !== "string") return false;
		target[key] = String(value);
		return true;
	},
	deleteProperty: (target, key) => {
		delete target[key];
		return true;
	},
	ownKeys: (target) => Reflect.ownKeys(target),
	getOwnPropertyDescriptor: (target, key) => {
		if (!Object.hasOwn(target, key)) return void 0;
		return {
			value: target[key],
			writable: true,
			enumerable: true,
			configurable: true
		};
	}
});
const argv = [];
const argv0 = "hibana";
const execArgv = [];
const execPath = "/";
const versions = Object.freeze({
	hibana: "wasm",
	node: "24.12.0"
});
const version = "v24.12.0";
const platform = "linux";
const arch = "wasm32";
const browser = false;
const pid = 1;
const ppid = 0;
const title = "hibana";
const features = Object.freeze({
	tls: true,
	tls_alpn: true,
	inspector: false
});
const release = Object.freeze({ name: "hibana" });
let exitCode;
let directory = "/bundle";
const cwd = () => directory;
function chdir(next) {
	if (typeof next !== "string" || !next.startsWith("/")) throw Object.assign(/* @__PURE__ */ new Error("directory must be an absolute path"), { code: "ERR_INVALID_ARG_TYPE" });
	directory = next;
}
function nextTick(callback, ...args) {
	if (typeof callback !== "function") throw new TypeError("callback must be a function");
	queueMicrotask(() => callback(...args));
}
function lineStream(prefix) {
	let pending = "";
	const flush = () => {
		if (!pending) return;
		console.log(prefix + pending);
		pending = "";
	};
	return {
		isTTY: false,
		write(chunk) {
			pending += typeof chunk === "string" ? chunk : String(chunk);
			let newline = pending.indexOf("\n");
			while (newline !== -1) {
				console.log(prefix + pending.slice(0, newline));
				pending = pending.slice(newline + 1);
				newline = pending.indexOf("\n");
			}
			queueMicrotask(flush);
			return true;
		},
		end() {
			flush();
		}
	};
}
const stdout = lineStream("stdout: ");
const stderr = lineStream("stderr: ");
const stdin = {
	isTTY: false,
	read() {
		return null;
	}
};
let started;
function clock() {
	const now = globalThis.performance?.now;
	return typeof now === "function" ? now.call(globalThis.performance) : Date.now();
}
function elapsed() {
	const now = clock();
	if (started === void 0) started = now;
	const millis = Math.max(0, now - started);
	const seconds = Math.floor(millis / 1e3);
	return [seconds, Math.floor((millis - seconds * 1e3) * 1e6)];
}
function hrtime(previous) {
	const [seconds, nanoseconds] = elapsed();
	if (previous === void 0) return [seconds, nanoseconds];
	if (!Array.isArray(previous) || previous.length !== 2) throw Object.assign(/* @__PURE__ */ new TypeError("time must be an array of length 2"), { code: "ERR_INVALID_ARG_TYPE" });
	let sec = seconds - previous[0];
	let nsec = nanoseconds - previous[1];
	if (nsec < 0) {
		sec -= 1;
		nsec += 1e9;
	}
	return [sec, nsec];
}
hrtime.bigint = () => {
	const [seconds, nanoseconds] = elapsed();
	return BigInt(seconds) * 1000000000n + BigInt(nanoseconds);
};
function memoryUsage() {
	const used = globalThis.performance?.memory?.usedJSHeapSize ?? 0;
	return {
		rss: used,
		heapTotal: used,
		heapUsed: used,
		external: 0,
		arrayBuffers: 0
	};
}
memoryUsage.rss = () => memoryUsage().rss;
function uptime() {
	return elapsed()[0] + elapsed()[1] / 1e9;
}
function constrainedMemory() {
	return globalThis.performance?.memory?.jsHeapSizeLimit ?? void 0;
}
function availableMemory() {
	const limit = constrainedMemory();
	return limit === void 0 ? void 0 : Math.max(0, limit - memoryUsage().rss);
}
function exit(code) {
	if (code !== void 0) exitCode = code;
	throw Object.assign(/* @__PURE__ */ new Error("process.exit is not available in a Worker"), { code: "ERR_WORKER_NOT_SUPPORTED" });
}
function getBuiltinModule(name) {
	if (name === "process" || name === "node:process") return process;
}
const process = {
	env,
	argv,
	argv0,
	execArgv,
	execPath: "/",
	versions,
	version,
	platform,
	arch,
	browser: false,
	pid: 1,
	ppid: 0,
	title,
	features,
	release,
	cwd,
	chdir,
	nextTick,
	stdout,
	stderr,
	stdin,
	hrtime,
	memoryUsage,
	uptime,
	constrainedMemory,
	availableMemory,
	exit,
	getBuiltinModule,
	get exitCode() {
		return exitCode;
	},
	set exitCode(value) {
		exitCode = value;
	}
};
//#endregion
export { arch, argv, argv0, availableMemory, browser, chdir, constrainedMemory, cwd, process as default, env, execArgv, execPath, exit, exitCode, features, getBuiltinModule, hrtime, memoryUsage, nextTick, pid, platform, ppid, release, stderr, stdin, stdout, title, uptime, version, versions };
