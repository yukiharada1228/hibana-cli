import { AsyncLocalStorage } from "./async_hooks.mjs";
import { Buffer } from "./buffer.mjs";
import process from "./process.mjs";
import { clearImmediate, setImmediate } from "./timers.mjs";
//#region src/globals.mjs
for (const name of ["setTimeout", "setInterval"]) {
	const schedule = globalThis[name];
	globalThis[name] = (callback, delay, ...args) => schedule(AsyncLocalStorage.bind(callback), delay, ...args);
}
globalThis.Buffer ??= Buffer;
globalThis.process ??= process;
globalThis.global ??= globalThis;
globalThis.setImmediate ??= setImmediate;
globalThis.clearImmediate ??= clearImmediate;
//#endregion
