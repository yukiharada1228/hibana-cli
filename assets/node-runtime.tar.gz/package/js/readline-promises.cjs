module.exports = require('./readline-promises.mjs').default;
