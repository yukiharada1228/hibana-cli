module.exports = require('./repl.mjs').default;
