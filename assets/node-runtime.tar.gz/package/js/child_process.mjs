import { v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { Buffer } from "./buffer.mjs";
import { n as denyThrow, t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/child-process-host.js
/**
* The default adapter intentionally grants no process-spawning capability.
* Applications must explicitly provide a host implementation, such as the
* separately exported Node adapter, when they instantiate or map a component.
*/
const spawnSync$1 = denyThrow("ERR_JCO_CHILD_PROCESS_ADAPTER_REQUIRED", adapterRequiredMessage("node:child_process"));
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/child-process/core.js
/**
* Portable `node:child_process` core over a synchronous WIT spawn host.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/child_process.js (MIT
* license): the spawnSync/execFileSync/execSync flow, default maxBuffer and
* killSignal, and the "Command failed" error shape. Argument validation and
* stdio normalization are rewritten for a typed host provider; asynchronous
* entry points and ChildProcess are refused rather than emulated.
*/
function unsupported(api) {
	throw unsupportedNodeApi(api, "the Jco child_process adapter does not implement it");
}
function requireString(value, name) {
	if (typeof value !== "string") throw new TypeError(`The \"${name}\" argument must be of type string. Received ${String(value)}`);
	if (value.length === 0) throw new TypeError(`The argument '${name}' cannot be empty. Received ''`);
}
function normalizeArgs(command, argsOrOptions, maybeOptions) {
	requireString(command, "file");
	let args = [];
	let options = {};
	if (Array.isArray(argsOrOptions)) {
		args = argsOrOptions;
		options = maybeOptions ?? {};
	} else if (argsOrOptions !== void 0) {
		if (argsOrOptions === null || typeof argsOrOptions !== "object") throw new TypeError("The \"options\" argument must be of type object");
		options = argsOrOptions;
	}
	for (const arg of args) requireString(arg, "args");
	return {
		args: [...args],
		options
	};
}
function normalizeStdio(stdio) {
	if (stdio === void 0 || stdio === "pipe") return;
	if (typeof stdio === "string") {
		if (stdio !== "ignore" && stdio !== "inherit") throw new TypeError(`Invalid stdio option: ${stdio}`);
		return [
			stdio,
			stdio,
			stdio
		];
	}
	if (!Array.isArray(stdio) || stdio.length > 3) unsupported("child_process stdio descriptors");
	const values = [...stdio];
	for (const value of values) if (value !== "pipe" && value !== "ignore" && value !== "inherit") unsupported("child_process stdio descriptors");
	while (values.length < 3) values.push("pipe");
	return values;
}
function toBytes(input) {
	if (input === void 0) return;
	if (typeof input === "string") return Buffer.from(input);
	if (ArrayBuffer.isView(input)) return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
	throw new TypeError("The \"options.input\" property must be of type string or an ArrayBufferView");
}
function hostOptions(options) {
	const timeout = options.timeout ?? 0;
	const maxBuffer = options.maxBuffer ?? 1048576;
	if (!Number.isSafeInteger(timeout) || timeout < 0) throw new RangeError("The value of \"timeout\" is out of range");
	if (!Number.isSafeInteger(maxBuffer) || maxBuffer < 0) throw new RangeError("The value of \"maxBuffer\" is out of range");
	const cwd = options.cwd === void 0 ? void 0 : String(options.cwd);
	const env = options.env ? Object.entries(options.env).flatMap(([key, value]) => value === void 0 ? [] : [[key, String(value)]]) : void 0;
	const killSignal = options.killSignal === void 0 ? "SIGTERM" : String(options.killSignal);
	return {
		cwd,
		cwdIsUrl: typeof URL !== "undefined" && options.cwd instanceof URL,
		env,
		input: toBytes(options.input),
		timeout: BigInt(timeout),
		killSignal,
		maxBuffer: BigInt(maxBuffer),
		shell: options.shell === true ? "" : typeof options.shell === "string" ? options.shell : void 0,
		stdio: normalizeStdio(options.stdio),
		windowsHide: options.windowsHide ?? false,
		windowsVerbatimArguments: options.windowsVerbatimArguments ?? false,
		uid: options.uid,
		gid: options.gid
	};
}
function processError(value, output) {
	const error = new Error(value.message);
	error.name = value.name;
	Object.assign(error, value, output && {
		status: output.status ?? null,
		signal: output.signal ?? null,
		stdout: output.stdout ? Buffer.from(output.stdout) : null,
		stderr: output.stderr ? Buffer.from(output.stderr) : null,
		output: [
			null,
			output.stdout ? Buffer.from(output.stdout) : null,
			output.stderr ? Buffer.from(output.stderr) : null
		]
	});
	return error;
}
function decode(data, encoding) {
	if (data === void 0) return null;
	const buffer = Buffer.from(data);
	return encoding === void 0 || encoding === null || encoding === "buffer" ? buffer : buffer.toString(encoding);
}
function completionError(output, command) {
	if (output.error) return processError(output.error, output);
	if ((output.status ?? 0) === 0 && output.signal === void 0) return;
	const error = /* @__PURE__ */ new Error(`Command failed${output.status === void 0 ? ` due to ${output.signal}` : ` with exit code ${output.status}`}: ${command}`);
	return Object.assign(error, {
		code: output.status ?? null,
		killed: output.signal !== void 0,
		signal: output.signal ?? null,
		status: output.status ?? null,
		stdout: output.stdout ? Buffer.from(output.stdout) : null,
		stderr: output.stderr ? Buffer.from(output.stderr) : null
	});
}
function createChildProcess(host) {
	function spawnSync(command, argsOrOptions, maybeOptions) {
		const { args, options } = normalizeArgs(command, argsOrOptions, maybeOptions);
		const output = host.spawnSync(command, args, hostOptions(options));
		const encoding = options.encoding;
		const stdout = decode(output.stdout, encoding);
		const stderr = decode(output.stderr, encoding);
		const result = {
			pid: output.pid ?? 0,
			output: [
				null,
				stdout,
				stderr
			],
			stdout,
			stderr,
			status: output.status ?? null,
			signal: output.signal ?? null
		};
		if (output.error) result.error = processError(output.error);
		return result;
	}
	function execFileSync(file, argsOrOptions, maybeOptions) {
		const { args, options } = normalizeArgs(file, argsOrOptions, maybeOptions);
		const output = host.spawnSync(file, args, hostOptions(options));
		const error = completionError(output, [file, ...args].join(" "));
		if (error) throw error;
		return decode(output.stdout, options.encoding) ?? (options.encoding ? "" : Buffer.alloc(0));
	}
	function execSync(command, options = {}) {
		requireString(command, "command");
		return execFileSync(command, {
			...options,
			shell: options.shell ?? true
		});
	}
	class ChildProcess {
		constructor() {
			unsupported("child_process.ChildProcess");
		}
	}
	function spawn(command, argsOrOptions, maybeOptions) {
		unsupported("child_process.spawn and asynchronous process lifecycle events");
	}
	function execFile(file, argsOrOptions, optionsOrCallback, maybeCallback) {
		unsupported("child_process.execFile callbacks");
	}
	function exec(command, optionsOrCallback, maybeCallback) {
		unsupported("child_process.exec callbacks");
	}
	function fork() {
		return unsupported("child_process.fork and IPC");
	}
	return {
		ChildProcess,
		exec,
		execFile,
		execFileSync,
		execSync,
		fork,
		spawn,
		spawnSync
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/child-process.js
const childProcess = createChildProcess({ spawnSync: spawnSync$1 });
const ChildProcess = childProcess.ChildProcess;
const exec = childProcess.exec;
const execFile = childProcess.execFile;
const execFileSync = childProcess.execFileSync;
const execSync = childProcess.execSync;
const fork = childProcess.fork;
const spawn = childProcess.spawn;
const spawnSync = childProcess.spawnSync;
//#endregion
export { ChildProcess, childProcess as default, exec, execFile, execFileSync, execSync, fork, spawn, spawnSync };
