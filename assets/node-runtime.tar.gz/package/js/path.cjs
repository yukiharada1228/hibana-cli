module.exports = require('./path.mjs').default;
