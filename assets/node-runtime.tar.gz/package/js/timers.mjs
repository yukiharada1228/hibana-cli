import timers_promises_default from "./timers-promises.mjs";
//#region src/timers.mjs
var Timer = class {
	#id;
	#repeat;
	#callback;
	#delay;
	#args;
	#refed = true;
	constructor(repeat, callback, delay, args) {
		this.#repeat = repeat;
		this.#callback = callback;
		this.#delay = delay;
		this.#args = args;
		this.#arm();
	}
	#arm() {
		const invoke = () => this.#callback(...this.#args);
		this.#id = this.#repeat ? globalThis.setInterval(invoke, this.#delay) : globalThis.setTimeout(invoke, this.#delay);
	}
	ref() {
		this.#refed = true;
		return this;
	}
	unref() {
		this.#refed = false;
		return this;
	}
	hasRef() {
		return this.#refed;
	}
	refresh() {
		this.close();
		this.#arm();
		return this;
	}
	close() {
		if (this.#repeat) globalThis.clearInterval(this.#id);
		else globalThis.clearTimeout(this.#id);
		return this;
	}
	[Symbol.toPrimitive]() {
		return this.#id;
	}
};
function start(repeat, callback, delay, args) {
	if (typeof callback !== "function") throw Object.assign(/* @__PURE__ */ new TypeError("The \"callback\" argument must be of type function"), { code: "ERR_INVALID_ARG_TYPE" });
	return new Timer(repeat, callback, delay, args);
}
const setTimeout = (callback, delay, ...args) => start(false, callback, delay, args);
const setInterval = (callback, delay, ...args) => start(true, callback, delay, args);
const setImmediate = (callback, ...args) => start(false, callback, 0, args);
function clearTimeout(handle) {
	if (handle instanceof Timer) handle.close();
	else globalThis.clearTimeout(handle);
}
function clearInterval(handle) {
	if (handle instanceof Timer) handle.close();
	else globalThis.clearInterval(handle);
}
const clearImmediate = clearTimeout;
var timers_default = {
	setTimeout,
	clearTimeout,
	setInterval,
	clearInterval,
	setImmediate,
	clearImmediate,
	promises: timers_promises_default
};
//#endregion
export { clearImmediate, clearInterval, clearTimeout, timers_default as default, timers_promises_default as promises, setImmediate, setInterval, setTimeout };
