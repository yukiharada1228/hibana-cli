import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType$1 } from "./chunks/core-DGqXzKN-.mjs";
import { r as denyVariant } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { t as EventEmitter } from "./chunks/event-emitter-D4b0qsct.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector-host.js
var inspector_host_exports = /* @__PURE__ */ __exportAll({
	close: () => close$1,
	consoleCall: () => consoleCall,
	default: () => inspector_host_default,
	emit: () => emit,
	open: () => open$1,
	putNetworkResource: () => putNetworkResource,
	sessionConnect: () => sessionConnect,
	sessionDisconnect: () => sessionDisconnect,
	sessionPost: () => sessionPost,
	url: () => url$1,
	waitForDebugger: () => waitForDebugger$1
});
/**
* The default adapter grants no inspector capability.
*
* The inspector exposes and drives the running isolate over a debugging protocol, so declaring the
* WIT import must not, on its own, hand that power to a component. Applications opt in by mapping
* `jco:node/inspector@0.1.0` to a host implementation such as `inspector-host-node.ts`.
*
* The refusal is thrown in the shape of the WIT `variant error` `denied` case, so the guest reports
* it the same way it reports any other host failure -- as `ERR_JCO_INSPECTOR_ADAPTER_REQUIRED`.
*/
const denied = denyVariant("jco:node/inspector@0.1.0");
const open$1 = denied;
const close$1 = denied;
const url$1 = denied;
const waitForDebugger$1 = denied;
const consoleCall = denied;
const sessionConnect = denied;
const sessionPost = denied;
const sessionDisconnect = denied;
const emit = denied;
const putNetworkResource = denied;
var inspector_host_default = {
	open: open$1,
	close: close$1,
	url: url$1,
	waitForDebugger: waitForDebugger$1,
	consoleCall,
	sessionConnect,
	sessionPost,
	sessionDisconnect,
	emit,
	putNetworkResource
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/errors.js
/**
* Node-faithful errors for the `node:inspector` shim.
*
* State errors (`ERR_INSPECTOR_*`) and argument errors (`ERR_INVALID_ARG_TYPE`) are raised
* guest-side before any host call, so their codes and messages match Node's exactly without a
* round trip. Protocol errors (`ERR_INSPECTOR_COMMAND`) and other host failures are reconstructed
* from the host's `failure` record. `ERR_JCO_INSPECTOR_ADAPTER_REQUIRED` reports the deny-by-default
* adapter.
*
* The coded-error factory and the `Received ...` clause of `ERR_INVALID_ARG_TYPE` are the shared
* ones in `../errors/core.js` (which follow nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/errors.js, MIT license). The
* `ERR_INSPECTOR_*` messages below are verbatim from the same file.
*/
function coded(code, message) {
	return codedError(new Error(message), code);
}
function notConnected() {
	return coded("ERR_INSPECTOR_NOT_CONNECTED", "Session is not connected");
}
function alreadyConnected() {
	return coded("ERR_INSPECTOR_ALREADY_CONNECTED", "The inspector session is already connected");
}
function adapterRequired() {
	return coded("ERR_JCO_INSPECTOR_ADAPTER_REQUIRED", "node:inspector requires an application-provided host adapter; map jco:node/inspector@0.1.0 to one to grant it");
}
/**
* Node's `ERR_INVALID_ARG_TYPE` for a single expected type.
*
* @param name - the argument name, as Node names it
* @param expected - the expected type word (`string`, `object`, `function`)
* @param actual - the value received
*/
function invalidArgType(name, expected, actual) {
	return invalidArgType$1(name, expected, actual);
}
/** Reconstruct the `Error` a protocol/host failure should surface as, preserving Node's code. */
function fromFailure(failure) {
	return coded(failure.code, failure.message);
}
/**
* Turn a thrown host `error` variant into the `Error` the guest should surface.
*
* The deny adapter and the Node adapter both throw the WIT variant shape; jco lowers it back to the
* same object on the guest side.
*/
function fromHostError(error) {
	if (isHostError(error)) switch (error.tag) {
		case "denied": return adapterRequired();
		case "unavailable": return coded("ERR_JCO_INSPECTOR_UNAVAILABLE", error.val);
		case "no-such-session": return notConnected();
		case "failed": return fromFailure(error.val);
	}
	if (error instanceof Error) return error;
	return coded("ERR_JCO_INSPECTOR_HOST", String(error));
}
function isHostError(value) {
	return typeof value === "object" && value !== null && "tag" in value && typeof value.tag === "string";
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/broadcast.js
/**
* The experimental broadcast namespaces: `inspector.Network`, `inspector.DOMStorage`, and
* `inspector.NetworkResources`.
*
* The `Network`/`DOMStorage` methods each take one `params` object and forward it to the host as a
* CDP event through `emit(target, event, params-json)`. `NetworkResources.put(url, data)` registers
* a resource the inspector can serve.
*
* Validation matches Node: `params` defaults to `{}` when omitted, but an explicit non-object
* (including `null` and arrays) throws `ERR_INVALID_ARG_TYPE`.
*/
const NETWORK_EVENTS = [
	"dataReceived",
	"dataSent",
	"loadingFailed",
	"loadingFinished",
	"requestWillBeSent",
	"responseReceived",
	"webSocketClosed",
	"webSocketCreated",
	"webSocketHandshakeResponseReceived"
];
const DOM_STORAGE_EVENTS = [
	"domStorageItemAdded",
	"domStorageItemRemoved",
	"domStorageItemUpdated",
	"domStorageItemsCleared",
	"registerStorage"
];
/** Node's `params` default-and-validate: `undefined` -> `{}`, anything non-object-shaped throws. */
function normalizeParams(params) {
	if (params === void 0) return {};
	if (params === null || typeof params !== "object" || Array.isArray(params)) throw invalidArgType("params", "object", params);
	return params;
}
function buildNamespace(host, target, events) {
	const namespace = {};
	for (const event of events) namespace[event] = (params) => {
		host.emit(target, event, JSON.stringify(normalizeParams(params)));
	};
	return namespace;
}
function createNetwork(host) {
	return buildNamespace(host, "network", NETWORK_EVENTS);
}
function createDomStorage(host) {
	return buildNamespace(host, "dom-storage", DOM_STORAGE_EVENTS);
}
function createNetworkResources(host) {
	return { put(url, data) {
		host.putNetworkResource(String(url), String(data));
	} };
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/callbacks.js
/**
* The guest-exported `jco:node/inspector-callbacks@0.1.0` interface: the channel the host uses to
* re-enter the component when a protocol response or a notification arrives.
*
* A component cannot implement a resource declared in an *imported* interface -- its methods would
* run host-side. So the callback resources are exported here, the guest owns their implementations,
* and the host redeems a `u32` id (passed on the matching import call) for an owned handle through
* the `take-*` functions before invoking a method.
*
* There is one registry per component. `session.ts` registers callbacks into it and passes their
* ids to the host; the exported functions hand the resources back to the host on demand.
*/
/** Reconstruct the `(err, result)` pair from the JSON the host delivers. */
function parseResponse(errorJson, resultJson) {
	if (errorJson !== void 0) {
		const parsed = JSON.parse(errorJson);
		const message = typeof parsed.message === "string" ? parsed.message : String(errorJson);
		const error = new Error(message);
		if (typeof parsed.code === "string") error.code = parsed.code;
		return {
			error,
			result: void 0
		};
	}
	return {
		error: null,
		result: resultJson !== void 0 ? JSON.parse(resultJson) : void 0
	};
}
/**
* One-shot response to a `session.post`. The host redeems it, calls `done` exactly once, then drops
* it. Reconstructing the error guest-side keeps `ERR_INSPECTOR_COMMAND` faithful.
*/
var PostCallback = class {
	#fn;
	constructor(fn) {
		this.#fn = fn;
	}
	done(errorJson, resultJson) {
		const { error, result } = parseResponse(errorJson, resultJson);
		this.#fn(error, result);
	}
};
/**
* The long-lived channel for one connected session's notifications. The host redeems it once at
* connect, keeps the handle, and calls `notify` per CDP notification until it drops the handle at
* disconnect.
*/
var NotificationListener = class {
	#fn;
	constructor(fn) {
		this.#fn = fn;
	}
	notify(method, paramsJson) {
		this.#fn(method, paramsJson);
	}
};
/**
* The per-component callback registry shared between the session shim and the exported interface.
*
* Ids are `u32`s from a single counter; a given id is only ever one kind, so the two maps never
* collide. `register*` returns the id to pass to the host; `take*` hands the resource to the host
* and removes it (one-shot for posts; the host owns the listener handle after taking it).
*/
var CallbackRegistry = class {
	#nextId = 1;
	#posts = /* @__PURE__ */ new Map();
	#listeners = /* @__PURE__ */ new Map();
	#allocate() {
		let id = this.#nextId;
		this.#nextId = id >= 4294967295 ? 1 : id + 1;
		while (this.#posts.has(id) || this.#listeners.has(id)) {
			id = this.#nextId;
			this.#nextId = id >= 4294967295 ? 1 : id + 1;
		}
		return id;
	}
	registerPost(fn) {
		const id = this.#allocate();
		this.#posts.set(id, new PostCallback(fn));
		return id;
	}
	registerListener(fn) {
		const id = this.#allocate();
		this.#listeners.set(id, new NotificationListener(fn));
		return id;
	}
	/** Drop a pending registration the host never took, e.g. when the import call threw. */
	releasePost(id) {
		this.#posts.delete(id);
	}
	releaseListener(id) {
		this.#listeners.delete(id);
	}
	takePost(id) {
		const callback = this.#posts.get(id);
		this.#posts.delete(id);
		return callback;
	}
	takeListener(id) {
		const listener = this.#listeners.get(id);
		this.#listeners.delete(id);
		return listener;
	}
};
/** Build the exported interface object over a registry. */
function createInspectorCallbacks(registry) {
	return {
		PostCallback,
		NotificationListener,
		takePostCallback: (id) => registry.takePost(id),
		takeNotificationListener: (id) => registry.takeListener(id)
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/console.js
/**
* `inspector.console` -- the console whose output is routed to the connected inspector front-end
* rather than to stdout.
*
* Every method forwards to the host as `console-call(context, method, args-json)`. Arguments are
* JSON-encoded, which is lossy for functions, symbols, cycles, and `undefined`; this is best-effort
* and documented. The main object also carries `context(name)`, which returns a fresh console bound
* to that named context.
*
* Node quirk reproduced faithfully: the main console spells the method `dirxml`, while the console
* returned by `context()` spells it `dirXml`, and the context console has no nested `context`.
*/
/** Method names on `inspector.console` (besides `context`). */
const MAIN_METHODS = [
	"assert",
	"clear",
	"count",
	"countReset",
	"debug",
	"dir",
	"dirxml",
	"error",
	"group",
	"groupCollapsed",
	"groupEnd",
	"info",
	"log",
	"profile",
	"profileEnd",
	"table",
	"time",
	"timeEnd",
	"timeLog",
	"timeStamp",
	"trace",
	"warn"
];
/** Method names on the console returned by `context()` -- note `dirXml`, and no `context`. */
const CONTEXT_METHODS = MAIN_METHODS.map((name) => name === "dirxml" ? "dirXml" : name);
/**
* JSON-encode a console argument list without throwing. Values JSON cannot carry become `null`,
* matching how JSON.stringify already drops functions and `undefined`; a cyclic structure falls
* back to an empty list so a stray `console.log` never breaks the caller.
*/
function encodeArgs(args) {
	try {
		return JSON.stringify(args, (_key, value) => typeof value === "bigint" ? `${value}n` : value) ?? "[]";
	} catch {
		return "[]";
	}
}
function buildContext(host, context, methods) {
	const target = {};
	for (const method of methods) target[method] = (...args) => {
		host.consoleCall(context, method, encodeArgs(args));
	};
	return target;
}
/** Build `inspector.console`, forwarding to the host. */
function createConsole(host) {
	const base = buildContext(host, void 0, MAIN_METHODS);
	base.context = (name) => buildContext(host, name, CONTEXT_METHODS);
	return base;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/session.js
/**
* `inspector.Session` and `inspector/promises.Session`.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/inspector.js and
* lib/inspector/promises.js (MIT license). The native `Connection` and
* message-id map are replaced by a typed WIT host and a guest-exported
* callback registry; argument validation keeps Node's order.
*
* `Session` extends jco-std's internal `EventEmitter` (shim code cannot pull one from `node:events`;
* see `../internal/event-emitter.ts`). Session ids are guest-allocated `u32`s, so `new Session()`
* touches no host state -- state lives here and only `connect`/`post`/`disconnect` reach the host.
*
* Argument validation reproduces Node's, and in Node's order: `method`, then `params`, then
* `callback`, all *before* the connection check, so an ill-typed argument on a disconnected session
* still reports `ERR_INVALID_ARG_TYPE` rather than `ERR_INSPECTOR_NOT_CONNECTED`.
*
* Notifications arrive through a `notification-listener` resource registered at connect: the host
* calls it per CDP notification, and the session re-emits each as `inspectorNotification` and as an
* event named for the method, both carrying the whole `{ method, params }` message, exactly as Node
* does.
*/
function validatePost(method, paramsOrCallback, maybeCallback) {
	if (typeof method !== "string") throw invalidArgType("method", "string", method);
	let params;
	let callback;
	if (typeof paramsOrCallback === "function") {
		callback = paramsOrCallback;
		params = void 0;
	} else {
		params = paramsOrCallback;
		callback = maybeCallback;
	}
	if (params !== void 0 && params !== null && (typeof params !== "object" || Array.isArray(params))) throw invalidArgType("params", "object", params);
	if (callback !== void 0 && typeof callback !== "function") throw invalidArgType("callback", "function", callback);
	return {
		method,
		params: params ?? void 0,
		callback
	};
}
/** Invoke a `post` callback with a synchronously-resolved host response. */
function deliverResponse(response, callback) {
	if (callback === void 0) return;
	if (response.tag === "failed") callback(fromFailure(response.val), void 0);
	else callback(null, response.val === void 0 ? {} : JSON.parse(response.val));
}
function createSessions(host, registry) {
	let nextSessionId = 1;
	class Session extends EventEmitter {
		#id = nextSessionId++;
		#connected = false;
		#connect(kind) {
			if (this.#connected) throw alreadyConnected();
			const listenerId = registry.registerListener((method, paramsJson) => this.#onNotification(method, paramsJson));
			try {
				host.sessionConnect(this.#id, kind, listenerId);
			} catch (error) {
				registry.releaseListener(listenerId);
				throw fromHostError(error);
			}
			this.#connected = true;
		}
		connect() {
			this.#connect("local");
		}
		connectToMainThread() {
			this.#connect("main-thread");
		}
		disconnect() {
			if (!this.#connected) return;
			this.#connected = false;
			try {
				host.sessionDisconnect(this.#id);
			} catch (error) {
				throw fromHostError(error);
			}
		}
		post(method, paramsOrCallback, maybeCallback) {
			const { method: name, params, callback } = validatePost(method, paramsOrCallback, maybeCallback);
			if (!this.#connected) throw notConnected();
			const paramsJson = params === void 0 ? void 0 : JSON.stringify(params);
			const callbackId = callback === void 0 ? void 0 : registry.registerPost(callback);
			let response;
			try {
				response = host.sessionPost(this.#id, name, paramsJson, callbackId);
			} catch (error) {
				if (callbackId !== void 0) registry.releasePost(callbackId);
				throw fromHostError(error);
			}
			if (response !== void 0) {
				if (callbackId !== void 0) registry.releasePost(callbackId);
				deliverResponse(response, callback);
			}
		}
		#onNotification(method, paramsJson) {
			const message = {
				method,
				params: paramsJson ? JSON.parse(paramsJson) : {}
			};
			this.emit("inspectorNotification", message);
			this.emit(method, message);
		}
	}
	class PromisesSession extends Session {
		post(method, params) {
			return new Promise((resolve, reject) => {
				try {
					super.post(method, params, (error, result) => error ? reject(error) : resolve(result));
				} catch (error) {
					reject(error);
				}
			});
		}
	}
	Object.defineProperty(PromisesSession.prototype.post, "length", { value: 3 });
	return {
		Session,
		PromisesSession
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector/core.js
/**
* Assembles the `node:inspector` surface over a host adapter.
*
* `createInspectorCore(host)` builds one core shared by both entry points: `node:inspector` and
* `node:inspector/promises` expose the same module members by identity and differ only in their
* `Session` class. The core also owns the callback registry the guest-exported callbacks interface
* hands back to the host.
*
* Inspector activation state (whether `open` has run, whether a client is attached) lives host-side,
* so `open`/`close`/`url`/`waitForDebugger` forward and let the host be the source of truth for
* `ERR_INSPECTOR_ALREADY_ACTIVATED` and `ERR_INSPECTOR_NOT_ACTIVE`.
*/
function createInspectorCore(host) {
	const registry = new CallbackRegistry();
	const { Session, PromisesSession } = createSessions(host, registry);
	function close() {
		try {
			host.close();
		} catch (error) {
			throw fromHostError(error);
		}
	}
	function open(port, host_, wait) {
		const portValue = typeof port === "number" && Number.isInteger(port) && port >= 0 ? port : void 0;
		const hostValue = typeof host_ === "string" ? host_ : void 0;
		try {
			host.open(portValue, hostValue, wait === true);
		} catch (error) {
			throw fromHostError(error);
		}
		const activation = Object.create(null);
		Object.defineProperty(activation, Symbol.dispose, {
			value: () => close(),
			enumerable: false
		});
		return activation;
	}
	function url() {
		try {
			return host.url();
		} catch (error) {
			throw fromHostError(error);
		}
	}
	function waitForDebugger() {
		try {
			host.waitForDebugger();
		} catch (error) {
			throw fromHostError(error);
		}
	}
	return {
		registry,
		open,
		close,
		url,
		waitForDebugger,
		console: createConsole(host),
		Session,
		PromisesSession,
		Network: createNetwork(host),
		DOMStorage: createDomStorage(host),
		NetworkResources: createNetworkResources(host)
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/inspector.js
/**
* `node:inspector` entry point.
*
* Host-backed, like `node:child_process` and `node:ffi`: the inspector is V8/host machinery WASI
* cannot express, so this imports the `jco:node/inspector@0.1.0` interface and builds the module
* surface over it. One core is created here and shared with `node:inspector/promises` so both
* expose the same module members by identity, differing only in their `Session` class.
*
* `inspectorCallbacks` is the guest-*exported* `jco:node/inspector-callbacks@0.1.0` interface, the
* channel the host uses to call back into the component. Jco's two-pass bundling adds it to the
* component's top-level exports; keeping it here means it shares the one callback registry the
* sessions register into.
*/
const core = createInspectorCore(inspector_host_exports);
const open = core.open;
const close = core.close;
const url = core.url;
const waitForDebugger = core.waitForDebugger;
const console = core.console;
const Session = core.Session;
const Network = core.Network;
const DOMStorage = core.DOMStorage;
const NetworkResources = core.NetworkResources;
const inspector = {
	open,
	close,
	url,
	waitForDebugger,
	console,
	Session,
	Network,
	DOMStorage,
	NetworkResources
};
/**
* The shared core, consumed only by `inspector-promises.ts` so the promises entry reuses this
* instance (and its callback registry) rather than building a second one.
*/
const __inspectorCore = core;
/** The guest-exported callbacks interface. Bundled into the component's top-level exports by Jco. */
const inspectorCallbacks = createInspectorCallbacks(core.registry);
//#endregion
export { DOMStorage, Network, NetworkResources, Session, __inspectorCore, close, console, inspector as default, inspectorCallbacks, open, url, waitForDebugger };
