module.exports = require('./punycode.mjs').default;
