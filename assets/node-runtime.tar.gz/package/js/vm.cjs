module.exports = require('./vm.mjs').default;
