module.exports = require('./perf_hooks.mjs').default;
