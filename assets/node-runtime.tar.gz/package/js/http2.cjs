module.exports = require('./http2.mjs').default;
