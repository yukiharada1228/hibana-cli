//#region src/stream-web.mjs
function present(name) {
	const value = globalThis[name];
	if (value !== void 0) return value;
	return function unavailable() {
		throw Object.assign(/* @__PURE__ */ new Error(`${name} is not provided by this engine`), { code: "ERR_NOT_SUPPORTED" });
	};
}
const ReadableStream = present("ReadableStream");
const ReadableStreamDefaultReader = present("ReadableStreamDefaultReader");
const ReadableStreamBYOBReader = present("ReadableStreamBYOBReader");
const ReadableStreamBYOBRequest = present("ReadableStreamBYOBRequest");
const ReadableStreamDefaultController = present("ReadableStreamDefaultController");
const ReadableByteStreamController = present("ReadableByteStreamController");
const WritableStream = present("WritableStream");
const WritableStreamDefaultWriter = present("WritableStreamDefaultWriter");
const WritableStreamDefaultController = present("WritableStreamDefaultController");
const TransformStream = present("TransformStream");
const TransformStreamDefaultController = present("TransformStreamDefaultController");
const ByteLengthQueuingStrategy = present("ByteLengthQueuingStrategy");
const CountQueuingStrategy = present("CountQueuingStrategy");
const CompressionStream = present("CompressionStream");
const DecompressionStream = present("DecompressionStream");
const TextEncoderStream = present("TextEncoderStream");
const TextDecoderStream = present("TextDecoderStream");
var stream_web_default = {
	ReadableStream,
	ReadableStreamDefaultReader,
	ReadableStreamBYOBReader,
	ReadableStreamBYOBRequest,
	ReadableStreamDefaultController,
	ReadableByteStreamController,
	WritableStream,
	WritableStreamDefaultWriter,
	WritableStreamDefaultController,
	TransformStream,
	TransformStreamDefaultController,
	ByteLengthQueuingStrategy,
	CountQueuingStrategy,
	CompressionStream,
	DecompressionStream,
	TextEncoderStream,
	TextDecoderStream
};
//#endregion
export { ByteLengthQueuingStrategy, CompressionStream, CountQueuingStrategy, DecompressionStream, ReadableByteStreamController, ReadableStream, ReadableStreamBYOBReader, ReadableStreamBYOBRequest, ReadableStreamDefaultController, ReadableStreamDefaultReader, TextDecoderStream, TextEncoderStream, TransformStream, TransformStreamDefaultController, WritableStream, WritableStreamDefaultController, WritableStreamDefaultWriter, stream_web_default as default };
