import { d as invalidArgType, g as outOfRange } from "./chunks/core-DGqXzKN-.mjs";
import { n as SocketAddress, t as BlockList } from "./chunks/block-list-BgxWsckK.mjs";
import { c as isIPv6, l as normalizeConnect, n as baseOptions, o as isIP, s as isIPv4, t as Socket, u as unsupported } from "./chunks/socket-DEcwU0em.mjs";
//#region ../../extensions/node-net/src/index.mjs
function connect(...args) {
	const { options, callback } = normalizeConnect(args);
	const streamOptions = Object.fromEntries(baseOptions.filter((key) => key in options).map((key) => [key, options[key]]));
	const socket = new Socket(streamOptions);
	return callback ? socket.connect(options, callback) : socket.connect(options);
}
const createConnection = connect;
function createServer() {
	unsupported("TCP servers");
}
var Server = class {
	constructor() {
		unsupported("TCP servers");
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/net/defaults.js
/** Module-local defaults from nodejs/node v24.19.0 `lib/net.js`, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae (MIT license). Native flags become local state. */
let autoSelectFamily = true;
let autoSelectFamilyAttemptTimeout = 250;
function getDefaultAutoSelectFamily() {
	return autoSelectFamily;
}
function setDefaultAutoSelectFamily(value) {
	if (typeof value !== "boolean") throw invalidArgType("value", "boolean", value);
	autoSelectFamily = value;
}
function getDefaultAutoSelectFamilyAttemptTimeout() {
	return autoSelectFamilyAttemptTimeout;
}
function setDefaultAutoSelectFamilyAttemptTimeout(value) {
	if (typeof value !== "number") throw invalidArgType("value", "number", value);
	if (!Number.isInteger(value) || value < 1 || value > 2147483647) throw outOfRange("value", "an integer >= 1 and <= 2147483647", value);
	autoSelectFamilyAttemptTimeout = Math.max(value, 10);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/net/normalize.js
/** Overload normalization adapted from nodejs/node v24.19.0 `lib/net.js`, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae (MIT license). Uses a local normalization symbol. */
const normalizedArgsSymbol = Symbol("normalizedArgs");
function isPipeName(value) {
	return typeof value === "string" && !(Number(value) >= 0);
}
function normalizeArgs(args) {
	let options;
	if (args.length === 0) options = {};
	else if (typeof args[0] === "object" && args[0] !== null) options = args[0];
	else if (isPipeName(args[0])) options = { path: args[0] };
	else {
		options = { port: args[0] };
		if (typeof args[1] === "string") options.host = args[1];
	}
	const last = args.at(-1);
	const result = [options, typeof last === "function" ? last : null];
	result[normalizedArgsSymbol] = true;
	return result;
}
//#endregion
//#region src/net.mjs
const Stream = Socket;
function _createServerHandle() {
	throw Object.assign(/* @__PURE__ */ new Error("TCP servers are not provided"), { code: "ERR_METHOD_NOT_IMPLEMENTED" });
}
var net_default = {
	BlockList,
	Server,
	Socket,
	SocketAddress,
	Stream,
	_createServerHandle,
	_normalizeArgs: normalizeArgs,
	connect,
	createConnection,
	createServer,
	getDefaultAutoSelectFamily,
	getDefaultAutoSelectFamilyAttemptTimeout,
	isIP,
	isIPv4,
	isIPv6,
	setDefaultAutoSelectFamily,
	setDefaultAutoSelectFamilyAttemptTimeout
};
//#endregion
export { BlockList, Server, Socket, SocketAddress, Stream, _createServerHandle, normalizeArgs as _normalizeArgs, connect, createConnection, createServer, net_default as default, getDefaultAutoSelectFamily, getDefaultAutoSelectFamilyAttemptTimeout, isIP, isIPv4, isIPv6, setDefaultAutoSelectFamily, setDefaultAutoSelectFamilyAttemptTimeout };
