//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/sqlite-host.js
/** Default provider: importing node:sqlite grants no database or filesystem authority. */
function denied() {
	throw {
		name: "Error",
		code: "ERR_JCO_SQLITE_ADAPTER_REQUIRED",
		message: "node:sqlite requires an explicit jco:node/sqlite host provider."
	};
}
const openDatabase = denied;
const backup$1 = denied;
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/sqlite/codec.js
function fail(code, message, kind = "TypeError") {
	throw Object.assign(new (kind === "TypeError" ? TypeError : kind === "RangeError" ? RangeError : Error)(message), { code });
}
function encode(value) {
	if (value === null) return { tag: "null" };
	if (typeof value === "number") return {
		tag: "number",
		val: value
	};
	if (typeof value === "string") return {
		tag: "text",
		val: value
	};
	if (typeof value === "bigint") {
		if (value < -(1n << 63n) || value >= 1n << 63n) fail("ERR_INVALID_ARG_VALUE", "BigInt value is too large to bind.");
		return {
			tag: "bigint",
			val: value
		};
	}
	if (ArrayBuffer.isView(value)) return {
		tag: "blob",
		val: new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
	};
	return fail("ERR_INVALID_ARG_TYPE", "Provided value cannot be bound to SQLite parameter.");
}
function decode(value) {
	return value.tag === "null" ? null : value.tag === "blob" ? new Uint8Array(value.val) : value.val;
}
function decodeRow(row) {
	if (row.tag === "array") return row.val.map(decode);
	const result = Object.create(null);
	for (const [key, value] of row.val) result[key] = decode(value);
	return result;
}
function bindings(args) {
	const first = args[0];
	if (first !== null && typeof first === "object" && !ArrayBuffer.isView(first)) return {
		named: Object.keys(first).map((k) => [k, encode(first[k])]),
		positional: args.slice(1).map(encode)
	};
	return { positional: args.map(encode) };
}
function path(value) {
	if (typeof value === "string") return {
		tag: "text",
		val: value
	};
	if (value instanceof Uint8Array) return {
		tag: "bytes",
		val: value
	};
	if (value !== null && typeof value === "object" && typeof value.href === "string") return {
		tag: "url",
		val: value.href
	};
	return fail("ERR_INVALID_ARG_TYPE", "The \"path\" argument must be a string, Uint8Array, or URL without null bytes.");
}
function restoreError(error) {
	const record = error;
	const e = record?.payload ?? error;
	if (error instanceof Error && !record.payload) return error;
	const result = new (e?.name === "TypeError" ? TypeError : e?.name === "RangeError" ? RangeError : Error)(e?.message ?? String(error));
	for (const key of [
		"code",
		"errcode",
		"errstr"
	]) if (e?.[key] !== void 0) Object.assign(result, { [key]: e[key] });
	return result;
}
function call(fn) {
	try {
		return fn();
	} catch (error) {
		throw restoreError(error);
	}
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/sqlite/constants.js
/** Node v24.20.0 SQLite constants, from src/node_sqlite.cc. */
const constants$1 = {
	SQLITE_CHANGESET_OMIT: 0,
	SQLITE_CHANGESET_REPLACE: 1,
	SQLITE_CHANGESET_ABORT: 2,
	SQLITE_CHANGESET_DATA: 1,
	SQLITE_CHANGESET_NOTFOUND: 2,
	SQLITE_CHANGESET_CONFLICT: 3,
	SQLITE_CHANGESET_CONSTRAINT: 4,
	SQLITE_CHANGESET_FOREIGN_KEY: 5,
	SQLITE_OK: 0,
	SQLITE_DENY: 1,
	SQLITE_IGNORE: 2,
	SQLITE_CREATE_INDEX: 1,
	SQLITE_CREATE_TABLE: 2,
	SQLITE_CREATE_TEMP_INDEX: 3,
	SQLITE_CREATE_TEMP_TABLE: 4,
	SQLITE_CREATE_TEMP_TRIGGER: 5,
	SQLITE_CREATE_TEMP_VIEW: 6,
	SQLITE_CREATE_TRIGGER: 7,
	SQLITE_CREATE_VIEW: 8,
	SQLITE_DELETE: 9,
	SQLITE_DROP_INDEX: 10,
	SQLITE_DROP_TABLE: 11,
	SQLITE_DROP_TEMP_INDEX: 12,
	SQLITE_DROP_TEMP_TABLE: 13,
	SQLITE_DROP_TEMP_TRIGGER: 14,
	SQLITE_DROP_TEMP_VIEW: 15,
	SQLITE_DROP_TRIGGER: 16,
	SQLITE_DROP_VIEW: 17,
	SQLITE_INSERT: 18,
	SQLITE_PRAGMA: 19,
	SQLITE_READ: 20,
	SQLITE_SELECT: 21,
	SQLITE_TRANSACTION: 22,
	SQLITE_UPDATE: 23,
	SQLITE_ATTACH: 24,
	SQLITE_DETACH: 25,
	SQLITE_ALTER_TABLE: 26,
	SQLITE_REINDEX: 27,
	SQLITE_ANALYZE: 28,
	SQLITE_CREATE_VTABLE: 29,
	SQLITE_DROP_VTABLE: 30,
	SQLITE_FUNCTION: 31,
	SQLITE_SAVEPOINT: 32,
	SQLITE_COPY: 0,
	SQLITE_RECURSIVE: 33
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/sqlite/core.js
const limitNames = {
	length: "length",
	sqlLength: "sql-length",
	column: "column",
	exprDepth: "expr-depth",
	compoundSelect: "compound-select",
	vdbeOp: "vdbe-op",
	functionArg: "function-arg",
	attach: "attach",
	likePatternLength: "like-pattern-length",
	variableNumber: "variable-number",
	triggerDepth: "trigger-depth"
};
function object(value) {
	if (value === null || typeof value !== "object" && typeof value !== "function") fail("ERR_INVALID_ARG_TYPE", "The \"options\" argument must be an object.");
	return value;
}
function string(value, name = "sql") {
	if (typeof value !== "string") fail("ERR_INVALID_ARG_TYPE", `The "${name}" argument must be a string.`);
	return value;
}
function bool(value, name = "enabled") {
	if (typeof value !== "boolean") fail("ERR_INVALID_ARG_TYPE", `The "${name}" argument must be a boolean.`);
	return value;
}
function bytes(value, name = "changeset") {
	if (!(value instanceof Uint8Array)) fail("ERR_INVALID_ARG_TYPE", `The "${name}" argument must be a Uint8Array.`);
	return value;
}
function statementOptions(value) {
	const result = {};
	for (const key of [
		"readBigInts",
		"returnArrays",
		"allowBareNamedParameters",
		"allowUnknownNamedParameters"
	]) if (value[key] !== void 0) result[key] = bool(value[key], `options.${key}`);
	return result;
}
function unsupported(name) {
	return fail("ERR_JCO_SQLITE_CALLBACK_UNSUPPORTED", `node:sqlite ${name} is not supported: synchronous SQL callbacks cannot re-enter a WebAssembly component.`, "Error");
}
function row(value) {
	return value == null ? void 0 : decodeRow(value);
}
function changes(value) {
	return {
		changes: decode(value.changes),
		lastInsertRowid: decode(value.lastInsertRowid)
	};
}
function ownGetter(target, key, get) {
	Object.defineProperty(target, key, {
		get,
		enumerable: true
	});
}
function createSqlite(host) {
	const databases = /* @__PURE__ */ new WeakMap();
	const secret = Symbol("sqlite construction");
	function iterator(cursor, owner) {
		let done = false;
		const result = {
			[Symbol.iterator]() {
				return this;
			},
			next() {
				if (done) return {
					done: true,
					value: void 0
				};
				const value = call(() => cursor.next());
				if (value == null) {
					done = true;
					call(() => cursor[Symbol.dispose]?.());
					return {
						done: true,
						value: void 0
					};
				}
				return {
					done: false,
					value: decodeRow(value)
				};
			},
			return() {
				if (!done) {
					done = true;
					call(() => cursor.close());
					call(() => cursor[Symbol.dispose]?.());
				}
				return {
					done: true,
					value: void 0
				};
			}
		};
		Object.defineProperty(result, Symbol("sqlite owner"), { value: owner });
		return result;
	}
	class DatabaseSync {
		#resource;
		constructor(filename, options) {
			const opts = arguments.length < 2 ? {} : object(options);
			const wire = {
				statement: statementOptions(opts),
				limits: []
			};
			for (const key of [
				"open",
				"readOnly",
				"enableForeignKeyConstraints",
				"enableDoubleQuotedStringLiterals",
				"allowExtension",
				"defensive"
			]) if (opts[key] !== void 0) wire[key] = bool(opts[key], `options.${key}`);
			if (opts.timeout !== void 0) {
				if (typeof opts.timeout !== "number") fail("ERR_INVALID_ARG_TYPE", "The \"options.timeout\" argument must be an integer.");
				wire.timeout = opts.timeout;
			}
			if (opts.limits !== void 0) {
				const limits = object(opts.limits);
				for (const [key, name] of Object.entries(limitNames)) if (limits[key] !== void 0) wire.limits.push([name, validateLimit(limits[key])]);
			}
			this.#resource = call(() => host.openDatabase(path(filename), wire));
			databases.set(this, this.#resource);
			ownGetter(this, "isOpen", () => call(() => this.#resource.isOpen()));
			ownGetter(this, "isTransaction", () => call(() => this.#resource.isTransaction()));
			const limits = {};
			for (const [key, name] of Object.entries(limitNames)) Object.defineProperty(limits, key, {
				enumerable: true,
				get: () => call(() => this.#resource.getLimit(name)),
				set: (value) => call(() => this.#resource.setLimit(name, validateLimit(value)))
			});
			ownGetter(this, "limits", () => {
				if (!this.isOpen) fail("ERR_INVALID_STATE", "database is not open", "Error");
				return limits;
			});
		}
		open() {
			call(() => this.#resource.open());
		}
		close() {
			call(() => this.#resource.close());
		}
		prepare(sql, options) {
			return new StatementSync(secret, call(() => this.#resource.prepare(string(sql), statementOptions(options === void 0 ? {} : object(options)))), this);
		}
		exec(sql) {
			call(() => this.#resource.exec(string(sql)));
		}
		function(..._args) {
			return unsupported("DatabaseSync.function");
		}
		createTagStore(maxSize = 1e3) {
			return new SQLTagStore(call(() => this.#resource.createTagStore(typeof maxSize === "number" ? maxSize : 1e3)), this);
		}
		location(dbName) {
			return call(() => this.#resource.location(dbName === void 0 ? void 0 : string(dbName, "dbName"))) ?? null;
		}
		aggregate(..._args) {
			return unsupported("DatabaseSync.aggregate");
		}
		createSession(options = {}) {
			const o = object(options);
			return new Session(secret, call(() => this.#resource.createSession({
				table: "table" in o ? string(o.table, "options.table") : void 0,
				db: "db" in o ? string(o.db, "options.db") : void 0
			})), this);
		}
		applyChangeset(changeset, options = {}) {
			const o = object(options);
			if (o.filter !== void 0 || o.onConflict !== void 0) unsupported("DatabaseSync.applyChangeset callbacks");
			return call(() => this.#resource.applyChangeset(bytes(changeset)));
		}
		enableLoadExtension(allow) {
			call(() => this.#resource.enableLoadExtension(bool(allow, "allow")));
		}
		enableDefensive(active) {
			call(() => this.#resource.enableDefensive(bool(active, "active")));
		}
		loadExtension(filename, entryPoint) {
			call(() => this.#resource.loadExtension(string(filename, "path"), entryPoint === void 0 ? void 0 : string(entryPoint, "entryPoint")));
		}
		serialize(dbName) {
			return new Uint8Array(call(() => this.#resource.serialize(dbName === void 0 ? void 0 : string(dbName, "dbName"))));
		}
		deserialize(data, options = {}) {
			const o = object(options);
			call(() => this.#resource.deserialize(bytes(data, "buffer"), o.dbName === void 0 ? void 0 : string(o.dbName, "dbName")));
		}
		setAuthorizer(..._args) {
			return unsupported("DatabaseSync.setAuthorizer");
		}
		[Symbol.dispose]() {
			if (this.isOpen) this.close();
		}
	}
	class StatementSync {
		#resource;
		#owner;
		constructor(token, resource, owner) {
			if (token !== secret) throw new TypeError("Illegal constructor");
			this.#resource = resource;
			this.#owner = owner;
			ownGetter(this, "sourceSQL", () => call(() => resource.sourceSql()));
			ownGetter(this, "expandedSQL", () => call(() => resource.expandedSql()));
		}
		iterate(...args) {
			return iterator(call(() => this.#resource.iterate(bindings(args))), this);
		}
		all(...args) {
			return call(() => this.#resource.all(bindings(args))).map(decodeRow);
		}
		get(...args) {
			return row(call(() => this.#resource.get(bindings(args))));
		}
		run(...args) {
			return changes(call(() => this.#resource.run(bindings(args))));
		}
		columns() {
			return call(() => this.#resource.columns()).map((c) => ({
				name: c.name,
				column: c.column ?? null,
				database: c.database ?? null,
				table: c.table ?? null,
				type: c.type ?? null
			}));
		}
		setAllowBareNamedParameters(enabled) {
			call(() => this.#resource.setAllowBareNamedParameters(bool(enabled, "allowBareNamedParameters")));
		}
		setAllowUnknownNamedParameters(enabled) {
			call(() => this.#resource.setAllowUnknownNamedParameters(bool(enabled)));
		}
		setReadBigInts(enabled) {
			call(() => this.#resource.setReadBigInts(bool(enabled, "readBigInts")));
		}
		setReturnArrays(enabled) {
			call(() => this.#resource.setReturnArrays(bool(enabled, "returnArrays")));
		}
	}
	class Session {
		#resource;
		#owner;
		#closed = false;
		constructor(token, resource, owner) {
			if (token !== secret) throw new TypeError("Illegal constructor");
			this.#resource = resource;
			this.#owner = owner;
		}
		changeset() {
			return new Uint8Array(call(() => this.#resource.changeset()));
		}
		patchset() {
			return new Uint8Array(call(() => this.#resource.patchset()));
		}
		close() {
			call(() => this.#resource.close());
			this.#closed = true;
		}
		[Symbol.dispose]() {
			if (!this.#closed) this.close();
		}
	}
	class SQLTagStore {
		#resource;
		#owner;
		constructor(resource, owner) {
			this.#resource = resource;
			this.#owner = owner;
			ownGetter(this, "capacity", () => call(() => resource.capacity()));
			ownGetter(this, "db", () => owner);
			ownGetter(this, "size", () => call(() => resource.size()));
		}
		get(parts, ...values) {
			return row(call(() => this.#resource.get(template(parts), values.map(encode))));
		}
		all(parts, ...values) {
			return call(() => this.#resource.all(template(parts), values.map(encode))).map(decodeRow);
		}
		iterate(parts, ...values) {
			return iterator(call(() => this.#resource.iterate(template(parts), values.map(encode))), this);
		}
		run(parts, ...values) {
			return changes(call(() => this.#resource.run(template(parts), values.map(encode))));
		}
		clear() {
			call(() => this.#resource.clear());
		}
	}
	function template(parts) {
		if (!Array.isArray(parts)) fail("ERR_INVALID_ARG_TYPE", "The \"sql\" argument must be a template literal.");
		return parts.map((v) => string(v));
	}
	function validateLimit(value) {
		if (typeof value !== "number" || value !== Infinity && (!Number.isInteger(value) || value > 2147483647)) fail("ERR_INVALID_ARG_TYPE", "Limit value must be a non-negative integer or Infinity.");
		if (value < 0) fail("ERR_OUT_OF_RANGE", "Limit value must be non-negative.", "RangeError");
		return value;
	}
	async function backup(source, filename, options = {}) {
		const o = object(options);
		if (o.progress !== void 0) unsupported("backup progress callback");
		const resource = databases.get(source);
		if (!resource) fail("ERR_INVALID_ARG_TYPE", "The \"sourceDb\" argument must be a DatabaseSync.");
		const opts = {};
		for (const key of ["source", "target"]) if (o[key] !== void 0) opts[key] = string(o[key], `options.${key}`);
		if (o.rate !== void 0) {
			if (typeof o.rate !== "number") fail("ERR_INVALID_ARG_TYPE", "The \"options.rate\" argument must be an integer.");
			opts.rate = o.rate;
		}
		try {
			return await host.backup(resource, path(filename), opts);
		} catch (error) {
			throw restoreError(error);
		}
	}
	for (const ctor of [
		DatabaseSync,
		StatementSync,
		Session,
		SQLTagStore
	]) for (const key of Reflect.ownKeys(ctor.prototype)) if (key !== "constructor") Object.defineProperty(ctor.prototype, key, { enumerable: true });
	return {
		DatabaseSync,
		StatementSync,
		Session,
		constants: { ...constants$1 },
		backup
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/sqlite.js
const sqlite = createSqlite({
	openDatabase,
	backup: backup$1
});
const { DatabaseSync, StatementSync, Session, constants, backup } = sqlite;
//#endregion
export { DatabaseSync, Session, StatementSync, backup, constants, sqlite as default };
