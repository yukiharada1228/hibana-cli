module.exports = require('./_stream_wrap.mjs').default;
