import { win32 } from "./path.mjs";
//#region src/path-win32.mjs
const { basename, dirname, extname, format, isAbsolute, join, normalize, parse, relative, resolve, sep, delimiter, posix, toNamespacedPath, matchesGlob, _makeLong } = win32;
var path_win32_default = win32;
//#endregion
export { _makeLong, basename, path_win32_default as default, delimiter, dirname, extname, format, isAbsolute, join, matchesGlob, normalize, parse, posix, relative, resolve, sep, toNamespacedPath, win32 };
