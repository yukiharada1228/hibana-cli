module.exports = require('./crypto.mjs').default;
