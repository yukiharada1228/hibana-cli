module.exports = require('./net.mjs').default;
