module.exports = require('./test-reporters.mjs').default;
