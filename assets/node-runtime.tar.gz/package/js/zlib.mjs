import { a as codedError, d as invalidArgType, g as outOfRange, s as deprecatedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { Buffer } from "./buffer.mjs";
import { a as Transform } from "./chunks/stream-BA_0bejK.mjs";
import { t as nextTick } from "./chunks/scheduler-C8tFqnQW.mjs";
import { r as toUint8Array } from "./chunks/shared-DSGRKwku.mjs";
import { n as decodeErrno, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import * as host from "hibana:node-zlib/api@0.5.0";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/zlib/constants.js
/** Constant snapshot from Node.js v24.20.0, commit
* 71b8b174857e25106d39b61a9e6f30d927da8b01, src/node_constants.cc (MIT).
* Generated from the pinned runtime; Infinity is preserved. No native code is ported. */
const constants$1 = Object.create(null, Object.fromEntries(Object.entries({
	Z_NO_FLUSH: 0,
	Z_PARTIAL_FLUSH: 1,
	Z_SYNC_FLUSH: 2,
	Z_FULL_FLUSH: 3,
	Z_FINISH: 4,
	Z_BLOCK: 5,
	Z_OK: 0,
	Z_STREAM_END: 1,
	Z_NEED_DICT: 2,
	Z_ERRNO: -1,
	Z_STREAM_ERROR: -2,
	Z_DATA_ERROR: -3,
	Z_MEM_ERROR: -4,
	Z_BUF_ERROR: -5,
	Z_VERSION_ERROR: -6,
	Z_NO_COMPRESSION: 0,
	Z_BEST_SPEED: 1,
	Z_BEST_COMPRESSION: 9,
	Z_DEFAULT_COMPRESSION: -1,
	Z_FILTERED: 1,
	Z_HUFFMAN_ONLY: 2,
	Z_RLE: 3,
	Z_FIXED: 4,
	Z_DEFAULT_STRATEGY: 0,
	ZLIB_VERNUM: 4897,
	DEFLATE: 1,
	INFLATE: 2,
	GZIP: 3,
	GUNZIP: 4,
	DEFLATERAW: 5,
	INFLATERAW: 6,
	UNZIP: 7,
	BROTLI_DECODE: 8,
	BROTLI_ENCODE: 9,
	ZSTD_DECOMPRESS: 11,
	ZSTD_COMPRESS: 10,
	Z_MIN_WINDOWBITS: 8,
	Z_MAX_WINDOWBITS: 15,
	Z_DEFAULT_WINDOWBITS: 15,
	Z_MIN_CHUNK: 64,
	Z_MAX_CHUNK: Infinity,
	Z_DEFAULT_CHUNK: 16384,
	Z_MIN_MEMLEVEL: 1,
	Z_MAX_MEMLEVEL: 9,
	Z_DEFAULT_MEMLEVEL: 8,
	Z_MIN_LEVEL: -1,
	Z_MAX_LEVEL: 9,
	Z_DEFAULT_LEVEL: -1,
	BROTLI_OPERATION_PROCESS: 0,
	BROTLI_OPERATION_FLUSH: 1,
	BROTLI_OPERATION_FINISH: 2,
	BROTLI_OPERATION_EMIT_METADATA: 3,
	BROTLI_PARAM_MODE: 0,
	BROTLI_MODE_GENERIC: 0,
	BROTLI_MODE_TEXT: 1,
	BROTLI_MODE_FONT: 2,
	BROTLI_DEFAULT_MODE: 0,
	BROTLI_PARAM_QUALITY: 1,
	BROTLI_MIN_QUALITY: 0,
	BROTLI_MAX_QUALITY: 11,
	BROTLI_DEFAULT_QUALITY: 11,
	BROTLI_PARAM_LGWIN: 2,
	BROTLI_MIN_WINDOW_BITS: 10,
	BROTLI_MAX_WINDOW_BITS: 24,
	BROTLI_LARGE_MAX_WINDOW_BITS: 30,
	BROTLI_DEFAULT_WINDOW: 22,
	BROTLI_PARAM_LGBLOCK: 3,
	BROTLI_MIN_INPUT_BLOCK_BITS: 16,
	BROTLI_MAX_INPUT_BLOCK_BITS: 24,
	BROTLI_PARAM_DISABLE_LITERAL_CONTEXT_MODELING: 4,
	BROTLI_PARAM_SIZE_HINT: 5,
	BROTLI_PARAM_LARGE_WINDOW: 6,
	BROTLI_PARAM_NPOSTFIX: 7,
	BROTLI_PARAM_NDIRECT: 8,
	BROTLI_DECODER_RESULT_ERROR: 0,
	BROTLI_DECODER_RESULT_SUCCESS: 1,
	BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT: 2,
	BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT: 3,
	BROTLI_DECODER_PARAM_DISABLE_RING_BUFFER_REALLOCATION: 0,
	BROTLI_DECODER_PARAM_LARGE_WINDOW: 1,
	BROTLI_DECODER_NO_ERROR: 0,
	BROTLI_DECODER_SUCCESS: 1,
	BROTLI_DECODER_NEEDS_MORE_INPUT: 2,
	BROTLI_DECODER_NEEDS_MORE_OUTPUT: 3,
	BROTLI_DECODER_ERROR_FORMAT_EXUBERANT_NIBBLE: -1,
	BROTLI_DECODER_ERROR_FORMAT_RESERVED: -2,
	BROTLI_DECODER_ERROR_FORMAT_EXUBERANT_META_NIBBLE: -3,
	BROTLI_DECODER_ERROR_FORMAT_SIMPLE_HUFFMAN_ALPHABET: -4,
	BROTLI_DECODER_ERROR_FORMAT_SIMPLE_HUFFMAN_SAME: -5,
	BROTLI_DECODER_ERROR_FORMAT_CL_SPACE: -6,
	BROTLI_DECODER_ERROR_FORMAT_HUFFMAN_SPACE: -7,
	BROTLI_DECODER_ERROR_FORMAT_CONTEXT_MAP_REPEAT: -8,
	BROTLI_DECODER_ERROR_FORMAT_BLOCK_LENGTH_1: -9,
	BROTLI_DECODER_ERROR_FORMAT_BLOCK_LENGTH_2: -10,
	BROTLI_DECODER_ERROR_FORMAT_TRANSFORM: -11,
	BROTLI_DECODER_ERROR_FORMAT_DICTIONARY: -12,
	BROTLI_DECODER_ERROR_FORMAT_WINDOW_BITS: -13,
	BROTLI_DECODER_ERROR_FORMAT_PADDING_1: -14,
	BROTLI_DECODER_ERROR_FORMAT_PADDING_2: -15,
	BROTLI_DECODER_ERROR_FORMAT_DISTANCE: -16,
	BROTLI_DECODER_ERROR_DICTIONARY_NOT_SET: -19,
	BROTLI_DECODER_ERROR_INVALID_ARGUMENTS: -20,
	BROTLI_DECODER_ERROR_ALLOC_CONTEXT_MODES: -21,
	BROTLI_DECODER_ERROR_ALLOC_TREE_GROUPS: -22,
	BROTLI_DECODER_ERROR_ALLOC_CONTEXT_MAP: -25,
	BROTLI_DECODER_ERROR_ALLOC_RING_BUFFER_1: -26,
	BROTLI_DECODER_ERROR_ALLOC_RING_BUFFER_2: -27,
	BROTLI_DECODER_ERROR_ALLOC_BLOCK_TYPE_TREES: -30,
	BROTLI_DECODER_ERROR_UNREACHABLE: -31,
	ZSTD_e_continue: 0,
	ZSTD_e_flush: 1,
	ZSTD_e_end: 2,
	ZSTD_fast: 1,
	ZSTD_dfast: 2,
	ZSTD_greedy: 3,
	ZSTD_lazy: 4,
	ZSTD_lazy2: 5,
	ZSTD_btlazy2: 6,
	ZSTD_btopt: 7,
	ZSTD_btultra: 8,
	ZSTD_btultra2: 9,
	ZSTD_c_compressionLevel: 100,
	ZSTD_c_windowLog: 101,
	ZSTD_c_hashLog: 102,
	ZSTD_c_chainLog: 103,
	ZSTD_c_searchLog: 104,
	ZSTD_c_minMatch: 105,
	ZSTD_c_targetLength: 106,
	ZSTD_c_strategy: 107,
	ZSTD_c_enableLongDistanceMatching: 160,
	ZSTD_c_ldmHashLog: 161,
	ZSTD_c_ldmMinMatch: 162,
	ZSTD_c_ldmBucketSizeLog: 163,
	ZSTD_c_ldmHashRateLog: 164,
	ZSTD_c_contentSizeFlag: 200,
	ZSTD_c_checksumFlag: 201,
	ZSTD_c_dictIDFlag: 202,
	ZSTD_c_nbWorkers: 400,
	ZSTD_c_jobSize: 401,
	ZSTD_c_overlapLog: 402,
	ZSTD_d_windowLogMax: 100,
	ZSTD_CLEVEL_DEFAULT: 3,
	ZSTD_error_no_error: 0,
	ZSTD_error_GENERIC: 1,
	ZSTD_error_prefix_unknown: 10,
	ZSTD_error_version_unsupported: 12,
	ZSTD_error_frameParameter_unsupported: 14,
	ZSTD_error_frameParameter_windowTooLarge: 16,
	ZSTD_error_corruption_detected: 20,
	ZSTD_error_checksum_wrong: 22,
	ZSTD_error_literals_headerWrong: 24,
	ZSTD_error_dictionary_corrupted: 30,
	ZSTD_error_dictionary_wrong: 32,
	ZSTD_error_dictionaryCreation_failed: 34,
	ZSTD_error_parameter_unsupported: 40,
	ZSTD_error_parameter_combination_unsupported: 41,
	ZSTD_error_parameter_outOfBound: 42,
	ZSTD_error_tableLog_tooLarge: 44,
	ZSTD_error_maxSymbolValue_tooLarge: 46,
	ZSTD_error_maxSymbolValue_tooSmall: 48,
	ZSTD_error_stabilityCondition_notRespected: 50,
	ZSTD_error_stage_wrong: 60,
	ZSTD_error_init_missing: 62,
	ZSTD_error_memory_allocation: 64,
	ZSTD_error_workSpace_tooSmall: 66,
	ZSTD_error_dstSize_tooSmall: 70,
	ZSTD_error_srcSize_wrong: 72,
	ZSTD_error_dstBuffer_null: 74,
	ZSTD_error_noForwardProgress_destFull: 80,
	ZSTD_error_noForwardProgress_inputEmpty: 82
}).map(([key, value]) => [key, {
	value,
	enumerable: true
}])));
const codes$1 = Object.freeze({
	"0": "Z_OK",
	"1": "Z_STREAM_END",
	"2": "Z_NEED_DICT",
	Z_OK: 0,
	Z_STREAM_END: 1,
	Z_NEED_DICT: 2,
	Z_ERRNO: -1,
	Z_STREAM_ERROR: -2,
	Z_DATA_ERROR: -3,
	Z_MEM_ERROR: -4,
	Z_BUF_ERROR: -5,
	Z_VERSION_ERROR: -6,
	"-1": "Z_ERRNO",
	"-2": "Z_STREAM_ERROR",
	"-3": "Z_DATA_ERROR",
	"-4": "Z_MEM_ERROR",
	"-5": "Z_BUF_ERROR",
	"-6": "Z_VERSION_ERROR"
});
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/zlib/core.js
/** Node-compatible stream/callback orchestration over the explicit compression capability.
* Contract: Node.js v24.20.0, lib/zlib.js, commit
* 71b8b174857e25106d39b61a9e6f30d927da8b01 (MIT). Compression stays in the host. */
function restoreError(record) {
	const error = new (record.name === "TypeError" ? TypeError : record.name === "RangeError" ? RangeError : Error)(record.message);
	error.name = record.name;
	if (record.code !== void 0) Object.assign(error, { code: record.code });
	if (record.errno !== void 0) Object.assign(error, { errno: decodeErrno(record.errno) });
	return error;
}
const call = (operation) => callHost(operation, restoreError);
const asError = (error) => error instanceof Error ? error : new Error(String(error));
function inputBytes(value, name = "buffer") {
	return typeof value === "string" ? Buffer.from(value) : toUint8Array(value, name);
}
function optionsForHost(options = {}) {
	const result = {};
	for (const key of [
		"flush",
		"finishFlush",
		"chunkSize",
		"windowBits",
		"level",
		"memLevel",
		"strategy",
		"maxOutputLength",
		"pledgedSrcSize"
	]) {
		const value = options?.[key];
		if (value !== void 0) {
			if (typeof value !== "number") throw invalidArgType(`options.${key}`, "number", value);
			result[key] = value;
		}
	}
	if (options?.rejectGarbageAfterEnd !== void 0) {
		if (typeof options.rejectGarbageAfterEnd !== "boolean") throw invalidArgType("options.rejectGarbageAfterEnd", "boolean", options.rejectGarbageAfterEnd);
		result.rejectGarbageAfterEnd = options.rejectGarbageAfterEnd;
	}
	if (options?.dictionary !== void 0) {
		if (!(options.dictionary instanceof ArrayBuffer) && !ArrayBuffer.isView(options.dictionary)) throw invalidArgType("options.dictionary", [
			"Buffer",
			"TypedArray",
			"DataView",
			"ArrayBuffer"
		], options.dictionary);
		result.dictionary = toUint8Array(options.dictionary);
	}
	if (options?.params !== void 0) result.params = Object.entries(options.params).map(([key, value]) => {
		if (typeof value !== "number" && typeof value !== "boolean") throw invalidArgType(`options.params[${key}]`, ["number", "boolean"], value);
		return [key, Number(value)];
	});
	return result;
}
/** Build an isolated module; importing it never calls the provider. */
function createZlib(host) {
	const flushes = /* @__PURE__ */ new WeakMap();
	const completed = Symbol("completed compression");
	class Base extends Transform {
		bytesWritten = 0;
		#engine;
		#fullFlush;
		#maxFlush;
		constructor(algorithm, options, state) {
			const native = optionsForHost(options);
			super({
				...options,
				flush: void 0,
				encoding: void 0,
				objectMode: false,
				writableObjectMode: false
			});
			this.#engine = state === completed ? void 0 : call(() => host.open(algorithm, native));
			this.#maxFlush = algorithm.startsWith("brotli") ? 3 : algorithm.startsWith("zstd") ? 2 : 5;
			this.#fullFlush = algorithm.startsWith("brotli") ? 1 : algorithm.startsWith("zstd") ? 1 : 3;
		}
		get bytesRead() {
			throw deprecatedNodeApi("zlib.bytesRead", "zlib.bytesWritten");
		}
		engine() {
			if (!this.#engine) throw codedError(/* @__PURE__ */ new Error("zlib binding closed"), "ERR_ASSERTION");
			return this.#engine;
		}
		output(result) {
			this.bytesWritten = result.bytesWritten;
			if (result.data.length) this.push(Buffer.from(result.data));
		}
		_transform(chunk, _encoding, callback) {
			try {
				const bytes = toUint8Array(chunk);
				const kind = chunk instanceof Uint8Array ? flushes.get(chunk) : void 0;
				this.output(call(() => kind === void 0 ? this.engine().write(bytes) : this.engine().flush(kind)));
			} catch (error) {
				callback(asError(error));
				return;
			}
			callback();
		}
		_flush(callback) {
			try {
				this.output(call(() => this.engine().finish()));
			} catch (error) {
				callback(asError(error));
				return;
			}
			callback();
		}
		_destroy(error, callback) {
			const engine = this.#engine;
			this.#engine = void 0;
			try {
				if (engine) {
					call(() => engine.close());
					engine[Symbol.dispose]?.();
				}
			} catch (closeError) {
				callback(error ?? asError(closeError));
				return;
			}
			callback(error);
		}
		close(callback) {
			if (callback !== void 0) {
				if (typeof callback !== "function") throw invalidArgType("callback", "function", callback);
				if (this.closed) nextTick(callback);
				else this.once("close", callback);
			}
			this.destroy();
		}
		reset() {
			call(() => this.engine().reset());
		}
		flush(kind, callback) {
			if (typeof kind === "function") {
				callback = kind;
				kind = void 0;
			}
			kind ??= this.#fullFlush;
			if (typeof kind !== "number") throw invalidArgType("kind", "number", kind);
			if (kind < 0 || kind > this.#maxFlush || Number.isNaN(kind)) throw outOfRange("kind", `>= 0 and <= ${this.#maxFlush}`, kind);
			if (callback !== void 0 && typeof callback !== "function") throw invalidArgType("callback", "function", callback);
			if (this.writableFinished) {
				if (callback) nextTick(callback);
				return;
			}
			if (this.writableEnded) {
				if (callback) this.once("end", callback);
				return;
			}
			const marker = Buffer.alloc(0);
			flushes.set(marker, kind);
			this.write(marker, callback);
		}
	}
	class WithParams extends Base {
		params(level, strategy, callback) {
			if (typeof level !== "number") throw invalidArgType("level", "number", level);
			if (typeof strategy !== "number") throw invalidArgType("strategy", "number", strategy);
			if (level < -1 || level > 9 || Number.isNaN(level)) throw outOfRange("level", ">= -1 and <= 9", level);
			if (strategy < 0 || strategy > 4 || Number.isNaN(strategy)) throw outOfRange("strategy", ">= 0 and <= 4", strategy);
			if (typeof callback !== "function") throw invalidArgType("callback", "function", callback);
			this.flush(constants$1.Z_SYNC_FLUSH, (error) => {
				if (error) {
					callback(error);
					return;
				}
				try {
					this.output(call(() => this.engine().params(level, strategy)));
				} catch (cause) {
					callback(asError(cause));
					return;
				}
				callback();
			});
		}
	}
	function family(name, algorithm, params) {
		const Parent = params ? WithParams : Base;
		class Compression extends Parent {
			constructor(options, state) {
				super(algorithm, options, state);
			}
		}
		Object.defineProperty(Compression, "name", { value: name });
		const Callable = new Proxy(Compression, { apply(target, _this, args) {
			return Reflect.construct(target, args);
		} });
		Object.defineProperty(Compression.prototype, "constructor", {
			value: Callable,
			writable: true,
			configurable: true
		});
		const Constructor = Callable;
		function sync(input, options) {
			const result = call(() => host.compress(algorithm, inputBytes(input), optionsForHost(options)));
			const buffer = Buffer.from(result.data);
			if (!options?.info) return buffer;
			const engine = new Compression(options, completed);
			engine.bytesWritten = result.bytesWritten;
			engine.destroy();
			return {
				buffer,
				engine
			};
		}
		function asyncMethod(input, optionsOrCallback, callback) {
			const options = typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback;
			if (typeof optionsOrCallback === "function") callback = optionsOrCallback;
			if (typeof callback !== "function") throw invalidArgType("callback", "function", callback);
			const cb = callback;
			const data = inputBytes(input);
			const stream = new Constructor(options);
			nextTick(() => {
				let result;
				try {
					result = call(() => host.compress(algorithm, data, optionsForHost(options)));
				} catch (error) {
					stream.destroy();
					cb(asError(error));
					return;
				}
				stream.bytesWritten = result.bytesWritten;
				stream.destroy();
				const buffer = Buffer.from(result.data);
				cb(null, options?.info ? {
					buffer,
					engine: stream
				} : buffer);
			});
		}
		return {
			Constructor,
			create: (options) => new Constructor(options),
			sync,
			async: asyncMethod
		};
	}
	const deflate = family("Deflate", "deflate", true);
	const inflate = family("Inflate", "inflate", true);
	const gzip = family("Gzip", "gzip", true);
	const gunzip = family("Gunzip", "gunzip", true);
	const deflateRaw = family("DeflateRaw", "deflateraw", true);
	const inflateRaw = family("InflateRaw", "inflateraw", true);
	const unzip = family("Unzip", "unzip", true);
	const brotliCompress = family("BrotliCompress", "brotlicompress", false);
	const brotliDecompress = family("BrotliDecompress", "brotlidecompress", false);
	const zstdCompress = family("ZstdCompress", "zstdcompress", false);
	const zstdDecompress = family("ZstdDecompress", "zstddecompress", false);
	const module = {
		constants: constants$1,
		codes: codes$1,
		crc32(data, value = 0) {
			if (typeof data !== "string" && !ArrayBuffer.isView(data)) throw invalidArgType("data", [
				"Buffer",
				"TypedArray",
				"DataView",
				"string"
			], data);
			if (typeof value !== "number") throw invalidArgType("value", "number", value);
			if (!Number.isInteger(value) || value < 0 || value > 4294967295) throw outOfRange("value", ">= 0 and <= 4294967295", value);
			return call(() => host.crc32(inputBytes(data), value)) >>> 0;
		},
		Deflate: deflate.Constructor,
		createDeflate: deflate.create,
		deflate: deflate.async,
		deflateSync: deflate.sync,
		Inflate: inflate.Constructor,
		createInflate: inflate.create,
		inflate: inflate.async,
		inflateSync: inflate.sync,
		Gzip: gzip.Constructor,
		createGzip: gzip.create,
		gzip: gzip.async,
		gzipSync: gzip.sync,
		Gunzip: gunzip.Constructor,
		createGunzip: gunzip.create,
		gunzip: gunzip.async,
		gunzipSync: gunzip.sync,
		DeflateRaw: deflateRaw.Constructor,
		createDeflateRaw: deflateRaw.create,
		deflateRaw: deflateRaw.async,
		deflateRawSync: deflateRaw.sync,
		InflateRaw: inflateRaw.Constructor,
		createInflateRaw: inflateRaw.create,
		inflateRaw: inflateRaw.async,
		inflateRawSync: inflateRaw.sync,
		Unzip: unzip.Constructor,
		createUnzip: unzip.create,
		unzip: unzip.async,
		unzipSync: unzip.sync,
		BrotliCompress: brotliCompress.Constructor,
		createBrotliCompress: brotliCompress.create,
		brotliCompress: brotliCompress.async,
		brotliCompressSync: brotliCompress.sync,
		BrotliDecompress: brotliDecompress.Constructor,
		createBrotliDecompress: brotliDecompress.create,
		brotliDecompress: brotliDecompress.async,
		brotliDecompressSync: brotliDecompress.sync,
		ZstdCompress: zstdCompress.Constructor,
		createZstdCompress: zstdCompress.create,
		zstdCompress: zstdCompress.async,
		zstdCompressSync: zstdCompress.sync,
		ZstdDecompress: zstdDecompress.Constructor,
		createZstdDecompress: zstdDecompress.create,
		zstdDecompress: zstdDecompress.async,
		zstdDecompressSync: zstdDecompress.sync
	};
	for (const key of Object.keys(module)) if (key.startsWith("create")) Object.defineProperty(module, key, {
		writable: false,
		configurable: true
	});
	Object.defineProperty(module, "constants", {
		writable: false,
		configurable: false
	});
	Object.defineProperty(module, "codes", {
		writable: false,
		configurable: false
	});
	for (const key of Object.keys(constants$1)) if (!key.startsWith("BROTLI")) Object.defineProperty(module, key, { get() {
		throw deprecatedNodeApi(`zlib.${key}`, `zlib.constants.${key}`);
	} });
	return module;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/zlib.js
const zlib = createZlib(host);
const { constants, codes, crc32, Deflate, createDeflate, deflate, deflateSync, Inflate, createInflate, inflate, inflateSync, Gzip, createGzip, gzip, gzipSync, Gunzip, createGunzip, gunzip, gunzipSync, DeflateRaw, createDeflateRaw, deflateRaw, deflateRawSync, InflateRaw, createInflateRaw, inflateRaw, inflateRawSync, Unzip, createUnzip, unzip, unzipSync, BrotliCompress, createBrotliCompress, brotliCompress, brotliCompressSync, BrotliDecompress, createBrotliDecompress, brotliDecompress, brotliDecompressSync, ZstdCompress, createZstdCompress, zstdCompress, zstdCompressSync, ZstdDecompress, createZstdDecompress, zstdDecompress, zstdDecompressSync } = zlib;
//#endregion
export { BrotliCompress, BrotliDecompress, Deflate, DeflateRaw, Gunzip, Gzip, Inflate, InflateRaw, Unzip, ZstdCompress, ZstdDecompress, brotliCompress, brotliCompressSync, brotliDecompress, brotliDecompressSync, codes, constants, crc32, createBrotliCompress, createBrotliDecompress, createDeflate, createDeflateRaw, createGunzip, createGzip, createInflate, createInflateRaw, createUnzip, createZstdCompress, createZstdDecompress, zlib as default, deflate, deflateRaw, deflateRawSync, deflateSync, gunzip, gunzipSync, gzip, gzipSync, inflate, inflateRaw, inflateRawSync, inflateSync, unzip, unzipSync, zstdCompress, zstdCompressSync, zstdDecompress, zstdDecompressSync };
