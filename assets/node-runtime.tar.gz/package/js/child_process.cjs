module.exports = require('./child_process.mjs').default;
