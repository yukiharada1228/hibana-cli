module.exports = require('./async_hooks.mjs').default;
