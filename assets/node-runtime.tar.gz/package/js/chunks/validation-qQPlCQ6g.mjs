import { d as invalidArgType, f as invalidArgValue, g as outOfRange } from "./core-DGqXzKN-.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/validation.js
function validateFunction(value, name) {
	if (typeof value !== "function") throw invalidArgType(name, "Function", value);
}
function validateObject(value, name, options = {}) {
	if (value === null || typeof value !== "object" || !options.allowArray && Array.isArray(value)) throw invalidArgType(name, "Object", value);
}
function validateOneOf(value, name, allowed) {
	if (!allowed.includes(value)) throw invalidArgValue(name, value, `must be one of: ${allowed.map(String).join(", ")}`);
}
function validateUint32(value, name, positive = false) {
	const minimum = positive ? 1 : 0;
	if (!Number.isInteger(value) || value < minimum || value > 4294967295) throw outOfRange(name, `>= ${minimum} and <= 4294967295`, value);
}
function validateString(value, name) {
	if (typeof value !== "string") throw invalidArgType(name, "string", value);
}
function validateBoolean(value, name) {
	if (typeof value !== "boolean") throw invalidArgType(name, "boolean", value);
}
function validateInteger(value, name, min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER) {
	validateNumber(value, name);
	if (!Number.isInteger(value)) throw outOfRange(name, "an integer", value);
	if (value < min || value > max) throw outOfRange(name, `>= ${min} && <= ${max}`, value);
}
function validateAbortSignal(signal, name) {
	if (signal === null || typeof signal !== "object" || !("aborted" in signal) || typeof signal.aborted !== "boolean") throw invalidArgType(name, "AbortSignal", signal);
}
function validateArray(value, name) {
	if (!Array.isArray(value)) throw invalidArgType(name, "Array", value);
}
function validateStringArray(value, name) {
	validateArray(value, name);
	value.forEach((v, i) => validateString(v, `${name}[${i}]`));
}
function validateBooleanArray(value, name) {
	validateArray(value, name);
	value.forEach((v, i) => validateBoolean(v, `${name}[${i}]`));
}
function validateNumber(value, name) {
	if (typeof value !== "number") throw invalidArgType(name, "number", value);
}
//#endregion
export { validateFunction as a, validateObject as c, validateStringArray as d, validateUint32 as f, validateBooleanArray as i, validateOneOf as l, validateArray as n, validateInteger as o, validateBoolean as r, validateNumber as s, validateAbortSignal as t, validateString as u };
