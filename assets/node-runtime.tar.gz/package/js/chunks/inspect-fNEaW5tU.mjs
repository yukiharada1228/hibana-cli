//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/assert/inspect.js
function quote(value) {
	return `'${value.replaceAll("\\", "\\\\").replaceAll("'", "\\'").replaceAll("\n", "\\n").replaceAll("\r", "\\r").replaceAll("	", "\\t")}'`;
}
function inspect(value, seen = /* @__PURE__ */ new Set(), depth = 0) {
	switch (typeof value) {
		case "string": return quote(value);
		case "number": return Object.is(value, -0) ? "-0" : String(value);
		case "bigint": return `${value}n`;
		case "boolean":
		case "undefined": return String(value);
		case "symbol": return String(value);
		case "function": return `[Function: ${value.name || "anonymous"}]`;
	}
	if (value === null) return "null";
	if (typeof value !== "object") return String(value);
	if (seen.has(value)) return "[Circular]";
	if (depth > 20) return "[Object]";
	seen.add(value);
	try {
		if (value instanceof Date) {
			const time = value.getTime();
			return Number.isNaN(time) ? "Invalid Date" : value.toISOString();
		}
		if (value instanceof RegExp) return String(value);
		if (value instanceof Error) return `${value.name}: ${value.message}`;
		if (ArrayBuffer.isView(value)) {
			const name = value.constructor.name;
			if (value instanceof DataView) return `DataView { byteLength: ${value.byteLength} }`;
			return `${name}(${value.length}) [ ${Array.from(value, (item) => inspect(item, seen, depth + 1)).join(", ")} ]`;
		}
		if (value instanceof ArrayBuffer) return `ArrayBuffer { byteLength: ${value.byteLength} }`;
		if (value instanceof Map) {
			const entries = Array.from(value, ([key, item]) => `${inspect(key, seen, depth + 1)} => ${inspect(item, seen, depth + 1)}`);
			return `Map(${value.size}) { ${entries.join(", ")} }`;
		}
		if (value instanceof Set) return `Set(${value.size}) { ${Array.from(value, (item) => inspect(item, seen, depth + 1)).join(", ")} }`;
		if (Array.isArray(value)) {
			const entries = [];
			for (let i = 0; i < value.length; i++) entries.push(Object.hasOwn(value, i) ? inspect(value[i], seen, depth + 1) : "<1 empty item>");
			return `[ ${entries.join(", ")} ]`;
		}
		const ctor = Object.getPrototypeOf(value)?.constructor;
		return `${ctor && ctor !== Object ? `${ctor.name} ` : ""}{ ${Reflect.ownKeys(value).filter((key) => Object.prototype.propertyIsEnumerable.call(value, key)).sort((a, b) => String(a).localeCompare(String(b))).map((key) => {
			return `${typeof key === "symbol" ? `[${String(key)}]` : /^[A-Za-z_$][\w$]*$/.test(key) ? key : quote(key)}: ${inspect(value[key], seen, depth + 1)}`;
		}).join(", ")} }`;
	} finally {
		seen.delete(value);
	}
}
//#endregion
export { inspect as t };
