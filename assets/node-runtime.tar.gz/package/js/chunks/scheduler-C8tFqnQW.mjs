//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/stream/scheduler.js
/** Guest-local scheduling for readable-stream's process.nextTick dependency. */
const queue = [];
let scheduled = false;
function flush() {
	try {
		while (queue.length) queue.shift()();
	} finally {
		scheduled = false;
		if (queue.length) schedule();
	}
}
function schedule() {
	if (scheduled) return;
	scheduled = true;
	queueMicrotask(flush);
}
function nextTick(callback, ...args) {
	queue.push(() => callback(...args));
	schedule();
}
//#endregion
export { nextTick as t };
