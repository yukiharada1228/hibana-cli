import { v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/event-emitter.js
/**
* Minimal `EventEmitter` for jco-std's own shims.
*
* Several Node modules are EventEmitters -- `cluster` and `cluster.Worker` today, more later -- but
* shim code cannot get one from `node:events`. Guests reach that specifier through unenv, which
* jco-std does not depend on and deliberately does not: a shim importing a `node:*` builtin relies
* on a bundler rewriting it, which is not true of every way jco-std is consumed.
*
* So this is the internal one. It implements the subset the shims reach, not Node's full surface.
* Deliberately absent: `errorMonitor`, `captureRejections`, `[Symbol.for('nodejs.rejection')]`, and
* the `newListener`/`removeListener` meta-events -- reaching for one throws rather than silently
* doing nothing.
*
* If a shim ever needs more of the surface, revisit whether jco-std should own a full
* implementation instead of tracking unenv's separately.
*/
var EventEmitter = class {
	#events = /* @__PURE__ */ new Map();
	#maxListeners = 10;
	#add(event, listener, once, prepend) {
		if (event === "newListener" || event === "removeListener") throw unsupportedNodeApi(`EventEmitter '${event}' meta-event`, "jco-std's internal EventEmitter implements only the ordinary event surface");
		const registrations = this.#events.get(event) ?? [];
		const registration = {
			listener,
			once
		};
		if (prepend) registrations.unshift(registration);
		else registrations.push(registration);
		this.#events.set(event, registrations);
		return this;
	}
	on(event, listener) {
		return this.#add(event, listener, false, false);
	}
	addListener(event, listener) {
		return this.#add(event, listener, false, false);
	}
	once(event, listener) {
		return this.#add(event, listener, true, false);
	}
	prependListener(event, listener) {
		return this.#add(event, listener, false, true);
	}
	prependOnceListener(event, listener) {
		return this.#add(event, listener, true, true);
	}
	off(event, listener) {
		return this.removeListener(event, listener);
	}
	removeListener(event, listener) {
		const registrations = this.#events.get(event);
		if (!registrations) return this;
		for (let i = registrations.length - 1; i >= 0; i -= 1) if (registrations[i].listener === listener) {
			registrations.splice(i, 1);
			break;
		}
		if (registrations.length === 0) this.#events.delete(event);
		return this;
	}
	removeAllListeners(event) {
		if (event === void 0) this.#events.clear();
		else this.#events.delete(event);
		return this;
	}
	emit(event, ...args) {
		const registrations = this.#events.get(event);
		if (!registrations || registrations.length === 0) {
			if (event === "error") throw args[0] instanceof Error ? args[0] : /* @__PURE__ */ new Error(`Unhandled error. (${String(args[0])})`);
			return false;
		}
		for (const registration of [...registrations]) {
			if (registration.once) this.removeListener(event, registration.listener);
			registration.listener(...args);
		}
		return true;
	}
	listeners(event) {
		return (this.#events.get(event) ?? []).map((registration) => registration.listener);
	}
	rawListeners(event) {
		return this.listeners(event);
	}
	listenerCount(event) {
		return this.#events.get(event)?.length ?? 0;
	}
	eventNames() {
		return [...this.#events.keys()];
	}
	setMaxListeners(value) {
		this.#maxListeners = value;
		return this;
	}
	getMaxListeners() {
		return this.#maxListeners;
	}
};
//#endregion
export { EventEmitter as t };
