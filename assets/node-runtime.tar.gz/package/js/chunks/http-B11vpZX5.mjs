import { a as codedError } from "./core-DGqXzKN-.mjs";
import { r as validateBoolean, s as validateNumber, u as validateString } from "./validation-qQPlCQ6g.mjs";
import { t as EventEmitter } from "./event-emitter-D4b0qsct.mjs";
import { a as validateHeaderValue$1, c as deprecated, d as outOfRange, f as unsupported$1, i as validateHeaderName$1, l as invalidArgType, n as OutgoingMessage$1, o as base64, r as IncomingMessage$1, t as parseListenArguments, u as invalidArgValue } from "./net-server-BNP7dcFI.mjs";
import { request } from "hibana:node-http/api@0.5.0";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/agent.js
/**
* Inert Agent for the portable node:http shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_agent.js (MIT license).
* Option defaults and getName() are kept for compatibility; socket pooling is
* owned by the selected implementation.
*/
var Agent$1 = class extends EventEmitter {
	options;
	defaultPort;
	protocol;
	requests = Object.create(null);
	sockets = Object.create(null);
	freeSockets = Object.create(null);
	keepAlive;
	keepAliveMsecs;
	maxSockets;
	maxFreeSockets;
	maxTotalSockets;
	scheduling;
	constructor(options = {}) {
		super();
		this.options = {
			...options,
			noDelay: options.noDelay ?? true,
			path: null
		};
		this.defaultPort = options.defaultPort ?? 80;
		this.protocol = options.protocol ?? "http:";
		this.keepAlive = options.keepAlive ?? false;
		this.keepAliveMsecs = options.keepAliveMsecs ?? 1e3;
		this.maxSockets = options.maxSockets ?? Number.POSITIVE_INFINITY;
		this.maxFreeSockets = options.maxFreeSockets ?? 256;
		this.maxTotalSockets = options.maxTotalSockets ?? Number.POSITIVE_INFINITY;
		this.scheduling = options.scheduling ?? "lifo";
	}
	createConnection(..._args) {
		return unsupported$1("http.Agent.createConnection", "the selected implementation owns connections");
	}
	getName(options = {}) {
		let name = options.host || "localhost";
		name += ":";
		if (options.port) name += options.port;
		name += ":";
		if (options.localAddress) name += options.localAddress;
		if (options.family === 4 || options.family === 6) name += `:${options.family}`;
		if (options.socketPath) name += `:${options.socketPath}`;
		return name;
	}
	keepSocketAlive(_socket) {
		return false;
	}
	reuseSocket(_socket, _request) {}
	destroy() {
		for (const collection of [
			this.requests,
			this.sockets,
			this.freeSockets
		]) for (const key of Object.keys(collection)) delete collection[key];
	}
};
const globalAgent$1 = new Agent$1({
	keepAlive: true,
	scheduling: "lifo",
	timeout: 5e3
});
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/tls.js
/**
* Normalizes Node's TLS options into the material the WIT boundary carries.
*
* The accepted option shapes follow nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_tls_common.js `configSecureContext`,
* lib/_tls_wrap.js, and doc/api/tls.md (MIT license). Only the serializable subset crosses the
* boundary: PEM/DER/PFX blobs, strings, booleans, and ALPN protocol names. Options that install
* a callback, hand over an opaque host handle, or name an OpenSSL engine have no representation
* in a typed WIT record and are refused by name instead of being silently dropped. Options the
* record does not carry at all are ignored, exactly as `http.createServer` ignores keys it does
* not know.
*
* Every material field stays a list. Node accepts arrays for `key`, `cert`, `pfx`, `ca`, and
* `crl`, and OpenSSL reads only the first key from a concatenated PEM, so joining a `key`
* bundle into one blob would silently drop every key after the first.
*/
const CALLBACK = "a callback cannot be retained across the WIT boundary";
const ENGINE = "OpenSSL engines are not addressable from a component";
/** TLS options that cannot cross a typed WIT boundary, mapped to the reason they cannot. */
const UNREPRESENTABLE_TLS_OPTIONS = {
	ALPNCallback: CALLBACK,
	SNICallback: CALLBACK,
	checkServerIdentity: CALLBACK,
	pskCallback: CALLBACK,
	secureContext: "a prebuilt SecureContext is an opaque host handle",
	session: "a TLS session is bound to the implementation's own connections",
	ticketKeys: "TLS ticket keys are owned by the implementation",
	clientCertEngine: ENGINE,
	privateKeyEngine: ENGINE,
	privateKeyIdentifier: ENGINE,
	allowPartialTrustChain: "partial-chain trust policy is not carried by the TLS boundary",
	enableTrace: "native TLS tracing is not exposed by the TLS boundary",
	requestOCSP: "OCSP negotiation is not exposed by the TLS boundary",
	minDHSize: "the TLS boundary cannot configure a minimum Diffie-Hellman key size",
	handshakeTimeout: "handshake deadlines are host policy at the TLS boundary",
	sessionTimeout: "session lifetime is host policy at the TLS boundary"
};
const encoder = new TextEncoder();
function isMaterial(value) {
	return typeof value === "string" || ArrayBuffer.isView(value) || value instanceof ArrayBuffer;
}
function bytes(name, value) {
	if (typeof value === "string") return encoder.encode(value);
	if (value instanceof ArrayBuffer) return new Uint8Array(value.slice(0));
	if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength));
	throw invalidArgType(name, "string, Buffer, TypedArray, DataView, or ArrayBuffer", value);
}
/**
* Reads a material option that Node accepts either as one blob or as an array of blobs.
*
* Object entries (`{ pem, passphrase }` for keys, `{ buf, passphrase }` for PFX bundles) carry
* a per-entry passphrase the WIT record has no field for, so they are refused rather than
* losing the passphrase.
*/
function materialList(api, name, value) {
	if (Array.isArray(value)) return value.map((entry, index) => {
		if (typeof entry === "object" && entry !== null && !isMaterial(entry)) throw unsupported$1(`${api} ${name}[${index}]`, "only string, Buffer, TypedArray, DataView, and ArrayBuffer entries can cross the WIT boundary");
		return bytes(`${name}[${index}]`, entry);
	});
	return [bytes(name, value)];
}
function string(name, value) {
	validateString(value, name);
	return value;
}
function boolean(name, value) {
	validateBoolean(value, name);
	return value;
}
function uint32(name, value) {
	validateNumber(value, name);
	if (!Number.isInteger(value) || value < 0 || value > 4294967295) throw outOfRange(name, ">= 0 && <= 4294967295", value);
	return value;
}
function alpnProtocols(value) {
	if (Array.isArray(value)) return value.map((entry, index) => string(`ALPNProtocols[${index}]`, entry));
	if (!isMaterial(value)) throw invalidArgType("ALPNProtocols", "Array, Buffer, TypedArray, or DataView", value);
	const wire = bytes("ALPNProtocols", value);
	const protocols = [];
	const decoder = new TextDecoder();
	let offset = 0;
	while (offset < wire.byteLength) {
		const length = wire[offset];
		offset += 1;
		if (length === 0 || offset + length > wire.byteLength) throw invalidArgType("ALPNProtocols", "a valid ALPN protocol list", value);
		protocols.push(decoder.decode(wire.subarray(offset, offset + length)));
		offset += length;
	}
	return protocols;
}
/**
* Extracts the TLS material from `https.createServer` or `https.request` options.
*
* `api` labels refusals, e.g. `https.request option`. Returns `undefined` when no carried option
* is present at all so callers can tell "no TLS configuration" from an empty one.
*/
function tlsMaterial(options, api) {
	const bag = options;
	for (const [name, reason] of Object.entries(UNREPRESENTABLE_TLS_OPTIONS)) if (bag[name] !== void 0) unsupported$1(`${api} ${name}`, reason);
	const material = {};
	const read = (name, key, convert) => {
		if (bag[name] !== void 0) material[key] = convert(bag[name]);
	};
	read("key", "key", (value) => materialList(api, "key", value));
	read("cert", "cert", (value) => materialList(api, "cert", value));
	read("pfx", "pfx", (value) => materialList(api, "pfx", value));
	read("passphrase", "passphrase", (value) => string("passphrase", value));
	read("ca", "ca", (value) => materialList(api, "ca", value));
	read("crl", "crl", (value) => materialList(api, "crl", value));
	read("dhparam", "dhparam", (value) => bytes("dhparam", value));
	read("ciphers", "ciphers", (value) => string("ciphers", value));
	read("ecdhCurve", "ecdhCurve", (value) => string("ecdhCurve", value));
	read("sigalgs", "sigalgs", (value) => string("sigalgs", value));
	read("minVersion", "minVersion", (value) => string("minVersion", value));
	read("maxVersion", "maxVersion", (value) => string("maxVersion", value));
	read("secureProtocol", "secureProtocol", (value) => string("secureProtocol", value));
	read("secureOptions", "secureOptions", (value) => uint32("secureOptions", value));
	read("sessionIdContext", "sessionIdContext", (value) => string("sessionIdContext", value));
	read("honorCipherOrder", "honorCipherOrder", (value) => boolean("honorCipherOrder", value));
	read("ALPNProtocols", "alpnProtocols", alpnProtocols);
	read("servername", "servername", (value) => string("servername", value));
	read("rejectUnauthorized", "rejectUnauthorized", (value) => boolean("rejectUnauthorized", value));
	read("requestCert", "requestCert", (value) => boolean("requestCert", value));
	return Object.keys(material).length > 0 ? material : void 0;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/client-request.js
/**
* Buffered ClientRequest for the portable node:http shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_client.js and the
* urlToHttpOptions helper in lib/internal/url.js (MIT license). Option
* normalisation, Host/Authorization defaults, and validation errors are kept;
* agents, sockets, and the streaming parser are replaced by one typed
* request/response exchange with the selected implementation.
*/
/**
* Resolves the port assumed when the options carry none.
*
* lib/_http_client.js reads `options.defaultPort || (this.agent && this.agent.defaultPort)`,
* and an `agent: false` request still gets a fresh instance of the module's own agent class,
* so the profile's port is the correct final fallback for both modules.
*/
function resolvedDefaultPort(options, profile) {
	const agent = options.agent;
	const agentDefaultPort = typeof agent === "object" && agent !== null && typeof agent.defaultPort === "number" ? agent.defaultPort : void 0;
	return Number(options.defaultPort || agentDefaultPort || profile.defaultPort);
}
function urlOptions(input) {
	const url = input instanceof URL ? input : new URL(input);
	return {
		protocol: url.protocol,
		hostname: url.hostname,
		port: url.port || void 0,
		path: `${url.pathname}${url.search}`,
		auth: url.username || url.password ? `${decodeURIComponent(url.username)}:${decodeURIComponent(url.password)}` : void 0
	};
}
function numericPort(value, fallback) {
	const port = value === null || value === void 0 || value === "" ? fallback : Number(value);
	if (!Number.isInteger(port) || port < 1 || port > 65535) throw invalidArgValue("options.port", value);
	return port;
}
function normalizedRequest(input, extra, profile) {
	const base = typeof input === "string" || input instanceof URL ? urlOptions(input) : input;
	if (typeof base !== "object" || base === null) throw invalidArgType("options", "object, string, or URL", input);
	const options = {
		...base,
		...extra
	};
	const protocol = options.protocol ?? profile.protocol;
	if (protocol !== profile.protocol) {
		const error = invalidArgValue("protocol", protocol);
		error.code = "ERR_INVALID_PROTOCOL";
		error.message = `Protocol \"${protocol}\" not supported. Expected \"${profile.protocol}\"`;
		throw error;
	}
	let hostname = options.hostname ?? options.host ?? "localhost";
	if (typeof hostname !== "string") throw invalidArgType("options.hostname", "string", hostname);
	let hostPort;
	if (hostname.startsWith("[") && hostname.includes("]")) {
		const closing = hostname.indexOf("]");
		hostPort = hostname.slice(closing + 1).replace(/^:/, "") || void 0;
		hostname = hostname.slice(1, closing);
	} else if (hostname.split(":").length === 2) [hostname, hostPort] = hostname.split(":");
	const defaultPort = resolvedDefaultPort(options, profile);
	const port = numericPort(options.port ?? hostPort, defaultPort);
	const method = (options.method ?? "GET").toUpperCase();
	validateHeaderName$1(method, "Method");
	const path = options.path ?? "/";
	if (typeof path !== "string") throw invalidArgType("options.path", "string", path);
	if (/[\u0000-\u0020]/.test(path)) {
		const error = invalidArgValue("path", path);
		error.code = "ERR_UNESCAPED_CHARACTERS";
		error.message = "Request path contains unescaped characters";
		throw error;
	}
	const authorityHost = hostname.includes(":") ? `[${hostname}]` : hostname;
	return {
		options,
		method,
		protocol,
		hostname,
		port,
		authority: port === defaultPort ? authorityHost : `${authorityHost}:${port}`,
		path
	};
}
function abortError(reason) {
	return Object.assign(new Error(reason === void 0 ? "The operation was aborted" : String(reason)), {
		name: "AbortError",
		code: "ABORT_ERR"
	});
}
var ClientRequestBase = class extends OutgoingMessage$1 {
	agent;
	protocol;
	host;
	path;
	method;
	reusedSocket = false;
	maxHeadersCount = null;
	#implementation;
	#profile;
	#hostname;
	#port;
	#tls;
	#responseListener;
	constructor(implementation, profile, input, options, responseListener) {
		const normalized = normalizedRequest(input, options, profile);
		super(normalized.options.headers);
		this.#implementation = implementation;
		this.#profile = profile;
		this.#hostname = normalized.hostname;
		this.#port = normalized.port;
		this.#tls = profile.scheme === "https" ? tlsMaterial(normalized.options, `${profile.module}.request option`) : void 0;
		this.#responseListener = responseListener;
		this.agent = normalized.options.agent === false ? new profile.globalAgent.constructor() : normalized.options.agent ?? profile.globalAgent;
		this.protocol = normalized.protocol;
		this.host = normalized.authority;
		this.path = normalized.path;
		this.method = normalized.method;
		if (normalized.options.setHost !== false && !this.hasHeader("host")) this.setHeader("Host", normalized.authority);
		if (normalized.options.auth && !this.hasHeader("authorization")) this.setHeader("Authorization", `Basic ${base64(normalized.options.auth)}`);
		if (normalized.options.timeout !== void 0) this.setTimeout(normalized.options.timeout);
		const signal = normalized.options.signal;
		if (signal) {
			const abort = () => this.destroy(abortError(signal.reason));
			if (signal.aborted) abort();
			else signal.addEventListener("abort", abort, { once: true });
		}
	}
	abort() {
		return deprecated(`${this.#profile.module}.ClientRequest.abort`, "request.destroy()");
	}
	setNoDelay(_noDelay = true) {
		return unsupported$1(`${this.#profile.module}.ClientRequest.setNoDelay`, "the selected implementation owns the socket");
	}
	setSocketKeepAlive(_enable = false, _initialDelay = 0) {
		return unsupported$1(`${this.#profile.module}.ClientRequest.setSocketKeepAlive`, "the selected implementation owns the socket");
	}
	_finalize(body) {
		if (body.byteLength > 0 && !this.hasHeader("content-length") && !this.hasHeader("transfer-encoding")) this._headers.setInternal("Content-Length", body.byteLength);
		const timeout = this._timeout() || void 0;
		const request = {
			method: this.method,
			scheme: this.#profile.scheme,
			authority: this.host,
			pathWithQuery: this.path,
			headers: this._headers.fields(),
			body,
			connectTimeoutMs: timeout,
			firstByteTimeoutMs: timeout,
			betweenBytesTimeoutMs: timeout
		};
		if (this.#tls !== void 0) request.tls = this.#tls;
		const response = this.#implementation.request(request);
		return () => this.#deliver(response);
	}
	#deliver(response) {
		if (this.destroyed) return;
		const message = new IncomingMessage$1(response);
		this.emit("response", message);
		this.#responseListener?.(message);
		message._start();
	}
	_remote() {
		return {
			hostname: this.#hostname,
			port: this.#port
		};
	}
};
function createClientRequest(implementation, profile) {
	return class ClientRequest extends ClientRequestBase {
		constructor(input, options, callback) {
			super(implementation, profile, input, typeof options === "function" ? void 0 : options, typeof options === "function" ? options : callback);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/constants.js
/**
* Values follow nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_common.js and
* lib/_http_server.js (MIT license). The tables are copied as data; native
* parser bindings and process options are replaced by portable constants.
*/
const METHODS$1 = [
	"ACL",
	"BIND",
	"CHECKOUT",
	"CONNECT",
	"COPY",
	"DELETE",
	"GET",
	"HEAD",
	"LINK",
	"LOCK",
	"M-SEARCH",
	"MERGE",
	"MKACTIVITY",
	"MKCALENDAR",
	"MKCOL",
	"MOVE",
	"NOTIFY",
	"OPTIONS",
	"PATCH",
	"POST",
	"PROPFIND",
	"PROPPATCH",
	"PURGE",
	"PUT",
	"QUERY",
	"REBIND",
	"REPORT",
	"SEARCH",
	"SOURCE",
	"SUBSCRIBE",
	"TRACE",
	"UNBIND",
	"UNLINK",
	"UNLOCK",
	"UNSUBSCRIBE"
];
const STATUS_CODES$1 = {
	100: "Continue",
	101: "Switching Protocols",
	102: "Processing",
	103: "Early Hints",
	200: "OK",
	201: "Created",
	202: "Accepted",
	203: "Non-Authoritative Information",
	204: "No Content",
	205: "Reset Content",
	206: "Partial Content",
	207: "Multi-Status",
	208: "Already Reported",
	226: "IM Used",
	300: "Multiple Choices",
	301: "Moved Permanently",
	302: "Found",
	303: "See Other",
	304: "Not Modified",
	305: "Use Proxy",
	307: "Temporary Redirect",
	308: "Permanent Redirect",
	400: "Bad Request",
	401: "Unauthorized",
	402: "Payment Required",
	403: "Forbidden",
	404: "Not Found",
	405: "Method Not Allowed",
	406: "Not Acceptable",
	407: "Proxy Authentication Required",
	408: "Request Timeout",
	409: "Conflict",
	410: "Gone",
	411: "Length Required",
	412: "Precondition Failed",
	413: "Payload Too Large",
	414: "URI Too Long",
	415: "Unsupported Media Type",
	416: "Range Not Satisfiable",
	417: "Expectation Failed",
	418: "I'm a Teapot",
	421: "Misdirected Request",
	422: "Unprocessable Entity",
	423: "Locked",
	424: "Failed Dependency",
	425: "Too Early",
	426: "Upgrade Required",
	428: "Precondition Required",
	429: "Too Many Requests",
	431: "Request Header Fields Too Large",
	451: "Unavailable For Legal Reasons",
	500: "Internal Server Error",
	501: "Not Implemented",
	502: "Bad Gateway",
	503: "Service Unavailable",
	504: "Gateway Timeout",
	505: "HTTP Version Not Supported",
	506: "Variant Also Negotiates",
	507: "Insufficient Storage",
	508: "Loop Detected",
	509: "Bandwidth Limit Exceeded",
	510: "Not Extended",
	511: "Network Authentication Required"
};
const maxHeaderSize$1 = 16384;
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/profile.js
/**
* Protocol profile shared by the node:http and node:https shims.
*
* `node:https` is `lib/_http_client.js` and `lib/_http_server.js` driven with a different
* protocol, default port, and global agent (nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/https.js). Rather than fork those modules,
* every protocol-dependent constant is collected here and threaded through the shared core.
*/
const HTTP_PROFILE = {
	module: "http",
	protocol: "http:",
	scheme: "http",
	defaultPort: 80,
	globalAgent: globalAgent$1
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/server.js
/**
* Server and ServerResponse for the portable node:http shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_server.js and the
* listen errors in lib/internal/errors.js (MIT license). Option defaults and
* the writeHead contract are kept; net.Server, the connection parser, and
* per-socket timers are replaced by a typed server implementation that
* returns one buffered response per request.
*/
/**
* Reads the first `Server` argument the way lib/_http_server.js does.
*
* A listener or a nullish value means "no options"; any other non-object is
* `ERR_INVALID_ARG_TYPE` rather than being read as an option bag.
*/
function serverOptions(value) {
	if (typeof value === "function" || value === null || value === void 0) return {};
	if (typeof value !== "object") throw invalidArgType("options", "object", value);
	return value;
}
var ServerResponse$1 = class extends OutgoingMessage$1 {
	req;
	statusCode = 200;
	statusMessage = "";
	sendDate = true;
	strictContentLength = false;
	#completed;
	#resolveCompleted;
	#rejectCompleted;
	constructor(request) {
		super();
		this.req = request;
		this.#completed = new Promise((resolve, reject) => {
			this.#resolveCompleted = resolve;
			this.#rejectCompleted = reject;
		});
	}
	writeHead(statusCode, statusMessageOrHeaders, headers) {
		if (!Number.isInteger(statusCode) || statusCode < 100 || statusCode > 999) throw invalidArgValue("statusCode", statusCode);
		this.statusCode = statusCode;
		if (typeof statusMessageOrHeaders === "string") this.statusMessage = statusMessageOrHeaders;
		else headers = statusMessageOrHeaders;
		for (const [name, value] of Object.entries(headers ?? {})) if (value !== void 0) this.setHeader(name, value);
		this.flushHeaders();
		return this;
	}
	writeContinue(callback) {
		unsupported$1("http.ServerResponse.writeContinue", "the buffered HTTP boundary returns one final response");
	}
	writeProcessing() {
		unsupported$1("http.ServerResponse.writeProcessing", "the buffered HTTP boundary returns one final response");
	}
	writeEarlyHints(_hints, callback) {
		unsupported$1("http.ServerResponse.writeEarlyHints", "the buffered HTTP boundary returns one final response");
	}
	writeInformation(_statusCode, _headers, callback) {
		unsupported$1("http.ServerResponse.writeInformation", "the buffered HTTP boundary returns one final response");
	}
	_finalize(body) {
		if (!this.statusMessage) this.statusMessage = STATUS_CODES$1[this.statusCode] ?? "";
		this.#resolveCompleted({
			statusCode: this.statusCode,
			statusMessage: this.statusMessage,
			headers: this._headers.fields(),
			body
		});
	}
	_completed() {
		return this.#completed;
	}
	appendHeader(name, value) {
		return super.appendHeader(name, value);
	}
	end(chunkOrCallback, encodingOrCallback, callback) {
		return super.end(chunkOrCallback, encodingOrCallback, callback);
	}
	destroy(error) {
		super.destroy(error);
		this.#rejectCompleted(error ?? /* @__PURE__ */ new Error("HTTP response was destroyed before it completed"));
		return this;
	}
};
var ServerBase = class extends EventEmitter {
	options;
	listening = false;
	maxHeadersCount = null;
	maxRequestsPerSocket = 0;
	timeout = 0;
	headersTimeout;
	keepAliveTimeout;
	keepAliveTimeoutBuffer;
	requestTimeout;
	#server;
	#profile;
	constructor(implementation, profile, optionsOrListener = {}, listener) {
		super();
		this.#profile = profile;
		if (!implementation.createServer) unsupported$1(`${profile.module}.Server`, implementation.serverUnsupportedReason ?? "the selected HTTP implementation cannot accept inbound connections");
		const options = serverOptions(optionsOrListener);
		const requestListener = typeof optionsOrListener === "function" ? optionsOrListener : listener;
		for (const name of [
			"IncomingMessage",
			"ServerResponse",
			"shouldUpgradeCallback",
			"highWaterMark",
			"insecureHTTPParser",
			"uniqueHeaders"
		]) if (options[name] !== void 0) unsupported$1(`${profile.module}.Server option ${name}`, "this option cannot be represented by the current typed WIT boundary");
		this.options = { ...options };
		this.headersTimeout = options.headersTimeout ?? 6e4;
		this.keepAliveTimeout = options.keepAliveTimeout ?? 5e3;
		this.keepAliveTimeoutBuffer = options.keepAliveTimeoutBuffer ?? 1e3;
		this.requestTimeout = options.requestTimeout ?? 3e5;
		if (requestListener) this.on("request", requestListener);
		const tls = profile.scheme === "https" ? tlsMaterial(options, `${profile.module}.createServer option`) ?? {} : void 0;
		this.#server = implementation.createServer({
			...options,
			tls
		}, (request) => this.#handle(request), (error) => queueMicrotask(() => this.emit("error", error)));
	}
	listen(...args) {
		const { options, callback } = parseListenArguments(args);
		if (options.signal !== void 0) unsupported$1(`${this.#profile.module}.Server.listen signal`, "an AbortSignal cannot be retained across the current WIT server resource boundary");
		if (this.listening) throw codedError(/* @__PURE__ */ new Error("Listen method has been called more than once without closing."), "ERR_SERVER_ALREADY_LISTEN");
		this.#server.listen(options);
		this.listening = true;
		queueMicrotask(() => {
			this.emit("listening");
			callback?.();
		});
		return this;
	}
	close(callback) {
		try {
			const wasListening = this.#server.close();
			this.listening = false;
			queueMicrotask(() => {
				if (wasListening) this.emit("close");
				callback?.();
			});
		} catch (error) {
			queueMicrotask(() => callback?.(error instanceof Error ? error : new Error(String(error))));
		}
		return this;
	}
	closeAllConnections() {
		this.#server.closeAllConnections();
	}
	closeIdleConnections() {
		this.#server.closeIdleConnections();
	}
	getConnections(callback) {
		if (typeof callback !== "function") throw invalidArgType("callback", "function", callback);
		try {
			const count = this.#server.getConnections();
			queueMicrotask(() => callback(null, count));
		} catch (error) {
			queueMicrotask(() => callback(error instanceof Error ? error : new Error(String(error)), 0));
		}
	}
	setTimeout(milliseconds = 0, callback) {
		if (milliseconds !== 0 || callback !== void 0) unsupported$1(`${this.#profile.module}.Server.setTimeout`, "timeout events require an additional server callback across the WIT boundary");
		this.timeout = milliseconds;
		return this;
	}
	address() {
		return this.#server.address();
	}
	ref() {
		this.#server.ref();
		return this;
	}
	unref() {
		this.#server.unref();
		return this;
	}
	async [Symbol.asyncDispose]() {
		await new Promise((resolve, reject) => {
			this.close((error) => error ? reject(error) : resolve());
		});
	}
	async #handle(data) {
		const request = new IncomingMessage$1(data);
		const response = new ServerResponse$1(request);
		if (!this.emit("request", request, response)) unsupported$1(`${this.#profile.module}.Server request`, "the server has no request listener");
		request._start();
		return response._completed();
	}
};
function createServerConstructor(implementation, profile) {
	return class Server extends ServerBase {
		constructor(optionsOrListener = {}, listener) {
			super(implementation, profile, optionsOrListener, listener);
		}
	};
}
function connectionListener(..._args) {
	return unsupported$1("http._connectionListener", "raw inbound sockets cannot call into guest JavaScript");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/core.js
function unavailableConstructor(name) {
	return class {
		constructor() {
			unsupported$1(`http.${name}`, `${name} is not provided by the JavaScript engine`);
		}
	};
}
function globalConstructor(name) {
	const value = globalThis[name];
	return typeof value === "function" ? value : unavailableConstructor(name);
}
/**
* Builds the request/server surface for one protocol.
*
* `lib/https.js` reuses `_http_client` and `_http_server` unchanged and only varies the
* protocol, default port, and default agent, so both modules share this builder.
*/
function createProtocolModule(implementation, profile) {
	const ClientRequest = createClientRequest(implementation, profile);
	const Server = createServerConstructor(implementation, profile);
	function request(input, options, callback) {
		return new ClientRequest(input, options, callback);
	}
	function get(input, options, callback) {
		const clientRequest = request(input, options, callback);
		clientRequest.end();
		return clientRequest;
	}
	function createServer(optionsOrListener = {}, listener) {
		return new Server(optionsOrListener, listener);
	}
	return {
		ClientRequest,
		Server,
		createServer,
		get,
		request
	};
}
function createHttp(implementation) {
	const { ClientRequest, Server, createServer, get, request } = createProtocolModule(implementation, HTTP_PROFILE);
	function setMaxIdleHTTPParsers(max) {
		if (typeof max !== "number") throw invalidArgType("max", "number", max);
		if (!Number.isInteger(max) || max < 1) throw outOfRange("max", "an integer >= 1", max);
	}
	function setGlobalProxyFromEnv(_environment) {
		return unsupported$1("http.setGlobalProxyFromEnv", "components do not own Node's process-wide undici and HTTPS agent state");
	}
	return {
		Agent: Agent$1,
		ClientRequest,
		CloseEvent: globalConstructor("CloseEvent"),
		IncomingMessage: IncomingMessage$1,
		METHODS: METHODS$1,
		MessageEvent: globalConstructor("MessageEvent"),
		OutgoingMessage: OutgoingMessage$1,
		STATUS_CODES: STATUS_CODES$1,
		Server,
		ServerResponse: ServerResponse$1,
		WebSocket: globalConstructor("WebSocket"),
		_connectionListener: connectionListener,
		createServer,
		get,
		globalAgent: globalAgent$1,
		maxHeaderSize: maxHeaderSize$1,
		request,
		setGlobalProxyFromEnv,
		setMaxIdleHTTPParsers,
		validateHeaderName: validateHeaderName$1,
		validateHeaderValue: validateHeaderValue$1
	};
}
//#endregion
//#region src/http-transport.mjs
let statusMessages = {};
function useStatusCodes(codes) {
	statusMessages = codes;
}
const unsupported = (name, reason) => Object.assign(/* @__PURE__ */ new Error(`${name} is not supported: ${reason}`), { code: "ERR_NOT_SUPPORTED" });
function failure(caught) {
	const payload = caught?.payload;
	if (!payload) return caught;
	return Object.assign(new Error(payload.message), {
		name: payload.name || "Error",
		code: payload.code,
		syscall: payload.syscall
	});
}
const implementation = {
	serverUnsupportedReason: "Workers handle inbound requests through the exported fetch handler",
	request({ tls, ...options }) {
		if (tls !== void 0) throw unsupported(`${options.scheme}.request with TLS options`, "the Worker terminates TLS and verifies certificates for approved destinations");
		let response;
		try {
			response = request(options);
		} catch (caught) {
			throw failure(caught);
		}
		return {
			...response,
			statusMessage: statusMessages[response.statusCode] ?? ""
		};
	}
};
//#endregion
//#region src/http.mjs
const http = createHttp(implementation);
useStatusCodes(http.STATUS_CODES);
const Agent = http.Agent;
const ClientRequest = http.ClientRequest;
const CloseEvent = http.CloseEvent;
const IncomingMessage = http.IncomingMessage;
const METHODS = http.METHODS;
const MessageEvent = http.MessageEvent;
const OutgoingMessage = http.OutgoingMessage;
const STATUS_CODES = http.STATUS_CODES;
const Server = http.Server;
const ServerResponse = http.ServerResponse;
const WebSocket = http.WebSocket;
const _connectionListener = http._connectionListener;
const createServer = http.createServer;
const get = http.get;
const globalAgent = http.globalAgent;
const maxHeaderSize = http.maxHeaderSize;
const request$1 = http.request;
const setGlobalProxyFromEnv = http.setGlobalProxyFromEnv;
const setMaxIdleHTTPParsers = http.setMaxIdleHTTPParsers;
const validateHeaderName = http.validateHeaderName;
const validateHeaderValue = http.validateHeaderValue;
//#endregion
export { implementation as C, Agent$1 as E, validateHeaderValue as S, createProtocolModule as T, maxHeaderSize as _, METHODS as a, setMaxIdleHTTPParsers as b, STATUS_CODES as c, WebSocket as d, _connectionListener as f, http as g, globalAgent as h, IncomingMessage as i, Server as l, get as m, ClientRequest as n, MessageEvent as o, createServer as p, CloseEvent as r, OutgoingMessage as s, Agent as t, ServerResponse as u, request$1 as v, useStatusCodes as w, validateHeaderName as x, setGlobalProxyFromEnv as y };
