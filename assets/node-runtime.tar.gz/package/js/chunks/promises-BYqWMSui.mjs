import { r as __exportAll } from "./rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, f as invalidArgValue, g as outOfRange, m as invalidThis, t as AbortError, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { o as validateInteger, r as validateBoolean, t as validateAbortSignal, u as validateString } from "./validation-qQPlCQ6g.mjs";
import { Buffer } from "../buffer.mjs";
import { m as import_events, n as addAbortListener } from "./events-KhrHxd6b.mjs";
import "./errors-Dlg0HNHo.mjs";
import { a as CSI, c as commonPrefix, d as reverseString, f as defer, h as validateUint32, i as moveCursor, l as emitKeys, m as isWritable, n as clearScreenDown, o as charLengthAt, p as inspect, r as cursorTo, s as charLengthLeft, u as kSubstringSearch } from "./callbacks-CB8KGxqT.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/string-decoder.js
const kNativeDecoder = Symbol("kNativeDecoder");
function lower(value) {
	return String.prototype.toLowerCase.call(value);
}
function normalizeEncoding(encoding) {
	if (encoding == null || encoding === "utf8" || encoding === "utf-8") return "utf8";
	switch (encoding.length) {
		case 4:
			if (encoding === "UTF8") return "utf8";
			if (encoding === "ucs2" || encoding === "UCS2") return "utf16le";
			if (lower(encoding) === "utf8") return "utf8";
			if (lower(encoding) === "ucs2") return "utf16le";
			break;
		case 3:
			if (encoding === "hex" || encoding === "HEX" || lower(encoding) === "hex") return "hex";
			break;
		case 5:
			if (encoding === "ascii" || encoding === "ASCII") return "ascii";
			if (encoding === "ucs-2" || encoding === "UCS-2") return "utf16le";
			if (encoding === "UTF-8") return "utf8";
			if (lower(encoding) === "utf-8") return "utf8";
			if (lower(encoding) === "ascii") return "ascii";
			if (lower(encoding) === "ucs-2") return "utf16le";
			break;
		case 6:
			if (encoding === "base64" || encoding === "BASE64") return "base64";
			if (encoding === "latin1" || encoding === "LATIN1") return "latin1";
			if (encoding === "binary" || encoding === "BINARY") return "latin1";
			if (lower(encoding) === "base64") return "base64";
			if (lower(encoding) === "latin1" || lower(encoding) === "binary") return "latin1";
			break;
		case 7:
			if (encoding === "utf16le" || encoding === "UTF16LE" || lower(encoding) === "utf16le") return "utf16le";
			break;
		case 8:
			if (encoding === "utf-16le" || encoding === "UTF-16LE" || lower(encoding) === "utf-16le") return "utf16le";
			break;
		case 9:
			if (encoding === "base64url" || encoding === "BASE64URL" || lower(encoding) === "base64url") return "base64url";
			break;
		default: if (encoding === "") return "utf8";
	}
}
function unknownEncoding(encoding) {
	return codedError(/* @__PURE__ */ new TypeError(`Unknown encoding: ${String(encoding)}`), "ERR_UNKNOWN_ENCODING");
}
function inputBytes(input) {
	return Buffer.from(new Uint8Array(input.buffer, input.byteOffset, input.byteLength));
}
function encodeBytes(input, encoding, start = 0, end = input.length) {
	if (encoding === "base64url") return input.toString("base64", start, end).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
	return input.toString(encoding, start, end);
}
function utf8CheckByte(byte) {
	if (byte <= 127) return 0;
	if (byte >> 5 === 6) return 2;
	if (byte >> 4 === 14) return 3;
	if (byte >> 3 === 30) return 4;
	return byte >> 6 === 2 ? -1 : -2;
}
function utf8CheckIncomplete(state, input, start) {
	let index = input.length - 1;
	if (index < start) return 0;
	let bytes = utf8CheckByte(input[index]);
	if (bytes >= 0) {
		if (bytes > 0) state.lastNeed = bytes - 1;
		return bytes;
	}
	if (--index < start || bytes === -2) return 0;
	bytes = utf8CheckByte(input[index]);
	if (bytes >= 0) {
		if (bytes > 0) state.lastNeed = bytes - 2;
		return bytes;
	}
	if (--index < start || bytes === -2) return 0;
	bytes = utf8CheckByte(input[index]);
	if (bytes >= 0) {
		if (bytes > 0) {
			if (bytes === 2) bytes = 0;
			else state.lastNeed = bytes - 3;
		}
		return bytes;
	}
	return 0;
}
function fillLast(state, input, encoding) {
	if (state.lastNeed <= input.length) {
		input.copy(state.lastChar, state.lastTotal - state.lastNeed, 0, state.lastNeed);
		return encodeBytes(state.lastChar, encoding, 0, state.lastTotal);
	}
	input.copy(state.lastChar, state.lastTotal - state.lastNeed, 0, input.length);
	state.lastNeed -= input.length;
}
function utf8Text(state, input, start) {
	const total = utf8CheckIncomplete(state, input, start);
	if (state.lastNeed === 0) return input.toString("utf8", start);
	state.lastTotal = total;
	const end = input.length - (total - state.lastNeed);
	input.copy(state.lastChar, 0, end);
	return input.toString("utf8", start, end);
}
function utf8Write(state, input) {
	const buffered = state.lastTotal - state.lastNeed;
	const bytes = buffered > 0 ? Buffer.concat([state.lastChar.subarray(0, buffered), input]) : input;
	state.lastNeed = 0;
	state.lastTotal = 0;
	return utf8Text(state, bytes, 0);
}
function utf16Text(state, input, start) {
	if ((input.length - start) % 2 === 0) {
		const result = input.toString("utf16le", start);
		if (result) {
			const code = result.charCodeAt(result.length - 1);
			if (code >= 55296 && code <= 56319) {
				state.lastNeed = 2;
				state.lastTotal = 4;
				state.lastChar[0] = input[input.length - 2];
				state.lastChar[1] = input[input.length - 1];
				return result.slice(0, -1);
			}
		}
		return result;
	}
	state.lastNeed = 1;
	state.lastTotal = 2;
	state.lastChar[0] = input[input.length - 1];
	return input.toString("utf16le", start, input.length - 1);
}
function base64Text(state, input, start, encoding) {
	const remainder = (input.length - start) % 3;
	if (remainder === 0) return encodeBytes(input, encoding, start);
	state.lastNeed = 3 - remainder;
	state.lastTotal = 3;
	if (remainder === 1) state.lastChar[0] = input[input.length - 1];
	else {
		state.lastChar[0] = input[input.length - 2];
		state.lastChar[1] = input[input.length - 1];
	}
	return encodeBytes(input, encoding, start, input.length - remainder);
}
/** A guest-local implementation of Node's streaming string decoder. */
var StringDecoder = class {
	encoding;
	[kNativeDecoder];
	constructor(encoding) {
		const normalized = normalizeEncoding(encoding);
		if (normalized === void 0) throw unknownEncoding(encoding);
		this.encoding = normalized;
		this[kNativeDecoder] = {
			lastChar: Buffer.alloc(4),
			lastNeed: 0,
			lastTotal: 0
		};
	}
	write(input) {
		if (typeof input === "string") return input;
		if (!ArrayBuffer.isView(input)) throw invalidArgType("buf", [
			"Buffer",
			"TypedArray",
			"DataView"
		], input);
		const state = this?.[kNativeDecoder];
		if (!state) throw invalidThis("StringDecoder");
		const bytes = inputBytes(input);
		if (bytes.length === 0) return "";
		if (this.encoding === "utf8") return utf8Write(state, bytes);
		let prefix;
		let start = 0;
		if (state.lastNeed > 0) {
			prefix = fillLast(state, bytes, this.encoding);
			if (prefix === void 0) return "";
			start = state.lastNeed;
			state.lastNeed = 0;
			state.lastTotal = 0;
		}
		let decoded = "";
		if (start < bytes.length) switch (this.encoding) {
			case "utf16le":
				decoded = utf16Text(state, bytes, start);
				break;
			case "base64":
			case "base64url":
				decoded = base64Text(state, bytes, start, this.encoding);
				break;
			default: decoded = encodeBytes(bytes, this.encoding, start);
		}
		return prefix ? prefix + decoded : decoded;
	}
	end(input) {
		const result = input === void 0 ? "" : this.write(input);
		const state = this[kNativeDecoder];
		if (state.lastNeed === 0) return result;
		let trailing = "";
		switch (this.encoding) {
			case "utf8":
				trailing = state.lastChar.toString("utf8", 0, state.lastTotal - state.lastNeed);
				break;
			case "utf16le":
				trailing = state.lastChar.toString("utf16le", 0, state.lastTotal - state.lastNeed);
				break;
			case "base64":
			case "base64url": trailing = encodeBytes(state.lastChar, this.encoding, 0, state.lastTotal - state.lastNeed);
		}
		state.lastNeed = 0;
		state.lastTotal = 0;
		return result + trailing;
	}
	/** Undocumented legacy method retained by Node 24. */
	text(input, offset) {
		const state = this[kNativeDecoder];
		state.lastNeed = 0;
		state.lastTotal = 0;
		if (typeof input === "string") return this.write(input.slice(offset));
		if (!ArrayBuffer.isView(input)) throw invalidArgType("buf", [
			"Buffer",
			"TypedArray",
			"DataView"
		], input);
		const bytes = new Uint8Array(input.buffer, input.byteOffset, input.byteLength).subarray(offset);
		return this.write(bytes);
	}
	/** Undocumented legacy buffered-byte view retained by Node 24. */
	get lastChar() {
		const state = this?.[kNativeDecoder];
		if (!state) throw invalidThis("StringDecoder");
		return state.lastChar.subarray(0, 4);
	}
	/** Undocumented legacy count retained by Node 24. */
	get lastNeed() {
		const state = this?.[kNativeDecoder];
		if (!state) throw invalidThis("StringDecoder");
		return state.lastNeed;
	}
	/** Undocumented legacy count retained by Node 24. */
	get lastTotal() {
		const state = this?.[kNativeDecoder];
		if (!state) throw invalidThis("StringDecoder");
		return state.lastTotal;
	}
};
for (const name of [
	"write",
	"end",
	"text",
	"lastChar",
	"lastNeed",
	"lastTotal"
]) {
	const descriptor = Object.getOwnPropertyDescriptor(StringDecoder.prototype, name);
	if (descriptor) Object.defineProperty(StringDecoder.prototype, name, {
		...descriptor,
		enumerable: true
	});
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/keypress.js
const { kEscape } = CSI;
const states = /* @__PURE__ */ new WeakMap();
const ESCAPE_CODE_TIMEOUT$1 = 500;
/**
* accepts a readable Stream instance and makes it emit "keypress" events
*/
function emitKeypressEvents(stream, iface = {}) {
	if (states.has(stream)) return;
	const state = {
		decoder: new StringDecoder("utf8"),
		escape: emitKeys(stream)
	};
	states.set(stream, state);
	state.escape = emitKeys(stream);
	state.escape.next();
	const triggerEscape = () => state.escape.next("");
	const { escapeCodeTimeout = ESCAPE_CODE_TIMEOUT$1 } = iface;
	let timeoutId;
	function onData(input) {
		if (stream.listenerCount("keypress") > 0) {
			const string = state.decoder.write(input);
			if (string) {
				if (timeoutId !== void 0) clearTimeout(timeoutId);
				iface[kSawKeyPress] = charLengthAt(string, 0) === string.length;
				iface.isCompletionEnabled = false;
				let length = 0;
				for (const character of string) {
					length += character.length;
					if (length === string.length) iface.isCompletionEnabled = true;
					try {
						state.escape.next(character);
						if (length === string.length && character === kEscape) {
							if (typeof setTimeout !== "function") throw unsupportedNodeApi("readline escapeCodeTimeout", "this engine does not provide timers");
							timeoutId = setTimeout(triggerEscape, escapeCodeTimeout);
						}
					} catch (err) {
						state.escape = emitKeys(stream);
						state.escape.next();
						throw err;
					}
				}
			}
		} else {
			stream.removeListener("data", onData);
			stream.on("newListener", onNewListener);
		}
	}
	function onNewListener(event) {
		if (event === "keypress") {
			stream.on("data", onData);
			stream.removeListener("newListener", onNewListener);
		}
	}
	if (stream.listenerCount("keypress") > 0) stream.on("data", onData);
	else stream.on("newListener", onNewListener);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/history.js
var History = class {
	context;
	history;
	index = -1;
	size;
	isFlushing = false;
	removeHistoryDuplicates;
	constructor(context, options = {}) {
		this.context = context;
		if (options.history !== void 0 && !Array.isArray(options.history)) throw invalidArgType("history", "Array", options.history);
		if (options.size !== void 0) {
			if (typeof options.size !== "number") throw invalidArgType("size", "number", options.size);
			if (options.size < 0) throw outOfRange("size", ">= 0", options.size);
		}
		this.history = options.history ?? [];
		this.size = options.size ?? 30;
		this.removeHistoryDuplicates = options.removeHistoryDuplicates || false;
	}
	addHistory(isMultiline, lastCommandErrored) {
		const line = this.context.line;
		if (line.length === 0) return "";
		if (this.size === 0) return line;
		if (line.trim().length === 0) return line;
		if (isMultiline && this.index === -1) this.history.shift();
		else if (lastCommandErrored) this.history.shift();
		const normalizedLine = reverseString(line, "\n", "\r");
		if (this.history.length === 0 || this.history[0] !== normalizedLine) {
			if (this.removeHistoryDuplicates) {
				const dupIndex = this.history.indexOf(normalizedLine);
				if (dupIndex !== -1) this.history.splice(dupIndex, 1);
			}
			this.history.unshift(normalizedLine);
			if (this.history.length > this.size) this.history.pop();
		}
		this.index = -1;
		const finalLine = isMultiline ? reverseString(this.history[0]) : this.history[0];
		this.context.emit("history", this.history);
		return finalLine;
	}
	canNavigateToNext() {
		return this.index > -1 && this.history.length > 0;
	}
	navigateToNext(substringSearch) {
		if (!this.canNavigateToNext()) return null;
		const search = substringSearch || "";
		let index = this.index - 1;
		while (index >= 0 && (!this.history[index].startsWith(search) || this.context.line === this.history[index])) index--;
		this.index = index;
		if (index === -1) return search;
		return reverseString(this.history[index], "\r", "\n");
	}
	canNavigateToPrevious() {
		return this.history.length !== this.index && this.history.length > 0;
	}
	navigateToPrevious(substringSearch = "") {
		if (!this.canNavigateToPrevious()) return null;
		const search = substringSearch || "";
		let index = this.index + 1;
		while (index < this.history.length && (!this.history[index].startsWith(search) || this.context.line === this.history[index])) index++;
		this.index = index;
		if (index === this.history.length) return search;
		return reverseString(this.history[index], "\r", "\n");
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/display.js
function isZeroWidthCodePoint(code) {
	return code <= 31 || code >= 127 && code <= 159 || code >= 768 && code <= 879 || code >= 8203 && code <= 8207 || code >= 8400 && code <= 8447 || code >= 65024 && code <= 65039 || code >= 65056 && code <= 65071 || code >= 917760 && code <= 917999;
}
function getStringWidth(str, removeControlChars = true) {
	let width = 0;
	if (removeControlChars) str = stripVTControlCharacters(str);
	if (typeof str.normalize === "function") str = str.normalize("NFC");
	for (const char of str) {
		const code = char.codePointAt(0);
		if (isFullWidthCodePoint(code)) width += 2;
		else if (!isZeroWidthCodePoint(code)) width++;
	}
	return width;
}
/**
* Returns true if the character represented by a given
* Unicode code point is full-width. Otherwise returns false.
* @param {string} code
* @returns {boolean}
*/
const isFullWidthCodePoint = (code) => {
	return code >= 4352 && (code <= 4447 || code === 9001 || code === 9002 || code >= 11904 && code <= 12871 && code !== 12351 || code >= 12880 && code <= 19903 || code >= 19968 && code <= 42182 || code >= 43360 && code <= 43388 || code >= 44032 && code <= 55203 || code >= 63744 && code <= 64255 || code >= 65040 && code <= 65049 || code >= 65072 && code <= 65131 || code >= 65281 && code <= 65376 || code >= 65504 && code <= 65510 || code >= 110592 && code <= 110593 || code >= 127488 && code <= 127569 || code >= 127744 && code <= 128591 || code >= 131072 && code <= 262141);
};
function stripVTControlCharacters(str) {
	return str.replace(ansi, "");
}
const ansi = /* @__PURE__ */ new RegExp("[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/\\#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/\\#&.:=?%@~_]*)*)?(?:\\u0007|\\u001B\\u005C|\\u009C))|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))", "g");
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/iterator.js
/** Event-backed iterator with Node's 1024-line water mark and close-on-return contract. */
function lineIterator(rl) {
	const lines = [];
	const pending = [];
	let finished = !!rl.closed;
	let paused = false;
	function onLine(line) {
		if (pending.length) pending.shift()({
			value: line,
			done: false
		});
		else {
			lines.push(line);
			if (lines.length > 1024 && !paused) {
				paused = true;
				rl.pause();
			}
		}
	}
	function cleanup() {
		finished = true;
		rl.removeListener("line", onLine);
		rl.removeListener("close", cleanup);
		while (pending.length) pending.shift()({
			value: void 0,
			done: true
		});
	}
	if (!finished) {
		rl.on("line", onLine);
		rl.on("close", cleanup);
	}
	return {
		[Symbol.asyncIterator]() {
			return this;
		},
		next() {
			if (lines.length) {
				const value = lines.shift();
				if (paused && lines.length < 1 && !finished) {
					paused = false;
					rl.resume();
				}
				return Promise.resolve({
					value,
					done: false
				});
			}
			if (finished) return Promise.resolve({
				value: void 0,
				done: true
			});
			return new Promise((resolve) => pending.push(resolve));
		},
		return() {
			lines.length = 0;
			cleanup();
			rl.close();
			return Promise.resolve({
				value: void 0,
				done: true
			});
		},
		throw(error) {
			lines.length = 0;
			cleanup();
			rl.close();
			return Promise.reject(error);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/interface.js
var interface_exports = /* @__PURE__ */ __exportAll({
	InterfaceCore: () => InterfaceCore,
	kAddHistory: () => kAddHistory,
	kAddNewLineOnTTY: () => kAddNewLineOnTTY,
	kBeforeEdit: () => kBeforeEdit,
	kDecoder: () => kDecoder,
	kDeleteLeft: () => kDeleteLeft,
	kDeleteLineLeft: () => kDeleteLineLeft,
	kDeleteLineRight: () => kDeleteLineRight,
	kDeleteRight: () => kDeleteRight,
	kDeleteWordLeft: () => kDeleteWordLeft,
	kDeleteWordRight: () => kDeleteWordRight,
	kGetDisplayPos: () => kGetDisplayPos,
	kHistoryNext: () => kHistoryNext,
	kHistoryPrev: () => kHistoryPrev,
	kInsertString: () => kInsertString,
	kIsMultiline: () => kIsMultiline,
	kKillRing: () => kKillRing,
	kKillRingCursor: () => kKillRingCursor,
	kLastCommandErrored: () => kLastCommandErrored,
	kLine: () => kLine,
	kLineObjectStream: () => kLineObjectStream,
	kLine_buffer: () => kLine_buffer,
	kMoveCursor: () => kMoveCursor,
	kMoveDownOrHistoryNext: () => kMoveDownOrHistoryNext,
	kMoveUpOrHistoryPrev: () => kMoveUpOrHistoryPrev,
	kMultilineMove: () => kMultilineMove,
	kMultilinePrompt: () => kMultilinePrompt,
	kNormalWrite: () => kNormalWrite,
	kOldPrompt: () => kOldPrompt,
	kOnLine: () => kOnLine,
	kPreviousCursor: () => kPreviousCursor,
	kPreviousCursorCols: () => kPreviousCursorCols,
	kPreviousKey: () => kPreviousKey,
	kPreviousLine: () => kPreviousLine,
	kPreviousPrevRows: () => kPreviousPrevRows,
	kPrompt: () => kPrompt,
	kPushToKillRing: () => kPushToKillRing,
	kPushToUndoStack: () => kPushToUndoStack,
	kQuestion: () => kQuestion,
	kQuestionCallback: () => kQuestionCallback,
	kQuestionCancel: () => kQuestionCancel,
	kQuestionReject: () => kQuestionReject,
	kRedo: () => kRedo,
	kRedoStack: () => kRedoStack,
	kRefreshLine: () => kRefreshLine,
	kRestorePreviousState: () => kRestorePreviousState,
	kSavePreviousState: () => kSavePreviousState,
	kSawKeyPress: () => kSawKeyPress,
	kSawReturnAt: () => kSawReturnAt,
	kSetLine: () => kSetLine,
	kSetRawMode: () => kSetRawMode,
	kTabComplete: () => kTabComplete,
	kTabCompleter: () => kTabCompleter,
	kTtyWrite: () => kTtyWrite,
	kUndo: () => kUndo,
	kUndoStack: () => kUndoStack,
	kWordLeft: () => kWordLeft,
	kWordRight: () => kWordRight,
	kWriteToOutput: () => kWriteToOutput,
	kYank: () => kYank,
	kYankPop: () => kYankPop,
	kYanking: () => kYanking
});
const EventEmitter = import_events.EventEmitter;
const kEmptyObject = Object.freeze({});
const kMaxUndoRedoStackSize = 2048;
const kMincrlfDelay = 100;
/**
* The end of a line is signaled by either one of the following:
*  - \r\n
*  - \n
*  - \r followed by something other than \n
*  - \u2028 (Unicode 'LINE SEPARATOR')
*  - \u2029 (Unicode 'PARAGRAPH SEPARATOR')
*/
const lineEnding = /\r?\n|\r(?!\n)|\u2028|\u2029/g;
const kLineObjectStream = Symbol("line object stream");
const kQuestionCancel = Symbol("kQuestionCancel");
const kQuestion = Symbol("kQuestion");
const ESCAPE_CODE_TIMEOUT = 500;
const kMaxLengthOfKillRing = 32;
const kMultilinePrompt = Symbol("| ");
const kAddHistory = Symbol("_addHistory");
const kBeforeEdit = Symbol("_beforeEdit");
const kDecoder = Symbol("_decoder");
const kDeleteLeft = Symbol("_deleteLeft");
const kDeleteLineLeft = Symbol("_deleteLineLeft");
const kDeleteLineRight = Symbol("_deleteLineRight");
const kDeleteRight = Symbol("_deleteRight");
const kDeleteWordLeft = Symbol("_deleteWordLeft");
const kDeleteWordRight = Symbol("_deleteWordRight");
const kGetDisplayPos = Symbol("_getDisplayPos");
const kHistoryNext = Symbol("_historyNext");
const kMoveDownOrHistoryNext = Symbol("_moveDownOrHistoryNext");
const kHistoryPrev = Symbol("_historyPrev");
const kMoveUpOrHistoryPrev = Symbol("_moveUpOrHistoryPrev");
const kInsertString = Symbol("_insertString");
const kLine = Symbol("_line");
const kLine_buffer = Symbol("_line_buffer");
const kKillRing = Symbol("_killRing");
const kKillRingCursor = Symbol("_killRingCursor");
const kMoveCursor = Symbol("_moveCursor");
const kNormalWrite = Symbol("_normalWrite");
const kOldPrompt = Symbol("_oldPrompt");
const kOnLine = Symbol("_onLine");
const kSetLine = Symbol("_setLine");
const kPreviousKey = Symbol("_previousKey");
const kPrompt = Symbol("_prompt");
const kPushToKillRing = Symbol("_pushToKillRing");
const kPushToUndoStack = Symbol("_pushToUndoStack");
const kQuestionCallback = Symbol("_questionCallback");
const kLastCommandErrored = Symbol("_lastCommandErrored");
const kQuestionReject = Symbol("_questionReject");
const kRedo = Symbol("_redo");
const kRedoStack = Symbol("_redoStack");
const kRefreshLine = Symbol("_refreshLine");
const kSawKeyPress = Symbol("_sawKeyPress");
const kSawReturnAt = Symbol("_sawReturnAt");
const kSetRawMode = Symbol("_setRawMode");
const kTabComplete = Symbol("_tabComplete");
const kTabCompleter = Symbol("_tabCompleter");
const kTtyWrite = Symbol("_ttyWrite");
const kUndo = Symbol("_undo");
const kUndoStack = Symbol("_undoStack");
const kIsMultiline = Symbol("_isMultiline");
const kWordLeft = Symbol("_wordLeft");
const kWordRight = Symbol("_wordRight");
const kWriteToOutput = Symbol("_writeToOutput");
const kYank = Symbol("_yank");
const kYanking = Symbol("_yanking");
const kYankPop = Symbol("_yankPop");
const kSavePreviousState = Symbol("_savePreviousState");
const kRestorePreviousState = Symbol("_restorePreviousState");
const kPreviousLine = Symbol("_previousLine");
const kPreviousCursor = Symbol("_previousCursor");
const kPreviousCursorCols = Symbol("_previousCursorCols");
const kMultilineMove = Symbol("_multilineMove");
const kPreviousPrevRows = Symbol("_previousPrevRows");
const kAddNewLineOnTTY = Symbol("_addNewLineOnTTY");
var InterfaceCore = class extends EventEmitter {
	input;
	output;
	line = "";
	terminal;
	crlfDelay;
	completer;
	escapeCodeTimeout = ESCAPE_CODE_TIMEOUT;
	tabSize = 8;
	isCompletionEnabled = true;
	historyManager;
	constructor(inputOrOptions, output, completer, terminal) {
		super();
		this[kSawReturnAt] = 0;
		this[kSawKeyPress] = false;
		this[kPreviousKey] = null;
		let input;
		let prompt = "> ";
		let signal;
		let crlfDelay;
		let historyOptions = {};
		if (inputOrOptions && "input" in inputOrOptions && inputOrOptions.input) {
			const options = inputOrOptions;
			input = options.input;
			output = options.output;
			completer = options.completer;
			terminal = options.terminal;
			signal = options.signal;
			crlfDelay = options.crlfDelay;
			if (options.prompt !== void 0) prompt = options.prompt;
			if (options.tabSize !== void 0) {
				validateUint32(options.tabSize, "tabSize", true);
				this.tabSize = options.tabSize;
			}
			if (options.escapeCodeTimeout !== void 0) {
				if (!Number.isFinite(options.escapeCodeTimeout)) throw invalidArgValue("input.escapeCodeTimeout", this.escapeCodeTimeout);
				this.escapeCodeTimeout = options.escapeCodeTimeout;
			}
			if (signal) validateAbortSignal(signal, "options.signal");
			historyOptions = {
				size: options.historySize,
				history: options.history,
				removeHistoryDuplicates: options.removeHistoryDuplicates
			};
		} else input = inputOrOptions;
		this.historyManager = new History(this, historyOptions);
		for (const [name, property] of [
			["history", "history"],
			["historyIndex", "index"],
			["historySize", "size"],
			["isFlushing", "isFlushing"]
		]) Object.defineProperty(this, name, {
			configurable: true,
			enumerable: true,
			get: () => this.historyManager[property],
			...property === "history" || property === "index" ? { set: (value) => {
				if (property === "history") this.historyManager.history = value;
				else this.historyManager.index = value;
			} } : {}
		});
		if (completer !== void 0 && typeof completer !== "function") throw invalidArgValue("completer", completer);
		if (terminal === void 0 && output != null) terminal = !!output.isTTY;
		const self = this;
		this.line = "";
		this[kIsMultiline] = false;
		this[kSubstringSearch] = null;
		this.output = output;
		this.input = input;
		this[kUndoStack] = [];
		this[kRedoStack] = [];
		this[kPreviousCursorCols] = -1;
		this[kKillRing] = [];
		this[kKillRingCursor] = 0;
		this.crlfDelay = crlfDelay ? Math.max(kMincrlfDelay, crlfDelay) : kMincrlfDelay;
		this.completer = completer;
		this.setPrompt(prompt);
		this.terminal = !!terminal;
		function onerror(err) {
			self.emit("error", err);
		}
		function ondata(data) {
			self[kNormalWrite](data);
		}
		function onend() {
			if (typeof self[kLine_buffer] === "string" && self[kLine_buffer].length > 0) self.emit("line", self[kLine_buffer]);
			self.close();
		}
		function ontermend() {
			if (typeof self.line === "string" && self.line.length > 0) self.emit("line", self.line);
			self.close();
		}
		function onkeypress(s, key) {
			self[kTtyWrite](s, key);
			if (key?.sequence) {
				const ch = key.sequence.codePointAt(0);
				if (ch >= 55296 && ch <= 57343) self[kRefreshLine]();
			}
		}
		function onresize() {
			self[kRefreshLine]();
		}
		this[kLineObjectStream] = void 0;
		input.on("error", onerror);
		if (!this.terminal) {
			function onSelfCloseWithoutTerminal() {
				input.removeListener("data", ondata);
				input.removeListener("error", onerror);
				input.removeListener("end", onend);
			}
			input.on("data", ondata);
			input.on("end", onend);
			self.once("close", onSelfCloseWithoutTerminal);
			this[kDecoder] = new StringDecoder("utf8");
		} else {
			function onSelfCloseWithTerminal() {
				input.removeListener("keypress", onkeypress);
				input.removeListener("error", onerror);
				input.removeListener("end", ontermend);
				if (output !== null && output !== void 0) output.removeListener?.("resize", onresize);
			}
			emitKeypressEvents(input, this);
			input.on("keypress", onkeypress);
			input.on("end", ontermend);
			this[kSetRawMode](true);
			this.terminal = true;
			this.cursor = 0;
			if (output !== null && output !== void 0) output.on?.("resize", onresize);
			self.once("close", onSelfCloseWithTerminal);
		}
		if (signal) {
			const onAborted = () => self.close();
			if (signal.aborted) defer(onAborted);
			else {
				const disposable = addAbortListener(signal, onAborted);
				self.once("close", disposable[Symbol.dispose]);
			}
		}
		this[kSetLine]("");
		input.resume();
	}
	get columns() {
		if (this.output?.columns) return this.output.columns;
		return Infinity;
	}
	/**
	* Sets the prompt written to the output.
	* @param {string} prompt
	* @returns {void}
	*/
	setPrompt(prompt) {
		this[kPrompt] = prompt;
	}
	/**
	* Returns the current prompt used by `rl.prompt()`.
	* @returns {string}
	*/
	getPrompt() {
		return this[kPrompt];
	}
	[kSetRawMode](mode) {
		const wasInRawMode = this.input.isRaw;
		if (typeof this.input.setRawMode === "function") this.input.setRawMode(mode);
		return wasInRawMode;
	}
	/**
	* Writes the configured `prompt` to a new line in `output`.
	* @param {boolean} [preserveCursor]
	* @returns {void}
	*/
	prompt(preserveCursor) {
		if (this.paused) this.resume();
		if (this.terminal) {
			if (!preserveCursor) this.cursor = 0;
			this[kRefreshLine]();
		} else this[kWriteToOutput](this[kPrompt]);
	}
	[kQuestion](query, cb) {
		if (this.closed) throw codedError(/* @__PURE__ */ new Error("readline was closed"), "ERR_USE_AFTER_CLOSE");
		if (this[kQuestionCallback]) this.prompt();
		else {
			this[kOldPrompt] = this[kPrompt];
			this.setPrompt(query);
			this[kQuestionCallback] = cb;
			this.prompt();
		}
	}
	[kSetLine](line = "") {
		this.line = line;
		this[kIsMultiline] = line.includes("\n");
	}
	[kOnLine](line) {
		if (this[kQuestionCallback]) {
			const cb = this[kQuestionCallback];
			this[kQuestionCallback] = null;
			this.setPrompt(this[kOldPrompt]);
			cb(line);
		} else this.emit("line", line);
	}
	[kBeforeEdit](oldText, oldCursor) {
		this[kPushToUndoStack](oldText, oldCursor);
	}
	[kQuestionCancel]() {
		if (this[kQuestionCallback]) {
			this[kQuestionCallback] = null;
			this.setPrompt(this[kOldPrompt]);
			this.clearLine();
		}
	}
	[kWriteToOutput](stringToWrite) {
		validateString(stringToWrite, "stringToWrite");
		if (this.output !== null && this.output !== void 0) this.output.write(stringToWrite);
	}
	[kAddHistory]() {
		return this.historyManager.addHistory(this[kIsMultiline], this[kLastCommandErrored]);
	}
	[kRefreshLine]() {
		const line = this[kPrompt] + this.line;
		const dispPos = this[kGetDisplayPos](line);
		const lineCols = dispPos.cols;
		const lineRows = dispPos.rows;
		const cursorPos = this.getCursorPos();
		const prevRows = this.prevRows || 0;
		if (prevRows > 0) moveCursor(this.output, 0, -prevRows);
		cursorTo(this.output, 0);
		clearScreenDown(this.output);
		if (this[kIsMultiline]) {
			const lines = this.line.split("\n");
			this[kWriteToOutput](this[kPrompt] + lines[0]);
			for (let i = 1; i < lines.length; i++) this[kWriteToOutput](`\n${kMultilinePrompt.description}` + lines[i]);
		} else this[kWriteToOutput](line);
		if (lineCols === 0) this[kWriteToOutput](" ");
		cursorTo(this.output, cursorPos.cols);
		const diff = lineRows - cursorPos.rows;
		if (diff > 0) moveCursor(this.output, 0, -diff);
		this.prevRows = cursorPos.rows;
	}
	/**
	* Closes the `readline.Interface` instance.
	* @returns {void}
	*/
	close() {
		if (this.closed) return;
		this.pause();
		if (this.terminal) this[kSetRawMode](false);
		this.closed = true;
		this.emit("close");
	}
	/**
	* Pauses the `input` stream.
	* @returns {void | Interface}
	*/
	pause() {
		if (this.closed) throw codedError(/* @__PURE__ */ new Error("readline was closed"), "ERR_USE_AFTER_CLOSE");
		if (this.paused) return;
		this.input.pause();
		this.paused = true;
		this.emit("pause");
		return this;
	}
	/**
	* Resumes the `input` stream if paused.
	* @returns {void | Interface}
	*/
	resume() {
		if (this.closed) throw codedError(/* @__PURE__ */ new Error("readline was closed"), "ERR_USE_AFTER_CLOSE");
		if (!this.paused) return;
		this.input.resume();
		this.paused = false;
		this.emit("resume");
		return this;
	}
	/**
	* Writes either `data` or a `key` sequence identified by
	* `key` to the `output`.
	* @param {string} d
	* @param {{
	*   ctrl?: boolean;
	*   meta?: boolean;
	*   shift?: boolean;
	*   name?: string;
	*   }} [key]
	* @returns {void}
	*/
	write(d, key) {
		if (this.closed) throw codedError(/* @__PURE__ */ new Error("readline was closed"), "ERR_USE_AFTER_CLOSE");
		if (this.paused) this.resume();
		if (this.terminal) this[kTtyWrite](d, key);
		else this[kNormalWrite](d);
	}
	[kNormalWrite](b) {
		if (b === void 0) return;
		if (b === null) throw invalidArgType("buf", [
			"Buffer",
			"TypedArray",
			"DataView"
		], b);
		let string = this[kDecoder].write(b);
		if (this[kSawReturnAt] && Date.now() - this[kSawReturnAt] <= this.crlfDelay) {
			if (string.codePointAt(0) === 10) string = string.slice(1);
			this[kSawReturnAt] = 0;
		}
		if (!string) return;
		const lines = string.includes("\r") || string.includes("\u2028") || string.includes("\u2029") ? lineEnding[Symbol.split](string) : string.split("\n");
		const lastIndex = lines.length - 1;
		if (lastIndex === 0) {
			if (this[kLine_buffer]) this[kLine_buffer] += string;
			else this[kLine_buffer] = string;
			return;
		}
		this[kSawReturnAt] = string.endsWith("\r") ? Date.now() : 0;
		let first = lines[0];
		if (this[kLine_buffer]) first = this[kLine_buffer] + first;
		this[kLine_buffer] = lines[lastIndex];
		this[kOnLine](first);
		for (let i = 1; i < lastIndex; i++) this[kOnLine](lines[i]);
	}
	[kInsertString](c) {
		this[kBeforeEdit](this.line, this.cursor);
		if (!this.isCompletionEnabled) {
			if (this.cursor < this.line.length) {
				const beg = this.line.slice(0, this.cursor);
				const end = this.line.slice(this.cursor, this.line.length);
				this.line = beg + c + end;
			} else this.line += c;
			this.cursor += c.length;
			this[kWriteToOutput](c);
			return;
		}
		if (this.cursor < this.line.length) {
			const beg = this.line.slice(0, this.cursor);
			const end = this.line.slice(this.cursor, this.line.length);
			this[kSetLine](beg + c + end);
			this.cursor += c.length;
			this[kRefreshLine]();
		} else {
			const oldPos = this.getCursorPos();
			this.line += c;
			this.cursor += c.length;
			const newPos = this.getCursorPos();
			if (oldPos.rows < newPos.rows) this[kRefreshLine]();
			else this[kWriteToOutput](c);
		}
	}
	async [kTabComplete](lastKeypressWasTab) {
		this.pause();
		const string = this.line.slice(0, this.cursor);
		let value;
		try {
			value = await this.completer(string);
		} catch (err) {
			this[kWriteToOutput](`Tab completion error: ${inspect(err)}`);
			return;
		} finally {
			this.resume();
		}
		this[kTabCompleter](lastKeypressWasTab, value);
	}
	[kTabCompleter](lastKeypressWasTab, [completions, completeOn]) {
		if (!completions || completions.length === 0) return;
		const prefix = commonPrefix(completions.filter((e) => e !== ""));
		if (prefix.startsWith(completeOn) && prefix.length > completeOn.length) {
			this[kInsertString](prefix.slice(completeOn.length));
			return;
		} else if (!completeOn.startsWith(prefix)) {
			this[kSetLine](this.line.slice(0, this.cursor - completeOn.length) + prefix + this.line.slice(this.cursor, this.line.length));
			this.cursor = this.cursor - completeOn.length + prefix.length;
			this[kRefreshLine]();
			return;
		}
		if (!lastKeypressWasTab) return;
		this[kBeforeEdit](this.line, this.cursor);
		const completionsWidth = completions.map((e) => getStringWidth(e));
		const width = Math.max(...completionsWidth) + 2;
		let maxColumns = Math.floor(this.columns / width) || 1;
		if (maxColumns === Infinity) maxColumns = 1;
		let output = "\r\n";
		let lineIndex = 0;
		let whitespace = 0;
		for (let i = 0; i < completions.length; i++) {
			const completion = completions[i];
			if (completion === "" || lineIndex === maxColumns) {
				output += "\r\n";
				lineIndex = 0;
				whitespace = 0;
			} else output += " ".repeat(whitespace);
			if (completion !== "") {
				output += completion;
				whitespace = width - completionsWidth[i];
				lineIndex++;
			} else output += "\r\n";
		}
		if (lineIndex !== 0) output += "\r\n\r\n";
		this[kWriteToOutput](output);
		this[kRefreshLine]();
	}
	[kWordLeft]() {
		if (this.cursor > 0) {
			const leading = this.line.slice(0, this.cursor);
			const reversed = Array.from(leading).reverse().join("");
			const match = /^\s*(?:[^\w\s]+|\w+)?/.exec(reversed);
			this[kMoveCursor](-match[0].length);
		}
	}
	[kWordRight]() {
		if (this.cursor < this.line.length) {
			const trailing = this.line.slice(this.cursor);
			const match = /^(?:\s+|[^\w\s]+|\w+)\s*/.exec(trailing);
			this[kMoveCursor](match[0].length);
		}
	}
	[kDeleteLeft]() {
		if (this.cursor > 0 && this.line.length > 0) {
			this[kBeforeEdit](this.line, this.cursor);
			const charSize = charLengthLeft(this.line, this.cursor);
			this.line = this.line.slice(0, this.cursor - charSize) + this.line.slice(this.cursor, this.line.length);
			this.cursor -= charSize;
			this[kRefreshLine]();
		}
	}
	[kDeleteRight]() {
		if (this.cursor < this.line.length) {
			this[kBeforeEdit](this.line, this.cursor);
			const charSize = charLengthAt(this.line, this.cursor);
			this.line = this.line.slice(0, this.cursor) + this.line.slice(this.cursor + charSize, this.line.length);
			this[kRefreshLine]();
		}
	}
	[kDeleteWordLeft]() {
		if (this.cursor > 0) {
			this[kBeforeEdit](this.line, this.cursor);
			let leading = this.line.slice(0, this.cursor);
			const reversed = Array.from(leading).reverse().join("");
			const match = /^\s*(?:[^\w\s]+|\w+)?/.exec(reversed);
			leading = leading.slice(0, leading.length - match[0].length);
			this.line = leading + this.line.slice(this.cursor, this.line.length);
			this.cursor = leading.length;
			this[kRefreshLine]();
		}
	}
	[kDeleteWordRight]() {
		if (this.cursor < this.line.length) {
			this[kBeforeEdit](this.line, this.cursor);
			const trailing = this.line.slice(this.cursor);
			const match = /^(?:\s+|\W+|\w+)\s*/.exec(trailing);
			this.line = this.line.slice(0, this.cursor) + trailing.slice(match[0].length);
			this[kRefreshLine]();
		}
	}
	[kDeleteLineLeft]() {
		this[kBeforeEdit](this.line, this.cursor);
		const del = this.line.slice(0, this.cursor);
		this[kSetLine](this.line.slice(this.cursor));
		this.cursor = 0;
		this[kPushToKillRing](del);
		this[kRefreshLine]();
	}
	[kDeleteLineRight]() {
		this[kBeforeEdit](this.line, this.cursor);
		const del = this.line.slice(this.cursor);
		this[kSetLine](this.line.slice(0, this.cursor));
		this[kPushToKillRing](del);
		this[kRefreshLine]();
	}
	[kPushToKillRing](del) {
		if (!del || del === this[kKillRing][0]) return;
		this[kKillRing].unshift(del);
		this[kKillRingCursor] = 0;
		while (this[kKillRing].length > kMaxLengthOfKillRing) this[kKillRing].pop();
	}
	[kYank]() {
		if (this[kKillRing].length > 0) {
			this[kYanking] = true;
			this[kInsertString](this[kKillRing][this[kKillRingCursor]]);
		}
	}
	[kYankPop]() {
		if (!this[kYanking]) return;
		if (this[kKillRing].length > 1) {
			const lastYank = this[kKillRing][this[kKillRingCursor]];
			this[kKillRingCursor]++;
			if (this[kKillRingCursor] >= this[kKillRing].length) this[kKillRingCursor] = 0;
			const currentYank = this[kKillRing][this[kKillRingCursor]];
			const head = this.line.slice(0, this.cursor - lastYank.length);
			const tail = this.line.slice(this.cursor);
			this[kSetLine](head + currentYank + tail);
			this.cursor = head.length + currentYank.length;
			this[kRefreshLine]();
		}
	}
	[kSavePreviousState]() {
		this[kPreviousLine] = this.line;
		this[kPreviousCursor] = this.cursor;
		this[kPreviousPrevRows] = this.prevRows;
	}
	[kRestorePreviousState]() {
		this[kSetLine](this[kPreviousLine]);
		this.cursor = this[kPreviousCursor];
		this.prevRows = this[kPreviousPrevRows];
	}
	clearLine() {
		this[kMoveCursor](Infinity);
		this[kWriteToOutput]("\r\n");
		this[kSetLine]("");
		this.cursor = 0;
		this.prevRows = 0;
	}
	[kLine]() {
		this[kSavePreviousState]();
		const line = this[kAddHistory]();
		this[kUndoStack] = [];
		this[kRedoStack] = [];
		this.clearLine();
		this[kOnLine](line);
	}
	[kAddNewLineOnTTY]() {
		this[kRestorePreviousState]();
		const originalLine = this.line;
		const beforeCursor = this.line.slice(0, this.cursor);
		let afterCursor = this.line.slice(this.cursor, this.line.length);
		this[kSetLine](`${beforeCursor}\n${afterCursor}`);
		this.cursor += 1;
		const hasContentAfterCursor = afterCursor.length > 0;
		const cursorIsNotOnFirstLine = this.prevRows > 0;
		let needsRewriteFirstLine = false;
		if (hasContentAfterCursor) {
			const splitBeg = beforeCursor.split("\n");
			needsRewriteFirstLine = splitBeg.length < 2;
			if (cursorIsNotOnFirstLine) {
				const dy = afterCursor.split("\n").length + 1;
				const dxEndOfLineAbove = (splitBeg[splitBeg.length - 2] || "").length + kMultilinePrompt.description.length;
				moveCursor(this.output, dxEndOfLineAbove, -dy);
				afterCursor = `${splitBeg[splitBeg.length - 1]}\n${afterCursor}`;
			} else {
				const dy = originalLine.split("\n").length;
				moveCursor(this.output, 0, -dy);
			}
			clearScreenDown(this.output);
			if (cursorIsNotOnFirstLine) this[kWriteToOutput]("\n");
		}
		if (needsRewriteFirstLine) this[kWriteToOutput](`${this[kPrompt]}${beforeCursor}\n${kMultilinePrompt.description}`);
		else this[kWriteToOutput](kMultilinePrompt.description);
		if (hasContentAfterCursor) {
			const oldCursor = this.getCursorPos();
			const formattedEndContent = afterCursor.replaceAll("\n", `\n${kMultilinePrompt.description}`);
			this[kWriteToOutput](formattedEndContent);
			const newCursor = this[kGetDisplayPos](this.line);
			moveCursor(this.output, oldCursor.cols - newCursor.cols, oldCursor.rows - newCursor.rows);
			this.prevRows = oldCursor.rows;
		} else this.prevRows = this.line.split("\n").length - 1;
	}
	[kPushToUndoStack](text, cursor) {
		if (this[kUndoStack].push({
			text,
			cursor
		}) > kMaxUndoRedoStackSize) this[kUndoStack].shift();
	}
	[kUndo]() {
		if (this[kUndoStack].length <= 0) return;
		this[kRedoStack].push({
			text: this.line,
			cursor: this.cursor
		});
		const entry = this[kUndoStack].pop();
		this[kSetLine](entry.text);
		this.cursor = entry.cursor;
		this[kRefreshLine]();
	}
	[kRedo]() {
		if (this[kRedoStack].length <= 0) return;
		this[kUndoStack].push({
			text: this.line,
			cursor: this.cursor
		});
		const entry = this[kRedoStack].pop();
		this[kSetLine](entry.text);
		this.cursor = entry.cursor;
		this[kRefreshLine]();
	}
	[kMultilineMove](direction, splitLines, { rows, cols }) {
		const curr = splitLines[rows];
		const down = direction === 1;
		const adj = splitLines[rows + direction];
		const promptLen = kMultilinePrompt.description.length;
		let amountToMove;
		const clamp = down ? curr.length - cols + promptLen + adj.length + 1 : -cols + 1;
		if (cols > adj.length + 1) {
			if (this[kPreviousCursorCols] === -1) this[kPreviousCursorCols] = cols;
			amountToMove = clamp;
		} else {
			if (down) amountToMove = curr.length + 1;
			else amountToMove = -adj.length - 1;
			if (this[kPreviousCursorCols] !== -1) {
				if (this[kPreviousCursorCols] <= adj.length) {
					amountToMove += this[kPreviousCursorCols] - cols;
					this[kPreviousCursorCols] = -1;
				} else amountToMove = clamp;
			}
		}
		this[kMoveCursor](amountToMove);
	}
	[kMoveDownOrHistoryNext]() {
		const cursorPos = this.getCursorPos();
		const splitLines = this.line.split("\n");
		if (this[kIsMultiline] && cursorPos.rows < splitLines.length - 1) {
			this[kMultilineMove](1, splitLines, cursorPos);
			return;
		}
		this[kPreviousCursorCols] = -1;
		this[kHistoryNext]();
	}
	[kHistoryNext]() {
		if (!this.historyManager.canNavigateToNext()) return;
		this[kBeforeEdit](this.line, this.cursor);
		this[kSetLine](this.historyManager.navigateToNext(this[kSubstringSearch]));
		this.cursor = this.line.length;
		this[kRefreshLine]();
	}
	[kMoveUpOrHistoryPrev]() {
		const cursorPos = this.getCursorPos();
		if (this[kIsMultiline] && cursorPos.rows > 0) {
			const splitLines = this.line.split("\n");
			this[kMultilineMove](-1, splitLines, cursorPos);
			return;
		}
		this[kPreviousCursorCols] = -1;
		this[kHistoryPrev]();
	}
	[kHistoryPrev]() {
		if (!this.historyManager.canNavigateToPrevious()) return;
		this[kBeforeEdit](this.line, this.cursor);
		this[kSetLine](this.historyManager.navigateToPrevious(this[kSubstringSearch]));
		this.cursor = this.line.length;
		this[kRefreshLine]();
	}
	[kGetDisplayPos](str) {
		let offset = 0;
		const col = this.columns;
		let rows = 0;
		str = stripVTControlCharacters(str);
		for (const char of str) {
			if (char === "\n") {
				rows += Math.ceil(offset / col) || 1;
				offset = this[kIsMultiline] ? kMultilinePrompt.description.length : 0;
				continue;
			}
			if (char === "	") {
				offset += this.tabSize - offset % this.tabSize;
				continue;
			}
			const width = getStringWidth(char, false);
			if (width === 0 || width === 1) offset += width;
			else {
				if ((offset + 1) % col === 0) offset++;
				offset += 2;
			}
		}
		const cols = offset % col;
		rows += (offset - cols) / col;
		return {
			cols,
			rows
		};
	}
	/**
	* Returns the real position of the cursor in relation
	* to the input prompt + string.
	* @returns {{
	*   rows: number;
	*   cols: number;
	*   }}
	*/
	getCursorPos() {
		const strBeforeCursor = this[kPrompt] + this.line.slice(0, this.cursor);
		return this[kGetDisplayPos](strBeforeCursor);
	}
	[kMoveCursor](dx) {
		if (dx === 0) return;
		const oldPos = this.getCursorPos();
		this.cursor += dx;
		if (this.cursor < 0) this.cursor = 0;
		else if (this.cursor > this.line.length) this.cursor = this.line.length;
		const newPos = this.getCursorPos();
		if (oldPos.rows === newPos.rows) {
			const diffWidth = newPos.cols - oldPos.cols;
			moveCursor(this.output, diffWidth, 0);
		} else this[kRefreshLine]();
	}
	[kTtyWrite](s, key) {
		const previousKey = this[kPreviousKey];
		key ||= kEmptyObject;
		this[kPreviousKey] = key;
		let shouldResetPreviousCursorCols = true;
		if (!key.meta || key.name !== "y") this[kYanking] = false;
		if ((key.name === "up" || key.name === "down") && !key.ctrl && !key.meta && !key.shift) {
			if (this[kSubstringSearch] === null && !this[kIsMultiline]) this[kSubstringSearch] = this.line.slice(0, this.cursor);
		} else if (this[kSubstringSearch] !== null) {
			this[kSubstringSearch] = null;
			if (this.history.length === this.historyIndex) this.historyIndex = -1;
		}
		if (typeof key.sequence === "string") switch (key.sequence.codePointAt(0)) {
			case 31:
				this[kUndo]();
				return;
			case 30:
				this[kRedo]();
				return;
		}
		if (key.name === "escape") return;
		if (key.ctrl && key.shift) switch (key.name) {
			case "backspace":
				this[kDeleteLineLeft]();
				break;
			case "delete": this[kDeleteLineRight]();
		}
		else if (key.ctrl) switch (key.name) {
			case "c":
				if (this.listenerCount("SIGINT") > 0) this.emit("SIGINT");
				else {
					this.close();
					this[kQuestionReject]?.(new AbortError("Aborted with Ctrl+C"));
				}
				break;
			case "h":
				this[kDeleteLeft]();
				break;
			case "d":
				if (this.cursor === 0 && this.line.length === 0) {
					this.close();
					this[kQuestionReject]?.(new AbortError("Aborted with Ctrl+D"));
				} else if (this.cursor < this.line.length) this[kDeleteRight]();
				break;
			case "u":
				this[kDeleteLineLeft]();
				break;
			case "k":
				this[kDeleteLineRight]();
				break;
			case "a":
				this[kMoveCursor](-Infinity);
				break;
			case "e":
				this[kMoveCursor](Infinity);
				break;
			case "b":
				this[kMoveCursor](-charLengthLeft(this.line, this.cursor));
				break;
			case "f":
				this[kMoveCursor](+charLengthAt(this.line, this.cursor));
				break;
			case "l":
				cursorTo(this.output, 0, 0);
				clearScreenDown(this.output);
				this[kRefreshLine]();
				break;
			case "n":
				this[kHistoryNext]();
				break;
			case "p":
				this[kHistoryPrev]();
				break;
			case "y":
				this[kYank]();
				break;
			case "z":
				if (this.listenerCount("SIGTSTP") > 0) this.emit("SIGTSTP");
				else throw unsupportedNodeApi("readline SIGTSTP", "components cannot suspend the host process");
				break;
			case "w":
			case "backspace":
				this[kDeleteWordLeft]();
				break;
			case "delete":
				this[kDeleteWordRight]();
				break;
			case "left":
				this[kWordLeft]();
				break;
			case "right": this[kWordRight]();
		}
		else if (key.meta) switch (key.name) {
			case "b":
				this[kWordLeft]();
				break;
			case "f":
				this[kWordRight]();
				break;
			case "d":
			case "delete":
				this[kDeleteWordRight]();
				break;
			case "backspace":
				this[kDeleteWordLeft]();
				break;
			case "y": this[kYankPop]();
		}
		else {
			if (this[kSawReturnAt] && key.name !== "enter") this[kSawReturnAt] = 0;
			switch (key.name) {
				case "return":
					this[kSawReturnAt] = Date.now();
					this[kLine]();
					break;
				case "enter":
					if (this[kSawReturnAt] === 0 || Date.now() - this[kSawReturnAt] > this.crlfDelay) this[kLine]();
					this[kSawReturnAt] = 0;
					break;
				case "backspace":
					this[kDeleteLeft]();
					break;
				case "delete":
					this[kDeleteRight]();
					break;
				case "left":
					this[kMoveCursor](-charLengthLeft(this.line, this.cursor));
					break;
				case "right":
					this[kMoveCursor](+charLengthAt(this.line, this.cursor));
					break;
				case "home":
					this[kMoveCursor](-Infinity);
					break;
				case "end":
					this[kMoveCursor](Infinity);
					break;
				case "up":
					shouldResetPreviousCursorCols = false;
					this[kMoveUpOrHistoryPrev]();
					break;
				case "down":
					shouldResetPreviousCursorCols = false;
					this[kMoveDownOrHistoryNext]();
					break;
				case "tab": if (typeof this.completer === "function" && this.isCompletionEnabled) {
					const lastKeypressWasTab = !!previousKey && previousKey.name === "tab";
					this[kTabComplete](lastKeypressWasTab);
					break;
				}
				default: if (typeof s === "string" && s) {
					lineEnding.lastIndex = 0;
					let nextMatch;
					let lastIndex = 0;
					while ((nextMatch = lineEnding.exec(s)) !== null) {
						this[kInsertString](s.slice(lastIndex, nextMatch.index));
						({lastIndex} = lineEnding);
						this[kLine]();
						lineEnding.lastIndex = lastIndex;
					}
					this[kInsertString](s.slice(lastIndex));
				}
			}
		}
		if (shouldResetPreviousCursorCols) this[kPreviousCursorCols] = -1;
	}
	/**
	* Creates an `AsyncIterator` object that iterates through
	* each line in the input stream as a string.
	* @returns {AsyncIterableIterator<string>}
	*/
	[Symbol.asyncIterator]() {
		return this[kLineObjectStream] ??= lineIterator(this);
	}
	[Symbol.dispose]() {
		this.close();
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/actions.js
const { kClearToLineBeginning, kClearToLineEnd, kClearLine, kClearScreenDown } = CSI;
var Readline = class {
	#autoCommit = false;
	#stream;
	#todo = [];
	constructor(stream, options = void 0) {
		if (!isWritable(stream)) throw invalidArgType("stream", "Writable", stream);
		this.#stream = stream;
		if (options?.autoCommit != null) {
			validateBoolean(options.autoCommit, "options.autoCommit");
			this.#autoCommit = options.autoCommit;
		}
	}
	/**
	* Moves the cursor to the x and y coordinate on the given stream.
	* @param {integer} x
	* @param {integer} [y]
	* @returns {Readline} this
	*/
	cursorTo(x, y) {
		validateInteger(x, "x");
		if (y != null) validateInteger(y, "y");
		const data = y == null ? CSI`${x + 1}G` : CSI`${y + 1};${x + 1}H`;
		if (this.#autoCommit) defer(() => this.#stream.write(data));
		else this.#todo.push(data);
		return this;
	}
	/**
	* Moves the cursor relative to its current location.
	* @param {integer} dx
	* @param {integer} dy
	* @returns {Readline} this
	*/
	moveCursor(dx, dy) {
		if (dx || dy) {
			validateInteger(dx, "dx");
			validateInteger(dy, "dy");
			let data = "";
			if (dx < 0) data += CSI`${-dx}D`;
			else if (dx > 0) data += CSI`${dx}C`;
			if (dy < 0) data += CSI`${-dy}A`;
			else if (dy > 0) data += CSI`${dy}B`;
			if (this.#autoCommit) defer(() => this.#stream.write(data));
			else this.#todo.push(data);
		}
		return this;
	}
	/**
	* Clears the current line the cursor is on.
	* @param {-1|0|1} dir Direction to clear:
	*   -1 for left of the cursor
	*   +1 for right of the cursor
	*   0 for the entire line
	* @returns {Readline} this
	*/
	clearLine(dir) {
		validateInteger(dir, "dir", -1, 1);
		const data = dir < 0 ? kClearToLineBeginning : dir > 0 ? kClearToLineEnd : kClearLine;
		if (this.#autoCommit) defer(() => this.#stream.write(data));
		else this.#todo.push(data);
		return this;
	}
	/**
	* Clears the screen from the current position of the cursor down.
	* @returns {Readline} this
	*/
	clearScreenDown() {
		if (this.#autoCommit) defer(() => this.#stream.write(kClearScreenDown));
		else this.#todo.push(kClearScreenDown);
		return this;
	}
	/**
	* Sends all the pending actions to the associated `stream` and clears the
	* internal list of pending actions.
	* @returns {Promise<void>} Resolves when all pending actions have been
	*   flushed to the associated `stream`.
	*/
	commit() {
		return new Promise((resolve) => {
			this.#stream.write(this.#todo.join(""), (error) => {
				Reflect.apply(resolve, void 0, [error]);
			});
			this.#todo = [];
		});
	}
	/**
	* Clears the internal list of pending actions without sending it to the
	* associated `stream`.
	* @returns {Readline} this
	*/
	rollback() {
		this.#todo = [];
		return this;
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/promises.js
var Interface = class extends InterfaceCore {
	question(query, options = {}) {
		return new Promise((resolve, reject) => {
			let cb = resolve;
			if (options?.signal) {
				const signal = options.signal;
				validateAbortSignal(signal, "options.signal");
				if (signal.aborted) {
					reject(new AbortError(void 0, { cause: signal.reason }));
					return;
				}
				const onAbort = () => {
					this[kQuestionCancel]();
					reject(new AbortError(void 0, { cause: signal.reason }));
				};
				const disposable = addAbortListener(signal, onAbort);
				cb = (answer) => {
					disposable[Symbol.dispose]();
					resolve(answer);
				};
			}
			this[kQuestionReject] = reject;
			this[kQuestion](query, cb);
		});
	}
};
function createInterface(input, output, completer, terminal) {
	return new Interface(input, output, completer, terminal);
}
const promises = {
	Interface,
	Readline,
	createInterface
};
//#endregion
export { emitKeypressEvents as _, InterfaceCore as a, kLastCommandErrored as c, kQuestionCancel as d, kSetLine as f, History as g, kWriteToOutput as h, Readline as i, kMultilinePrompt as l, kTabCompleter as m, createInterface as n, interface_exports as o, kTabComplete as p, promises as r, kAddNewLineOnTTY as s, Interface as t, kQuestion as u };
