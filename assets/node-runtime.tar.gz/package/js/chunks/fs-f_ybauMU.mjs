import { _ as systemError, a as codedError, d as invalidArgType, f as invalidArgValue, g as outOfRange, s as deprecatedNodeApi, t as AbortError, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { Buffer } from "../buffer.mjs";
import { o as Writable, r as Readable } from "./stream-BA_0bejK.mjs";
import "../stream.mjs";
import { n as decodeErrno, t as callHost } from "./host-error-DahHjm1T.mjs";
import * as host from "hibana:node-fs/api@0.5.0";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/fs/classes.js
/**
* Public filesystem value objects follow nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/fs/utils.js and
* lib/internal/fs/dir.js (MIT license). Local classes are reconstructed from
* typed WIT records rather than Node native binding arrays.
*/
function unsupported$1(api) {
	throw unsupportedNodeApi(api, "event-driven filesystem streams require a resource-oriented host interface");
}
function numeric(value, fallback) {
	return value.tag === "number" || value.tag === "bigint" ? value.val : fallback;
}
function date(value) {
	return new Date(Number(value.val));
}
function directoryClosed() {
	return codedError(/* @__PURE__ */ new Error("Directory handle was closed"), "ERR_DIR_CLOSED");
}
var Stats$2 = class {
	dev;
	ino;
	mode;
	nlink;
	uid;
	gid;
	rdev;
	size;
	blksize;
	blocks;
	atimeMs;
	mtimeMs;
	ctimeMs;
	birthtimeMs;
	atimeNs;
	mtimeNs;
	ctimeNs;
	birthtimeNs;
	atime;
	mtime;
	ctime;
	birthtime;
	#fileType;
	constructor(snapshot) {
		const zero = snapshot.dev.tag === "bigint" ? 0n : 0;
		this.dev = numeric(snapshot.dev, zero);
		this.ino = numeric(snapshot.ino, zero);
		this.mode = numeric(snapshot.mode, zero);
		this.nlink = numeric(snapshot.nlink, zero);
		this.uid = numeric(snapshot.uid, zero);
		this.gid = numeric(snapshot.gid, zero);
		this.rdev = numeric(snapshot.rdev, zero);
		this.size = numeric(snapshot.size, zero);
		this.blksize = numeric(snapshot.blksize, zero);
		this.blocks = numeric(snapshot.blocks, zero);
		this.atimeMs = numeric(snapshot.atimeMs, zero);
		this.mtimeMs = numeric(snapshot.mtimeMs, zero);
		this.ctimeMs = numeric(snapshot.ctimeMs, zero);
		this.birthtimeMs = numeric(snapshot.birthtimeMs, zero);
		this.atimeNs = snapshot.atimeNs;
		this.mtimeNs = snapshot.mtimeNs;
		this.ctimeNs = snapshot.ctimeNs;
		this.birthtimeNs = snapshot.birthtimeNs;
		this.atime = date(snapshot.atimeMs);
		this.mtime = date(snapshot.mtimeMs);
		this.ctime = date(snapshot.ctimeMs);
		this.birthtime = date(snapshot.birthtimeMs);
		this.#fileType = snapshot.fileType;
	}
	isBlockDevice() {
		return this.#fileType === "block";
	}
	isCharacterDevice() {
		return this.#fileType === "character";
	}
	isDirectory() {
		return this.#fileType === "directory";
	}
	isFIFO() {
		return this.#fileType === "fifo";
	}
	isFile() {
		return this.#fileType === "file";
	}
	isSocket() {
		return this.#fileType === "socket";
	}
	isSymbolicLink() {
		return this.#fileType === "symlink";
	}
};
var Dirent$2 = class Dirent$2 {
	name;
	parentPath;
	path;
	#fileType;
	constructor(name, parentPath, fileType = "unknown") {
		this.name = name;
		this.parentPath = parentPath;
		this.path = parentPath;
		this.#fileType = fileType;
	}
	static fromHost(value) {
		return new Dirent$2(value.name, value.parentPath, value.fileType);
	}
	isBlockDevice() {
		return this.#fileType === "block";
	}
	isCharacterDevice() {
		return this.#fileType === "character";
	}
	isDirectory() {
		return this.#fileType === "directory";
	}
	isFIFO() {
		return this.#fileType === "fifo";
	}
	isFile() {
		return this.#fileType === "file";
	}
	isSocket() {
		return this.#fileType === "socket";
	}
	isSymbolicLink() {
		return this.#fileType === "symlink";
	}
};
var Dir$2 = class {
	path;
	#entries;
	#index = 0;
	#closed = false;
	constructor(path, entries) {
		this.path = path;
		this.#entries = entries;
	}
	readSync() {
		if (this.#closed) throw directoryClosed();
		return this.#entries[this.#index++] ?? null;
	}
	read(callback) {
		if (callback !== void 0) {
			if (typeof callback !== "function") throw invalidArgType("callback", "Function", callback);
			queueMicrotask(() => {
				let entry;
				try {
					entry = this.readSync();
				} catch (error) {
					callback(error, null);
					return;
				}
				callback(null, entry);
			});
			return;
		}
		return Promise.resolve().then(() => this.readSync());
	}
	closeSync() {
		if (this.#closed) throw directoryClosed();
		this.#closed = true;
	}
	close(callback) {
		if (callback !== void 0) {
			if (typeof callback !== "function") throw invalidArgType("callback", "Function", callback);
			queueMicrotask(() => {
				try {
					this.closeSync();
				} catch (error) {
					callback(error);
					return;
				}
				callback(null);
			});
			return;
		}
		return Promise.resolve().then(() => this.closeSync());
	}
	async *[Symbol.asyncIterator]() {
		try {
			for (let entry = this.readSync(); entry !== null; entry = this.readSync()) yield entry;
		} finally {
			if (!this.#closed) this.closeSync();
		}
	}
	[Symbol.dispose]() {
		if (!this.#closed) this.closeSync();
	}
	async [Symbol.asyncDispose]() {
		this[Symbol.dispose]();
	}
};
var ReadStream$2 = class {
	constructor(..._args) {
		unsupported$1("fs.ReadStream");
	}
};
var WriteStream$2 = class {
	constructor(..._args) {
		unsupported$1("fs.WriteStream");
	}
};
var Utf8Stream$2 = class {
	constructor(..._args) {
		unsupported$1("fs.Utf8Stream");
	}
};
const FileReadStream$2 = ReadStream$2;
const FileWriteStream$2 = WriteStream$2;
const constants$2 = {
	UV_FS_SYMLINK_DIR: 1,
	UV_FS_SYMLINK_JUNCTION: 2,
	O_RDONLY: 0,
	O_WRONLY: 1,
	O_RDWR: 2,
	UV_DIRENT_UNKNOWN: 0,
	UV_DIRENT_FILE: 1,
	UV_DIRENT_DIR: 2,
	UV_DIRENT_LINK: 3,
	UV_DIRENT_FIFO: 4,
	UV_DIRENT_SOCKET: 5,
	UV_DIRENT_CHAR: 6,
	UV_DIRENT_BLOCK: 7,
	S_IFMT: 61440,
	S_IFREG: 32768,
	S_IFDIR: 16384,
	S_IFCHR: 8192,
	S_IFBLK: 24576,
	S_IFIFO: 4096,
	S_IFLNK: 40960,
	S_IFSOCK: 49152,
	O_CREAT: 64,
	O_EXCL: 128,
	UV_FS_O_FILEMAP: 0,
	O_NOCTTY: 256,
	O_TRUNC: 512,
	O_APPEND: 1024,
	O_DIRECTORY: 16384,
	O_NOATIME: 262144,
	O_NOFOLLOW: 32768,
	O_SYNC: 1052672,
	O_DSYNC: 4096,
	O_DIRECT: 65536,
	O_NONBLOCK: 2048,
	S_IRWXU: 448,
	S_IRUSR: 256,
	S_IWUSR: 128,
	S_IXUSR: 64,
	S_IRWXG: 56,
	S_IRGRP: 32,
	S_IWGRP: 16,
	S_IXGRP: 8,
	S_IRWXO: 7,
	S_IROTH: 4,
	S_IWOTH: 2,
	S_IXOTH: 1,
	F_OK: 0,
	R_OK: 4,
	W_OK: 2,
	X_OK: 1,
	UV_FS_COPYFILE_EXCL: 1,
	COPYFILE_EXCL: 1,
	UV_FS_COPYFILE_FICLONE: 2,
	COPYFILE_FICLONE: 2,
	UV_FS_COPYFILE_FICLONE_FORCE: 4,
	COPYFILE_FICLONE_FORCE: 4
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/fs/core.js
/**
* Shared Node.js filesystem core.
*
* Public validation and overload behavior follows nodejs/node v24.19.0,
* commit cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/fs.js,
* lib/internal/fs/promises.js, and lib/internal/fs/utils.js (MIT license).
* Local changes route operations through typed jco:node/fs functions,
* reconstruct public value objects guest-side, and reject resource/event APIs
* explicitly.
*/
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
function path(value, name = "path") {
	if (typeof value === "string") return {
		tag: "text",
		val: value
	};
	if (value instanceof Uint8Array) return {
		tag: "bytes",
		val: value
	};
	if (value instanceof URL) {
		if (value.protocol !== "file:") throw invalidArgValue(name, value, "must use the file: scheme");
		return {
			tag: "file-url",
			val: value.href
		};
	}
	throw invalidArgType(name, [
		"string",
		"Buffer",
		"URL"
	], value);
}
function pathOrFd(value, name = "path") {
	if (typeof value === "number") return {
		tag: "descriptor",
		val: fd(value)
	};
	return {
		tag: "path",
		val: path(value, name)
	};
}
function fd(value) {
	if (!Number.isInteger(value) || value < 0 || value > 2147483647) throw outOfRange("fd", ">= 0 and <= 2147483647", value);
	return value;
}
function position(value) {
	if (value === void 0 || value === null) return;
	if (typeof value !== "number" && typeof value !== "bigint" || value < 0 || typeof value === "number" && !Number.isInteger(value)) throw outOfRange("position", ">= 0", value);
	return BigInt(value);
}
function integer(value, name, minimum = 0) {
	if (!Number.isInteger(value) || value < minimum) throw outOfRange(name, `>= ${minimum}`, value);
	return value;
}
function viewBytes(value) {
	return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
}
function bytes(value, name = "buffer") {
	if (value instanceof ArrayBuffer) return new Uint8Array(value);
	if (ArrayBuffer.isView(value)) return viewBytes(value);
	throw invalidArgType(name, [
		"Buffer",
		"TypedArray",
		"DataView"
	], value);
}
function encodingFrom(options) {
	if (typeof options === "string") return options;
	if (options === void 0 || options === null) return null;
	if (typeof options !== "object") throw invalidArgType("options", ["string", "Object"], options);
	return options.encoding ?? null;
}
function decodeData(value, encoding) {
	if (!ArrayBuffer.isView(value) || Object.prototype.toString.call(value) !== "[object Uint8Array]") throw new TypeError("invalid filesystem byte response");
	const buffer = Buffer.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
	return encoding && encoding !== "buffer" ? buffer.toString(encoding) : buffer;
}
function encodeData(value, encoding = "utf8") {
	if (typeof value === "string") return Buffer.from(value, encoding);
	return bytes(value, "data");
}
function optionsRecord(value, name = "options") {
	if (value === void 0 || value === null) return {};
	if (typeof value !== "object") throw invalidArgType(name, "Object", value);
	return { ...value };
}
function checkSignal(value) {
	if (value === void 0) return;
	if (!(value instanceof AbortSignal)) throw invalidArgType("options.signal", "AbortSignal", value);
	if (value.aborted) throw new AbortError(void 0, { cause: value.reason });
}
function unsupported(api, reason) {
	throw unsupportedNodeApi(api, reason);
}
function stats(value) {
	if (value === void 0) return;
	return new Stats$2(value);
}
function hostMode(value) {
	return typeof value === "number" ? {
		tag: "number",
		val: integer(value, "mode")
	} : {
		tag: "symbolic",
		val: value
	};
}
function hostOpenMode(value) {
	return typeof value === "number" ? {
		tag: "number",
		val: value
	} : {
		tag: "symbolic",
		val: value
	};
}
function statOptions(options) {
	const value = optionsRecord(options);
	return {
		bigint: value.bigint === true,
		throwIfNoEntry: value.throwIfNoEntry !== false
	};
}
function readFileOptions(options) {
	return { flag: typeof options.flag === "string" ? options.flag : void 0 };
}
function writeFileOptions(options) {
	return {
		flag: typeof options.flag === "string" ? options.flag : void 0,
		mode: typeof options.mode === "string" || typeof options.mode === "number" ? hostMode(options.mode) : void 0,
		flush: options.flush === true
	};
}
function removeOptions(options) {
	return {
		force: options.force === true,
		maxRetries: integer(options.maxRetries ?? 0, "options.maxRetries"),
		recursive: options.recursive === true,
		retryDelay: integer(options.retryDelay ?? 100, "options.retryDelay")
	};
}
function unwrap(operation) {
	return callHost(operation, (value) => {
		const error = systemError({
			message: value.message,
			code: value.code ?? "UNKNOWN",
			errno: decodeErrno(value.errno),
			syscall: value.syscall,
			path: value.path,
			dest: value.dest
		});
		error.name = value.name;
		return error;
	});
}
var FileHandle = class {
	fd;
	#core;
	#closed = false;
	constructor(core, descriptor) {
		this.#core = core;
		this.fd = descriptor;
	}
	#open() {
		if (this.#closed) {
			const error = /* @__PURE__ */ new Error("file closed");
			error.code = "EBADF";
			throw error;
		}
	}
	async appendFile(data, options) {
		this.#open();
		this.#core.appendFileSync(this.fd, data, options);
	}
	async chmod(mode) {
		this.#open();
		this.#core.fchmodSync(this.fd, mode);
	}
	async chown(uid, gid) {
		this.#open();
		this.#core.fchownSync(this.fd, uid, gid);
	}
	async close() {
		if (this.#closed) return;
		this.#core.closeSync(this.fd);
		this.#closed = true;
	}
	createReadStream(..._args) {
		return unsupported("filehandle.createReadStream", "Node streams cannot cross the filesystem host boundary");
	}
	createWriteStream(..._args) {
		return unsupported("filehandle.createWriteStream", "Node streams cannot cross the filesystem host boundary");
	}
	async datasync() {
		this.#open();
		this.#core.fdatasyncSync(this.fd);
	}
	pull(..._args) {
		return unsupported("filehandle.pull", "iterable stream transforms require Node stream resources");
	}
	pullSync(..._args) {
		return unsupported("filehandle.pullSync", "iterable stream transforms require Node stream resources");
	}
	async read(buffer, offsetOrOptions = 0, length, readPosition) {
		this.#open();
		const options = typeof offsetOrOptions === "object" ? offsetOrOptions : {
			offset: offsetOrOptions,
			length,
			position: readPosition
		};
		return {
			bytesRead: this.#core.readSync(this.fd, buffer, options),
			buffer
		};
	}
	readableWebStream(..._args) {
		return unsupported("filehandle.readableWebStream", "Web streams require a resource-oriented host boundary");
	}
	async readFile(options) {
		this.#open();
		return this.#core.readFileSync(this.fd, options);
	}
	readLines(..._args) {
		return unsupported("filehandle.readLines", "Node readline streams are not available in the component runtime");
	}
	async readv(buffers, readPosition) {
		this.#open();
		return {
			bytesRead: this.#core.readvSync(this.fd, buffers, readPosition),
			buffers
		};
	}
	async stat(options) {
		this.#open();
		return this.#core.fstatSync(this.fd, options);
	}
	async sync() {
		this.#open();
		this.#core.fsyncSync(this.fd);
	}
	async truncate(length = 0) {
		this.#open();
		this.#core.ftruncateSync(this.fd, length);
	}
	async utimes(atime, mtime) {
		this.#open();
		this.#core.futimesSync(this.fd, atime, mtime);
	}
	async write(value, offsetOrPosition = 0, lengthOrEncoding, writePosition) {
		this.#open();
		if (typeof value === "string") {
			const buffer = Buffer.from(value, typeof lengthOrEncoding === "string" ? lengthOrEncoding : "utf8");
			return {
				bytesWritten: this.#core.writeSync(this.fd, buffer, 0, buffer.byteLength, typeof offsetOrPosition === "number" ? offsetOrPosition : null),
				buffer
			};
		}
		const options = typeof offsetOrPosition === "object" && offsetOrPosition !== null ? offsetOrPosition : {
			offset: typeof offsetOrPosition === "number" ? offsetOrPosition : 0,
			length: typeof lengthOrEncoding === "number" ? lengthOrEncoding : void 0,
			position: writePosition
		};
		return {
			bytesWritten: this.#core.writeSync(this.fd, value, options),
			buffer: value
		};
	}
	async writeFile(data, options) {
		this.#open();
		this.#core.writeFileSync(this.fd, data, options);
	}
	async writev(buffers, writePosition) {
		this.#open();
		return {
			bytesWritten: this.#core.writevSync(this.fd, buffers, writePosition),
			buffers
		};
	}
	writer(..._args) {
		return unsupported("filehandle.writer", "iterable stream writers require Node stream resources");
	}
	async [Symbol.asyncDispose]() {
		if (!this.#closed) await this.close();
	}
};
var FsCore = class {
	#host;
	constructor(host) {
		this.#host = host;
	}
	accessSync(value, mode = 0) {
		unwrap(() => this.#host.access(path(value), mode));
	}
	appendFileSync(file, data, options) {
		const opts = typeof options === "string" ? { encoding: options } : optionsRecord(options);
		checkSignal(opts.signal);
		const encoding = typeof opts.encoding === "string" && opts.encoding !== "buffer" ? opts.encoding : "utf8";
		unwrap(() => this.#host.appendFile(pathOrFd(file), encodeData(data, encoding), writeFileOptions(opts)));
	}
	chmodSync(value, mode) {
		unwrap(() => this.#host.chmod(path(value), hostMode(mode)));
	}
	chownSync(value, uid, gid) {
		unwrap(() => this.#host.chown(path(value), integer(uid, "uid"), integer(gid, "gid")));
	}
	closeSync(descriptor) {
		unwrap(() => this.#host.close(fd(descriptor)));
	}
	copyFileSync(source, destination, mode = 0) {
		unwrap(() => this.#host.copyFile(path(source, "src"), path(destination, "dest"), mode));
	}
	cpSync(source, destination, options) {
		const opts = optionsRecord(options);
		if (typeof opts.filter === "function") unsupported("fs.cp filter", "functions cannot cross the filesystem host boundary");
		const hostOptions = {
			dereference: opts.dereference === true,
			errorOnExist: opts.errorOnExist === true,
			force: opts.force !== false,
			preserveTimestamps: opts.preserveTimestamps === true,
			recursive: opts.recursive === true,
			verbatimSymlinks: opts.verbatimSymlinks === true
		};
		unwrap(() => this.#host.cp(path(source, "src"), path(destination, "dest"), hostOptions));
	}
	existsSync(value) {
		try {
			return unwrap(() => this.#host.exists(path(value)));
		} catch (error) {
			if (isRecord(error) && error.code === "ERR_JCO_FS_ADAPTER_REQUIRED") throw error;
			return false;
		}
	}
	fchmodSync(descriptor, mode) {
		unwrap(() => this.#host.fchmod(fd(descriptor), hostMode(mode)));
	}
	fchownSync(descriptor, uid, gid) {
		unwrap(() => this.#host.fchown(fd(descriptor), integer(uid, "uid"), integer(gid, "gid")));
	}
	fdatasyncSync(descriptor) {
		unwrap(() => this.#host.fdatasync(fd(descriptor)));
	}
	fstatSync(descriptor, options) {
		const result = stats(unwrap(() => this.#host.fstat(fd(descriptor), statOptions(options))));
		if (!result) throw new TypeError("missing filesystem stats response");
		return result;
	}
	fsyncSync(descriptor) {
		unwrap(() => this.#host.fsync(fd(descriptor)));
	}
	ftruncateSync(descriptor, length = 0) {
		unwrap(() => this.#host.ftruncate(fd(descriptor), integer(length, "len")));
	}
	futimesSync(descriptor, atime, mtime) {
		unwrap(() => this.#host.futimes(fd(descriptor), toUnixTimestamp(atime), toUnixTimestamp(mtime)));
	}
	globSync(pattern, options) {
		if (typeof pattern !== "string" && !Array.isArray(pattern)) throw invalidArgType("pattern", ["string", "Array"], pattern);
		const opts = optionsRecord(options);
		if (typeof opts.exclude === "function") unsupported("fs.glob exclude", "functions cannot cross the filesystem host boundary");
		let exclude;
		if (typeof opts.exclude === "string") exclude = {
			tag: "pattern",
			val: opts.exclude
		};
		else if (Array.isArray(opts.exclude)) exclude = {
			tag: "patterns",
			val: opts.exclude.map(String)
		};
		const hostOptions = {
			cwd: opts.cwd === void 0 ? void 0 : path(opts.cwd, "options.cwd"),
			exclude,
			withFileTypes: opts.withFileTypes === true
		};
		return unwrap(() => this.#host.glob(typeof pattern === "string" ? [pattern] : [...pattern], hostOptions)).map((entry) => entry.tag === "dirent" ? Dirent$2.fromHost(entry.val) : entry.val);
	}
	lchownSync(value, uid, gid) {
		unwrap(() => this.#host.lchown(path(value), integer(uid, "uid"), integer(gid, "gid")));
	}
	linkSync(existingPath, newPath) {
		unwrap(() => this.#host.link(path(existingPath, "existingPath"), path(newPath, "newPath")));
	}
	lstatSync(value, options) {
		return stats(unwrap(() => this.#host.lstat(path(value), statOptions(options))));
	}
	lutimesSync(value, atime, mtime) {
		unwrap(() => this.#host.lutimes(path(value), toUnixTimestamp(atime), toUnixTimestamp(mtime)));
	}
	mkdirSync(value, options) {
		const opts = typeof options === "string" || typeof options === "number" ? { mode: options } : optionsRecord(options);
		const hostOptions = {
			recursive: opts.recursive === true,
			mode: typeof opts.mode === "string" || typeof opts.mode === "number" ? hostMode(opts.mode) : void 0
		};
		return unwrap(() => this.#host.mkdir(path(value), hostOptions));
	}
	mkdtempSync(prefix, options) {
		if (typeof prefix !== "string") throw invalidArgType("prefix", "string", prefix);
		const encoding = encodingFrom(options);
		const result = unwrap(() => this.#host.mkdtemp(prefix));
		return encoding === "buffer" ? Buffer.from(result) : result;
	}
	mkdtempDisposableSync(prefix, options) {
		const value = this.mkdtempSync(prefix, options);
		if (typeof value !== "string") throw new TypeError("temporary directory path must be a string");
		const remove = () => this.rmSync(value, {
			recursive: true,
			force: true
		});
		return {
			path: value,
			remove,
			[Symbol.dispose]: remove
		};
	}
	openSync(value, flags = "r", mode = 438) {
		return unwrap(() => this.#host.open(path(value), hostOpenMode(flags), hostMode(mode)));
	}
	opendirSync(value, options) {
		if (typeof value !== "string") throw invalidArgType("path", "string", value);
		const pathname = value;
		return new Dir$2(pathname, this.readdirSync(pathname, {
			...options,
			encoding: "utf8",
			withFileTypes: true
		}));
	}
	readFileSync(file, options) {
		const opts = typeof options === "string" ? { encoding: options } : optionsRecord(options);
		checkSignal(opts.signal);
		const encoding = encodingFrom(typeof options === "string" ? options : opts);
		return decodeData(unwrap(() => this.#host.readFile(pathOrFd(file), readFileOptions(opts))), encoding);
	}
	readdirSync(value, options) {
		const opts = typeof options === "string" ? { encoding: options } : optionsRecord(options);
		const encoding = encodingFrom(typeof options === "string" ? options : opts);
		const hostOptions = {
			recursive: opts.recursive === true,
			withFileTypes: opts.withFileTypes === true
		};
		return unwrap(() => this.#host.readdir(path(value), hostOptions)).map((entry) => {
			if (entry.tag === "dirent") {
				const dirent = Dirent$2.fromHost(entry.val);
				return encoding === "buffer" ? new Dirent$2(Buffer.from(String(dirent.name)), dirent.parentPath, dirent.isFile() ? "file" : dirent.isDirectory() ? "directory" : dirent.isSymbolicLink() ? "symlink" : "unknown") : dirent;
			}
			const name = entry.val;
			return encoding === "buffer" ? Buffer.from(name) : name;
		});
	}
	readlinkSync(value, options) {
		const encoding = encodingFrom(options);
		const result = unwrap(() => this.#host.readlink(path(value)));
		return encoding === "buffer" ? Buffer.from(result) : result;
	}
	realpathSync(value, options) {
		const encoding = encodingFrom(options);
		const result = unwrap(() => this.#host.realpath(path(value)));
		return encoding === "buffer" ? Buffer.from(result) : result;
	}
	renameSync(oldPath, newPath) {
		unwrap(() => this.#host.rename(path(oldPath, "oldPath"), path(newPath, "newPath")));
	}
	rmSync(value, options) {
		unwrap(() => this.#host.rm(path(value), removeOptions(optionsRecord(options))));
	}
	rmdirSync(value, options) {
		const opts = optionsRecord(options);
		if (opts.recursive) throw deprecatedNodeApi("fs.rmdir(path, { recursive: true })", "fs.rm(path, { recursive: true })");
		unwrap(() => this.#host.rmdir(path(value), removeOptions(opts)));
	}
	statSync(value, options) {
		return stats(unwrap(() => this.#host.stat(path(value), statOptions(options))));
	}
	statfsSync(value, options) {
		const result = unwrap(() => this.#host.statfs(path(value), options?.bigint === true));
		return Object.fromEntries(Object.entries(result).map(([name, value]) => [name, value.val]));
	}
	symlinkSync(target, value, type) {
		unwrap(() => this.#host.symlink(path(target, "target"), path(value), type ?? void 0));
	}
	truncateSync(value, length = 0) {
		unwrap(() => this.#host.truncate(path(value), integer(length, "len")));
	}
	unlinkSync(value) {
		unwrap(() => this.#host.unlink(path(value)));
	}
	utimesSync(value, atime, mtime) {
		unwrap(() => this.#host.utimes(path(value), toUnixTimestamp(atime), toUnixTimestamp(mtime)));
	}
	writeFileSync(file, data, options) {
		const opts = typeof options === "string" ? { encoding: options } : optionsRecord(options);
		checkSignal(opts.signal);
		const encoding = typeof opts.encoding === "string" && opts.encoding !== "buffer" ? opts.encoding : "utf8";
		unwrap(() => this.#host.writeFile(pathOrFd(file), encodeData(data, encoding), writeFileOptions(opts)));
	}
	readSync(descriptor, buffer, offsetOrOptions = 0, length, readPosition) {
		const target = bytes(buffer);
		const opts = typeof offsetOrOptions === "object" ? offsetOrOptions : {
			offset: offsetOrOptions,
			length,
			position: readPosition
		};
		const offset = integer(opts.offset ?? 0, "offset");
		const count = integer(opts.length ?? target.byteLength - offset, "length");
		if (offset + count > target.byteLength) throw outOfRange("length", `<= ${target.byteLength - offset}`, count);
		const result = unwrap(() => this.#host.read(fd(descriptor), count, position(opts.position)));
		target.set(result.data, offset);
		return result.bytesRead;
	}
	writeSync(descriptor, value, offsetOrOptions = 0, lengthOrEncoding, writePosition) {
		if (typeof value === "string") {
			const data = Buffer.from(value, typeof lengthOrEncoding === "string" ? lengthOrEncoding : "utf8");
			return unwrap(() => this.#host.write(fd(descriptor), data, position(typeof offsetOrOptions === "number" ? offsetOrOptions : null)));
		}
		const source = bytes(value);
		const opts = typeof offsetOrOptions === "object" && offsetOrOptions !== null ? offsetOrOptions : {
			offset: typeof offsetOrOptions === "number" ? offsetOrOptions : 0,
			length: typeof lengthOrEncoding === "number" ? lengthOrEncoding : void 0,
			position: writePosition
		};
		const offset = integer(opts.offset ?? 0, "offset");
		const count = integer(opts.length ?? source.byteLength - offset, "length");
		if (offset + count > source.byteLength) throw outOfRange("length", `<= ${source.byteLength - offset}`, count);
		return unwrap(() => this.#host.write(fd(descriptor), source.subarray(offset, offset + count), position(opts.position)));
	}
	readvSync(descriptor, buffers, readPosition) {
		if (!Array.isArray(buffers)) throw invalidArgType("buffers", "Array", buffers);
		const targets = buffers.map((buffer) => bytes(buffer));
		const result = unwrap(() => this.#host.readv(fd(descriptor), targets.map((buffer) => buffer.byteLength), position(readPosition)));
		result.buffers.forEach((buffer, index) => targets[index]?.set(buffer));
		return result.bytesRead;
	}
	writevSync(descriptor, buffers, writePosition) {
		if (!Array.isArray(buffers)) throw invalidArgType("buffers", "Array", buffers);
		return unwrap(() => this.#host.writev(fd(descriptor), buffers.map((buffer) => bytes(buffer)), position(writePosition)));
	}
	async open(value, flags = "r", mode = 438) {
		return new FileHandle(this, this.openSync(value, flags, mode));
	}
	async mkdtempDisposable(prefix, options) {
		const disposable = this.mkdtempDisposableSync(prefix, options);
		const remove = async () => disposable.remove();
		return {
			path: disposable.path,
			remove,
			[Symbol.asyncDispose]: remove
		};
	}
};
function createFsCore(host) {
	return new FsCore(host);
}
function toUnixTimestamp(value) {
	if (value instanceof Date) return value.getTime() / 1e3;
	if (typeof value === "string" && value.trim() !== "") value = Number(value);
	if (typeof value !== "number") throw invalidArgType("time", [
		"number",
		"string",
		"Date"
	], value);
	if (Number.isNaN(value) || value < 0) throw invalidArgValue("time", value);
	return value;
}
function unsupportedFsApi(api) {
	return unsupported(api, "the filesystem WIT interface does not model event or stream resources");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/fs/callbacks.js
function callback(value) {
	if (typeof value !== "function") throw invalidArgType("callback", "Function", value);
	return value;
}
function deferred(operation, cb, values = (result) => [result]) {
	const done = callback(cb);
	queueMicrotask(() => {
		let result;
		try {
			result = operation();
		} catch (error) {
			done(error);
			return;
		}
		done(null, ...values(result));
	});
}
function splitCallback(args) {
	const values = [...args];
	return {
		args: values,
		callback: callback(values.pop())
	};
}
/** Build Node's callback/synchronous facade over one filesystem core. */
function createFs(core, promises) {
	const access = (path, modeOrCallback, maybeCallback) => {
		const mode = typeof modeOrCallback === "number" ? modeOrCallback : 0;
		deferred(() => core.accessSync(path, mode), typeof modeOrCallback === "function" ? modeOrCallback : maybeCallback, () => []);
	};
	const appendFile = (file, data, optionsOrCallback, maybeCallback) => {
		const options = typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback;
		deferred(() => core.appendFileSync(file, data, options), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback, () => []);
	};
	const chmod = (path, mode, cb) => deferred(() => core.chmodSync(path, mode), cb, () => []);
	const chown = (path, uid, gid, cb) => deferred(() => core.chownSync(path, uid, gid), cb, () => []);
	const close = (fd, cb = (error) => {
		if (error) throw error;
	}) => deferred(() => core.closeSync(fd), cb, () => []);
	const copyFile = (source, destination, modeOrCallback, maybeCallback) => deferred(() => core.copyFileSync(source, destination, typeof modeOrCallback === "number" ? modeOrCallback : 0), typeof modeOrCallback === "function" ? modeOrCallback : maybeCallback, () => []);
	const cp = (source, destination, optionsOrCallback, maybeCallback) => deferred(() => core.cpSync(source, destination, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback, () => []);
	const fchmod = (fd, mode, cb) => deferred(() => core.fchmodSync(fd, mode), cb, () => []);
	const fchown = (fd, uid, gid, cb) => deferred(() => core.fchownSync(fd, uid, gid), cb, () => []);
	const fdatasync = (fd, cb) => deferred(() => core.fdatasyncSync(fd), cb, () => []);
	const fstat = (fd, optionsOrCallback, maybeCallback) => deferred(() => core.fstatSync(fd, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const fsync = (fd, cb) => deferred(() => core.fsyncSync(fd), cb, () => []);
	const ftruncate = (fd, lengthOrCallback, maybeCallback) => deferred(() => core.ftruncateSync(fd, typeof lengthOrCallback === "number" ? lengthOrCallback : 0), typeof lengthOrCallback === "function" ? lengthOrCallback : maybeCallback, () => []);
	const futimes = (fd, atime, mtime, cb) => deferred(() => core.futimesSync(fd, atime, mtime), cb, () => []);
	const glob = (pattern, optionsOrCallback, maybeCallback) => deferred(() => core.globSync(pattern, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const lchown = (path, uid, gid, cb) => deferred(() => core.lchownSync(path, uid, gid), cb, () => []);
	const link = (existingPath, newPath, cb) => deferred(() => core.linkSync(existingPath, newPath), cb, () => []);
	const lstat = (path, optionsOrCallback, maybeCallback) => deferred(() => core.lstatSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const lutimes = (path, atime, mtime, cb) => deferred(() => core.lutimesSync(path, atime, mtime), cb, () => []);
	const mkdir = (path, optionsOrCallback, maybeCallback) => deferred(() => core.mkdirSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const mkdtemp = (prefix, optionsOrCallback, maybeCallback) => deferred(() => core.mkdtempSync(prefix, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const open = (path, flagsOrCallback, modeOrCallback, maybeCallback) => {
		const flags = typeof flagsOrCallback === "function" ? "r" : flagsOrCallback;
		const mode = typeof modeOrCallback === "function" || modeOrCallback === void 0 ? 438 : modeOrCallback;
		deferred(() => core.openSync(path, flags, mode), typeof flagsOrCallback === "function" ? flagsOrCallback : typeof modeOrCallback === "function" ? modeOrCallback : maybeCallback);
	};
	const opendir = (path, optionsOrCallback, maybeCallback) => deferred(() => core.opendirSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const readFile = (file, optionsOrCallback, maybeCallback) => deferred(() => core.readFileSync(file, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const readdir = (path, optionsOrCallback, maybeCallback) => deferred(() => core.readdirSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const readlink = (path, optionsOrCallback, maybeCallback) => deferred(() => core.readlinkSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const realpathOperation = (path, optionsOrCallback, maybeCallback) => deferred(() => core.realpathSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const realpath = Object.assign(realpathOperation, { native: (path, optionsOrCallback, maybeCallback) => realpathOperation(path, optionsOrCallback, maybeCallback) });
	const rename = (oldPath, newPath, cb) => deferred(() => core.renameSync(oldPath, newPath), cb, () => []);
	const rm = (path, optionsOrCallback, maybeCallback) => deferred(() => core.rmSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback, () => []);
	const rmdir = (path, optionsOrCallback, maybeCallback) => deferred(() => core.rmdirSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback, () => []);
	const stat = (path, optionsOrCallback, maybeCallback) => deferred(() => core.statSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const statfs = (path, optionsOrCallback, maybeCallback) => deferred(() => core.statfsSync(path, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback);
	const symlink = (target, path, typeOrCallback, maybeCallback) => deferred(() => core.symlinkSync(target, path, typeof typeOrCallback === "function" ? void 0 : typeOrCallback), typeof typeOrCallback === "function" ? typeOrCallback : maybeCallback, () => []);
	const truncate = (path, lengthOrCallback, maybeCallback) => deferred(() => core.truncateSync(path, typeof lengthOrCallback === "number" ? lengthOrCallback : 0), typeof lengthOrCallback === "function" ? lengthOrCallback : maybeCallback, () => []);
	const unlink = (path, cb) => deferred(() => core.unlinkSync(path), cb, () => []);
	const utimes = (path, atime, mtime, cb) => deferred(() => core.utimesSync(path, atime, mtime), cb, () => []);
	const writeFile = (file, data, optionsOrCallback, maybeCallback) => deferred(() => core.writeFileSync(file, data, typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback), typeof optionsOrCallback === "function" ? optionsOrCallback : maybeCallback, () => []);
	const read = (...input) => {
		const { args, callback: cb } = splitCallback(input);
		const [descriptor, buffer, offsetOrOptions, length, position] = args;
		if (!ArrayBuffer.isView(buffer)) throw invalidArgType("buffer", [
			"Buffer",
			"TypedArray",
			"DataView"
		], buffer);
		deferred(() => typeof offsetOrOptions === "object" && offsetOrOptions !== null ? core.readSync(descriptor, buffer, offsetOrOptions) : core.readSync(descriptor, buffer, offsetOrOptions, length, position), cb, (bytesRead) => [bytesRead, buffer]);
	};
	const write = (...input) => {
		const { args, callback: cb } = splitCallback(input);
		const [descriptor, value, offsetOrPosition, lengthOrEncoding, position] = args;
		if (typeof value !== "string" && !ArrayBuffer.isView(value)) throw invalidArgType("buffer", [
			"string",
			"Buffer",
			"TypedArray",
			"DataView"
		], value);
		deferred(() => {
			if (typeof value === "string") return core.writeSync(descriptor, value, offsetOrPosition, lengthOrEncoding);
			return typeof offsetOrPosition === "object" && offsetOrPosition !== null ? core.writeSync(descriptor, value, offsetOrPosition) : core.writeSync(descriptor, value, offsetOrPosition, lengthOrEncoding, position);
		}, cb, (bytesWritten) => [bytesWritten, value]);
	};
	const readv = (fd, buffers, positionOrCallback, maybeCallback) => deferred(() => core.readvSync(fd, buffers, typeof positionOrCallback === "number" ? positionOrCallback : void 0), typeof positionOrCallback === "function" ? positionOrCallback : maybeCallback, (bytesRead) => [bytesRead, buffers]);
	const writev = (fd, buffers, positionOrCallback, maybeCallback) => deferred(() => core.writevSync(fd, buffers, typeof positionOrCallback === "number" ? positionOrCallback : void 0), typeof positionOrCallback === "function" ? positionOrCallback : maybeCallback, (bytesWritten) => [bytesWritten, buffers]);
	const realpathSync = Object.assign(core.realpathSync.bind(core), { native: core.realpathSync.bind(core) });
	const unsupported = (api) => (..._args) => unsupportedFsApi(api);
	const deprecated = (api, replacement) => (..._args) => {
		throw deprecatedNodeApi(api, replacement);
	};
	return {
		constants: constants$2,
		promises,
		Dir: Dir$2,
		Dirent: Dirent$2,
		FileReadStream: FileReadStream$2,
		FileWriteStream: FileWriteStream$2,
		ReadStream: ReadStream$2,
		Stats: Stats$2,
		Utf8Stream: Utf8Stream$2,
		WriteStream: WriteStream$2,
		_toUnixTimestamp: toUnixTimestamp,
		access,
		accessSync: core.accessSync.bind(core),
		appendFile,
		appendFileSync: core.appendFileSync.bind(core),
		chmod,
		chmodSync: core.chmodSync.bind(core),
		chown,
		chownSync: core.chownSync.bind(core),
		close,
		closeSync: core.closeSync.bind(core),
		copyFile,
		copyFileSync: core.copyFileSync.bind(core),
		cp,
		cpSync: core.cpSync.bind(core),
		createReadStream: unsupported("fs.createReadStream"),
		createWriteStream: unsupported("fs.createWriteStream"),
		exists: deprecated("fs.exists", "fs.stat or fs.access"),
		existsSync: core.existsSync.bind(core),
		fchmod,
		fchmodSync: core.fchmodSync.bind(core),
		fchown,
		fchownSync: core.fchownSync.bind(core),
		fdatasync,
		fdatasyncSync: core.fdatasyncSync.bind(core),
		fstat,
		fstatSync: core.fstatSync.bind(core),
		fsync,
		fsyncSync: core.fsyncSync.bind(core),
		ftruncate,
		ftruncateSync: core.ftruncateSync.bind(core),
		futimes,
		futimesSync: core.futimesSync.bind(core),
		glob,
		globSync: core.globSync.bind(core),
		lchmod: deprecated("fs.lchmod"),
		lchmodSync: deprecated("fs.lchmodSync"),
		lchown,
		lchownSync: core.lchownSync.bind(core),
		link,
		linkSync: core.linkSync.bind(core),
		lstat,
		lstatSync: core.lstatSync.bind(core),
		lutimes,
		lutimesSync: core.lutimesSync.bind(core),
		mkdir,
		mkdirSync: core.mkdirSync.bind(core),
		mkdtemp,
		mkdtempSync: core.mkdtempSync.bind(core),
		mkdtempDisposableSync: core.mkdtempDisposableSync.bind(core),
		open,
		openAsBlob: unsupported("fs.openAsBlob"),
		openSync: core.openSync.bind(core),
		opendir,
		opendirSync: core.opendirSync.bind(core),
		read,
		readFile,
		readFileSync: core.readFileSync.bind(core),
		readSync: core.readSync.bind(core),
		readdir,
		readdirSync: core.readdirSync.bind(core),
		readlink,
		readlinkSync: core.readlinkSync.bind(core),
		readv,
		readvSync: core.readvSync.bind(core),
		realpath,
		realpathSync,
		rename,
		renameSync: core.renameSync.bind(core),
		rm,
		rmSync: core.rmSync.bind(core),
		rmdir,
		rmdirSync: core.rmdirSync.bind(core),
		stat,
		statSync: core.statSync.bind(core),
		statfs,
		statfsSync: core.statfsSync.bind(core),
		symlink,
		symlinkSync: core.symlinkSync.bind(core),
		truncate,
		truncateSync: core.truncateSync.bind(core),
		unlink,
		unlinkSync: core.unlinkSync.bind(core),
		unwatchFile: unsupported("fs.unwatchFile"),
		utimes,
		utimesSync: core.utimesSync.bind(core),
		watch: unsupported("fs.watch"),
		watchFile: unsupported("fs.watchFile"),
		write,
		writeFile,
		writeFileSync: core.writeFileSync.bind(core),
		writeSync: core.writeSync.bind(core),
		writev,
		writevSync: core.writevSync.bind(core)
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/fs/promises.js
/** Build the promise facade over the same descriptor/state core as `node:fs`. */
function createFsPromises(core) {
	return {
		constants: constants$2,
		async access(path, mode) {
			core.accessSync(path, mode);
		},
		async appendFile(file, data, options) {
			core.appendFileSync(file, data, options);
		},
		async chmod(path, mode) {
			core.chmodSync(path, mode);
		},
		async chown(path, uid, gid) {
			core.chownSync(path, uid, gid);
		},
		async copyFile(source, destination, mode) {
			core.copyFileSync(source, destination, mode);
		},
		async cp(source, destination, options) {
			core.cpSync(source, destination, options);
		},
		async glob(pattern, options) {
			return core.globSync(pattern, options);
		},
		async lchmod(_path, _mode) {
			throw deprecatedNodeApi("fsPromises.lchmod");
		},
		async lchown(path, uid, gid) {
			core.lchownSync(path, uid, gid);
		},
		async link(existingPath, newPath) {
			core.linkSync(existingPath, newPath);
		},
		async lstat(path, options) {
			return core.lstatSync(path, options);
		},
		async lutimes(path, atime, mtime) {
			core.lutimesSync(path, atime, mtime);
		},
		async mkdir(path, options) {
			return core.mkdirSync(path, options);
		},
		async mkdtemp(prefix, options) {
			return core.mkdtempSync(prefix, options);
		},
		async mkdtempDisposable(prefix, options) {
			return core.mkdtempDisposable(prefix, options);
		},
		async open(path, flags, mode) {
			return core.open(path, flags, mode);
		},
		async opendir(path, options) {
			return core.opendirSync(path, options);
		},
		async readFile(file, options) {
			return core.readFileSync(file, options);
		},
		async readdir(path, options) {
			return core.readdirSync(path, options);
		},
		async readlink(path, options) {
			return core.readlinkSync(path, options);
		},
		async realpath(path, options) {
			return core.realpathSync(path, options);
		},
		async rename(oldPath, newPath) {
			core.renameSync(oldPath, newPath);
		},
		async rm(path, options) {
			core.rmSync(path, options);
		},
		async rmdir(path, options) {
			core.rmdirSync(path, options);
		},
		async stat(path, options) {
			return core.statSync(path, options);
		},
		async statfs(path, options) {
			return core.statfsSync(path, options);
		},
		async symlink(target, path, type) {
			core.symlinkSync(target, path, type);
		},
		async truncate(path, length) {
			core.truncateSync(path, length);
		},
		async unlink(path) {
			core.unlinkSync(path);
		},
		async utimes(path, atime, mtime) {
			core.utimesSync(path, atime, mtime);
		},
		watch(..._args) {
			throw unsupportedNodeApi("fsPromises.watch", "the filesystem WIT interface does not model watcher resources");
		},
		async writeFile(file, data, options) {
			core.writeFileSync(file, data, options);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/fs/shared.js
const filesystemCore = createFsCore(host);
const filesystem = createFs(filesystemCore, createFsPromises(filesystemCore));
filesystem.constants;
filesystem.promises;
filesystem.Dir;
filesystem.Dirent;
filesystem.FileReadStream;
filesystem.FileWriteStream;
filesystem.ReadStream;
filesystem.Stats;
filesystem.Utf8Stream;
filesystem.WriteStream;
filesystem._toUnixTimestamp;
filesystem.access;
filesystem.accessSync;
filesystem.appendFile;
filesystem.appendFileSync;
filesystem.chmod;
filesystem.chmodSync;
filesystem.chown;
filesystem.chownSync;
filesystem.close;
filesystem.closeSync;
filesystem.copyFile;
filesystem.copyFileSync;
filesystem.cp;
filesystem.cpSync;
filesystem.createReadStream;
filesystem.createWriteStream;
filesystem.exists;
filesystem.existsSync;
filesystem.fchmod;
filesystem.fchmodSync;
filesystem.fchown;
filesystem.fchownSync;
filesystem.fdatasync;
filesystem.fdatasyncSync;
filesystem.fstat;
filesystem.fstatSync;
filesystem.fsync;
filesystem.fsyncSync;
filesystem.ftruncate;
filesystem.ftruncateSync;
filesystem.futimes;
filesystem.futimesSync;
filesystem.glob;
filesystem.globSync;
filesystem.lchmod;
filesystem.lchmodSync;
filesystem.lchown;
filesystem.lchownSync;
filesystem.link;
filesystem.linkSync;
filesystem.lstat;
filesystem.lstatSync;
filesystem.lutimes;
filesystem.lutimesSync;
filesystem.mkdir;
filesystem.mkdirSync;
filesystem.mkdtemp;
filesystem.mkdtempDisposableSync;
filesystem.mkdtempSync;
filesystem.open;
filesystem.openAsBlob;
filesystem.openSync;
filesystem.opendir;
filesystem.opendirSync;
filesystem.read;
filesystem.readFile;
filesystem.readFileSync;
filesystem.readSync;
filesystem.readdir;
filesystem.readdirSync;
filesystem.readlink;
filesystem.readlinkSync;
filesystem.readv;
filesystem.readvSync;
filesystem.realpath;
filesystem.realpathSync;
filesystem.rename;
filesystem.renameSync;
filesystem.rm;
filesystem.rmSync;
filesystem.rmdir;
filesystem.rmdirSync;
filesystem.stat;
filesystem.statSync;
filesystem.statfs;
filesystem.statfsSync;
filesystem.symlink;
filesystem.symlinkSync;
filesystem.truncate;
filesystem.truncateSync;
filesystem.unlink;
filesystem.unlinkSync;
filesystem.unwatchFile;
filesystem.utimes;
filesystem.utimesSync;
filesystem.watch;
filesystem.watchFile;
filesystem.write;
filesystem.writeFile;
filesystem.writeFileSync;
filesystem.writeSync;
filesystem.writev;
filesystem.writevSync;
var fs_default$1 = filesystem;
//#endregion
//#region src/fs-streams.mjs
function installStreams(fs) {
	function settings(options) {
		return typeof options === "string" ? { encoding: options } : options ?? {};
	}
	function position(value, name) {
		if (value !== void 0 && (!Number.isSafeInteger(value) || value < 0)) throw new RangeError(`${name} must be a non-negative safe integer`);
		return value;
	}
	class ReadStream extends Readable {
		constructor(path, options) {
			options = settings(options);
			super({
				...options,
				highWaterMark: options.highWaterMark ?? 65536
			});
			this.path = path;
			this.fd = options.fd ?? null;
			this.start = position(options.start, "start");
			this.end = position(options.end, "end") ?? Infinity;
			if (this.start !== void 0 && this.start > this.end) throw new RangeError("start exceeds end");
			this.pos = this.start;
			this.bytesRead = 0;
			this.autoClose = options.autoClose !== false;
			this.pending = this.fd === null;
			this.flags = options.flags ?? "r";
			this.mode = options.mode;
		}
		_construct(callback) {
			try {
				if (this.fd === null) {
					this.fd = fs.openSync(this.path, this.flags, this.mode);
					this.emit("open", this.fd);
				}
				this.pending = false;
				this.emit("ready");
				callback();
			} catch (error) {
				callback(error);
			}
		}
		_read(size) {
			try {
				const count = Math.min(size, this.end - (this.pos ?? this.bytesRead) + 1);
				if (count <= 0) {
					this.push(null);
					return;
				}
				const data = Buffer.allocUnsafe(count);
				const read = fs.readSync(this.fd, data, 0, count, this.pos ?? null);
				if (this.pos !== void 0) this.pos += read;
				this.bytesRead += read;
				this.push(read ? data.subarray(0, read) : null);
			} catch (error) {
				this.destroy(error);
			}
		}
		_destroy(error, callback) {
			try {
				if (this.autoClose && this.fd !== null) {
					fs.closeSync(this.fd);
					this.fd = null;
				}
			} catch (closeError) {
				error ??= closeError;
			}
			callback(error);
		}
		close(callback) {
			if (callback) this.once("close", callback);
			this.autoClose = true;
			this.destroy();
		}
	}
	class WriteStream extends Writable {
		constructor(path, options) {
			options = settings(options);
			super(options);
			this.path = path;
			this.fd = options.fd ?? null;
			this.pos = position(options.start, "start");
			this.bytesWritten = 0;
			this.autoClose = options.autoClose !== false;
			this.pending = this.fd === null;
			this.flags = options.flags ?? "w";
			this.mode = options.mode;
		}
		_construct(callback) {
			try {
				if (this.fd === null) {
					this.fd = fs.openSync(this.path, this.flags, this.mode);
					this.emit("open", this.fd);
				}
				this.pending = false;
				this.emit("ready");
				callback();
			} catch (error) {
				callback(error);
			}
		}
		_write(chunk, encoding, callback) {
			try {
				const written = fs.writeSync(this.fd, chunk, 0, chunk.length, this.pos ?? null);
				if (this.pos !== void 0) this.pos += written;
				this.bytesWritten += written;
				callback();
			} catch (error) {
				callback(error);
			}
		}
		_destroy(error, callback) {
			ReadStream.prototype._destroy.call(this, error, callback);
		}
		close(callback) {
			if (callback) this.once("close", callback);
			this.autoClose = true;
			this.end();
		}
	}
	Object.assign(fs, {
		ReadStream,
		FileReadStream: ReadStream,
		WriteStream,
		FileWriteStream: WriteStream,
		createReadStream: (path, options) => new ReadStream(path, options),
		createWriteStream: (path, options) => new WriteStream(path, options)
	});
	const open = fs.promises.open;
	fs.promises.open = async (...args) => {
		const file = await open(...args);
		const close = file.close.bind(file);
		for (const method of ["createReadStream", "createWriteStream"]) file[method] = (options) => {
			const stream = fs[method](void 0, {
				...options,
				fd: file.fd,
				autoClose: false
			});
			if (options?.autoClose !== false) stream.once("close", () => {
				close().catch((error) => stream.emit("error", error));
			});
			return stream;
		};
		file.readableWebStream = (options) => {
			let done = false;
			return new ReadableStream({
				type: options?.type === "bytes" ? "bytes" : void 0,
				async pull(controller) {
					if (done) return;
					const buffer = /* @__PURE__ */ new Uint8Array(65536);
					try {
						const { bytesRead } = await file.read(buffer);
						if (bytesRead) controller.enqueue(buffer.subarray(0, bytesRead));
						else {
							done = true;
							controller.close();
							if (options?.autoClose) await close();
						}
					} catch (error) {
						done = true;
						controller.error(error);
					}
				},
				async cancel() {
					done = true;
					if (options?.autoClose) await close();
				}
			});
		};
		return file;
	};
}
//#endregion
//#region src/fs.mjs
installStreams(fs_default$1);
const constants = fs_default$1.constants;
const promises = fs_default$1.promises;
const Dir = fs_default$1.Dir;
const Dirent = fs_default$1.Dirent;
const FileReadStream = fs_default$1.FileReadStream;
const FileWriteStream = fs_default$1.FileWriteStream;
const ReadStream = fs_default$1.ReadStream;
const Stats = fs_default$1.Stats;
const Utf8Stream = fs_default$1.Utf8Stream;
const WriteStream = fs_default$1.WriteStream;
const _toUnixTimestamp = fs_default$1._toUnixTimestamp;
const access = fs_default$1.access;
const accessSync = fs_default$1.accessSync;
const appendFile = fs_default$1.appendFile;
const appendFileSync = fs_default$1.appendFileSync;
const chmod = fs_default$1.chmod;
const chmodSync = fs_default$1.chmodSync;
const chown = fs_default$1.chown;
const chownSync = fs_default$1.chownSync;
const close = fs_default$1.close;
const closeSync = fs_default$1.closeSync;
const copyFile = fs_default$1.copyFile;
const copyFileSync = fs_default$1.copyFileSync;
const cp = fs_default$1.cp;
const cpSync = fs_default$1.cpSync;
const createReadStream = fs_default$1.createReadStream;
const createWriteStream = fs_default$1.createWriteStream;
const exists = fs_default$1.exists;
const existsSync = fs_default$1.existsSync;
const fchmod = fs_default$1.fchmod;
const fchmodSync = fs_default$1.fchmodSync;
const fchown = fs_default$1.fchown;
const fchownSync = fs_default$1.fchownSync;
const fdatasync = fs_default$1.fdatasync;
const fdatasyncSync = fs_default$1.fdatasyncSync;
const fstat = fs_default$1.fstat;
const fstatSync = fs_default$1.fstatSync;
const fsync = fs_default$1.fsync;
const fsyncSync = fs_default$1.fsyncSync;
const ftruncate = fs_default$1.ftruncate;
const ftruncateSync = fs_default$1.ftruncateSync;
const futimes = fs_default$1.futimes;
const futimesSync = fs_default$1.futimesSync;
const glob = fs_default$1.glob;
const globSync = fs_default$1.globSync;
const lchmod = fs_default$1.lchmod;
const lchmodSync = fs_default$1.lchmodSync;
const lchown = fs_default$1.lchown;
const lchownSync = fs_default$1.lchownSync;
const link = fs_default$1.link;
const linkSync = fs_default$1.linkSync;
const lstat = fs_default$1.lstat;
const lstatSync = fs_default$1.lstatSync;
const lutimes = fs_default$1.lutimes;
const lutimesSync = fs_default$1.lutimesSync;
const mkdir = fs_default$1.mkdir;
const mkdirSync = fs_default$1.mkdirSync;
const mkdtemp = fs_default$1.mkdtemp;
const mkdtempDisposableSync = fs_default$1.mkdtempDisposableSync;
const mkdtempSync = fs_default$1.mkdtempSync;
const open = fs_default$1.open;
const openAsBlob = fs_default$1.openAsBlob;
const openSync = fs_default$1.openSync;
const opendir = fs_default$1.opendir;
const opendirSync = fs_default$1.opendirSync;
const read = fs_default$1.read;
const readFile = fs_default$1.readFile;
const readFileSync = fs_default$1.readFileSync;
const readSync = fs_default$1.readSync;
const readdir = fs_default$1.readdir;
const readdirSync = fs_default$1.readdirSync;
const readlink = fs_default$1.readlink;
const readlinkSync = fs_default$1.readlinkSync;
const readv = fs_default$1.readv;
const readvSync = fs_default$1.readvSync;
const realpath = fs_default$1.realpath;
const realpathSync = fs_default$1.realpathSync;
const rename = fs_default$1.rename;
const renameSync = fs_default$1.renameSync;
const rm = fs_default$1.rm;
const rmSync = fs_default$1.rmSync;
const rmdir = fs_default$1.rmdir;
const rmdirSync = fs_default$1.rmdirSync;
const stat = fs_default$1.stat;
const statSync = fs_default$1.statSync;
const statfs = fs_default$1.statfs;
const statfsSync = fs_default$1.statfsSync;
const symlink = fs_default$1.symlink;
const symlinkSync = fs_default$1.symlinkSync;
const truncate = fs_default$1.truncate;
const truncateSync = fs_default$1.truncateSync;
const unlink = fs_default$1.unlink;
const unlinkSync = fs_default$1.unlinkSync;
const unwatchFile = fs_default$1.unwatchFile;
const utimes = fs_default$1.utimes;
const utimesSync = fs_default$1.utimesSync;
const watch = fs_default$1.watch;
const watchFile = fs_default$1.watchFile;
const write = fs_default$1.write;
const writeFile = fs_default$1.writeFile;
const writeFileSync = fs_default$1.writeFileSync;
const writeSync = fs_default$1.writeSync;
const writev = fs_default$1.writev;
const writevSync = fs_default$1.writevSync;
var fs_default = fs_default$1;
//#endregion
export { lstatSync as $, fchmodSync as A, rmdirSync as At, ftruncate as B, unlinkSync as Bt, cp as C, realpath as Ct, exists as D, rm as Dt, createWriteStream as E, renameSync as Et, fs_default as F, symlink as Ft, globSync as G, watchFile as Gt, futimes as H, utimes as Ht, fstat as I, symlinkSync as It, lchown as J, writeFileSync as Jt, lchmod as K, write as Kt, fstatSync as L, truncate as Lt, fchownSync as M, statSync as Mt, fdatasync as N, statfs as Nt, existsSync as O, rmSync as Ot, fdatasyncSync as P, statfsSync as Pt, lstat as Q, fsync as R, truncateSync as Rt, copyFileSync as S, readvSync as St, createReadStream as T, rename as Tt, futimesSync as U, utimesSync as Ut, ftruncateSync as V, unwatchFile as Vt, glob as W, watch as Wt, link as X, writev as Xt, lchownSync as Y, writeSync as Yt, linkSync as Z, writevSync as Zt, chownSync as _, readdir as _t, ReadStream as a, mkdtempDisposableSync as at, constants as b, readlinkSync as bt, WriteStream as c, openAsBlob as ct, accessSync as d, opendirSync as dt, lutimes as et, appendFile as f, promises as ft, chown as g, readSync as gt, chmodSync as h, readFileSync as ht, FileWriteStream as i, mkdtemp as it, fchown as j, stat as jt, fchmod as k, rmdir as kt, _toUnixTimestamp as l, openSync as lt, chmod as m, readFile as mt, Dirent as n, mkdir as nt, Stats as o, mkdtempSync as ot, appendFileSync as p, read as pt, lchmodSync as q, writeFile as qt, FileReadStream as r, mkdirSync as rt, Utf8Stream as s, open as st, Dir as t, lutimesSync as tt, access as u, opendir as ut, close as v, readdirSync as vt, cpSync as w, realpathSync as wt, copyFile as x, readv as xt, closeSync as y, readlink as yt, fsyncSync as z, unlink as zt };
