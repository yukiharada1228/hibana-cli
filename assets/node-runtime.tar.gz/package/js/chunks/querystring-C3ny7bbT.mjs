import { a as __toESM, t as __commonJSMin } from "./rolldown-runtime-7_rZTKki.mjs";
import { Buffer } from "../buffer.mjs";
//#region node_modules/querystring-es3/decode.js
var require_decode = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function hasOwnProperty(obj, prop) {
		return Object.prototype.hasOwnProperty.call(obj, prop);
	}
	module.exports = function(qs, sep, eq, options) {
		sep = sep || "&";
		eq = eq || "=";
		var obj = {};
		if (typeof qs !== "string" || qs.length === 0) return obj;
		var regexp = /\+/g;
		qs = qs.split(sep);
		var maxKeys = 1e3;
		if (options && typeof options.maxKeys === "number") maxKeys = options.maxKeys;
		var len = qs.length;
		if (maxKeys > 0 && len > maxKeys) len = maxKeys;
		for (var i = 0; i < len; ++i) {
			var x = qs[i].replace(regexp, "%20"), idx = x.indexOf(eq), kstr, vstr, k, v;
			if (idx >= 0) {
				kstr = x.substr(0, idx);
				vstr = x.substr(idx + 1);
			} else {
				kstr = x;
				vstr = "";
			}
			k = decodeURIComponent(kstr);
			v = decodeURIComponent(vstr);
			if (!hasOwnProperty(obj, k)) obj[k] = v;
			else if (isArray(obj[k])) obj[k].push(v);
			else obj[k] = [obj[k], v];
		}
		return obj;
	};
	var isArray = Array.isArray || function(xs) {
		return Object.prototype.toString.call(xs) === "[object Array]";
	};
}));
//#endregion
//#region node_modules/querystring-es3/encode.js
var require_encode = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var stringifyPrimitive = function(v) {
		switch (typeof v) {
			case "string": return v;
			case "boolean": return v ? "true" : "false";
			case "number": return isFinite(v) ? v : "";
			default: return "";
		}
	};
	module.exports = function(obj, sep, eq, name) {
		sep = sep || "&";
		eq = eq || "=";
		if (obj === null) obj = void 0;
		if (typeof obj === "object") return map(objectKeys(obj), function(k) {
			var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
			if (isArray(obj[k])) return map(obj[k], function(v) {
				return ks + encodeURIComponent(stringifyPrimitive(v));
			}).join(sep);
			else return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
		}).join(sep);
		if (!name) return "";
		return encodeURIComponent(stringifyPrimitive(name)) + eq + encodeURIComponent(stringifyPrimitive(obj));
	};
	var isArray = Array.isArray || function(xs) {
		return Object.prototype.toString.call(xs) === "[object Array]";
	};
	function map(xs, f) {
		if (xs.map) return xs.map(f);
		var res = [];
		for (var i = 0; i < xs.length; i++) res.push(f(xs[i], i));
		return res;
	}
	var objectKeys = Object.keys || function(obj) {
		var res = [];
		for (var key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
		return res;
	};
}));
//#endregion
//#region src/querystring.mjs
var import_querystring_es3 = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports) => {
	exports.decode = exports.parse = require_decode();
	exports.encode = exports.stringify = require_encode();
})))(), 1);
const { decode, encode, parse, stringify } = import_querystring_es3.default;
const escape = encodeURIComponent;
function unescape(value) {
	try {
		return decodeURIComponent(value);
	} catch {
		return value.replace(/(?:%[0-9a-f]{2})+/gi, (text) => new TextDecoder().decode(Uint8Array.from(text.matchAll(/%([0-9a-f]{2})/gi), (match) => parseInt(match[1], 16))));
	}
}
function unescapeBuffer(value, decodeSpaces = false) {
	const text = String(value);
	const bytes = [];
	for (let index = 0; index < text.length; index += 1) {
		const char = text[index];
		if (decodeSpaces && char === "+") {
			bytes.push(32);
			continue;
		}
		if (char === "%" && index + 2 < text.length) {
			const hex = text.slice(index + 1, index + 3);
			if (/^[0-9a-f]{2}$/i.test(hex)) {
				bytes.push(parseInt(hex, 16));
				index += 2;
				continue;
			}
		}
		const encoded = Buffer.from(char);
		for (const byte of encoded) bytes.push(byte);
	}
	return Buffer.from(bytes);
}
var querystring_default = {
	...import_querystring_es3.default,
	escape,
	unescape,
	unescapeBuffer
};
//#endregion
export { querystring_default as a, unescapeBuffer as c, parse as i, encode as n, stringify as o, escape as r, unescape as s, decode as t };
