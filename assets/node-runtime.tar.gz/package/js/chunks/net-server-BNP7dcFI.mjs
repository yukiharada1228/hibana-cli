import { a as codedError, d as invalidArgType$2, f as invalidArgValue$2, g as outOfRange$1, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { t as EventEmitter } from "./event-emitter-D4b0qsct.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/errors.js
/**
* Error constructors for the portable node:http shim.
*
* Node's generic argument errors and Jco's unsupported/deprecated refusals come from the shared
* factory and templates in `../errors/core.js`, so they carry the same identity as every other
* builtin. Only the HTTP-specific codes (`ERR_INVALID_HTTP_TOKEN`, `ERR_INVALID_CHAR`,
* `ERR_HTTP_HEADERS_SENT`, `ERR_STREAM_WRITE_AFTER_END`) and the host-record reconstruction live
* here. Message templates for those follow nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/errors.js (MIT license).
*/
function httpError(name, code, message) {
	const error = name === "TypeError" ? new TypeError(message) : name === "RangeError" ? new RangeError(message) : new Error(message);
	return codedError(error, code);
}
function invalidArgType$1(name, expected, value) {
	return invalidArgType$2(name, expected, value);
}
function invalidArgValue$1(name, value) {
	return invalidArgValue$2(name, value);
}
function outOfRange(name, range, value) {
	return outOfRange$1(name, range, value);
}
function invalidHttpToken(label, value) {
	return httpError("TypeError", "ERR_INVALID_HTTP_TOKEN", `${label} must be a valid HTTP token ["${value}"]`);
}
function invalidHeaderChar(name) {
	return httpError("TypeError", "ERR_INVALID_CHAR", `Invalid character in header content ["${name}"]`);
}
function headerAlreadySent() {
	return httpError("Error", "ERR_HTTP_HEADERS_SENT", "Cannot modify headers after they are sent to the client");
}
function writeAfterEnd() {
	return httpError("Error", "ERR_STREAM_WRITE_AFTER_END", "write after end");
}
function unsupported(api, detail) {
	throw unsupportedNodeApi(api, detail ?? "the Jco component runtime does not implement it");
}
function deprecated(api, replacement) {
	throw deprecatedNodeApi(api, replacement);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/bytes.js
/** Convert the byte-like chunk accepted by Node stream and protocol APIs. */
function bodyBytes(value, encoding = "utf8") {
	if (typeof value === "string") {
		const normalized = encoding.toLowerCase().replace("-", "");
		if (normalized === "utf8" || normalized === "utf") return new TextEncoder().encode(value);
		if (normalized === "latin1" || normalized === "binary" || normalized === "ascii") return Uint8Array.from(value, (character) => character.charCodeAt(0) & 255);
		throw invalidArgValue$2("encoding", encoding);
	}
	if (value instanceof ArrayBuffer) return new Uint8Array(value.slice(0));
	if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength));
	throw invalidArgType$2("chunk", "string, Buffer, TypedArray, or DataView", value);
}
function concatBytes(chunks) {
	const size = chunks.reduce((total, chunk) => total + chunk.byteLength, 0);
	const result = new Uint8Array(size);
	let offset = 0;
	for (const chunk of chunks) {
		result.set(chunk, offset);
		offset += chunk.byteLength;
	}
	return result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/body.js
function base64(value) {
	const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	const bytes = new TextEncoder().encode(value);
	let output = "";
	for (let index = 0; index < bytes.length; index += 3) {
		const a = bytes[index];
		const b = bytes[index + 1];
		const c = bytes[index + 2];
		output += alphabet[a >> 2];
		output += alphabet[(a & 3) << 4 | (b ?? 0) >> 4];
		output += b === void 0 ? "=" : alphabet[(b & 15) << 2 | (c ?? 0) >> 6];
		output += c === void 0 ? "=" : alphabet[c & 63];
	}
	return output;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/headers.js
/**
* Header validation and storage for the portable node:http shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_outgoing.js,
* lib/_http_common.js, and lib/_http_incoming.js (MIT license). Node's
* kOutHeaders store and header-line folding are reimplemented over a typed
* Map so headers can cross the WIT boundary as byte fields.
*/
const TOKEN = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
const INVALID_VALUE = /[\0\r\n]/;
function validateHeaderName(name, label = "Header name") {
	if (typeof name !== "string") throw invalidArgType$1("name", "string", name);
	if (!TOKEN.test(name)) throw invalidHttpToken(label, name);
}
function validateHeaderValue(name, value) {
	if (value === void 0) throw invalidArgType$1("value", "string", value);
	if (INVALID_VALUE.test(String(value))) throw invalidHeaderChar(name);
}
function values(value) {
	return (Array.isArray(value) ? value : [value]).map(String);
}
var HeaderStore = class {
	#headers = /* @__PURE__ */ new Map();
	#sent = false;
	constructor(headers) {
		if (Array.isArray(headers)) {
			if (headers.length % 2 !== 0) throw invalidArgType$1("headers", "an even-length array", headers);
			for (let index = 0; index < headers.length; index += 2) this.append(headers[index], headers[index + 1]);
		} else if (headers) {
			for (const [name, value] of Object.entries(headers)) if (value !== void 0) this.set(name, value);
		}
	}
	markSent() {
		this.#sent = true;
	}
	get sent() {
		return this.#sent;
	}
	set(name, value) {
		this.#assertMutable();
		this.setInternal(name, value);
	}
	setInternal(name, value) {
		validateHeaderName(name);
		for (const item of values(value)) validateHeaderValue(name, item);
		this.#headers.set(name.toLowerCase(), {
			name,
			value: Array.isArray(value) ? [...value] : value
		});
	}
	append(name, value) {
		this.#assertMutable();
		const current = this.#headers.get(name.toLowerCase());
		if (!current) {
			this.set(name, value);
			return;
		}
		this.set(current.name, [...values(current.value), ...values(value)]);
	}
	get(name) {
		return this.#headers.get(name.toLowerCase())?.value;
	}
	has(name) {
		return this.#headers.has(name.toLowerCase());
	}
	delete(name) {
		this.#assertMutable();
		this.#headers.delete(name.toLowerCase());
	}
	names() {
		return [...this.#headers.keys()];
	}
	rawNames() {
		return [...this.#headers.values()].map(({ name }) => name);
	}
	object() {
		const result = Object.create(null);
		for (const [name, { value }] of this.#headers) result[name] = Array.isArray(value) ? [...value] : value;
		return result;
	}
	entries() {
		return [...this.#headers.values()].flatMap(({ name, value }) => values(value).map((item) => [name, item]));
	}
	fields() {
		return this.entries().map(([name, value]) => ({
			name,
			value: Uint8Array.from(value, (character) => character.charCodeAt(0) & 255)
		}));
	}
	#assertMutable() {
		if (this.#sent) throw headerAlreadySent();
	}
};
function incomingHeaders(headers) {
	const decoder = new TextDecoder("latin1");
	const result = {};
	const rawHeaders = [];
	for (const { name, value } of headers) {
		const text = decoder.decode(value);
		rawHeaders.push(name, text);
		const lower = name.toLowerCase();
		const current = result[lower];
		if (lower === "set-cookie") result[lower] = current === void 0 ? [text] : [...Array.isArray(current) ? current : [current], text];
		else if (current === void 0) result[lower] = text;
		else result[lower] = `${Array.isArray(current) ? current.join(", ") : current}, ${text}`;
	}
	return {
		headers: result,
		rawHeaders
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/incoming-message.js
var IncomingMessage = class extends EventEmitter {
	aborted = false;
	complete = true;
	httpVersion;
	httpVersionMajor;
	httpVersionMinor;
	headers;
	headersDistinct;
	rawHeaders;
	trailers = {};
	trailersDistinct = {};
	rawTrailers = [];
	statusCode;
	statusMessage;
	method;
	url;
	socket;
	signal = void 0;
	closed = false;
	destroyed = false;
	readable = true;
	readableEnded = false;
	errored = null;
	#body;
	#read = false;
	#encoding;
	#started = false;
	constructor(message) {
		super();
		const [major = 1, minor = 1] = message.httpVersion.split(".").map(Number);
		const { headers, rawHeaders } = incomingHeaders(message.headers);
		this.httpVersion = message.httpVersion;
		this.httpVersionMajor = major;
		this.httpVersionMinor = minor;
		this.headers = headers;
		this.headersDistinct = Object.fromEntries(Object.entries(headers).map(([name, value]) => [name, Array.isArray(value) ? [...value] : [value]]));
		this.rawHeaders = rawHeaders;
		if ("statusCode" in message) {
			this.statusCode = message.statusCode;
			this.statusMessage = message.statusMessage;
			this.method = void 0;
			this.url = void 0;
			this.socket = void 0;
		} else {
			this.statusCode = void 0;
			this.statusMessage = void 0;
			this.method = message.method;
			this.url = message.url;
			this.socket = {
				readable: true,
				writable: true,
				remoteAddress: message.remoteAddress,
				remotePort: message.remotePort,
				remoteFamily: message.remoteAddress === void 0 ? void 0 : message.remoteAddress.includes(":") ? "IPv6" : "IPv4"
			};
		}
		this.#body = message.body.slice();
	}
	get connection() {
		return this.socket;
	}
	setEncoding(encoding) {
		this.#encoding = encoding;
		return this;
	}
	read() {
		if (this.#read) return null;
		this.#read = true;
		return this.#decodedBody();
	}
	resume() {
		this._start();
		return this;
	}
	pause() {
		return this;
	}
	pipe(destination) {
		const body = this.#decodedBody();
		if (this.#body.byteLength > 0) destination.write(body);
		destination.end?.();
		this._start();
		return destination;
	}
	setTimeout(_milliseconds, callback) {
		if (callback) this.once("timeout", callback);
		return this;
	}
	destroy(error) {
		if (this.destroyed) return this;
		this.destroyed = true;
		this.readable = false;
		this.errored = error ?? null;
		queueMicrotask(() => {
			if (error) this.emit("error", error);
			this.closed = true;
			this.emit("close");
		});
		return this;
	}
	_start() {
		if (this.#started || this.destroyed) return;
		this.#started = true;
		queueMicrotask(() => {
			if (this.destroyed) return;
			if (this.#body.byteLength > 0) {
				this.#read = true;
				this.emit("data", this.#decodedBody());
			}
			this.readable = false;
			this.readableEnded = true;
			this.emit("end");
			this.closed = true;
			this.emit("close");
		});
	}
	async *[Symbol.asyncIterator]() {
		if (!this.#read && this.#body.byteLength > 0) {
			this.#read = true;
			yield this.#decodedBody();
		}
		this.readable = false;
		this.readableEnded = true;
	}
	#decodedBody() {
		if (!this.#encoding) return this.#body.slice();
		return new TextDecoder(this.#encoding).decode(this.#body);
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http/outgoing-message.js
/**
* Buffered OutgoingMessage base for the portable node:http shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/_http_outgoing.js (MIT
* license). The header API and public state fields are kept; the
* socket-backed output queue is replaced by an in-memory body that is handed
* to the implementation once on end().
*/
var OutgoingMessage = class extends EventEmitter {
	#body = [];
	_headers;
	chunkedEncoding = false;
	shouldKeepAlive = true;
	useChunkedEncodingByDefault = true;
	sendDate = false;
	strictContentLength = false;
	destroyed = false;
	finished = false;
	writable = true;
	writableCorked = 0;
	writableEnded = false;
	writableFinished = false;
	writableHighWaterMark = 16384;
	writableObjectMode = false;
	#timeout = 0;
	constructor(headers) {
		super();
		this._headers = new HeaderStore(headers);
	}
	get headersSent() {
		return this._headers.sent;
	}
	get writableLength() {
		return this.#body.reduce((total, chunk) => total + chunk.byteLength, 0);
	}
	get socket() {}
	get connection() {
		return this.socket;
	}
	appendHeader(name, value) {
		this._headers.append(name, value);
		return this;
	}
	setHeader(name, value) {
		this._headers.set(name, value);
		return this;
	}
	setHeaders(headers) {
		for (const [name, value] of headers.entries()) this.setHeader(name, value);
		return this;
	}
	getHeader(name) {
		return this._headers.get(name);
	}
	getHeaders() {
		return this._headers.object();
	}
	getHeaderNames() {
		return this._headers.names();
	}
	getRawHeaderNames() {
		return this._headers.rawNames();
	}
	hasHeader(name) {
		return this._headers.has(name);
	}
	removeHeader(name) {
		this._headers.delete(name);
	}
	flushHeaders() {
		this._headers.markSent();
	}
	write(chunk, encoding, callback) {
		if (this.writableEnded) {
			const error = writeAfterEnd();
			queueMicrotask(() => this.emit("error", error));
			return false;
		}
		const actualEncoding = typeof encoding === "string" ? encoding : void 0;
		const actualCallback = typeof encoding === "function" ? encoding : callback;
		this._headers.markSent();
		this.#body.push(bodyBytes(chunk, actualEncoding));
		if (actualCallback) queueMicrotask(actualCallback);
		return true;
	}
	end(chunkOrCallback, encodingOrCallback, callback) {
		if (this.writableEnded) {
			const error = writeAfterEnd();
			queueMicrotask(() => this.emit("error", error));
			return this;
		}
		const chunk = typeof chunkOrCallback === "function" ? void 0 : chunkOrCallback;
		const actualEncoding = typeof encodingOrCallback === "string" ? encodingOrCallback : void 0;
		const actualCallback = typeof chunkOrCallback === "function" ? chunkOrCallback : typeof encodingOrCallback === "function" ? encodingOrCallback : callback;
		if (this.destroyed) {
			if (actualCallback) queueMicrotask(actualCallback);
			return this;
		}
		if (chunk !== void 0) this.#body.push(bodyBytes(chunk, actualEncoding));
		this.writableEnded = true;
		this.finished = true;
		this.writable = false;
		let deliver;
		let failure;
		try {
			deliver = this._finalize(concatBytes(this.#body));
		} catch (error) {
			failure = error;
		}
		this._headers.markSent();
		queueMicrotask(() => {
			if (failure !== void 0) {
				this.emit("error", failure);
				return;
			}
			this.writableFinished = true;
			this.emit("finish");
			actualCallback?.();
			deliver?.();
		});
		return this;
	}
	cork() {
		this.writableCorked += 1;
	}
	uncork() {
		this.writableCorked = Math.max(0, this.writableCorked - 1);
	}
	setTimeout(milliseconds, callback) {
		if (typeof milliseconds !== "number") throw invalidArgType$1("msecs", "number", milliseconds);
		if (!Number.isFinite(milliseconds) || milliseconds < 0 || milliseconds > 4294967295) throw outOfRange("msecs", ">= 0 and <= 4294967295", milliseconds);
		this.#timeout = Math.trunc(milliseconds);
		if (callback) this.once("timeout", callback);
		return this;
	}
	destroy(error) {
		if (this.destroyed) return this;
		this.destroyed = true;
		this.writable = false;
		queueMicrotask(() => {
			if (error) this.emit("error", error);
			this.emit("close");
		});
		return this;
	}
	addTrailers(_headers) {
		return unsupported("http.OutgoingMessage.addTrailers");
	}
	pipe() {
		return unsupported("http.OutgoingMessage.pipe", "outgoing HTTP messages are not readable");
	}
	_timeout() {
		return this.#timeout;
	}
	_finalize(_body) {}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/net-server.js
function invalidArgValue(name, value) {
	return Object.assign(/* @__PURE__ */ new TypeError(`The argument '${name}' is invalid. Received ${String(value)}`), { code: "ERR_INVALID_ARG_VALUE" });
}
function invalidArgType(name, value) {
	return Object.assign(/* @__PURE__ */ new TypeError(`The "${name}" argument must be of type object, string, or number. Received ${String(value)}`), { code: "ERR_INVALID_ARG_TYPE" });
}
/** Shared overload normalization for Node-style net-backed server `listen()` methods. */
function parseListenArguments(args) {
	const values = [...args];
	const callback = typeof values.at(-1) === "function" ? values.pop() : void 0;
	const first = values.shift();
	if (typeof first === "object" && first !== null) return {
		options: { ...first },
		callback
	};
	if (typeof first === "string" && !/^\d+$/.test(first)) return {
		options: { path: first },
		callback
	};
	const port = typeof first === "string" ? Number(first) : first;
	if (typeof port !== "number" || !Number.isInteger(port) || port < 0 || port > 65535) throw invalidArgValue("options.port", first);
	const options = { port };
	if (typeof values[0] === "string") options.host = values.shift();
	if (typeof values[0] === "number") options.backlog = values.shift();
	if (values.length > 0) throw invalidArgType("options", first);
	return {
		options,
		callback
	};
}
//#endregion
export { validateHeaderValue as a, deprecated as c, outOfRange as d, unsupported as f, validateHeaderName as i, invalidArgType$1 as l, OutgoingMessage as n, base64 as o, IncomingMessage as r, bodyBytes as s, parseListenArguments as t, invalidArgValue$1 as u };
