//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/diagnostics-channel/channel.js
/**
* A named publish/subscribe channel, matching Node's `diagnostics_channel.Channel`.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/diagnostics_channel.js (MIT
* license). The active/inactive prototype swap, weak channel map, and native
* binding are replaced by one interned `Map` and a plain subscriber array.
*
* Channels are interned by name so `channel(name)` returns the same object every time, which is
* what lets a publisher and a subscriber find each other without sharing a reference.
*/
var Channel = class {
	name;
	#subscribers = [];
	#stores = /* @__PURE__ */ new Map();
	constructor(name) {
		this.name = name;
	}
	/** Whether anything is listening. Publishers check this to skip building a message. */
	get hasSubscribers() {
		return this.#subscribers.length > 0;
	}
	/**
	* Deliver `message` to every subscriber.
	*
	* Bound stores are deliberately not applied: Node applies them from `runStores`, not `publish`.
	*/
	publish(message) {
		if (this.#subscribers.length === 0) return;
		for (const subscriber of [...this.#subscribers]) subscriber(message, this.name);
	}
	subscribe(onMessage) {
		this.#subscribers.push(onMessage);
	}
	/** Remove a subscriber, reporting whether one was actually registered. */
	unsubscribe(onMessage) {
		const index = this.#subscribers.indexOf(onMessage);
		if (index === -1) return false;
		this.#subscribers.splice(index, 1);
		return true;
	}
	/**
	* Bind a store so published data is visible through it while subscribers run.
	*
	* The store only has to offer `run`, so jco-std's `AsyncLocalStorage` and Node's both work. Note
	* the scoping is synchronous: see the async-hooks module for why a store cannot follow an await.
	*/
	bindStore(store, transform = (data) => data) {
		this.#stores.set(store, transform);
	}
	unbindStore(store) {
		return this.#stores.delete(store);
	}
	/**
	* Publish `data`, then run `fn` with it visible through every bound store.
	*
	* Node publishes from here as well as applying the stores, so subscribers see the message with
	* the stores already entered.
	*/
	runStores(data, fn, thisArg, ...args) {
		return this.#runWithStores(data, () => {
			this.publish(data);
			return Reflect.apply(fn, thisArg, args);
		});
	}
	/** Nest every bound store around `fn`, innermost last. */
	#runWithStores(data, fn) {
		let run = fn;
		for (const [store, transform] of this.#stores) {
			const inner = run;
			run = () => store.run(transform(data), inner);
		}
		return run();
	}
};
/** Interned channels, so a name always maps to one instance. */
const channels = /* @__PURE__ */ new Map();
function channel(name) {
	const existing = channels.get(name);
	if (existing) return existing;
	const created = new Channel(name);
	channels.set(name, created);
	return created;
}
/** Whether a channel with this name exists and has subscribers. */
function hasSubscribers(name) {
	return channels.get(name)?.hasSubscribers ?? false;
}
function subscribe(name, onMessage) {
	channel(name).subscribe(onMessage);
}
function unsubscribe(name, onMessage) {
	return channel(name).unsubscribe(onMessage);
}
//#endregion
export { unsubscribe as a, subscribe as i, channel as n, hasSubscribers as r, Channel as t };
