import { a as __toESM } from "./rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, c as determineSpecificType, d as invalidArgType$1, g as outOfRange$1, l as formatList } from "./core-DGqXzKN-.mjs";
import { AsyncResource } from "../async_hooks.mjs";
import { t as require_events } from "./events-Wk51UuK0.mjs";
//#region ../../extensions/node-events/src/index.mjs
var import_events = /* @__PURE__ */ __toESM(require_events(), 1);
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/events/listener-count.js
/**
* `events.listenerCount(emitter, eventName)`.
*
* Deprecated in Node in favour of `emitter.listenerCount()`, but still present and still used, so
* it is implemented rather than refused. unenv ships it as a `notImplemented` stub that throws.
*
* Follows Node: delegate to the emitter's own method when it has one, so subclasses that override
* counting are honoured, and otherwise apply the core implementation to the object.
*
* @param core - the emitter core to fall back to
*/
function createListenerCount(core) {
	return function listenerCount(emitter, eventName) {
		if (typeof emitter?.listenerCount === "function") return emitter.listenerCount.call(emitter, eventName);
		return core.EventEmitter.prototype.listenerCount.call(emitter, eventName);
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/events/errors.js
/**
* Node-style coded errors for the `node:events` entry points Jco implements.
*
* These mirror Node's own argument validation rather than Jco's unsupported-API errors: the
* functions here are supported, so a caller passing bad arguments must see what Node raises,
* message included. The factory, message templates, and `Received ...` clause are the shared
* ones in `../errors/core.js`.
*/
/**
* Node's `ERR_INVALID_ARG_TYPE`, phrased for a primitive type.
*
* @param name - the parameter that was wrong, as Node names it
* @param expected - the type Node accepts
* @param actual - the value that was passed
*/
function invalidArgType(name, expected, actual) {
	return invalidArgType$1(name, expected, actual);
}
/**
* Node's `ERR_INVALID_ARG_TYPE`, phrased for a class.
*
* @param name - the parameter that was wrong, as Node names it
* @param expected - the classes Node accepts for it
* @param actual - the value that was passed
*/
function invalidArgInstance(name, expected, actual) {
	return codedError(/* @__PURE__ */ new TypeError(`The "${name}" argument must be an instance of ${formatList(expected, "or")}. Received ${determineSpecificType(actual)}`), "ERR_INVALID_ARG_TYPE");
}
/**
* Node's `ERR_OUT_OF_RANGE`.
*
* @param name - the parameter that was out of range
* @param range - the range Node requires, phrased as Node phrases it
* @param actual - the value that was passed
*/
function outOfRange(name, range, actual) {
	return outOfRange$1(name, range, actual);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/events/max-listeners.js
/**
* Per-`EventTarget` listener limits.
*
* Node stores this on the target under an internal symbol. Nothing outside `node:events` may
* observe it, so a `WeakMap` keyed by the target is equivalent and does not mutate objects the
* caller owns.
*/
const eventTargetLimits = /* @__PURE__ */ new WeakMap();
/** Node accepts anything with `addEventListener`/`removeEventListener` as an `EventTarget`. */
function isEventTarget$1(value) {
	return typeof value === "object" && value !== null && typeof value.addEventListener === "function" && typeof value.removeEventListener === "function";
}
/** Node's `validateNumber(n, name, 0)`: a number, and not negative or `NaN`. */
function validateLimit(n) {
	if (typeof n !== "number") throw invalidArgType("setMaxListeners", "number", n);
	if (Number.isNaN(n) || n < 0) throw outOfRange("setMaxListeners", ">= 0", n);
}
/**
* `events.setMaxListeners()` and `events.getMaxListeners()`.
*
* unenv ships `setMaxListeners` as a `notImplemented` stub, and its `getMaxListeners` throws on an
* `EventTarget` because it only handles emitters. Both are implemented here against Node's
* behavior; the emitter half delegates to the core rather than reimplementing it.
*
* @param core - the emitter core supplying `defaultMaxListeners`
*/
function createMaxListeners(core) {
	/**
	* `events.setMaxListeners(n[, ...eventTargets])`.
	*
	* With no targets this sets the default for emitters created afterwards; with targets it sets
	* the limit on each one, accepting both `EventEmitter`s and `EventTarget`s.
	*/
	function setMaxListeners(n = core.EventEmitter.defaultMaxListeners, ...eventTargets) {
		validateLimit(n);
		if (eventTargets.length === 0) {
			core.EventEmitter.defaultMaxListeners = n;
			return;
		}
		for (const target of eventTargets) if (isEventTarget$1(target)) eventTargetLimits.set(target, n);
		else if (typeof target?.setMaxListeners === "function") target.setMaxListeners(n);
		else throw invalidArgInstance("eventTargets", ["EventEmitter", "EventTarget"], target);
	}
	/** `events.getMaxListeners(emitterOrEventTarget)`. */
	function getMaxListeners(emitterOrEventTarget) {
		if (typeof emitterOrEventTarget?.getMaxListeners === "function") return emitterOrEventTarget.getMaxListeners();
		if (isEventTarget$1(emitterOrEventTarget)) return eventTargetLimits.get(emitterOrEventTarget) ?? core.EventEmitter.defaultMaxListeners;
		throw invalidArgInstance("emitter", ["EventEmitter", "EventTarget"], emitterOrEventTarget);
	}
	return {
		getMaxListeners,
		setMaxListeners
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/events/index.js
/**
* Complete an emitter core with the module-level functions it is missing.
*
* Jco's `node:events` is unenv's `EventEmitter` plus these three. `EventEmitter` itself, `once`,
* `on`, `getEventListeners`, `addAbortListener` and `EventEmitterAsyncResource` all match Node
* already and are re-exported untouched.
*
* @param core - the emitter core to complete
* @returns the entry points to layer over it, each matching Node 24
*/
function completeEvents(core) {
	return {
		listenerCount: createListenerCount(core),
		...createMaxListeners(core)
	};
}
//#endregion
//#region src/events.mjs
const completed = completeEvents({ EventEmitter: import_events.EventEmitter });
const listenerCount = completed.listenerCount;
const getMaxListeners = completed.getMaxListeners;
const setMaxListeners = completed.setMaxListeners;
const errorMonitor = Symbol("events.errorMonitor");
const captureRejectionSymbol = Symbol.for("nodejs.rejection");
const captureRejections = false;
const usingDomains = false;
import_events.EventEmitter.errorMonitor ??= errorMonitor;
import_events.EventEmitter.captureRejectionSymbol ??= captureRejectionSymbol;
const isEventTarget = (target) => typeof target?.addEventListener === "function" && typeof target?.removeEventListener === "function";
function getEventListeners(target, name) {
	if (isEventTarget(target) && typeof target.listeners !== "function") return [];
	return target.listeners(name);
}
function addAbortListener(signal, listener) {
	if (typeof listener !== "function") throw Object.assign(/* @__PURE__ */ new TypeError("The \"listener\" argument must be of type function"), { code: "ERR_INVALID_ARG_TYPE" });
	let remove;
	if (signal.aborted) {
		queueMicrotask(() => listener({
			type: "abort",
			target: signal
		}));
		remove = () => {};
	} else {
		signal.addEventListener("abort", listener, { once: true });
		remove = () => signal.removeEventListener("abort", listener);
	}
	return { [Symbol.dispose]: remove };
}
/**
* `events.on()`: consume an emitter as an async iterator, buffering events that
* arrive faster than the consumer reads them.
*/
function on(emitter, name, options = {}) {
	const { signal, close = [], highWaterMark = Number.MAX_SAFE_INTEGER } = options;
	signal?.throwIfAborted?.();
	const queue = [];
	const waiting = [];
	let error = null;
	let done = false;
	const settle = () => {
		while (waiting.length && (queue.length || done || error)) {
			const { resolve, reject } = waiting.shift();
			if (queue.length) resolve({
				value: queue.shift(),
				done: false
			});
			else if (error) reject(error);
			else resolve({
				value: void 0,
				done: true
			});
		}
	};
	const push = (...args) => {
		if (queue.length < highWaterMark) queue.push(args);
		settle();
	};
	const finish = (cause) => {
		if (done) return;
		done = true;
		error = cause ?? error;
		emitter.off(name, push);
		emitter.off("error", fail);
		for (const event of close) emitter.off(event, stop);
		settle();
	};
	const fail = (cause) => finish(cause ?? /* @__PURE__ */ new Error("Emitter errored"));
	const stop = () => finish();
	emitter.on(name, push);
	emitter.on("error", fail);
	for (const event of close) emitter.on(event, stop);
	const abort = signal ? addAbortListener(signal, () => fail(signal.reason)) : void 0;
	return {
		next: () => new Promise((resolve, reject) => {
			waiting.push({
				resolve,
				reject
			});
			settle();
		}),
		return: async () => {
			finish();
			abort?.[Symbol.dispose]();
			return {
				value: void 0,
				done: true
			};
		},
		throw: async (cause) => {
			finish(cause);
			abort?.[Symbol.dispose]();
			throw cause;
		},
		[Symbol.asyncIterator]() {
			return this;
		}
	};
}
var EventEmitterAsyncResource = class extends import_events.EventEmitter {
	#resource;
	#type;
	constructor(options = {}) {
		const { captureRejections, ...rest } = options;
		super({ captureRejections });
		this.#type = rest.name ?? new.target.name;
		this.#resource = new AsyncResource(this.#type);
	}
	emit(...args) {
		return this.#resource.runInAsyncScope(() => super.emit(...args));
	}
	emitDestroy() {
		this.#resource.emitDestroy();
	}
	get asyncResource() {
		return this.#resource;
	}
	get type() {
		return this.#type;
	}
};
const defaultMaxListeners = import_events.default.defaultMaxListeners;
const init = import_events.default.init;
//#endregion
export { defaultMaxListeners as a, getMaxListeners as c, on as d, setMaxListeners as f, captureRejections as i, init as l, import_events as m, addAbortListener as n, errorMonitor as o, usingDomains as p, captureRejectionSymbol as r, getEventListeners as s, EventEmitterAsyncResource as t, listenerCount as u };
