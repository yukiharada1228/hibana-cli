//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/host-error.js
/**
* Serialization of errors across the host-backed Node builtin WIT boundary.
*
* A Node host adapter runs the real Node API and must hand any thrown error back to the guest as
* a plain WIT `error` record; the guest then rebuilds an `Error` from it. The record shape and the
* errno encoding are the same for every builtin, so the conversion lives here once. Builtins with
* extra fields (`path`/`dest`, `hostname`, `address`/`port`, `info`) spread `serializeHostError`
* and add them.
*/
/** Narrow an unknown thrown value to a readable record; anything else reads as empty. */
function errorRecord(error) {
	return typeof error === "object" && error !== null ? error : {};
}
/** Read a string-valued field, or `undefined` when it is absent or not a string. */
function stringField(value) {
	return typeof value === "string" ? value : void 0;
}
/** Encode Node's numeric-or-symbolic `errno` as the WIT `errno` variant. */
function encodeErrno(value) {
	if (typeof value === "number") return {
		tag: "number",
		val: BigInt(value)
	};
	if (typeof value === "string") return {
		tag: "symbolic",
		val: value
	};
}
/** Decode the WIT `errno` variant back to the number-or-string Node exposes. */
function decodeErrno(value) {
	if (!value) return;
	return value.tag === "number" ? Number(value.val) : value.val;
}
/** Serialize the fields every builtin's host error record shares. */
function serializeHostError(error) {
	const value = errorRecord(error);
	return {
		name: stringField(value.name) ?? "Error",
		message: stringField(value.message) ?? String(error),
		code: stringField(value.code),
		errno: encodeErrno(value.errno),
		syscall: stringField(value.syscall)
	};
}
/** Read either representation of a synchronous WIT result without losing its error fields. */
function callHost(operation, makeError) {
	let result;
	try {
		result = operation();
	} catch (error) {
		const record = errorRecord(error);
		const payload = errorRecord(record.payload ?? error);
		if ((!(error instanceof Error) || record.payload !== void 0) && typeof payload.name === "string" && typeof payload.message === "string") throw makeError(payload);
		throw error;
	}
	if (result !== null && typeof result === "object" && "tag" in result) {
		if (result.tag === "err") throw makeError(result.val);
		if (result.tag === "ok") return result.val;
	}
	return result;
}
//#endregion
export { decodeErrno as n, serializeHostError as r, callHost as t };
