import { d as invalidArgType } from "./core-DGqXzKN-.mjs";
import "./validation-qQPlCQ6g.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/stream/shared.js
let encoder;
function isObject(value) {
	return typeof value === "object" && value !== null || typeof value === "function";
}
function isPromiseLike(value) {
	return isObject(value) && typeof value.then === "function";
}
function isArrayBufferLike(value) {
	return value instanceof ArrayBuffer || typeof SharedArrayBuffer !== "undefined" && value instanceof SharedArrayBuffer;
}
function isPrimitiveChunk(value) {
	return typeof value === "string" || isArrayBufferLike(value) || ArrayBuffer.isView(value);
}
function primitiveToUint8Array(value) {
	if (typeof value === "string") return (encoder ??= new TextEncoder()).encode(value);
	if (isArrayBufferLike(value)) return new Uint8Array(value);
	return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
}
function toUint8Array(value, name = "chunk") {
	if (!isPrimitiveChunk(value)) throw invalidArgType(name, [
		"string",
		"ArrayBuffer",
		"ArrayBufferView"
	], value);
	return primitiveToUint8Array(value);
}
function validateAbortSignal(signal, name = "options.signal") {
	if (signal !== void 0 && (!isObject(signal) || typeof signal.aborted !== "boolean" || typeof signal.addEventListener !== "function" || typeof signal.removeEventListener !== "function" || typeof signal.throwIfAborted !== "function")) throw invalidArgType(name, "AbortSignal", signal);
}
//#endregion
export { validateAbortSignal as i, isPromiseLike as n, toUint8Array as r, isObject as t };
