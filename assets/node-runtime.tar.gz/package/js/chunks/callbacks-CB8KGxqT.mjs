import { a as codedError, f as invalidArgValue } from "./core-DGqXzKN-.mjs";
import { a as validateFunction, o as validateInteger } from "./validation-qQPlCQ6g.mjs";
import "./errors-Dlg0HNHo.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/compat.js
function isWritable(stream) {
	if (stream === null || typeof stream !== "object") return false;
	const value = stream;
	const explicit = value[Symbol.for("nodejs.stream.writable")];
	if (explicit != null) return !!explicit;
	if (typeof value.writable !== "boolean") return false;
	const state = value._writableState || value._readableState;
	if (value.destroyed || value[Symbol.for("nodejs.stream.destroyed")] || state?.destroyed) return false;
	const writable = typeof value.write === "function" && typeof value.on === "function" && (!value._readableState || value._writableState?.writable !== false);
	const ended = value.writableEnded === true || !value._writableState?.errored && value._writableState?.ended === true;
	return writable && value.writable && !ended;
}
/** Diagnostic formatting only; do not import Node's host-specific util implementation. */
function inspect(value) {
	return String(value);
}
function validateUint32(value, name, positive = false) {
	validateInteger(value, name, positive ? 1 : 0, 4294967295);
}
/** QuickJS exposes promise jobs even when queueMicrotask is not installed. */
function defer(callback) {
	if (typeof queueMicrotask === "function") queueMicrotask(callback);
	else Promise.resolve().then(callback);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/utils.js
const kUTF16SurrogateThreshold = 65536;
const kEscape = "\x1B";
const kSubstringSearch = Symbol("kSubstringSearch");
function CSI(strings, ...args) {
	let ret = `${kEscape}[`;
	for (let n = 0; n < strings.length; n++) {
		ret += strings[n];
		if (n < args.length) ret += args[n];
	}
	return ret;
}
CSI.kEscape = kEscape;
CSI.kClearToLineBeginning = CSI`1K`;
CSI.kClearToLineEnd = CSI`0K`;
CSI.kClearLine = CSI`2K`;
CSI.kClearScreenDown = CSI`0J`;
function charLengthLeft(str, i) {
	if (i <= 0) return 0;
	if (i > 1 && str.codePointAt(i - 2) >= kUTF16SurrogateThreshold || str.codePointAt(i - 1) >= kUTF16SurrogateThreshold) return 2;
	return 1;
}
function charLengthAt(str, i) {
	if (str.length <= i) return 1;
	return str.codePointAt(i) >= kUTF16SurrogateThreshold ? 2 : 1;
}
function* emitKeys(stream) {
	while (true) {
		let ch = yield;
		let s = ch;
		let escaped = false;
		const key = {
			sequence: void 0,
			name: void 0,
			ctrl: false,
			meta: false,
			shift: false
		};
		if (ch === kEscape) {
			escaped = true;
			s += ch = yield;
			if (ch === kEscape) s += ch = yield;
		}
		if (escaped && (ch === "O" || ch === "[")) {
			let code = ch;
			let modifier = 0;
			if (ch === "O") {
				s += ch = yield;
				if (ch >= "0" && ch <= "9") {
					modifier = (Number(ch) >> 0) - 1;
					s += ch = yield;
				}
				code += ch;
			} else if (ch === "[") {
				s += ch = yield;
				if (ch === "[") {
					code += ch;
					s += ch = yield;
				}
				const cmdStart = s.length - 1;
				if (ch >= "0" && ch <= "9") {
					s += ch = yield;
					if (ch >= "0" && ch <= "9") {
						s += ch = yield;
						if (ch >= "0" && ch <= "9") s += ch = yield;
					}
				}
				if (ch === ";") {
					s += ch = yield;
					if (ch >= "0" && ch <= "9") s += yield;
				}
				const cmd = s.slice(cmdStart);
				let match;
				if (match = /^(?:(\d\d?)(?:;(\d))?([~^$])|(\d{3}~))$/.exec(cmd)) {
					if (match[4]) code += match[4];
					else {
						code += match[1] + match[3];
						modifier = Number(match[2] || 1) - 1;
					}
				} else if (match = /^((\d;)?(\d))?([A-Za-z])$/.exec(cmd)) {
					code += match[4];
					modifier = Number(match[3] || 1) - 1;
				} else code += cmd;
			}
			key.ctrl = !!(modifier & 4);
			key.meta = !!(modifier & 10);
			key.shift = !!(modifier & 1);
			key.code = code;
			switch (code) {
				case "[P":
					key.name = "f1";
					break;
				case "[Q":
					key.name = "f2";
					break;
				case "[R":
					key.name = "f3";
					break;
				case "[S":
					key.name = "f4";
					break;
				case "OP":
					key.name = "f1";
					break;
				case "OQ":
					key.name = "f2";
					break;
				case "OR":
					key.name = "f3";
					break;
				case "OS":
					key.name = "f4";
					break;
				case "[11~":
					key.name = "f1";
					break;
				case "[12~":
					key.name = "f2";
					break;
				case "[13~":
					key.name = "f3";
					break;
				case "[14~":
					key.name = "f4";
					break;
				case "[200~":
					key.name = "paste-start";
					break;
				case "[201~":
					key.name = "paste-end";
					break;
				case "[[A":
					key.name = "f1";
					break;
				case "[[B":
					key.name = "f2";
					break;
				case "[[C":
					key.name = "f3";
					break;
				case "[[D":
					key.name = "f4";
					break;
				case "[[E":
					key.name = "f5";
					break;
				case "[15~":
					key.name = "f5";
					break;
				case "[17~":
					key.name = "f6";
					break;
				case "[18~":
					key.name = "f7";
					break;
				case "[19~":
					key.name = "f8";
					break;
				case "[20~":
					key.name = "f9";
					break;
				case "[21~":
					key.name = "f10";
					break;
				case "[23~":
					key.name = "f11";
					break;
				case "[24~":
					key.name = "f12";
					break;
				case "[A":
					key.name = "up";
					break;
				case "[B":
					key.name = "down";
					break;
				case "[C":
					key.name = "right";
					break;
				case "[D":
					key.name = "left";
					break;
				case "[E":
					key.name = "clear";
					break;
				case "[F":
					key.name = "end";
					break;
				case "[H":
					key.name = "home";
					break;
				case "OA":
					key.name = "up";
					break;
				case "OB":
					key.name = "down";
					break;
				case "OC":
					key.name = "right";
					break;
				case "OD":
					key.name = "left";
					break;
				case "OE":
					key.name = "clear";
					break;
				case "OF":
					key.name = "end";
					break;
				case "OH":
					key.name = "home";
					break;
				case "[1~":
					key.name = "home";
					break;
				case "[2~":
					key.name = "insert";
					break;
				case "[3~":
					key.name = "delete";
					break;
				case "[4~":
					key.name = "end";
					break;
				case "[5~":
					key.name = "pageup";
					break;
				case "[6~":
					key.name = "pagedown";
					break;
				case "[[5~":
					key.name = "pageup";
					break;
				case "[[6~":
					key.name = "pagedown";
					break;
				case "[7~":
					key.name = "home";
					break;
				case "[8~":
					key.name = "end";
					break;
				case "[a":
					key.name = "up";
					key.shift = true;
					break;
				case "[b":
					key.name = "down";
					key.shift = true;
					break;
				case "[c":
					key.name = "right";
					key.shift = true;
					break;
				case "[d":
					key.name = "left";
					key.shift = true;
					break;
				case "[e":
					key.name = "clear";
					key.shift = true;
					break;
				case "[2$":
					key.name = "insert";
					key.shift = true;
					break;
				case "[3$":
					key.name = "delete";
					key.shift = true;
					break;
				case "[5$":
					key.name = "pageup";
					key.shift = true;
					break;
				case "[6$":
					key.name = "pagedown";
					key.shift = true;
					break;
				case "[7$":
					key.name = "home";
					key.shift = true;
					break;
				case "[8$":
					key.name = "end";
					key.shift = true;
					break;
				case "Oa":
					key.name = "up";
					key.ctrl = true;
					break;
				case "Ob":
					key.name = "down";
					key.ctrl = true;
					break;
				case "Oc":
					key.name = "right";
					key.ctrl = true;
					break;
				case "Od":
					key.name = "left";
					key.ctrl = true;
					break;
				case "Oe":
					key.name = "clear";
					key.ctrl = true;
					break;
				case "[2^":
					key.name = "insert";
					key.ctrl = true;
					break;
				case "[3^":
					key.name = "delete";
					key.ctrl = true;
					break;
				case "[5^":
					key.name = "pageup";
					key.ctrl = true;
					break;
				case "[6^":
					key.name = "pagedown";
					key.ctrl = true;
					break;
				case "[7^":
					key.name = "home";
					key.ctrl = true;
					break;
				case "[8^":
					key.name = "end";
					key.ctrl = true;
					break;
				case "[Z":
					key.name = "tab";
					key.shift = true;
					break;
				default: key.name = "undefined";
			}
		} else if (ch === "\r") {
			key.name = "return";
			key.meta = escaped;
		} else if (ch === "\n") {
			key.name = "enter";
			key.meta = escaped;
		} else if (ch === "	") {
			key.name = "tab";
			key.meta = escaped;
		} else if (ch === "\b" || ch === "") {
			key.name = "backspace";
			key.meta = escaped;
		} else if (ch === kEscape) {
			key.name = "escape";
			key.meta = escaped;
		} else if (ch === " ") {
			key.name = "space";
			key.meta = escaped;
		} else if (!escaped && ch <= "") {
			key.name = String.fromCharCode(ch.charCodeAt(0) + "a".charCodeAt(0) - 1);
			key.ctrl = true;
		} else if (/^[0-9A-Za-z]$/.exec(ch) !== null) {
			key.name = ch.toLowerCase();
			key.shift = /^[A-Z]$/.exec(ch) !== null;
			key.meta = escaped;
		} else if (escaped) {
			key.name = ch.length ? void 0 : "escape";
			key.meta = true;
		}
		key.sequence = s;
		if (s.length !== 0 && (key.name !== void 0 || escaped)) stream.emit("keypress", escaped ? void 0 : s, key);
		else if (charLengthAt(s, 0) === s.length) stream.emit("keypress", s, key);
	}
}
function commonPrefix(strings) {
	if (strings.length === 0) return "";
	if (strings.length === 1) return strings[0];
	const sorted = strings.toSorted();
	const min = sorted[0];
	const max = sorted[sorted.length - 1];
	for (let i = 0; i < min.length; i++) if (min[i] !== max[i]) return min.slice(0, i);
	return min;
}
function reverseString(line, from = "\r", to = "\r") {
	const parts = line.split(from);
	let result = "";
	for (let i = parts.length - 1; i > 0; i--) result += parts[i] + to;
	result += parts[0];
	return result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/callbacks.js
const { kClearLine, kClearScreenDown, kClearToLineBeginning, kClearToLineEnd } = CSI;
/**
* moves the cursor to the x and y coordinate on the given stream
*/
function cursorTo(stream, x, y, callback) {
	if (callback !== void 0) validateFunction(callback, "callback");
	if (typeof y === "function") {
		callback = y;
		y = void 0;
	}
	if (Number.isNaN(x)) throw invalidArgValue("x", x);
	if (Number.isNaN(y)) throw invalidArgValue("y", y);
	if (stream == null || typeof x !== "number" && typeof y !== "number") {
		if (typeof callback === "function") defer(() => callback(null));
		return true;
	}
	if (typeof x !== "number") throw codedError(/* @__PURE__ */ new TypeError("Cannot set cursor row without setting its column"), "ERR_INVALID_CURSOR_POS");
	const data = typeof y !== "number" ? CSI`${x + 1}G` : CSI`${y + 1};${x + 1}H`;
	return stream.write(data, callback);
}
/**
* moves the cursor relative to its current location
*/
function moveCursor(stream, dx, dy, callback) {
	if (callback !== void 0) validateFunction(callback, "callback");
	if (stream == null || !(dx || dy)) {
		if (typeof callback === "function") defer(() => callback(null));
		return true;
	}
	let data = "";
	if (dx < 0) data += CSI`${-dx}D`;
	else if (dx > 0) data += CSI`${dx}C`;
	if (dy < 0) data += CSI`${-dy}A`;
	else if (dy > 0) data += CSI`${dy}B`;
	return stream.write(data, callback);
}
/**
* clears the current line the cursor is on:
*   -1 for left of the cursor
*   +1 for right of the cursor
*    0 for the entire line
*/
function clearLine(stream, dir, callback) {
	if (callback !== void 0) validateFunction(callback, "callback");
	if (stream === null || stream === void 0) {
		if (typeof callback === "function") defer(() => callback(null));
		return true;
	}
	const type = dir < 0 ? kClearToLineBeginning : dir > 0 ? kClearToLineEnd : kClearLine;
	return stream.write(type, callback);
}
/**
* clears the screen from the current position of the cursor down
*/
function clearScreenDown(stream, callback) {
	if (callback !== void 0) validateFunction(callback, "callback");
	if (stream === null || stream === void 0) {
		if (typeof callback === "function") defer(() => callback(null));
		return true;
	}
	return stream.write(kClearScreenDown, callback);
}
//#endregion
export { CSI as a, commonPrefix as c, reverseString as d, defer as f, validateUint32 as h, moveCursor as i, emitKeys as l, isWritable as m, clearScreenDown as n, charLengthAt as o, inspect as p, cursorTo as r, charLengthLeft as s, clearLine as t, kSubstringSearch as u };
