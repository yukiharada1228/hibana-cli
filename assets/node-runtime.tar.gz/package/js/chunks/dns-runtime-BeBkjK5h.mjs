import { a as codedError, d as invalidArgType$1, f as invalidArgValue$1, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { n as decodeErrno, t as callHost } from "./host-error-DahHjm1T.mjs";
import * as host from "hibana:node-dns/api@0.5.0";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dns/errors.js
/**
* Errors for the `node:dns` shim.
*
* Argument errors use the shared factory and templates in `../errors/core.js`. `dnsError`
* reconstructs the host's serialized error record into the `Error` a guest should see.
*/
/**
* Node's `ERR_INVALID_ARG_TYPE`.
*
* Callers that have the offending value in hand pass it so the message carries Node's
* `Received ...` clause; callers that only know the expected type get the clause-free form.
*/
function invalidArgType(name, expected, actual) {
	if (arguments.length >= 3) return invalidArgType$1(name, expected, actual);
	return codedError(/* @__PURE__ */ new TypeError(`The "${name}" argument must be of type ${expected}`), "ERR_INVALID_ARG_TYPE");
}
function invalidArgValue(name, value) {
	return invalidArgValue$1(name, value);
}
function unsupported(api) {
	throw unsupportedNodeApi(api, "Jco's DNS host boundary is synchronous and cannot carry it");
}
function dnsError(data) {
	const error = new Error(data.message);
	error.name = data.name;
	error.code = data.code;
	error.errno = decodeErrno(data.errno);
	error.syscall = data.syscall;
	error.hostname = data.hostname;
	return error;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dns/core.js
/**
* Node.js DNS compatibility facade.
*
* Contract adapted from nodejs/node v24.19.0 (commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae), primarily lib/dns.js,
* lib/internal/dns/promises.js, and lib/internal/dns/utils.js (MIT license).
* Local changes replace c-ares/native request wrappers with a typed host provider,
* share state between callback and promise facades, and make cancellation explicit.
*/
const ADDRCONFIG = 32;
const ALL = 16;
const V4MAPPED = 8;
const NODATA = "ENODATA";
const FORMERR = "EFORMERR";
const SERVFAIL = "ESERVFAIL";
const NOTFOUND = "ENOTFOUND";
const NOTIMP = "ENOTIMP";
const REFUSED = "EREFUSED";
const BADQUERY = "EBADQUERY";
const BADNAME = "EBADNAME";
const BADFAMILY = "EBADFAMILY";
const BADRESP = "EBADRESP";
const CONNREFUSED = "ECONNREFUSED";
const TIMEOUT = "ETIMEOUT";
const EOF = "EOF";
const FILE = "EFILE";
const NOMEM = "ENOMEM";
const DESTRUCTION = "EDESTRUCTION";
const BADSTR = "EBADSTR";
const BADFLAGS = "EBADFLAGS";
const NONAME = "ENONAME";
const BADHINTS = "EBADHINTS";
const NOTINITIALIZED = "ENOTINITIALIZED";
const LOADIPHLPAPI = "ELOADIPHLPAPI";
const ADDRGETNETWORKPARAMS = "EADDRGETNETWORKPARAMS";
const CANCELLED = "ECANCELLED";
const VALID_ORDERS = /* @__PURE__ */ new Set([
	"ipv4first",
	"ipv6first",
	"verbatim"
]);
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
function hostResult(operation) {
	return callHost(operation, dnsError);
}
function hostFamily(value) {
	return value === 4 ? "ipv4" : value === 6 ? "ipv6" : "unspecified";
}
function publicFamily(value) {
	return value === "ipv4" ? 4 : value === "ipv6" ? 6 : 0;
}
function hostOrder(value) {
	return value === "ipv4first" ? "ipv4-first" : value === "ipv6first" ? "ipv6-first" : value;
}
function hostResolver(value) {
	return value ? {
		options: { ...value.options },
		servers: value.servers?.slice(),
		localAddress: value.localAddress ? [...value.localAddress] : void 0
	} : void 0;
}
function tlsaRecord(value) {
	const data = value.data.slice();
	return {
		certUsage: value.certUsage,
		selector: value.selector,
		match: value.match,
		data: data.buffer
	};
}
function anyRecord(value) {
	switch (value.tag) {
		case "a": return {
			type: "A",
			...value.val
		};
		case "aaaa": return {
			type: "AAAA",
			...value.val
		};
		case "caa": return {
			type: "CAA",
			...value.val
		};
		case "cname": return {
			type: "CNAME",
			value: value.val
		};
		case "mx": return {
			type: "MX",
			...value.val
		};
		case "naptr": return {
			type: "NAPTR",
			...value.val
		};
		case "ns": return {
			type: "NS",
			value: value.val
		};
		case "ptr": return {
			type: "PTR",
			value: value.val
		};
		case "soa": return {
			type: "SOA",
			...value.val
		};
		case "srv": return {
			type: "SRV",
			...value.val
		};
		case "tlsa": return {
			type: "TLSA",
			...tlsaRecord(value.val)
		};
		case "txt": return {
			type: "TXT",
			entries: value.val
		};
	}
}
function validateString(value, name) {
	if (typeof value !== "string") throw invalidArgType(name, "string");
	if (value.includes("\0")) throw invalidArgValue(name, value);
}
function validateFunction(value, name = "callback") {
	if (typeof value !== "function") throw invalidArgType(name, "function");
}
function familyValue(value) {
	if (value === "IPv4") return 4;
	if (value === "IPv6") return 6;
	if (value === void 0) return 0;
	if (value !== 0 && value !== 4 && value !== 6) throw invalidArgValue("options.family", value);
	return value;
}
function lookupOptions(options, defaultOrder) {
	if (typeof options === "number") return {
		family: familyValue(options),
		hints: 0,
		all: false,
		order: defaultOrder
	};
	if (options !== void 0 && (typeof options !== "object" || options === null)) throw invalidArgType("options", "integer or object");
	const family = familyValue(options?.family);
	const hints = options?.hints ?? 0;
	if (typeof hints !== "number") throw invalidArgType("options.hints", "number");
	if ((hints & -57) !== 0) throw invalidArgValue("options.hints", hints);
	if (options?.all !== void 0 && typeof options.all !== "boolean") throw invalidArgType("options.all", "boolean");
	if (options?.verbatim !== void 0 && typeof options.verbatim !== "boolean") throw invalidArgType("options.verbatim", "boolean");
	const order = options?.order ?? (options?.verbatim === void 0 ? defaultOrder : options.verbatim ? "verbatim" : "ipv4first");
	if (!VALID_ORDERS.has(order)) throw invalidArgValue("options.order", order);
	return {
		family,
		hints,
		all: options?.all ?? false,
		order
	};
}
function isIp(value) {
	if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(value) && value.split(".").every((part) => Number(part) <= 255)) return 4;
	if (value.includes(":") && /^[0-9a-f:.]+$/i.test(value)) return 6;
	return 0;
}
function enqueue(callback, response) {
	let value;
	let error;
	try {
		value = response();
	} catch (caught) {
		error = caught instanceof Error ? caught : new Error(String(caught));
	}
	queueMicrotask(() => {
		if (error) callback(error);
		else callback(null, value);
	});
}
function promiseCall(response) {
	return new Promise((resolve, reject) => queueMicrotask(() => {
		try {
			resolve(response());
		} catch (error) {
			reject(error);
		}
	}));
}
function resolveArgs(hostname, callback) {
	validateString(hostname, "hostname");
	validateFunction(callback);
}
function resolveOperation(rrtype) {
	const operation = {
		A: "resolve4",
		AAAA: "resolve6",
		ANY: "resolveAny",
		CAA: "resolveCaa",
		CNAME: "resolveCname",
		MX: "resolveMx",
		NAPTR: "resolveNaptr",
		NS: "resolveNs",
		PTR: "resolvePtr",
		SOA: "resolveSoa",
		SRV: "resolveSrv",
		TLSA: "resolveTlsa",
		TXT: "resolveTxt"
	}[rrtype.toUpperCase()];
	if (!operation) throw invalidArgValue("rrtype", rrtype);
	return operation;
}
function resolveHost(host, operation, hostname, ttl, resolver) {
	const configuration = hostResolver(resolver);
	switch (operation) {
		case "resolve4": {
			const records = hostResult(() => host.resolve4(hostname, ttl, configuration));
			return ttl ? records : records.map((record) => record.address);
		}
		case "resolve6": {
			const records = hostResult(() => host.resolve6(hostname, ttl, configuration));
			return ttl ? records : records.map((record) => record.address);
		}
		case "resolveAny": return hostResult(() => host.resolveAny(hostname, configuration)).map(anyRecord);
		case "resolveCaa": return hostResult(() => host.resolveCaa(hostname, configuration));
		case "resolveCname": return hostResult(() => host.resolveCname(hostname, configuration));
		case "resolveMx": return hostResult(() => host.resolveMx(hostname, configuration));
		case "resolveNaptr": return hostResult(() => host.resolveNaptr(hostname, configuration));
		case "resolveNs": return hostResult(() => host.resolveNs(hostname, configuration));
		case "resolvePtr": return hostResult(() => host.resolvePtr(hostname, configuration));
		case "resolveSoa": return hostResult(() => host.resolveSoa(hostname, configuration));
		case "resolveSrv": return hostResult(() => host.resolveSrv(hostname, configuration));
		case "resolveTlsa": return hostResult(() => host.resolveTlsa(hostname, configuration)).map(tlsaRecord);
		case "resolveTxt": return hostResult(() => host.resolveTxt(hostname, configuration));
		case "reverse": return hostResult(() => host.reverse(hostname, configuration));
	}
}
function createDns(host) {
	let defaultOrder = "verbatim";
	let defaultServers;
	function servers() {
		return (defaultServers ??= hostResult(() => host.getServers())).slice();
	}
	function setServers(serversValue) {
		if (!Array.isArray(serversValue)) throw invalidArgType("servers", "Array");
		defaultServers = hostResult(() => host.validateServers(serversValue)).slice();
	}
	function getDefaultResultOrder() {
		return defaultOrder;
	}
	function setDefaultResultOrder(order) {
		if (!VALID_ORDERS.has(order)) throw invalidArgValue("order", order);
		defaultOrder = order;
	}
	function hostLookup(hostname, options) {
		const addresses = hostResult(() => host.lookup(hostname, {
			family: hostFamily(options.family),
			hints: options.hints,
			all: options.all,
			order: hostOrder(options.order)
		})).map((address) => ({
			address: address.address,
			family: publicFamily(address.family)
		}));
		if (options.all) return addresses;
		const address = addresses[0];
		if (!address) throw new TypeError("node:dns host returned no lookup address");
		return address;
	}
	class ResolverBase {
		configuration;
		constructor(options = {}) {
			if (!isRecord(options)) throw invalidArgType("options", "object");
			for (const [name, value, minimum, maximum] of [
				[
					"timeout",
					options.timeout,
					-1,
					2147483647
				],
				[
					"tries",
					options.tries,
					1,
					2147483647
				],
				[
					"maxTimeout",
					options.maxTimeout,
					0,
					4294967295
				]
			]) if (value !== void 0 && (typeof value !== "number" || !Number.isInteger(value) || value < minimum || value > maximum)) throw invalidArgValue(`options.${name}`, value);
			this.configuration = { options: { ...options } };
		}
		cancel() {
			return unsupported("dns.Resolver.cancel");
		}
		getServers() {
			return (this.configuration.servers ?? servers()).slice();
		}
		setServers(value) {
			if (!Array.isArray(value)) throw invalidArgType("servers", "Array");
			this.configuration.servers = hostResult(() => host.validateServers(value));
		}
		setLocalAddress(ipv4 = "0.0.0.0", ipv6 = "::0") {
			validateString(ipv4, "ipv4");
			validateString(ipv6, "ipv6");
			if (isIp(ipv4) !== 4) throw invalidArgValue("ipv4", ipv4);
			if (isIp(ipv6) !== 6) throw invalidArgValue("ipv6", ipv6);
			this.configuration.localAddress = [ipv4, ipv6];
		}
	}
	class Resolver extends ResolverBase {
		call(operation, hostname, ttl, callback) {
			resolveArgs(hostname, callback);
			enqueue(callback, () => resolveHost(host, operation, hostname, ttl, this.configuration));
		}
		resolve(hostname, rrtypeOrCallback, callback) {
			const rrtype = typeof rrtypeOrCallback === "string" ? rrtypeOrCallback : "A";
			this.call(resolveOperation(rrtype), hostname, false, typeof rrtypeOrCallback === "function" ? rrtypeOrCallback : callback);
		}
		resolve4(hostname, optionsOrCallback, callback) {
			const options = typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback;
			this.call("resolve4", hostname, options?.ttl === true, typeof optionsOrCallback === "function" ? optionsOrCallback : callback);
		}
		resolve6(hostname, optionsOrCallback, callback) {
			const options = typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback;
			this.call("resolve6", hostname, options?.ttl === true, typeof optionsOrCallback === "function" ? optionsOrCallback : callback);
		}
		resolveAny(hostname, callback) {
			this.call("resolveAny", hostname, false, callback);
		}
		resolveCaa(hostname, callback) {
			this.call("resolveCaa", hostname, false, callback);
		}
		resolveCname(hostname, callback) {
			this.call("resolveCname", hostname, false, callback);
		}
		resolveMx(hostname, callback) {
			this.call("resolveMx", hostname, false, callback);
		}
		resolveNaptr(hostname, callback) {
			this.call("resolveNaptr", hostname, false, callback);
		}
		resolveNs(hostname, callback) {
			this.call("resolveNs", hostname, false, callback);
		}
		resolvePtr(hostname, callback) {
			this.call("resolvePtr", hostname, false, callback);
		}
		resolveSoa(hostname, callback) {
			this.call("resolveSoa", hostname, false, callback);
		}
		resolveSrv(hostname, callback) {
			this.call("resolveSrv", hostname, false, callback);
		}
		resolveTlsa(hostname, callback) {
			this.call("resolveTlsa", hostname, false, callback);
		}
		resolveTxt(hostname, callback) {
			this.call("resolveTxt", hostname, false, callback);
		}
		reverse(ip, callback) {
			this.call("reverse", ip, false, callback);
		}
	}
	const PromisesResolver = class Resolver extends ResolverBase {
		call(operation, hostname, ttl = false) {
			validateString(hostname, "hostname");
			return promiseCall(() => resolveHost(host, operation, hostname, ttl, this.configuration));
		}
		resolve(hostname, rrtype = "A") {
			return this.call(resolveOperation(rrtype), hostname);
		}
		resolve4(hostname, options) {
			return this.call("resolve4", hostname, options?.ttl === true);
		}
		resolve6(hostname, options) {
			return this.call("resolve6", hostname, options?.ttl === true);
		}
		resolveAny(hostname) {
			return this.call("resolveAny", hostname);
		}
		resolveCaa(hostname) {
			return this.call("resolveCaa", hostname);
		}
		resolveCname(hostname) {
			return this.call("resolveCname", hostname);
		}
		resolveMx(hostname) {
			return this.call("resolveMx", hostname);
		}
		resolveNaptr(hostname) {
			return this.call("resolveNaptr", hostname);
		}
		resolveNs(hostname) {
			return this.call("resolveNs", hostname);
		}
		resolvePtr(hostname) {
			return this.call("resolvePtr", hostname);
		}
		resolveSoa(hostname) {
			return this.call("resolveSoa", hostname);
		}
		resolveSrv(hostname) {
			return this.call("resolveSrv", hostname);
		}
		resolveTlsa(hostname) {
			return this.call("resolveTlsa", hostname);
		}
		resolveTxt(hostname) {
			return this.call("resolveTxt", hostname);
		}
		reverse(ip) {
			return this.call("reverse", ip);
		}
	};
	function lookup(hostname, optionsOrCallback, callback) {
		validateString(hostname, "hostname");
		const actualCallback = typeof optionsOrCallback === "function" ? optionsOrCallback : callback;
		validateFunction(actualCallback);
		const options = lookupOptions(typeof optionsOrCallback === "function" ? void 0 : optionsOrCallback, defaultOrder);
		const literalFamily = isIp(hostname);
		if (literalFamily || !hostname) {
			queueMicrotask(() => options.all ? actualCallback(null, hostname ? [{
				address: hostname,
				family: literalFamily
			}] : []) : actualCallback(null, hostname || null, literalFamily || (options.family === 6 ? 6 : 4)));
			return {};
		}
		let result;
		let error;
		try {
			result = hostLookup(hostname, options);
		} catch (caught) {
			error = caught instanceof Error ? caught : new Error(String(caught));
		}
		queueMicrotask(() => {
			if (error) actualCallback(error);
			else if (options.all) actualCallback(null, result);
			else {
				const address = result;
				actualCallback(null, address.address, address.family);
			}
		});
		return {};
	}
	function lookupService(address, port, callback) {
		validateString(address, "address");
		if (isIp(address) === 0) throw invalidArgValue("address", address);
		const numericPort = Number(port);
		if (!Number.isInteger(numericPort) || numericPort < 0 || numericPort > 65535) throw invalidArgValue("port", port);
		validateFunction(callback);
		let result;
		let error;
		try {
			result = hostResult(() => host.lookupService(address, numericPort));
		} catch (caught) {
			error = caught instanceof Error ? caught : new Error(String(caught));
		}
		queueMicrotask(() => {
			if (error) callback(error);
			else callback(null, result?.hostname, result?.service);
		});
		return {};
	}
	const defaultResolver = new Resolver();
	const promiseResolver = new PromisesResolver();
	return {
		callback: {
			Resolver,
			getServers: servers,
			setServers,
			getDefaultResultOrder,
			setDefaultResultOrder,
			lookup,
			lookupService,
			resolve: defaultResolver.resolve.bind(defaultResolver),
			resolve4: defaultResolver.resolve4.bind(defaultResolver),
			resolve6: defaultResolver.resolve6.bind(defaultResolver),
			resolveAny: defaultResolver.resolveAny.bind(defaultResolver),
			resolveCaa: defaultResolver.resolveCaa.bind(defaultResolver),
			resolveCname: defaultResolver.resolveCname.bind(defaultResolver),
			resolveMx: defaultResolver.resolveMx.bind(defaultResolver),
			resolveNaptr: defaultResolver.resolveNaptr.bind(defaultResolver),
			resolveNs: defaultResolver.resolveNs.bind(defaultResolver),
			resolvePtr: defaultResolver.resolvePtr.bind(defaultResolver),
			resolveSoa: defaultResolver.resolveSoa.bind(defaultResolver),
			resolveSrv: defaultResolver.resolveSrv.bind(defaultResolver),
			resolveTlsa: defaultResolver.resolveTlsa.bind(defaultResolver),
			resolveTxt: defaultResolver.resolveTxt.bind(defaultResolver),
			reverse: defaultResolver.reverse.bind(defaultResolver)
		},
		promises: {
			Resolver: PromisesResolver,
			getServers: servers,
			setServers,
			getDefaultResultOrder,
			setDefaultResultOrder,
			lookup: function lookup(hostname, options) {
				validateString(hostname, "hostname");
				const parsed = lookupOptions(options, defaultOrder);
				const family = isIp(hostname);
				if (family) return Promise.resolve(parsed.all ? [{
					address: hostname,
					family
				}] : {
					address: hostname,
					family
				});
				return promiseCall(() => hostLookup(hostname, parsed));
			},
			lookupService(address, port) {
				validateString(address, "address");
				if (isIp(address) === 0) throw invalidArgValue("address", address);
				const numericPort = Number(port);
				if (!Number.isInteger(numericPort) || numericPort < 0 || numericPort > 65535) throw invalidArgValue("port", port);
				return promiseCall(() => hostResult(() => host.lookupService(address, numericPort)));
			},
			resolve: promiseResolver.resolve.bind(promiseResolver),
			resolve4: promiseResolver.resolve4.bind(promiseResolver),
			resolve6: promiseResolver.resolve6.bind(promiseResolver),
			resolveAny: promiseResolver.resolveAny.bind(promiseResolver),
			resolveCaa: promiseResolver.resolveCaa.bind(promiseResolver),
			resolveCname: promiseResolver.resolveCname.bind(promiseResolver),
			resolveMx: promiseResolver.resolveMx.bind(promiseResolver),
			resolveNaptr: promiseResolver.resolveNaptr.bind(promiseResolver),
			resolveNs: promiseResolver.resolveNs.bind(promiseResolver),
			resolvePtr: promiseResolver.resolvePtr.bind(promiseResolver),
			resolveSoa: promiseResolver.resolveSoa.bind(promiseResolver),
			resolveSrv: promiseResolver.resolveSrv.bind(promiseResolver),
			resolveTlsa: promiseResolver.resolveTlsa.bind(promiseResolver),
			resolveTxt: promiseResolver.resolveTxt.bind(promiseResolver),
			reverse: promiseResolver.reverse.bind(promiseResolver)
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dns-runtime.js
const dns = createDns(host);
//#endregion
export { NOTIMP as C, TIMEOUT as D, SERVFAIL as E, V4MAPPED as O, NOTFOUND as S, REFUSED as T, FORMERR as _, BADFAMILY as a, NOMEM as b, BADNAME as c, BADSTR as d, CANCELLED as f, FILE as g, EOF as h, ALL as i, BADQUERY as l, DESTRUCTION as m, ADDRCONFIG as n, BADFLAGS as o, CONNREFUSED as p, ADDRGETNETWORKPARAMS as r, BADHINTS as s, dns as t, BADRESP as u, LOADIPHLPAPI as v, NOTINITIALIZED as w, NONAME as x, NODATA as y };
