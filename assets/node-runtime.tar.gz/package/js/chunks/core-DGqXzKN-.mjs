//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/errors/core.js
/**
* Portable Node.js error compatibility helpers.
*
* Adapted from nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, primarily
* lib/internal/errors.js (MIT license). Local changes replace primordials,
* V8 stack hooks, libuv bindings, and internal util.inspect with portable
* ECMAScript operations and typed host-neutral system-error data.
*/
const NativeError = globalThis.Error;
const NativeRangeError = globalThis.RangeError;
const NativeTypeError = globalThis.TypeError;
var AbortError = class extends NativeError {
	code = "ABORT_ERR";
	constructor(message = "The operation was aborted", options) {
		if (options !== void 0 && (typeof options !== "object" || options === null)) throw invalidArgType("options", "Object", options);
		super(message, options);
		this.name = "AbortError";
	}
};
function inspectObject(value) {
	try {
		const constructor = Reflect.get(value, "constructor");
		if (typeof constructor === "function" && constructor.name) return `an instance of ${constructor.name}`;
	} catch {}
	try {
		return Object.prototype.toString.call(value);
	} catch {
		return "an object";
	}
}
function inspectValue(value) {
	if (typeof value === "string") return value.includes("'") ? JSON.stringify(value) : `'${value}'`;
	if (typeof value === "bigint") return `${value}n`;
	if (typeof value === "number" && Object.is(value, -0)) return "-0";
	if (value === null || value === void 0 || typeof value === "number" || typeof value === "boolean" || typeof value === "symbol") return String(value);
	if (typeof value === "function") return `[Function: ${value.name || "anonymous"}]`;
	try {
		const serialized = JSON.stringify(value);
		if (serialized !== void 0) return serialized.length > 128 ? `${serialized.slice(0, 128)}...` : serialized;
	} catch {}
	return inspectObject(value);
}
/** Describe a value using the stable presentation used in Node type errors. */
function determineSpecificType(value) {
	if (value === null) return "null";
	if (value === void 0) return "undefined";
	switch (typeof value) {
		case "bigint": return `type bigint (${value}n)`;
		case "number":
			if (Object.is(value, -0)) return "type number (-0)";
			if (Number.isNaN(value)) return "type number (NaN)";
			return `type number (${String(value)})`;
		case "boolean": return `type boolean (${String(value)})`;
		case "symbol": return `type symbol (${String(value)})`;
		case "function": return `function ${value.name}`;
		case "object": return inspectObject(value);
		case "string": {
			const shortened = value.length > 28 ? `${value.slice(0, 25)}...` : value;
			return shortened.includes("'") ? `type string (${JSON.stringify(shortened)})` : `type string ('${shortened}')`;
		}
		default: return `type ${typeof value} (${String(value)})`;
	}
}
/** Format a list as `A and B` or `A, B, and C`, without depending on Intl. */
function formatList(values, conjunction = "and") {
	switch (values.length) {
		case 0: return "";
		case 1: return values[0];
		case 2: return `${values[0]} ${conjunction} ${values[1]}`;
		case 3: return `${values[0]}, ${values[1]}, ${conjunction} ${values[2]}`;
		default: return `${values.slice(0, -1).join(", ")}, ${conjunction} ${values.at(-1)}`;
	}
}
/** Attach Node's stable public `code` contract to a standard error instance. */
function codedError(error, code) {
	Object.defineProperty(error, "code", {
		value: code,
		enumerable: true,
		configurable: true,
		writable: true
	});
	Object.defineProperty(error, "name", {
		value: `${error.name} [${code}]`,
		enumerable: false,
		configurable: true,
		writable: true
	});
	error.stack;
	Reflect.deleteProperty(error, "name");
	Object.defineProperty(error, "toString", {
		value() {
			return `${this.name} [${code}]: ${this.message}`;
		},
		enumerable: false,
		configurable: true,
		writable: true
	});
	return error;
}
const PRIMITIVE_TYPES = /* @__PURE__ */ new Set([
	"string",
	"function",
	"number",
	"object",
	"Function",
	"Object",
	"boolean",
	"bigint",
	"symbol"
]);
const CLASS_NAME = /^[A-Z][a-zA-Z0-9]*$/;
function expectedTypeDescription(expected) {
	const values = typeof expected === "string" ? [expected] : [...expected];
	const types = [];
	const instances = [];
	const other = [];
	for (const value of values) if (PRIMITIVE_TYPES.has(value)) types.push(value.toLowerCase());
	else if (CLASS_NAME.test(value)) instances.push(value);
	else other.push(value);
	if (instances.length > 0 && types.includes("object")) {
		types.splice(types.indexOf("object"), 1);
		instances.push("Object");
	}
	const sections = [];
	if (types.length > 0) sections.push(`${types.length > 1 ? "one of type" : "of type"} ${formatList(types, "or")}`);
	if (instances.length > 0) sections.push(`an instance of ${formatList(instances, "or")}`);
	if (other.length > 0) sections.push(other.length > 1 ? `one of ${formatList(other, "or")}` : other[0]);
	return formatList(sections, "or");
}
function invalidArgType(name, expected, actual) {
	const subject = name.endsWith(" argument") ? `${name} ` : `"${name}" ${name.includes(".") ? "property" : "argument"} `;
	return codedError(new NativeTypeError(`The ${subject}must be ${expectedTypeDescription(expected)}. Received ${determineSpecificType(actual)}`), "ERR_INVALID_ARG_TYPE");
}
function invalidArgValue(name, value, reason = "is invalid") {
	const subject = name.includes(".") ? "property" : "argument";
	return codedError(new NativeTypeError(`The ${subject} '${name}' ${reason}. Received ${inspectValue(value)}`), "ERR_INVALID_ARG_VALUE");
}
function missingArgs(...names) {
	const formatted = names.map((name) => typeof name === "string" ? `"${name}"` : name.map((item) => `"${item}"`).join(" or "));
	const plural = names.length > 1 ? "arguments" : "argument";
	return codedError(new NativeTypeError(`The ${formatList(formatted)} ${plural} must be specified`), "ERR_MISSING_ARGS");
}
function invalidReturnValue(expected, name, value) {
	return codedError(new NativeTypeError(`Expected ${expected} to be returned from the "${name}" function but got ${determineSpecificType(value)}.`), "ERR_INVALID_RETURN_VALUE");
}
function ambiguousArgument(name, reason) {
	return codedError(new NativeTypeError(`The "${name}" argument is ambiguous. ${reason}`), "ERR_AMBIGUOUS_ARGUMENT");
}
function constructCallRequired(name) {
	return codedError(new NativeTypeError(`Cannot call constructor ${name} without \`new\``), "ERR_CONSTRUCT_CALL_REQUIRED");
}
function illegalConstructor() {
	return codedError(new NativeTypeError("Illegal constructor"), "ERR_ILLEGAL_CONSTRUCTOR");
}
/** Node's receiver check failure, raised when a method runs against a forged `this`. */
function invalidThis(name) {
	return codedError(new NativeTypeError(`Value of "this" must be of type ${name}`), "ERR_INVALID_THIS");
}
function deprecatedNodeApi(name, replacement) {
	const suffix = replacement ? ` Use ${replacement} instead.` : "";
	return codedError(new NativeError(`The deprecated Node.js API ${name} is not supported by jco-std.${suffix}`), "ERR_JCO_UNSUPPORTED_DEPRECATED_NODE_API");
}
function unsupportedNodeApi(api, reason) {
	return codedError(new NativeError(`${api} is not supported in a WebAssembly component: ${reason}`), "ERR_JCO_UNSUPPORTED_NODE_API");
}
/** Error code carried by every unsupported-API failure Jco raises for Node builtins. */
const UNSUPPORTED_CODE = "ERR_JCO_UNSUPPORTED_NODE_API";
/** Error code for APIs Node itself has deprecated, which Jco declines to implement. */
const DEPRECATED_CODE = "ERR_JCO_UNSUPPORTED_DEPRECATED_NODE_API";
function outOfRange(name, range, value) {
	return codedError(new NativeRangeError(`The value of "${name}" is out of range. It must be ${range}. Received ${inspectValue(value)}`), "ERR_OUT_OF_RANGE");
}
function systemError(data) {
	const error = new NativeError(data.message);
	for (const key of [
		"address",
		"code",
		"dest",
		"errno",
		"info",
		"path",
		"port",
		"syscall"
	]) if (data[key] !== void 0) Object.defineProperty(error, key, {
		value: data[key],
		enumerable: true,
		configurable: true,
		writable: true
	});
	return error;
}
//#endregion
export { systemError as _, codedError as a, determineSpecificType as c, invalidArgType as d, invalidArgValue as f, outOfRange as g, missingArgs as h, ambiguousArgument as i, formatList as l, invalidThis as m, DEPRECATED_CODE as n, constructCallRequired as o, invalidReturnValue as p, UNSUPPORTED_CODE as r, deprecatedNodeApi as s, AbortError as t, illegalConstructor as u, unsupportedNodeApi as v };
