import { r as __exportAll } from "./rolldown-runtime-7_rZTKki.mjs";
import { v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/types.js
var types_exports = /* @__PURE__ */ __exportAll({
	isAnyArrayBuffer: () => isAnyArrayBuffer,
	isArgumentsObject: () => isArgumentsObject,
	isArrayBuffer: () => isArrayBuffer,
	isArrayBufferView: () => isArrayBufferView,
	isAsyncFunction: () => isAsyncFunction,
	isBigInt64Array: () => isBigInt64Array,
	isBigIntObject: () => isBigIntObject,
	isBigUint64Array: () => isBigUint64Array,
	isBooleanObject: () => isBooleanObject,
	isBoxedPrimitive: () => isBoxedPrimitive,
	isCryptoKey: () => isCryptoKey,
	isDataView: () => isDataView,
	isDate: () => isDate,
	isExternal: () => isExternal,
	isFloat16Array: () => isFloat16Array,
	isFloat32Array: () => isFloat32Array,
	isFloat64Array: () => isFloat64Array,
	isGeneratorFunction: () => isGeneratorFunction,
	isGeneratorObject: () => isGeneratorObject,
	isInt16Array: () => isInt16Array,
	isInt32Array: () => isInt32Array,
	isInt8Array: () => isInt8Array,
	isKeyObject: () => isKeyObject,
	isMap: () => isMap,
	isMapIterator: () => isMapIterator,
	isModuleNamespaceObject: () => isModuleNamespaceObject,
	isNativeError: () => isNativeError,
	isNumberObject: () => isNumberObject,
	isPromise: () => isPromise,
	isProxy: () => isProxy,
	isRegExp: () => isRegExp,
	isSet: () => isSet,
	isSetIterator: () => isSetIterator,
	isSharedArrayBuffer: () => isSharedArrayBuffer,
	isStringObject: () => isStringObject,
	isSymbolObject: () => isSymbolObject,
	isTypedArray: () => isTypedArray,
	isUint16Array: () => isUint16Array,
	isUint32Array: () => isUint32Array,
	isUint8Array: () => isUint8Array,
	isUint8ClampedArray: () => isUint8ClampedArray,
	isWeakMap: () => isWeakMap,
	isWeakSet: () => isWeakSet
});
function brand(value, intrinsic, args = []) {
	if (!intrinsic || value === null || typeof value !== "object" && typeof value !== "function") return false;
	try {
		Reflect.apply(intrinsic, value, args);
		return true;
	} catch {
		return false;
	}
}
function getter(prototype, key) {
	return prototype && Object.getOwnPropertyDescriptor(prototype, key)?.get;
}
const typedArrayTag = getter(Object.getPrototypeOf(Uint8Array.prototype), Symbol.toStringTag);
function arrayTag(value) {
	return Reflect.apply(typedArrayTag, value, []);
}
function tag(value, name) {
	return Object.prototype.toString.call(value) === `[object ${name}]`;
}
const isArrayBufferView = ArrayBuffer.isView;
function isArrayBuffer(value) {
	return brand(value, getter(ArrayBuffer.prototype, "byteLength"));
}
function isSharedArrayBuffer(value) {
	return brand(value, getter(globalThis.SharedArrayBuffer?.prototype, "byteLength"));
}
function isAnyArrayBuffer(value) {
	return isArrayBuffer(value) || isSharedArrayBuffer(value);
}
function isDataView(value) {
	return ArrayBuffer.isView(value) && arrayTag(value) === void 0;
}
function isTypedArray(value) {
	return arrayTag(value) !== void 0;
}
function isInt8Array(value) {
	return arrayTag(value) === "Int8Array";
}
function isUint8Array(value) {
	return arrayTag(value) === "Uint8Array";
}
function isUint8ClampedArray(value) {
	return arrayTag(value) === "Uint8ClampedArray";
}
function isInt16Array(value) {
	return arrayTag(value) === "Int16Array";
}
function isUint16Array(value) {
	return arrayTag(value) === "Uint16Array";
}
function isInt32Array(value) {
	return arrayTag(value) === "Int32Array";
}
function isUint32Array(value) {
	return arrayTag(value) === "Uint32Array";
}
function isFloat16Array(value) {
	return arrayTag(value) === "Float16Array";
}
function isFloat32Array(value) {
	return arrayTag(value) === "Float32Array";
}
function isFloat64Array(value) {
	return arrayTag(value) === "Float64Array";
}
function isBigInt64Array(value) {
	return arrayTag(value) === "BigInt64Array";
}
function isBigUint64Array(value) {
	return arrayTag(value) === "BigUint64Array";
}
function isBooleanObject(value) {
	return brand(value, Boolean.prototype.valueOf);
}
function isNumberObject(value) {
	return brand(value, Number.prototype.valueOf);
}
function isStringObject(value) {
	return brand(value, String.prototype.valueOf);
}
function isSymbolObject(value) {
	return brand(value, Symbol.prototype.valueOf);
}
function isBigIntObject(value) {
	return brand(value, BigInt.prototype.valueOf);
}
function isBoxedPrimitive(value) {
	return isBooleanObject(value) || isNumberObject(value) || isStringObject(value) || isSymbolObject(value) || isBigIntObject(value);
}
function isDate(value) {
	return brand(value, Date.prototype.getTime);
}
function isRegExp(value) {
	return brand(value, getter(RegExp.prototype, "source"));
}
function isMap(value) {
	return brand(value, getter(Map.prototype, "size"));
}
function isSet(value) {
	return brand(value, getter(Set.prototype, "size"));
}
function isWeakMap(value) {
	return brand(value, WeakMap.prototype.has, [{}]);
}
function isWeakSet(value) {
	return brand(value, WeakSet.prototype.has, [{}]);
}
function isPromise(value) {
	return value instanceof Promise;
}
function isNativeError(value) {
	return typeof Error.isError === "function" ? Error.isError(value) : tag(value, "Error");
}
function isAsyncFunction(value) {
	return typeof value === "function" && (tag(value, "AsyncFunction") || tag(value, "AsyncGeneratorFunction"));
}
function isGeneratorFunction(value) {
	return typeof value === "function" && (tag(value, "GeneratorFunction") || tag(value, "AsyncGeneratorFunction"));
}
function isGeneratorObject(value) {
	return tag(value, "Generator") || tag(value, "AsyncGenerator");
}
function isArgumentsObject(value) {
	return tag(value, "Arguments");
}
function isMapIterator(value) {
	return tag(value, "Map Iterator");
}
function isSetIterator(value) {
	return tag(value, "Set Iterator");
}
function isModuleNamespaceObject(value) {
	return typeof value === "object" && value !== null && Object.getPrototypeOf(value) === null && !Object.isExtensible(value) && tag(value, "Module");
}
function isCryptoKey(value) {
	return brand(value, getter(globalThis.CryptoKey?.prototype, "type"));
}
function isKeyObject(_value) {
	throw unsupportedNodeApi("util.types.isKeyObject", "native key objects are not available in components");
}
function isExternal(_value) {
	throw unsupportedNodeApi("util.types.isExternal", "native external pointers cannot be inspected in components");
}
function isProxy(_value) {
	throw unsupportedNodeApi("util.types.isProxy", "the engine does not expose proxy targets");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util-types.js
const types = { ...types_exports };
Object.defineProperties(types, {
	isCryptoKey: {
		value: isCryptoKey,
		enumerable: true,
		writable: false,
		configurable: false
	},
	isKeyObject: {
		value: isKeyObject,
		enumerable: true,
		writable: false,
		configurable: false
	}
});
//#endregion
export { isPromise as A, isUint32Array as B, isInt8Array as C, isModuleNamespaceObject as D, isMapIterator as E, isSharedArrayBuffer as F, isUint8ClampedArray as H, isStringObject as I, isSymbolObject as L, isRegExp as M, isSet as N, isNativeError as O, isSetIterator as P, isTypedArray as R, isInt32Array as S, isMap as T, isWeakMap as U, isUint8Array as V, isWeakSet as W, isFloat32Array as _, isArrayBufferView as a, isGeneratorObject as b, isBigIntObject as c, isBoxedPrimitive as d, isCryptoKey as f, isFloat16Array as g, isExternal as h, isArrayBuffer as i, isProxy as j, isNumberObject as k, isBigUint64Array as l, isDate as m, isAnyArrayBuffer as n, isAsyncFunction as o, isDataView as p, isArgumentsObject as r, isBigInt64Array as s, types as t, isBooleanObject as u, isFloat64Array as v, isKeyObject as w, isInt16Array as x, isGeneratorFunction as y, isUint16Array as z };
