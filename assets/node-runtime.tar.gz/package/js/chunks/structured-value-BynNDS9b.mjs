import { v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { Buffer } from "../buffer.mjs";
import { t as DOMException } from "./errors-Dlg0HNHo.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/structured-value/types.js
const viewConstructors = {
	Int8Array,
	Uint8Array,
	Uint8ClampedArray,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array,
	BigInt64Array,
	BigUint64Array
};
function objectLike(value) {
	return typeof value === "object" && value !== null || typeof value === "function";
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/structured-value/encode.js
/** Reuse the worker transport, adding persistent IDs only for native V8 sessions. */
function createEncoder(options, uncloneable) {
	let nodes = [];
	let seen = /* @__PURE__ */ new Map();
	const unsupported = (detail) => {
		throw unsupportedNodeApi(options.api ?? "worker_threads structured messages", detail);
	};
	return function encode(value) {
		if (!options.persistent) {
			nodes = [];
			seen = /* @__PURE__ */ new Map();
		}
		const checkpoint = nodes.length;
		const added = [];
		function visit(value) {
			if (objectLike(value)) {
				if (uncloneable.has(value)) throw new DOMException("Cannot clone object marked as uncloneable", "DataCloneError");
				const previous = seen.get(value);
				if (previous !== void 0) return previous;
			}
			const id = nodes.length;
			nodes.push({ type: "undefined" });
			if (objectLike(value)) {
				seen.set(value, id);
				added.push(value);
			}
			nodes[id] = encodeValue(value, visit, options, unsupported);
			return id;
		}
		try {
			const root = visit(value);
			return JSON.stringify(options.persistent ? {
				root,
				nodes
			} : nodes);
		} catch (error) {
			nodes.length = checkpoint;
			for (const object of added) seen.delete(object);
			throw error;
		} finally {
			if (!options.persistent) {
				nodes = [];
				seen.clear();
			}
		}
	};
}
function encodeValue(value, visit, options, unsupported) {
	if (value === void 0) return { type: "undefined" };
	if (value === null || typeof value === "string" || typeof value === "boolean") return {
		type: "value",
		value
	};
	if (typeof value === "number") return {
		type: "number",
		value: Object.is(value, -0) ? "-0" : String(value)
	};
	if (typeof value === "bigint") return {
		type: "bigint",
		value: String(value)
	};
	if (typeof value !== "object") throw options.cloneError?.("Value cannot be cloned") ?? new DOMException("Value cannot be cloned", "DataCloneError");
	return encodeObject(value, visit, options, unsupported);
}
function encodeObject(value, visit, options, unsupported) {
	if (value instanceof Map) return {
		type: "map",
		entries: [...Map.prototype.entries.call(value)].map(([key, item]) => [visit(key), visit(item)])
	};
	if (value instanceof Set) return {
		type: "set",
		entries: [...Set.prototype.values.call(value)].map(visit)
	};
	if (value instanceof Date) return {
		type: "date",
		value: String(Date.prototype.getTime.call(value))
	};
	if (value instanceof RegExp) return {
		type: "regexp",
		source: value.source,
		flags: value.flags
	};
	if (options.preserveBuffers && Buffer.isBuffer(value)) return {
		type: "node-buffer",
		bytes: [...value]
	};
	if (ArrayBuffer.isView(value)) return encodeView(value, visit, unsupported);
	if (value instanceof ArrayBuffer) return {
		type: "buffer",
		bytes: [...new Uint8Array(value)]
	};
	return encodeRecord(value, visit, unsupported);
}
function encodeView(value, visit, unsupported) {
	const name = value instanceof DataView ? "DataView" : Object.entries(viewConstructors).find(([, ctor]) => value instanceof ctor)?.[0];
	if (!name) return unsupported("Unknown typed array view");
	return {
		type: "view",
		name,
		buffer: visit(value.buffer),
		offset: value.byteOffset,
		length: value.byteLength
	};
}
function encodeRecord(value, visit, unsupported) {
	const array = Array.isArray(value);
	const prototype = Object.getPrototypeOf(value);
	if (!array && prototype !== Object.prototype && prototype !== null) return unsupported("Only plain records, arrays, Map, Set, Date, RegExp, ArrayBuffer and typed views can cross this boundary");
	const entries = [];
	for (const key of Object.keys(value)) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (!("value" in descriptor)) return unsupported("Accessor properties are not supported");
		entries.push([key, visit(descriptor.value)]);
	}
	return array ? {
		type: "array",
		length: value.length,
		entries
	} : {
		type: "object",
		entries
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/structured-value/decode.js
/** Decode only the private graph representation emitted by the paired adapter. */
function decodeMessage(source, session) {
	const graph = JSON.parse(source);
	const nodes = Array.isArray(graph) ? graph : graph.nodes;
	const root = Array.isArray(graph) ? 0 : graph.root;
	const values = session?.values ?? [];
	const start = values.length;
	for (let index = start; index < nodes.length; index++) values.push(allocate(nodes[index]));
	for (let index = start; index < nodes.length; index++) {
		const node = nodes[index];
		if (node.type === "view") values[index] = restoreView(node, values);
	}
	for (let index = start; index < nodes.length; index++) fillReferences(nodes[index], values[index], values);
	return values[root];
}
function allocate(node) {
	switch (node.type) {
		case "value": return node.value;
		case "undefined":
		case "view": return;
		case "number": return Number(node.value);
		case "bigint": return BigInt(node.value);
		case "date": return new Date(Number(node.value));
		case "array": return new Array(node.length);
		case "object": return {};
		case "map": return /* @__PURE__ */ new Map();
		case "set": return /* @__PURE__ */ new Set();
		case "buffer": return Uint8Array.from(node.bytes).buffer;
		case "node-buffer": return Buffer.from(node.bytes);
		case "regexp": return new RegExp(node.source, node.flags);
	}
}
function restoreView(node, values) {
	const buffer = values[node.buffer];
	if (node.name === "DataView") return new DataView(buffer, node.offset, node.length);
	const Constructor = viewConstructors[node.name];
	return new Constructor(buffer, node.offset, node.length / Constructor.BYTES_PER_ELEMENT);
}
function fillReferences(node, target, values) {
	if (node.type === "object" || node.type === "array") for (const [key, reference] of node.entries) Object.defineProperty(target, key, {
		value: values[reference],
		enumerable: true,
		configurable: true,
		writable: true
	});
	else if (node.type === "map") for (const [key, value] of node.entries) target.set(values[key], values[value]);
	else if (node.type === "set") for (const value of node.entries) target.add(values[value]);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/structured-value.js
/**
* Shared bounded graph transport extracted from worker-threads/codec.ts.
* Worker defaults preserve its clone-mark policy and Uint8Array treatment of Buffer.
* V8 opts into Buffer branding and persistent identities between native serdes calls.
* The graph is transport only; it is never returned as a V8 serialization buffer.
*/
function createMessageCodec(options = {}) {
	const uncloneable = /* @__PURE__ */ new WeakSet();
	const untransferable = /* @__PURE__ */ new WeakSet();
	return {
		encode: createEncoder(options, uncloneable),
		markAsUncloneable(value) {
			if (objectLike(value) && !Array.isArray(value) && !ArrayBuffer.isView(value) && !(value instanceof ArrayBuffer) && !(value instanceof Map) && !(value instanceof Set) && !(value instanceof Date) && !(value instanceof RegExp)) uncloneable.add(value);
		},
		markAsUntransferable(value) {
			if (objectLike(value)) untransferable.add(value);
		},
		isMarkedAsUntransferable(value) {
			return objectLike(value) && untransferable.has(value);
		}
	};
}
//#endregion
export { decodeMessage as n, createMessageCodec as t };
