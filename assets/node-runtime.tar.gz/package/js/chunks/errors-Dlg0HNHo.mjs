import { d as invalidArgType } from "./core-DGqXzKN-.mjs";
import "./validation-qQPlCQ6g.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/errors/call-site.js
/**
* V8's structured stack traces, for engines that only produce a string.
*
* `Error.prepareStackTrace` is not part of the language: it is a V8 extension that Node
* exposes, and Node-shaped packages use it to read a stack frame by frame rather than by
* parsing text. `depd` -- which Express, `body-parser`, `http-errors` and `send` all load --
* does exactly that while it is being imported, so without this a component fails before it
* ever handles a request.
*
* The component engines produce a stack string instead, so the frames are recovered by
* parsing it. What comes back answers the `CallSite` methods that matter for locating a
* frame; the ones that need engine internals to answer honestly say what they do not know
* rather than inventing it.
*/
/**
* SpiderMonkey renders a frame as `name@file:line:column`, with an empty name for a
* top-level frame.
*/
const SPIDERMONKEY_FRAME = /^(?<name>.*?)@(?<location>.*?):(?<line>\d+):(?<column>\d+)$/;
/** V8 renders a frame as `    at name (file:line:column)`, or `    at file:line:column`. */
const V8_FRAME = /^\s*at\s+(?:(?<name>.*?)\s+\()?(?<location>.*?):(?<line>\d+):(?<column>\d+)\)?$/;
function parseFrame(line) {
	const match = SPIDERMONKEY_FRAME.exec(line) ?? V8_FRAME.exec(line);
	if (!match?.groups) return;
	const { name, location, line: lineNumber, column } = match.groups;
	const evalSeparator = location.lastIndexOf(" > eval");
	const isEval = evalSeparator !== -1 || location.startsWith("eval");
	return {
		functionName: name ? name : null,
		fileName: evalSeparator === -1 ? location || null : location.slice(evalSeparator + 7) || null,
		lineNumber: Number(lineNumber),
		columnNumber: Number(column),
		isEval,
		evalOrigin: evalSeparator === -1 ? null : location.slice(0, evalSeparator)
	};
}
function toCallSite(frame) {
	const location = `${frame.fileName ?? "<anonymous>"}:${frame.lineNumber ?? 0}:${frame.columnNumber ?? 0}`;
	return {
		getFileName: () => frame.fileName,
		getLineNumber: () => frame.lineNumber,
		getColumnNumber: () => frame.columnNumber,
		getFunctionName: () => frame.functionName,
		getTypeName: () => null,
		getMethodName: () => null,
		getFunction: () => void 0,
		getEvalOrigin: () => frame.evalOrigin,
		isNative: () => frame.fileName === null,
		isEval: () => frame.isEval,
		isConstructor: () => false,
		isToplevel: () => frame.functionName === null,
		isAsync: () => false,
		isPromiseAll: () => false,
		toString: () => frame.functionName ? `${frame.functionName} (${location})` : location
	};
}
/**
* Parse an engine stack string into V8-shaped call sites.
*
* @param stack - the engine's stack string
* @param skipUntil - drop every frame up to and including the first one for this function,
*   which is how `Error.captureStackTrace()`'s `constructorOpt` hides its own frames
* @returns one call site per frame the string named
*/
function parseCallSites(stack, skipUntil) {
	const frames = [];
	for (const line of stack.split("\n")) {
		const trimmed = line.trim();
		if (!trimmed) continue;
		const frame = parseFrame(trimmed);
		if (frame) frames.push(frame);
	}
	if (skipUntil) {
		const index = frames.findIndex((frame) => frame.functionName === skipUntil);
		if (index >= 0) frames.splice(0, index + 1);
	}
	return frames.map(toCallSite);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/errors.js
function captureStackTrace(targetObject, constructorOpt) {
	if (typeof targetObject !== "object" && typeof targetObject !== "function" || targetObject === null) throw invalidArgType("targetObject", "Object", targetObject);
	const target = targetObject;
	const raw = new globalThis.Error().stack ?? "Error";
	let stack = raw;
	if (constructorOpt?.name) {
		const lines = stack.split("\n");
		const frame = lines.findIndex((line) => line.includes(constructorOpt.name));
		if (frame >= 0) stack = [lines[0], ...lines.slice(frame + 1)].join("\n");
	}
	const name = typeof target.name === "string" ? target.name : "Error";
	const message = typeof target.message === "string" ? target.message : "";
	const lines = stack.split("\n");
	lines[0] = message ? `${name}: ${message}` : name;
	const rendered = lines.join("\n");
	let value;
	let computed = false;
	Object.defineProperty(targetObject, "stack", {
		enumerable: false,
		configurable: true,
		get() {
			if (!computed) {
				computed = true;
				const prepare = globalThis.Error.prepareStackTrace;
				value = typeof prepare === "function" ? prepare(targetObject, parseCallSites(raw, constructorOpt?.name)) : rendered;
			}
			return value;
		},
		set(replacement) {
			computed = true;
			value = replacement;
		}
	});
}
function ensureNodeErrorConstructor() {
	const constructor = globalThis.Error;
	let compatibleCaptureStackTrace = false;
	if (typeof constructor.captureStackTrace === "function") try {
		const target = {
			name: "JcoErrorProbe",
			message: "probe"
		};
		constructor.captureStackTrace(target);
		compatibleCaptureStackTrace = typeof target.stack === "string" && target.stack.startsWith("JcoErrorProbe: probe");
	} catch {}
	if (!compatibleCaptureStackTrace) Object.defineProperty(constructor, "captureStackTrace", {
		value: captureStackTrace,
		enumerable: false,
		configurable: true,
		writable: true
	});
	if (!("stackTraceLimit" in constructor)) Object.defineProperty(constructor, "stackTraceLimit", {
		value: 10,
		enumerable: true,
		configurable: true,
		writable: true
	});
	if (typeof constructor.isError !== "function") Object.defineProperty(constructor, "isError", {
		value(value) {
			return Object.prototype.toString.call(value) === "[object Error]";
		},
		enumerable: false,
		configurable: true,
		writable: true
	});
	return constructor;
}
ensureNodeErrorConstructor();
globalThis.EvalError;
globalThis.RangeError;
globalThis.ReferenceError;
globalThis.SyntaxError;
globalThis.TypeError;
globalThis.URIError;
globalThis.Error;
globalThis.Error;
const DOM_EXCEPTION_CODES = {
	IndexSizeError: 1,
	DOMStringSizeError: 2,
	HierarchyRequestError: 3,
	WrongDocumentError: 4,
	InvalidCharacterError: 5,
	NoDataAllowedError: 6,
	NoModificationAllowedError: 7,
	NotFoundError: 8,
	NotSupportedError: 9,
	InUseAttributeError: 10,
	InvalidStateError: 11,
	SyntaxError: 12,
	InvalidModificationError: 13,
	NamespaceError: 14,
	InvalidAccessError: 15,
	ValidationError: 16,
	TypeMismatchError: 17,
	SecurityError: 18,
	NetworkError: 19,
	AbortError: 20,
	URLMismatchError: 21,
	QuotaExceededError: 22,
	TimeoutError: 23,
	InvalidNodeTypeError: 24,
	DataCloneError: 25
};
var PortableDOMException = class extends globalThis.Error {
	code;
	constructor(message = "", name = "Error") {
		super(message);
		this.name = name;
		this.code = DOM_EXCEPTION_CODES[name] ?? 0;
	}
};
for (const [name, value] of Object.entries({
	INDEX_SIZE_ERR: 1,
	DOMSTRING_SIZE_ERR: 2,
	HIERARCHY_REQUEST_ERR: 3,
	WRONG_DOCUMENT_ERR: 4,
	INVALID_CHARACTER_ERR: 5,
	NO_DATA_ALLOWED_ERR: 6,
	NO_MODIFICATION_ALLOWED_ERR: 7,
	NOT_FOUND_ERR: 8,
	NOT_SUPPORTED_ERR: 9,
	INUSE_ATTRIBUTE_ERR: 10,
	INVALID_STATE_ERR: 11,
	SYNTAX_ERR: 12,
	INVALID_MODIFICATION_ERR: 13,
	NAMESPACE_ERR: 14,
	INVALID_ACCESS_ERR: 15,
	VALIDATION_ERR: 16,
	TYPE_MISMATCH_ERR: 17,
	SECURITY_ERR: 18,
	NETWORK_ERR: 19,
	ABORT_ERR: 20,
	URL_MISMATCH_ERR: 21,
	QUOTA_EXCEEDED_ERR: 22,
	TIMEOUT_ERR: 23,
	INVALID_NODE_TYPE_ERR: 24,
	DATA_CLONE_ERR: 25
})) {
	const descriptor = {
		value,
		enumerable: true,
		configurable: false,
		writable: false
	};
	Object.defineProperty(PortableDOMException, name, descriptor);
	Object.defineProperty(PortableDOMException.prototype, name, descriptor);
}
const optionalGlobals = globalThis;
optionalGlobals.AggregateError;
const DOMException = optionalGlobals.DOMException ?? PortableDOMException;
optionalGlobals.SuppressedError;
//#endregion
export { DOMException as t };
