import { t as AbortError } from "./core-DGqXzKN-.mjs";
import { t as validateAbortSignal } from "./validation-qQPlCQ6g.mjs";
import { n as addAbortListener } from "./events-KhrHxd6b.mjs";
import "./errors-Dlg0HNHo.mjs";
import { i as moveCursor, n as clearScreenDown, p as inspect, r as cursorTo, t as clearLine } from "./callbacks-CB8KGxqT.mjs";
import { _ as emitKeypressEvents, a as InterfaceCore, d as kQuestionCancel, h as kWriteToOutput, m as kTabCompleter, o as interface_exports, p as kTabComplete, r as promises, u as kQuestion } from "./promises-BYqWMSui.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/readline/index.js
var CallbackInterface = class extends InterfaceCore {
	constructor(input, output, completer, terminal) {
		if (input && "input" in input && typeof input.completer === "function" && input.completer.length !== 2) {
			const original = input.completer;
			input.completer = (v, cb) => cb(null, original(v));
		} else if (typeof completer === "function" && completer.length !== 2) {
			const original = completer;
			completer = (v, cb) => cb(null, original(v));
		}
		super(input, output, completer, terminal);
	}
	question(query, options, callback) {
		let cb = typeof options === "function" ? options : callback;
		const opts = options !== null && typeof options === "object" ? options : {};
		if (opts.signal) {
			validateAbortSignal(opts.signal, "options.signal");
			if (opts.signal.aborted) return;
			const disposable = addAbortListener(opts.signal, () => this[kQuestionCancel]());
			const original = cb;
			cb = typeof original === "function" ? (answer) => {
				disposable[Symbol.dispose]();
				original(answer);
			} : () => disposable[Symbol.dispose]();
		}
		if (typeof cb === "function") this[kQuestion](query, cb);
	}
};
const Interface = function Interface(input, output, completer, terminal) {
	return Reflect.construct(CallbackInterface, [
		input,
		output,
		completer,
		terminal
	], new.target || Interface);
};
Interface.prototype = CallbackInterface.prototype;
Object.defineProperty(Interface.prototype, "constructor", {
	value: Interface,
	writable: true,
	configurable: true
});
Object.setPrototypeOf(Interface, InterfaceCore);
Object.defineProperty(Interface.prototype, "question", { enumerable: true });
Object.defineProperty(Interface.prototype.question, Symbol.for("nodejs.util.promisify.custom"), {
	configurable: true,
	writable: true,
	enumerable: true,
	value: function question(query, options = {}) {
		if (options?.signal?.aborted) return Promise.reject(new AbortError(void 0, { cause: options.signal.reason }));
		return new Promise((resolve, reject) => {
			let cb = resolve;
			if (options?.signal) {
				const signal = options.signal;
				const disposable = addAbortListener(signal, () => reject(new AbortError(void 0, { cause: signal.reason })));
				cb = (answer) => {
					disposable[Symbol.dispose]();
					resolve(answer);
				};
			}
			this.question(query, options, cb);
		});
	}
});
for (const name of [
	"kSetRawMode",
	"kOnLine",
	"kWriteToOutput",
	"kAddHistory",
	"kRefreshLine",
	"kNormalWrite",
	"kInsertString",
	"kWordLeft",
	"kWordRight",
	"kDeleteLeft",
	"kDeleteRight",
	"kDeleteWordLeft",
	"kDeleteWordRight",
	"kDeleteLineLeft",
	"kDeleteLineRight",
	"kLine",
	"kHistoryNext",
	"kHistoryPrev",
	"kGetDisplayPos",
	"kMoveCursor",
	"kTtyWrite"
]) {
	const symbol = interface_exports[name];
	const publicName = "_" + name[1].toLowerCase() + name.slice(2);
	Object.defineProperty(Interface.prototype, publicName, {
		value: InterfaceCore.prototype[symbol],
		enumerable: true,
		configurable: true,
		writable: true
	});
	Object.defineProperty(Interface.prototype, symbol, { get() {
		return Reflect.get(this, publicName);
	} });
}
for (const name of [
	"kDecoder",
	"kLine_buffer",
	"kOldPrompt",
	"kPreviousKey",
	"kPrompt",
	"kQuestionCallback",
	"kSawKeyPress",
	"kSawReturnAt"
]) {
	const symbol = interface_exports[name];
	const publicName = "_" + name[1].toLowerCase() + name.slice(2);
	Object.defineProperty(Interface.prototype, publicName, {
		get() {
			return Reflect.get(this, symbol);
		},
		set(value) {
			Reflect.set(this, symbol, value);
		}
	});
}
Object.defineProperty(Interface.prototype, "_getCursorPos", {
	value: InterfaceCore.prototype.getCursorPos,
	enumerable: true,
	configurable: true,
	writable: true
});
Object.defineProperty(Interface.prototype, "_tabComplete", {
	configurable: true,
	writable: true,
	enumerable: true,
	value: function(lastKeypressWasTab) {
		this.pause();
		const line = this.line.slice(0, this.cursor);
		this.completer(line, (err, value) => {
			this.resume();
			if (err) {
				this[kWriteToOutput](`Tab completion error: ${inspect(err)}`);
				return;
			}
			this[kTabCompleter](lastKeypressWasTab, value);
		});
	}
});
Object.defineProperty(Interface.prototype, kTabComplete, { get() {
	return Reflect.get(this, "_tabComplete");
} });
function createInterface(input, output, completer, terminal) {
	return Reflect.construct(Interface, [
		input,
		output,
		completer,
		terminal
	]);
}
const readline = {
	Interface,
	clearLine,
	clearScreenDown,
	createInterface,
	cursorTo,
	emitKeypressEvents,
	moveCursor,
	promises
};
//#endregion
export { createInterface as n, readline as r, Interface as t };
