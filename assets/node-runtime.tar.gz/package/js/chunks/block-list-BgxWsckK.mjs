import { a as codedError, d as invalidArgType, f as invalidArgValue, g as outOfRange } from "./core-DGqXzKN-.mjs";
import { n as mappedIpv4Bytes, r as parseIp } from "./ip-DlsRrJdq.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/net/errors.js
/** Node-style errors used by the portable `node:net` shim. */
function invalidAddress() {
	return codedError(/* @__PURE__ */ new Error("Invalid socket address"), "ERR_INVALID_ADDRESS");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/net/socket-address.js
/**
* Portable `net.SocketAddress`.
*
* Adapted from nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/socketaddress.js (MIT license).
* The native `block_list` address handle is replaced by immutable validated JavaScript state.
*/
const details = /* @__PURE__ */ new WeakMap();
function validatePort(value, name = "options.port") {
	if (typeof value !== "number" && typeof value !== "string") throw invalidArgType(name, ["number", "string"], value);
	const port = typeof value === "string" && value.trim() !== "" ? Number(value) : value;
	if (typeof port !== "number" || !Number.isInteger(port) || port < 0 || port > 65535) throw codedError(/* @__PURE__ */ new RangeError(`${name} should be >= 0 and < 65536. Received ${String(value)}.`), "ERR_SOCKET_BAD_PORT");
	return port;
}
var SocketAddress = class SocketAddress {
	#address;
	#family;
	#port;
	#flowlabel;
	static isSocketAddress(value) {
		return value instanceof SocketAddress;
	}
	static parse(input) {
		if (typeof input !== "string") throw invalidArgType("input", "string", input);
		try {
			const url = new URL(`http://${input}`);
			const bracketed = url.hostname.startsWith("[") && url.hostname.endsWith("]");
			return new SocketAddress({
				address: bracketed ? url.hostname.slice(1, -1) : url.hostname,
				family: bracketed ? "ipv6" : "ipv4",
				port: url.port === "" ? 0 : Number(url.port)
			});
		} catch {
			return;
		}
	}
	constructor(options = {}) {
		if (typeof options !== "object" || options === null) throw invalidArgType("options", "Object", options);
		const rawFamily = options.family ?? "ipv4";
		if (typeof rawFamily !== "string") throw invalidArgValue("options.family", rawFamily);
		const family = rawFamily.toLowerCase();
		if (family !== "ipv4" && family !== "ipv6") throw invalidArgValue("options.family", options.family);
		const address = options.address ?? (family === "ipv4" ? "127.0.0.1" : "::");
		if (typeof address !== "string") throw invalidArgType("options.address", "string", address);
		const parsed = parseIp(address, family);
		if (!parsed) throw invalidAddress();
		const port = validatePort(options.port ?? 0);
		const flowlabel = family === "ipv4" ? 0 : options.flowlabel ?? 0;
		if (typeof flowlabel !== "number") throw invalidArgType("options.flowlabel", "number", flowlabel);
		if (!Number.isInteger(flowlabel) || flowlabel < 0 || flowlabel > 1048575) throw outOfRange("options.flowlabel", ">= 0 and <= 1048575", flowlabel);
		this.#address = parsed.canonical;
		this.#family = family;
		this.#port = port;
		this.#flowlabel = flowlabel;
		details.set(this, {
			familyNumber: parsed.family,
			bytes: parsed.bytes
		});
	}
	get address() {
		return this.#address;
	}
	get family() {
		return this.#family;
	}
	get port() {
		return this.#port;
	}
	get flowlabel() {
		return this.#flowlabel;
	}
	toJSON() {
		return {
			address: this.address,
			port: this.port,
			family: this.family,
			flowlabel: this.flowlabel
		};
	}
};
function socketAddressDetails(value) {
	return details.get(value);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/net/block-list.js
/**
* Portable `net.BlockList`.
*
* Adapted from nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/blocklist.js (MIT license).
* The native `block_list` handle is replaced by JavaScript byte/range comparisons while the
* public validation, newest-first rule ordering, JSON format, and IPv4-mapped behavior remain.
*/
function address(value, family, name) {
	if (SocketAddress.isSocketAddress(value)) return value;
	if (typeof value !== "string") throw invalidArgType(name, "string", value);
	const normalizedFamily = typeof family === "string" ? family.toLowerCase() : family;
	if (normalizedFamily !== "ipv4" && normalizedFamily !== "ipv6") throw invalidArgValue("family", family);
	return new SocketAddress({
		address: value,
		family: normalizedFamily
	});
}
function numeric(value) {
	let result = 0n;
	for (const byte of socketAddressDetails(value).bytes) result = result << 8n | BigInt(byte);
	return result;
}
function sameFamily(first, second) {
	if (first.family !== second.family) throw invalidArgValue("family", second.family, "must match the first address family");
}
function matches(rule, candidate) {
	if (rule.kind === "address") return rule.address.family === candidate.family && numeric(rule.address) === numeric(candidate);
	if (rule.kind === "range") {
		if (rule.start.family !== candidate.family) return false;
		const value = numeric(candidate);
		return value >= numeric(rule.start) && value <= numeric(rule.end);
	}
	if (rule.network.family !== candidate.family) return false;
	const bits = candidate.family === "ipv4" ? 32 : 128;
	const shift = BigInt(bits - rule.prefix);
	return numeric(candidate) >> shift === numeric(rule.network) >> shift;
}
var BlockList = class BlockList {
	#rules = [];
	static isBlockList(value) {
		return value instanceof BlockList;
	}
	addAddress(value, family = "ipv4") {
		const parsed = address(value, family, "address");
		this.#rules.unshift({
			kind: "address",
			address: parsed,
			text: `Address: ${parsed.family === "ipv4" ? "IPv4" : "IPv6"} ${parsed.address}`
		});
	}
	addRange(startValue, endValue, family = "ipv4") {
		const start = address(startValue, family, "start");
		const end = address(endValue, family, "end");
		sameFamily(start, end);
		if (numeric(start) > numeric(end)) throw invalidArgValue("start", start, "must come before end");
		this.#rules.unshift({
			kind: "range",
			start,
			end,
			text: `Range: ${start.family === "ipv4" ? "IPv4" : "IPv6"} ${start.address}-${end.address}`
		});
	}
	addSubnet(networkValue, prefix, family = "ipv4") {
		const network = address(networkValue, family, "network");
		const maximum = network.family === "ipv4" ? 32 : 128;
		if (typeof prefix !== "number") throw invalidArgType("prefix", "number", prefix);
		if (!Number.isInteger(prefix) || prefix < 0 || prefix > maximum) throw outOfRange("prefix", `>= 0 and <= ${maximum}`, prefix);
		this.#rules.unshift({
			kind: "subnet",
			network,
			prefix: Object.is(prefix, -0) ? 0 : prefix,
			text: `Subnet: ${network.family === "ipv4" ? "IPv4" : "IPv6"} ${network.address}/${prefix}`
		});
	}
	check(value, family = "ipv4") {
		if (!SocketAddress.isSocketAddress(value) && typeof value !== "string") throw invalidArgType("address", "string", value);
		let candidate;
		try {
			candidate = address(value, family, "address");
		} catch {
			return false;
		}
		if (this.#rules.some((rule) => matches(rule, candidate))) return true;
		if (candidate.family === "ipv4") {
			const mapped = new SocketAddress({
				address: `::ffff:${candidate.address}`,
				family: "ipv6"
			});
			return this.#rules.some((rule) => matches(rule, mapped));
		}
		if (candidate.family === "ipv6") {
			const mapped = mappedIpv4Bytes(socketAddressDetails(candidate).bytes);
			if (mapped) {
				const ipv4 = new SocketAddress({
					address: Array.from(mapped).join("."),
					family: "ipv4"
				});
				return this.#rules.some((rule) => matches(rule, ipv4));
			}
		}
		return false;
	}
	get rules() {
		return this.#rules.map((rule) => rule.text);
	}
	toJSON() {
		return this.rules;
	}
	fromJSON(data) {
		let rules = data;
		if (typeof rules === "string") rules = JSON.parse(rules);
		if (!Array.isArray(rules) || !rules.every((rule) => typeof rule === "string")) throw invalidArgType("data", ["string", "string[]"], data);
		for (const rule of rules) {
			if (rule.includes("IPv4")) {
				let match = /Subnet: IPv4 (\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})/.exec(rule);
				if (match) {
					this.addSubnet(match[1], Number.parseInt(match[2]));
					continue;
				}
				match = /Address: IPv4 (\d{1,3}(?:\.\d{1,3}){3})/.exec(rule);
				if (match) {
					this.addAddress(match[1]);
					continue;
				}
				match = /Range: IPv4 (\d{1,3}(?:\.\d{1,3}){3})-(\d{1,3}(?:\.\d{1,3}){3})/.exec(rule);
				if (match) {
					this.addRange(match[1], match[2]);
					continue;
				}
			}
			if (rule.includes("IPv6")) {
				let match = /Subnet: IPv6 ([0-9a-fA-F:]{1,39})\/([0-9]{1,3})/i.exec(rule);
				if (match) {
					this.addSubnet(match[1], Number.parseInt(match[2]), "ipv6");
					continue;
				}
				match = /Address: IPv6 ([0-9a-fA-F:]{1,39})/i.exec(rule);
				if (match) {
					this.addAddress(match[1], "ipv6");
					continue;
				}
				match = /Range: IPv6 ([0-9a-fA-F:]{1,39})-([0-9a-fA-F:]{1,39})/i.exec(rule);
				if (match) this.addRange(match[1], match[2], "ipv6");
			}
		}
	}
};
//#endregion
export { SocketAddress as n, BlockList as t };
