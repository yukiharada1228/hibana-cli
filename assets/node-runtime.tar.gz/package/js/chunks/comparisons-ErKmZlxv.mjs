//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/assert/comparisons.js
const toString = Object.prototype.toString;
const enumerable = Object.prototype.propertyIsEnumerable;
function tag(value) {
	return toString.call(value);
}
function ownKeys(value, mode) {
	const keys = Object.keys(value);
	if (mode !== "loose") {
		for (const symbol of Object.getOwnPropertySymbols(value)) if (enumerable.call(value, symbol)) keys.push(symbol);
	}
	return keys;
}
function isSharedArrayBuffer(value) {
	return typeof SharedArrayBuffer !== "undefined" && value instanceof SharedArrayBuffer;
}
function bytes(value) {
	if (value instanceof ArrayBuffer || isSharedArrayBuffer(value)) return new Uint8Array(value);
	return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
}
function isFloatArray(value) {
	return value instanceof Float32Array || value instanceof Float64Array;
}
function looseFloatArraysEqual(left, right) {
	if (left.length !== right.length) return false;
	for (let i = 0; i < left.length; i++) if (left[i] !== right[i]) return false;
	return true;
}
function bytesEqual(left, right, partial) {
	if (!partial) {
		if (left.byteLength !== right.byteLength) return false;
		for (let i = 0; i < left.byteLength; i++) if (left[i] !== right[i]) return false;
		return true;
	}
	if (left.byteLength < right.byteLength) return false;
	let leftIndex = 0;
	for (const byte of right) {
		while (leftIndex < left.length && left[leftIndex] !== byte) leftIndex++;
		if (leftIndex === left.length) return false;
		leftIndex++;
	}
	return true;
}
function boxedValue(value) {
	switch (tag(value)) {
		case "[object Number]": return Number.prototype.valueOf.call(value);
		case "[object String]": return String.prototype.valueOf.call(value);
		case "[object Boolean]": return Boolean.prototype.valueOf.call(value);
		case "[object BigInt]": return BigInt.prototype.valueOf.call(value);
		case "[object Symbol]": return Symbol.prototype.valueOf.call(value);
		default: return;
	}
}
function enumerablePropertiesEqual(left, right, mode, memo) {
	const leftRecord = left;
	const rightRecord = right;
	const leftKeys = ownKeys(left, mode);
	const rightKeys = ownKeys(right, mode);
	if (mode === "partial") {
		for (const key of rightKeys) if (!enumerable.call(left, key) || !innerEqual(leftRecord[key], rightRecord[key], mode, memo)) return false;
		return true;
	}
	if (leftKeys.length !== rightKeys.length) return false;
	for (const key of leftKeys) if (!enumerable.call(right, key) || !innerEqual(leftRecord[key], rightRecord[key], mode, memo)) return false;
	return true;
}
function unorderedSubset(left, right, mode, memo, compare = (a, b, state) => innerEqual(a, b, mode, state)) {
	if (mode === "partial" ? left.length < right.length : left.length !== right.length) return false;
	const used = /* @__PURE__ */ new Set();
	const search = (index, state) => {
		if (index === right.length) return true;
		for (let i = 0; i < left.length; i++) {
			if (used.has(i)) continue;
			const next = {
				left: new Map(state.left),
				right: new Map(state.right)
			};
			if (compare(left[i], right[index], next)) {
				used.add(i);
				if (search(index + 1, next)) return true;
				used.delete(i);
			}
		}
		return false;
	};
	return search(0, memo);
}
function compareArrays(left, right, mode, memo) {
	if (mode !== "partial") {
		if (left.length !== right.length) return false;
		for (let i = 0; i < left.length; i++) {
			if (Object.hasOwn(left, i) !== Object.hasOwn(right, i)) return false;
			if (Object.hasOwn(left, i) && !innerEqual(left[i], right[i], mode, memo)) return false;
		}
	} else {
		if (left.length < right.length) return false;
		let position = 0;
		for (let i = 0; i < left.length && position < right.length; i++) {
			const next = {
				left: new Map(memo.left),
				right: new Map(memo.right)
			};
			if (innerEqual(left[i], right[position], mode, next)) position++;
		}
		if (position !== right.length) return false;
	}
	const isArrayIndex = (key) => {
		if (typeof key !== "string") return false;
		const index = Number(key);
		return Number.isInteger(index) && index >= 0 && index < 4294967295 && String(index) === key;
	};
	const extras = (value) => {
		const record = value;
		const result = {};
		for (const key of ownKeys(value, mode)) if (!isArrayIndex(key)) result[key] = record[key];
		return result;
	};
	return enumerablePropertiesEqual(extras(left), extras(right), mode, memo);
}
function compareErrors(left, right, mode, memo) {
	const leftRecord = left;
	const rightRecord = right;
	for (const key of [
		"name",
		"message",
		"cause",
		"errors"
	]) {
		const leftHas = key in left;
		const rightHas = key in right;
		if (mode === "partial" && !rightHas) continue;
		if (leftHas !== rightHas || !innerEqual(leftRecord[key], rightRecord[key], mode, memo)) return false;
	}
	return enumerablePropertiesEqual(left, right, mode, memo);
}
function compareObjects(left, right, mode, memo) {
	if (mode === "strict" && Object.getPrototypeOf(left) !== Object.getPrototypeOf(right)) return false;
	const mappedRight = memo.left.get(left);
	if (mappedRight !== void 0) return mappedRight === right;
	if (memo.right.has(right)) return false;
	memo.left.set(left, right);
	memo.right.set(right, left);
	const leftTag = tag(left);
	if (leftTag !== tag(right)) return false;
	if (Array.isArray(left)) return compareArrays(left, right, mode, memo);
	if (left instanceof Date) {
		const a = left.getTime();
		const b = right.getTime();
		if (a !== b && !(Number.isNaN(a) && Number.isNaN(b))) return false;
	} else if (left instanceof RegExp) {
		const other = right;
		if (left.source !== other.source || left.flags !== other.flags || left.lastIndex !== other.lastIndex) return false;
	} else if (left instanceof ArrayBuffer || isSharedArrayBuffer(left)) {
		if (!(right instanceof ArrayBuffer || isSharedArrayBuffer(right))) return false;
		if (!bytesEqual(bytes(left), bytes(right), mode === "partial")) return false;
	} else if (ArrayBuffer.isView(left)) {
		if (!ArrayBuffer.isView(right) || left.constructor !== right.constructor) return false;
		if (mode === "loose" && isFloatArray(left) && isFloatArray(right) && left.constructor === right.constructor) {
			if (!looseFloatArraysEqual(left, right)) return false;
		} else if (!bytesEqual(bytes(left), bytes(right), mode === "partial")) return false;
	} else if (left instanceof Set) {
		if (!(right instanceof Set) || !unorderedSubset([...left], [...right], mode, memo)) return false;
	} else if (left instanceof Map) {
		if (!(right instanceof Map)) return false;
		const compareEntry = (a, b, state) => {
			const leftEntry = a;
			const rightEntry = b;
			return innerEqual(leftEntry[0], rightEntry[0], mode, state) && innerEqual(leftEntry[1], rightEntry[1], mode, state);
		};
		if (!unorderedSubset([...left], [...right], mode, memo, compareEntry)) return false;
	} else if (left instanceof Error) {
		if (!(right instanceof Error) || !compareErrors(left, right, mode, memo)) return false;
		return true;
	} else if (left instanceof WeakMap || left instanceof WeakSet || left instanceof Promise) return false;
	else if (typeof URL !== "undefined" && left instanceof URL) {
		if (!(right instanceof URL) || left.href !== right.href) return false;
	} else {
		const boxed = boxedValue(left);
		if (boxed !== void 0 || [
			"[object Number]",
			"[object String]",
			"[object Boolean]"
		].includes(leftTag)) {
			if (!Object.is(boxed, boxedValue(right))) return false;
		}
	}
	return enumerablePropertiesEqual(left, right, mode, memo);
}
function innerEqual(left, right, mode, memo) {
	if (left === right) return left !== 0 || Object.is(left, right) || mode === "loose";
	if (mode === "loose") {
		if ((left === null || typeof left !== "object") && (right === null || typeof right !== "object")) return left == right || Number.isNaN(left) && Number.isNaN(right);
	} else if (typeof left === "number" && Number.isNaN(left) && typeof right === "number" && Number.isNaN(right)) return true;
	if (left === null || right === null || typeof left !== "object" || typeof right !== "object") return false;
	return compareObjects(left, right, mode, memo);
}
function compare(left, right, mode) {
	return innerEqual(left, right, mode, {
		left: /* @__PURE__ */ new Map(),
		right: /* @__PURE__ */ new Map()
	});
}
function isDeepEqual(left, right) {
	return compare(left, right, "loose");
}
function isDeepStrictEqual(left, right, skipPrototype = false) {
	return compare(left, right, skipPrototype ? "strict-no-prototype" : "strict");
}
function isPartialStrictEqual(left, right) {
	return compare(left, right, "partial");
}
//#endregion
export { isDeepStrictEqual as n, isPartialStrictEqual as r, isDeepEqual as t };
