import { a as codedError } from "./core-DGqXzKN-.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/deny-host.js
/**
* Deny-by-default host providers for host-backed Node builtins.
*
* Declaring or injecting a `jco:node/*` WIT import must never grant host access on its own, so
* every host-backed builtin ships a provider whose every operation refuses. This module owns the
* refusal helpers so each `<mod>-host.ts` is only its member list; which shape a builtin uses
* is dictated by its WIT contract, not by preference:
*
* - `denyThrow` -- for interfaces whose functions do not return `result`. The provider throws a
*   coded `Error`, which jco surfaces to the guest as an exception carrying
*   `ERR_JCO_<MOD>_ADAPTER_REQUIRED` (child-process, cluster, console, dns, http).
* - fs returns a tagged error result so its denial stays catchable across WIT.
* - Interfaces returning `result<T, record error>` throw serialized error records, which the
*   bindings lower into the `err` case; the guest reconstructs the Node error (os).
* - `denyVariant` -- for interfaces whose functions return `result<T, variant error>` with an
*   explicit `denied(string)` case. The provider throws the raw variant, which jco lowers back to
*   the same tagged object guest-side, and the guest maps `denied` to its adapter-required code
*   (inspector, ffi).
*
* The per-member `export const x: XHost["x"] = deny;` lines in each host file are load-bearing:
* jco binds WIT functions to the module's named ESM exports, which cannot be generated.
*/
/** The standard refusal message for a builtin whose host adapter has not been mapped. */
function adapterRequiredMessage(specifier) {
	return `${specifier} requires an application-provided host adapter`;
}
/** A provider operation that throws a coded `Error` on every call. */
function denyThrow(code, message) {
	return () => {
		throw codedError(new Error(message), code);
	};
}
/** A provider operation that throws the WIT `variant error` `denied` case on every call. */
function denyVariant(witInterface) {
	return () => {
		throw {
			tag: "denied",
			val: `map ${witInterface} to a host adapter to grant it`
		};
	};
}
//#endregion
export { denyThrow as n, denyVariant as r, adapterRequiredMessage as t };
