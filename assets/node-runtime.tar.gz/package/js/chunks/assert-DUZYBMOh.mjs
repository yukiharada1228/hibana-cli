import { t as inspect } from "./inspect-fNEaW5tU.mjs";
import { d as invalidArgType, f as invalidArgValue, h as missingArgs, i as ambiguousArgument, o as constructCallRequired, p as invalidReturnValue, s as deprecatedNodeApi } from "./core-DGqXzKN-.mjs";
import { a as validateFunction, c as validateObject, l as validateOneOf } from "./validation-qQPlCQ6g.mjs";
import { n as isDeepStrictEqual, r as isPartialStrictEqual, t as isDeepEqual } from "./comparisons-ErKmZlxv.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/assert/assertion-error.js
const readableOperator = {
	deepStrictEqual: "Expected values to be strictly deep-equal:",
	partialDeepStrictEqual: "Expected values to be partially and strictly deep-equal:",
	strictEqual: "Expected values to be strictly equal:",
	deepEqual: "Expected values to be loosely deep-equal:",
	notDeepStrictEqual: "Expected \"actual\" not to be strictly deep-equal to:",
	notStrictEqual: "Expected \"actual\" to be strictly unequal to:",
	notDeepEqual: "Expected \"actual\" not to be loosely deep-equal to:"
};
function generatedMessage(actual, expected, operator, diff) {
	const left = inspect(actual);
	const right = inspect(expected);
	const heading = readableOperator[operator];
	if (operator === "strictEqual" || operator === "deepStrictEqual" || operator === "partialDeepStrictEqual") {
		if (left.length + right.length <= 12 && !left.includes("\n") && !right.includes("\n")) return `${left} !== ${right}`;
		return `${heading}\n\n+ actual - expected\n\n+ ${left}\n- ${right}\n`;
	}
	if (operator === "notStrictEqual" || operator === "notDeepStrictEqual") return `${heading}${left.length > 5 ? "\n\n" : " "}${diff === "full" ? left : left.slice(0, 512)}`;
	if (operator === "deepEqual") return `${heading}\n\n${left}\n\nshould loosely deep-equal\n\n${right}`;
	if (operator === "notDeepEqual") return `${heading}\n\n${diff === "full" ? left : left.slice(0, 1024)}`;
	return `${left} ${operator} ${right}`;
}
var AssertionError = class extends Error {
	constructor(options) {
		validateObject(options, "options");
		const { actual, expected, operator = "fail", diff = "simple" } = options;
		const message = options.message !== void 0 && options.message !== null ? String(options.message) : generatedMessage(actual, expected, operator, diff);
		super(message);
		this.generatedMessage = !options.message;
		Object.defineProperty(this, "name", {
			value: "AssertionError [ERR_ASSERTION]",
			enumerable: false,
			writable: true,
			configurable: true
		});
		this.code = "ERR_ASSERTION";
		this.actual = actual;
		this.expected = expected;
		this.operator = operator;
		const captureStackTrace = Error.captureStackTrace;
		captureStackTrace?.(this, options.stackStartFn);
		this.stack;
		this.name = "AssertionError";
		this.diff = diff;
	}
	toString() {
		return `${this.name} [${this.code}]: ${this.message}`;
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/assert/call-tracker.js
/**
* Compatibility stub for Node's deprecated assert.CallTracker API (DEP0173).
* Deprecated APIs intentionally fail before performing any work.
*/
var CallTracker = class {
	constructor() {
		throw deprecatedNodeApi("assert.CallTracker (DEP0173)");
	}
	calls() {
		throw deprecatedNodeApi("assert.CallTracker.calls() (DEP0173)");
	}
	getCalls(_fn) {
		throw deprecatedNodeApi("assert.CallTracker.getCalls() (DEP0173)");
	}
	report() {
		throw deprecatedNodeApi("assert.CallTracker.report() (DEP0173)");
	}
	reset(_fn) {
		throw deprecatedNodeApi("assert.CallTracker.reset() (DEP0173)");
	}
	verify() {
		throw deprecatedNodeApi("assert.CallTracker.verify() (DEP0173)");
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/assert/index.js
const optionsByInstance = /* @__PURE__ */ new WeakMap();
const noException = Symbol("no exception");
function optionsOf(value) {
	return value !== null && (typeof value === "object" || typeof value === "function") ? optionsByInstance.get(value) : void 0;
}
function failWith(options) {
	throw new AssertionError(options);
}
function failure(options) {
	if (options.message instanceof Error) throw options.message;
	failWith({
		...options,
		message: options.message
	});
}
function looseEqual(left, right) {
	return left == right;
}
function property(value, key) {
	return Reflect.get(value, key);
}
function messageOf(value) {
	return value !== null && (typeof value === "object" || typeof value === "function") ? property(value, "message") : void 0;
}
function innerOk(value, message, argumentCount, stackStartFn) {
	if (value) return;
	if (message instanceof Error) throw message;
	const generated = argumentCount === 0 || message == null;
	const error = new AssertionError({
		actual: value,
		expected: true,
		message: argumentCount === 0 ? "No value argument passed to `assert.ok()`" : message == null ? "The expression evaluated to a falsy value" : message,
		operator: "==",
		stackStartFn
	});
	error.generatedMessage = generated;
	throw error;
}
var AssertImplementation = class AssertImplementation {
	AssertionError = AssertionError;
	constructor(options = {}) {
		const resolved = {
			strict: true,
			skipPrototype: false,
			...options
		};
		if (resolved.diff !== void 0) validateOneOf(resolved.diff, "options.diff", ["simple", "full"]);
		optionsByInstance.set(this, resolved);
		if (resolved.strict) {
			this.equal = this.strictEqual;
			this.deepEqual = this.deepStrictEqual;
			this.notEqual = this.notStrictEqual;
			this.notDeepEqual = this.notDeepStrictEqual;
		}
	}
	fail(actual, ...deprecatedArguments) {
		if (deprecatedArguments.length > 0) throw deprecatedNodeApi("assert.fail(actual, expected, ...rest) (DEP0094)", "assert.strictEqual()");
		const message = arguments.length === 0 || actual == null ? "Failed" : actual;
		if (message instanceof Error) throw message;
		const error = new AssertionError({
			actual: void 0,
			expected: void 0,
			operator: "fail",
			message: String(message),
			stackStartFn: AssertImplementation.prototype.fail,
			diff: optionsOf(this)?.diff
		});
		if (arguments.length === 0 || actual == null) error.generatedMessage = true;
		throw error;
	}
	ok(value, message) {
		innerOk(value, message, arguments.length, AssertImplementation.prototype.ok);
	}
	equal(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (!looseEqual(actual, expected) && (!Number.isNaN(actual) || !Number.isNaN(expected))) failure({
			actual,
			expected,
			message,
			operator: "==",
			stackStartFn: AssertImplementation.prototype.equal,
			diff: optionsOf(this)?.diff
		});
	}
	notEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (looseEqual(actual, expected) || Number.isNaN(actual) && Number.isNaN(expected)) failure({
			actual,
			expected,
			message,
			operator: "!=",
			stackStartFn: AssertImplementation.prototype.notEqual,
			diff: optionsOf(this)?.diff
		});
	}
	deepEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (!isDeepEqual(actual, expected)) failure({
			actual,
			expected,
			message,
			operator: "deepEqual",
			stackStartFn: AssertImplementation.prototype.deepEqual,
			diff: optionsOf(this)?.diff
		});
	}
	notDeepEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (isDeepEqual(actual, expected)) failure({
			actual,
			expected,
			message,
			operator: "notDeepEqual",
			stackStartFn: AssertImplementation.prototype.notDeepEqual,
			diff: optionsOf(this)?.diff
		});
	}
	deepStrictEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (!isDeepStrictEqual(actual, expected, optionsOf(this)?.skipPrototype)) failure({
			actual,
			expected,
			message,
			operator: "deepStrictEqual",
			stackStartFn: AssertImplementation.prototype.deepStrictEqual,
			diff: optionsOf(this)?.diff
		});
	}
	notDeepStrictEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (isDeepStrictEqual(actual, expected, optionsOf(this)?.skipPrototype)) failure({
			actual,
			expected,
			message,
			operator: "notDeepStrictEqual",
			stackStartFn: AssertImplementation.prototype.notDeepStrictEqual,
			diff: optionsOf(this)?.diff
		});
	}
	strictEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (!Object.is(actual, expected)) failure({
			actual,
			expected,
			message,
			operator: "strictEqual",
			stackStartFn: AssertImplementation.prototype.strictEqual,
			diff: optionsOf(this)?.diff
		});
	}
	notStrictEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (Object.is(actual, expected)) failure({
			actual,
			expected,
			message,
			operator: "notStrictEqual",
			stackStartFn: AssertImplementation.prototype.notStrictEqual,
			diff: optionsOf(this)?.diff
		});
	}
	partialDeepStrictEqual(actual, expected, message) {
		if (arguments.length < 2) throw missingArgs("actual", "expected");
		if (!isPartialStrictEqual(actual, expected)) failure({
			actual,
			expected,
			message,
			operator: "partialDeepStrictEqual",
			stackStartFn: AssertImplementation.prototype.partialDeepStrictEqual,
			diff: optionsOf(this)?.diff
		});
	}
	throws(fn, error, message) {
		expectsError.call(this, AssertImplementation.prototype.throws, getActual(fn), error, message, arguments.length);
	}
	async rejects(promiseFn, error, message) {
		expectsError.call(this, AssertImplementation.prototype.rejects, await waitForActual(promiseFn), error, message, arguments.length);
	}
	doesNotThrow(fn, error, message) {
		expectsNoError.call(this, AssertImplementation.prototype.doesNotThrow, getActual(fn), error, message);
	}
	async doesNotReject(fn, error, message) {
		expectsNoError.call(this, AssertImplementation.prototype.doesNotReject, await waitForActual(fn), error, message);
	}
	ifError(error) {
		if (error === null || error === void 0) return;
		failure({
			actual: error,
			expected: null,
			operator: "ifError",
			message: `ifError got unwanted exception: ${error instanceof Error ? error.message || error.constructor.name : inspect(error)}`,
			stackStartFn: AssertImplementation.prototype.ifError,
			diff: optionsOf(this)?.diff
		});
	}
	match(value, regexp, message) {
		internalMatch.call(this, value, regexp, message, true, AssertImplementation.prototype.match);
	}
	doesNotMatch(value, regexp, message) {
		internalMatch.call(this, value, regexp, message, false, AssertImplementation.prototype.doesNotMatch);
	}
};
const Assert = new Proxy(AssertImplementation, { apply() {
	throw constructCallRequired("Assert");
} });
function getActual(fn) {
	validateFunction(fn, "fn");
	try {
		fn();
	} catch (error) {
		return error;
	}
	return noException;
}
function isPromise(value) {
	return value instanceof Promise;
}
async function waitForActual(value) {
	let promise;
	if (typeof value === "function") promise = value();
	else promise = value;
	if (!isPromise(promise)) {
		if (typeof value !== "function" && !isPromise(value)) throw invalidArgType("promiseFn", ["Function", "Promise"], value);
		throw invalidReturnValue("instance of Promise", "promiseFn", promise);
	}
	try {
		await promise;
	} catch (error) {
		return error;
	}
	return noException;
}
function matchExpected(actual, expected, owner, fn, message) {
	if (expected instanceof RegExp) return expected.exec(String(actual)) !== null;
	if (typeof expected === "function") {
		const candidate = expected;
		const constructor = candidate;
		if (candidate.prototype !== void 0 && actual instanceof constructor) return true;
		if (Error.isPrototypeOf(expected)) return false;
		return expected.call({}, actual) === true;
	}
	if (expected === null || typeof expected !== "object") throw invalidArgType("error", [
		"Object",
		"Error",
		"Function",
		"RegExp"
	], expected);
	const keys = Object.keys(expected);
	if (expected instanceof Error) keys.push("name", "message");
	else if (keys.length === 0) throw invalidArgValue("error", expected, "may not be an empty object");
	if (actual === null || typeof actual !== "object") return false;
	for (const key of keys) {
		const expectedValue = property(expected, key);
		const actualValue = property(actual, key);
		if (typeof actualValue === "string" && expectedValue instanceof RegExp && expectedValue.exec(actualValue)) continue;
		if (!isDeepStrictEqual(actualValue, expectedValue)) failure({
			actual,
			expected,
			message,
			operator: fn.name,
			stackStartFn: fn,
			diff: optionsOf(owner)?.diff
		});
	}
	return true;
}
function expectsError(fn, actual, error, message, argumentCount) {
	if (typeof error === "string") {
		if (argumentCount >= 3) throw invalidArgType("error", [
			"Object",
			"Error",
			"Function",
			"RegExp"
		], error);
		if (messageOf(actual) === error || actual === error) throw ambiguousArgument("error/message", `The error message "${error}" is identical to the message.`);
		message = error;
		error = void 0;
	}
	if (actual === noException) failure({
		actual: void 0,
		expected: error,
		operator: fn.name,
		message: `Missing expected ${fn.name === "rejects" ? "rejection" : "exception"}${message ? `: ${message}` : "."}`,
		stackStartFn: fn,
		diff: optionsOf(this)?.diff
	});
	if (error === void 0 || error === null) return;
	if (!matchExpected(actual, error, this, fn, message)) failure({
		actual,
		expected: error,
		message,
		operator: fn.name,
		stackStartFn: fn,
		diff: optionsOf(this)?.diff
	});
}
function expectsNoError(fn, actual, error, message) {
	if (actual === noException) return;
	if (typeof error === "string") {
		message = error;
		error = void 0;
	}
	if (error === void 0 || matchExpected(actual, error, this, fn, message)) failure({
		actual,
		expected: error,
		operator: fn.name,
		message: `Got unwanted ${fn.name === "doesNotReject" ? "rejection" : "exception"}${message ? `: ${message}` : "."}\nActual message: "${String(messageOf(actual))}"`,
		stackStartFn: fn,
		diff: optionsOf(this)?.diff
	});
	throw actual;
}
function internalMatch(value, regexp, message, shouldMatch, fn) {
	if (!(regexp instanceof RegExp)) throw invalidArgType("regexp", "RegExp", regexp);
	if ((typeof value === "string" && regexp.exec(value) !== null) === shouldMatch) return;
	if (message instanceof Error) throw message;
	const generated = message == null;
	const error = new AssertionError({
		actual: value,
		expected: regexp,
		message: message ?? (typeof value !== "string" ? `The "string" argument must be of type string. Received type ${typeof value} (${inspect(value)})` : `The input ${shouldMatch ? "did not match" : "was expected to not match"} the regular expression ${inspect(regexp)}. Input:\n\n${inspect(value)}\n`),
		operator: fn.name,
		stackStartFn: fn,
		diff: optionsOf(this)?.diff
	});
	error.generatedMessage = generated;
	throw error;
}
const fail = AssertImplementation.prototype.fail;
const equal = AssertImplementation.prototype.equal;
const notEqual = AssertImplementation.prototype.notEqual;
const deepEqual = AssertImplementation.prototype.deepEqual;
const notDeepEqual = AssertImplementation.prototype.notDeepEqual;
const deepStrictEqual = AssertImplementation.prototype.deepStrictEqual;
const notDeepStrictEqual = AssertImplementation.prototype.notDeepStrictEqual;
const strictEqual = AssertImplementation.prototype.strictEqual;
const notStrictEqual = AssertImplementation.prototype.notStrictEqual;
const partialDeepStrictEqual = AssertImplementation.prototype.partialDeepStrictEqual;
const throws = AssertImplementation.prototype.throws;
const rejects = AssertImplementation.prototype.rejects;
const doesNotThrow = AssertImplementation.prototype.doesNotThrow;
const doesNotReject = AssertImplementation.prototype.doesNotReject;
const ifError = AssertImplementation.prototype.ifError;
const match = AssertImplementation.prototype.match;
const doesNotMatch = AssertImplementation.prototype.doesNotMatch;
function ok(value, message) {
	innerOk(value, message, arguments.length, ok);
}
const base = {
	AssertionError,
	Assert,
	CallTracker,
	ok,
	fail,
	equal,
	notEqual,
	deepEqual,
	notDeepEqual,
	deepStrictEqual,
	notDeepStrictEqual,
	strictEqual,
	notStrictEqual,
	partialDeepStrictEqual,
	throws,
	rejects,
	doesNotThrow,
	doesNotReject,
	ifError,
	match,
	doesNotMatch
};
const strictFunction = function strict(value, message) {
	innerOk(value, message, arguments.length, strictFunction);
};
const strict = Object.assign(strictFunction, base, {
	equal: strictEqual,
	deepEqual: deepStrictEqual,
	notEqual: notStrictEqual,
	notDeepEqual: notDeepStrictEqual
});
strict.strict = strict;
const assert = Object.assign(ok, base, { strict });
assert.ok = assert;
//#endregion
export { AssertionError as C, CallTracker as S, partialDeepStrictEqual as _, doesNotMatch as a, strictEqual as b, equal as c, match as d, notDeepEqual as f, ok as g, notStrictEqual as h, deepStrictEqual as i, fail as l, notEqual as m, assert as n, doesNotReject as o, notDeepStrictEqual as p, deepEqual as r, doesNotThrow as s, Assert as t, ifError as u, rejects as v, throws as x, strict as y };
