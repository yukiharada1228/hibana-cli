import { t as __commonJSMin } from "./rolldown-runtime-7_rZTKki.mjs";
import { c as validateObject, u as validateString } from "./validation-qQPlCQ6g.mjs";
//#region node_modules/balanced-match/dist/commonjs/index.js
var require_commonjs$2 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.range = exports.balanced = void 0;
	const balanced = (a, b, str) => {
		const ma = a instanceof RegExp ? maybeMatch(a, str) : a;
		const mb = b instanceof RegExp ? maybeMatch(b, str) : b;
		const r = ma !== null && mb != null && (0, exports.range)(ma, mb, str);
		return r && {
			start: r[0],
			end: r[1],
			pre: str.slice(0, r[0]),
			body: str.slice(r[0] + ma.length, r[1]),
			post: str.slice(r[1] + mb.length)
		};
	};
	exports.balanced = balanced;
	const maybeMatch = (reg, str) => {
		const m = str.match(reg);
		return m ? m[0] : null;
	};
	const range = (a, b, str) => {
		let begs, beg, left, right = void 0, result;
		let ai = str.indexOf(a);
		let bi = str.indexOf(b, ai + 1);
		let i = ai;
		if (ai >= 0 && bi > 0) {
			if (a === b) return [ai, bi];
			begs = [];
			left = str.length;
			while (i >= 0 && !result) {
				if (i === ai) {
					begs.push(i);
					ai = str.indexOf(a, i + 1);
				} else if (begs.length === 1) {
					const r = begs.pop();
					if (r !== void 0) result = [r, bi];
				} else {
					beg = begs.pop();
					if (beg !== void 0 && beg < left) {
						left = beg;
						right = bi;
					}
					bi = str.indexOf(b, i + 1);
				}
				i = ai < bi && ai >= 0 ? ai : bi;
			}
			if (begs.length && right !== void 0) result = [left, right];
		}
		return result;
	};
	exports.range = range;
}));
//#endregion
//#region node_modules/brace-expansion/dist/commonjs/index.js
var require_commonjs$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EXPANSION_MAX_REWRITES = exports.EXPANSION_MAX_DEPTH = exports.EXPANSION_MAX_LENGTH = exports.EXPANSION_MAX = void 0;
	exports.expand = expand;
	const balanced_match_1 = require_commonjs$2();
	const escSlash = "\0SLASH" + Math.random() + "\0";
	const escOpen = "\0OPEN" + Math.random() + "\0";
	const escClose = "\0CLOSE" + Math.random() + "\0";
	const escComma = "\0COMMA" + Math.random() + "\0";
	const escPeriod = "\0PERIOD" + Math.random() + "\0";
	const escSlashPattern = new RegExp(escSlash, "g");
	const escOpenPattern = new RegExp(escOpen, "g");
	const escClosePattern = new RegExp(escClose, "g");
	const escCommaPattern = new RegExp(escComma, "g");
	const escPeriodPattern = new RegExp(escPeriod, "g");
	const slashPattern = /\\\\/g;
	const openPattern = /\\{/g;
	const closePattern = /\\}/g;
	const commaPattern = /\\,/g;
	const periodPattern = /\\\./g;
	exports.EXPANSION_MAX = 1e5;
	exports.EXPANSION_MAX_LENGTH = 4e6;
	exports.EXPANSION_MAX_DEPTH = 1e3;
	exports.EXPANSION_MAX_REWRITES = 1e3;
	function numeric(str) {
		return !isNaN(str) ? parseInt(str, 10) : str.charCodeAt(0);
	}
	function escapeBraces(str) {
		return str.replace(slashPattern, escSlash).replace(openPattern, escOpen).replace(closePattern, escClose).replace(commaPattern, escComma).replace(periodPattern, escPeriod);
	}
	function unescapeBraces(str) {
		return str.replace(escSlashPattern, "\\").replace(escOpenPattern, "{").replace(escClosePattern, "}").replace(escCommaPattern, ",").replace(escPeriodPattern, ".");
	}
	function pushAll(target, items) {
		for (let i = 0; i < items.length; i++) target.push(items[i]);
	}
	/**
	* Basically just str.split(","), but handling cases
	* where we have nested braced sections, which should be
	* treated as individual members, like {a,{b,c},d}
	*/
	function parseCommaParts(str) {
		const parts = [];
		let carry = "";
		for (;;) {
			const m = (0, balanced_match_1.balanced)("{", "}", str);
			if (!m) {
				const tail = str.split(",");
				tail[0] = carry + tail[0];
				pushAll(parts, tail);
				return parts;
			}
			const { pre, body, post } = m;
			const p = pre.split(",");
			p[0] = carry + p[0];
			p[p.length - 1] += "{" + body + "}";
			if (!post.length) {
				pushAll(parts, p);
				return parts;
			}
			carry = p.pop();
			pushAll(parts, p);
			str = post;
		}
	}
	function expand(str, options = {}) {
		if (!str) return [];
		const { max = exports.EXPANSION_MAX, maxLength = exports.EXPANSION_MAX_LENGTH, maxDepth = exports.EXPANSION_MAX_DEPTH, maxRewrites = exports.EXPANSION_MAX_REWRITES } = options;
		if (str.slice(0, 2) === "{}") str = "\\{\\}" + str.slice(2);
		return expand_(escapeBraces(str), max, maxLength, maxDepth, 0, maxRewrites, true).map(unescapeBraces);
	}
	function embrace(str) {
		return "{" + str + "}";
	}
	function isPadded(el) {
		return /^-?0\d/.test(el);
	}
	function lte(i, y) {
		return i <= y;
	}
	function gte(i, y) {
		return i >= y;
	}
	function combine(acc, pre, values, max, maxLength, dropEmpties) {
		const out = [];
		let length = 0;
		for (let a = 0; a < acc.length; a++) for (let v = 0; v < values.length; v++) {
			if (out.length >= max) return out;
			const expansion = acc[a] + pre + values[v];
			if (dropEmpties && !expansion) continue;
			if (length + expansion.length > maxLength) return out;
			out.push(expansion);
			length += expansion.length;
		}
		return out;
	}
	function expandSequence(body, isAlphaSequence, max, maxLength) {
		const n = body.split(/\.\./);
		const N = [];
		/* c8 ignore start */
		if (n[0] === void 0 || n[1] === void 0) return N;
		/* c8 ignore stop */
		const x = numeric(n[0]);
		const y = numeric(n[1]);
		const width = Math.max(n[0].length, n[1].length);
		let incr = n.length === 3 && n[2] !== void 0 ? Math.max(Math.abs(numeric(n[2])), 1) : 1;
		let test = lte;
		if (y < x) {
			incr *= -1;
			test = gte;
		}
		const pad = n.some(isPadded);
		let length = 0;
		for (let i = x; test(i, y) && N.length < max; i += incr) {
			let c;
			if (isAlphaSequence) {
				c = String.fromCharCode(i);
				if (c === "\\") c = "";
			} else {
				c = String(i);
				if (pad) {
					const need = width - c.length;
					if (need > 0) {
						const z = new Array(need + 1).join("0");
						if (i < 0) c = "-" + z + c.slice(1);
						else c = z + c;
					}
				}
			}
			if (length + c.length > maxLength) break;
			N.push(c);
			length += c.length;
		}
		return N;
	}
	function expand_(str, max, maxLength, maxDepth, depth, maxRewrites, isTop) {
		if (depth > maxDepth) return [str];
		let acc = [""];
		let rewrites = 0;
		let dropEmpties = false;
		let firstGroup = true;
		for (;;) {
			const m = (0, balanced_match_1.balanced)("{", "}", str);
			if (!m) return combine(acc, str, [""], max, maxLength, dropEmpties);
			const pre = m.pre;
			if (/\$$/.test(pre)) {
				acc = combine(acc, pre + "{" + m.body + "}", [""], max, maxLength, dropEmpties && !m.post.length);
				firstGroup = false;
				if (!m.post.length) break;
				str = m.post;
				continue;
			}
			const isNumericSequence = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(m.body);
			const isAlphaSequence = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(m.body);
			const isSequence = isNumericSequence || isAlphaSequence;
			const isOptions = m.body.indexOf(",") >= 0;
			if (!isSequence && !isOptions) {
				if (rewrites < maxRewrites && m.post.match(/,(?!,).*\}/)) {
					rewrites++;
					str = m.pre + "{" + m.body + escClose + m.post;
					isTop = true;
					continue;
				}
				return combine(acc, pre + "{" + m.body + "}" + m.post, [""], max, maxLength, dropEmpties);
			}
			if (firstGroup) {
				dropEmpties = isTop && !isSequence;
				firstGroup = false;
			}
			let values;
			if (isSequence) values = expandSequence(m.body, isAlphaSequence, max, maxLength);
			else {
				let n = parseCommaParts(m.body);
				if (n.length === 1 && n[0] !== void 0) {
					n = expand_(n[0], max, maxLength, maxDepth, depth + 1, maxRewrites, false).map(embrace);
					/* c8 ignore start */
					if (n.length === 1) {
						acc = combine(acc, pre + n[0], [""], max, maxLength, dropEmpties && !m.post.length);
						if (!m.post.length) break;
						str = m.post;
						continue;
					}
				}
				let dropsEmpties = dropEmpties && !m.post.length && !pre;
				for (let d = 0; dropsEmpties && d < acc.length; d++) if (acc[d]) dropsEmpties = false;
				values = [];
				let valuesLength = 0;
				outer: for (let j = 0; j < n.length; j++) {
					const expanded = expand_(n[j], max, maxLength, maxDepth, depth + 1, maxRewrites, false);
					for (let k = 0; k < expanded.length; k++) {
						const v = expanded[k];
						if (dropsEmpties && !v) continue;
						if (values.length >= max || valuesLength + v.length > maxLength) break outer;
						values.push(v);
						valuesLength += v.length;
					}
				}
			}
			acc = combine(acc, pre, values, max, maxLength, dropEmpties && !m.post.length);
			if (!m.post.length) break;
			str = m.post;
		}
		return acc;
	}
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/assert-valid-pattern.js
var require_assert_valid_pattern = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.assertValidPattern = void 0;
	const MAX_PATTERN_LENGTH = 65536;
	const assertValidPattern = (pattern) => {
		if (typeof pattern !== "string") throw new TypeError("invalid pattern");
		if (pattern.length > MAX_PATTERN_LENGTH) throw new TypeError("pattern is too long");
	};
	exports.assertValidPattern = assertValidPattern;
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/brace-expressions.js
var require_brace_expressions = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.parseClass = void 0;
	const posixClasses = {
		"[:alnum:]": ["\\p{L}\\p{Nl}\\p{Nd}", true],
		"[:alpha:]": ["\\p{L}\\p{Nl}", true],
		"[:ascii:]": ["\\x00-\\x7f", false],
		"[:blank:]": ["\\p{Zs}\\t", true],
		"[:cntrl:]": ["\\p{Cc}", true],
		"[:digit:]": ["\\p{Nd}", true],
		"[:graph:]": [
			"\\p{Z}\\p{C}",
			true,
			true
		],
		"[:lower:]": ["\\p{Ll}", true],
		"[:print:]": ["\\p{C}", true],
		"[:punct:]": ["\\p{P}", true],
		"[:space:]": ["\\p{Z}\\t\\r\\n\\v\\f", true],
		"[:upper:]": ["\\p{Lu}", true],
		"[:word:]": ["\\p{L}\\p{Nl}\\p{Nd}\\p{Pc}", true],
		"[:xdigit:]": ["A-Fa-f0-9", false]
	};
	const braceEscape = (s) => s.replace(/[[\]\\-]/g, "\\$&");
	const regexpEscape = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	const rangesToString = (ranges) => ranges.join("");
	const parseClass = (glob, position) => {
		const pos = position;
		/* c8 ignore start */
		if (glob.charAt(pos) !== "[") throw new Error("not in a brace expression");
		/* c8 ignore stop */
		const ranges = [];
		const negs = [];
		let i = pos + 1;
		let sawStart = false;
		let uflag = false;
		let escaping = false;
		let negate = false;
		let endPos = pos;
		let rangeStart = "";
		WHILE: while (i < glob.length) {
			const c = glob.charAt(i);
			if ((c === "!" || c === "^") && i === pos + 1) {
				negate = true;
				i++;
				continue;
			}
			if (c === "]" && sawStart && !escaping) {
				endPos = i + 1;
				break;
			}
			sawStart = true;
			if (c === "\\") {
				if (!escaping) {
					escaping = true;
					i++;
					continue;
				}
			}
			if (c === "[" && !escaping) {
				for (const [cls, [unip, u, neg]] of Object.entries(posixClasses)) if (glob.startsWith(cls, i)) {
					if (rangeStart) return [
						"$.",
						false,
						glob.length - pos,
						true
					];
					i += cls.length;
					if (neg) negs.push(unip);
					else ranges.push(unip);
					uflag = uflag || u;
					continue WHILE;
				}
			}
			escaping = false;
			if (rangeStart) {
				if (c > rangeStart) ranges.push(braceEscape(rangeStart) + "-" + braceEscape(c));
				else if (c === rangeStart) ranges.push(braceEscape(c));
				rangeStart = "";
				i++;
				continue;
			}
			if (glob.startsWith("-]", i + 1)) {
				ranges.push(braceEscape(c + "-"));
				i += 2;
				continue;
			}
			if (glob.startsWith("-", i + 1)) {
				rangeStart = c;
				i += 2;
				continue;
			}
			ranges.push(braceEscape(c));
			i++;
		}
		if (endPos < i) return [
			"",
			false,
			0,
			false
		];
		if (!ranges.length && !negs.length) return [
			"$.",
			false,
			glob.length - pos,
			true
		];
		if (negs.length === 0 && ranges.length === 1 && /^\\?.$/.test(ranges[0]) && !negate) {
			const r = ranges[0].length === 2 ? ranges[0].slice(-1) : ranges[0];
			return [
				regexpEscape(r),
				false,
				endPos - pos,
				false
			];
		}
		const sranges = "[" + (negate ? "^" : "") + rangesToString(ranges) + "]";
		const snegs = "[" + (negate ? "" : "^") + rangesToString(negs) + "]";
		return [
			ranges.length && negs.length ? "(" + sranges + "|" + snegs + ")" : ranges.length ? sranges : snegs,
			uflag,
			endPos - pos,
			true
		];
	};
	exports.parseClass = parseClass;
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/unescape.js
var require_unescape = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.unescape = void 0;
	/**
	* Un-escape a string that has been escaped with {@link escape}.
	*
	* If the {@link MinimatchOptions.windowsPathsNoEscape} option is used, then
	* square-bracket escapes are removed, but not backslash escapes.
	*
	* For example, it will turn the string `'[*]'` into `*`, but it will not
	* turn `'\\*'` into `'*'`, because `\` is a path separator in
	* `windowsPathsNoEscape` mode.
	*
	* When `windowsPathsNoEscape` is not set, then both square-bracket escapes and
	* backslash escapes are removed.
	*
	* Slashes (and backslashes in `windowsPathsNoEscape` mode) cannot be escaped
	* or unescaped.
	*
	* When `magicalBraces` is not set, escapes of braces (`{` and `}`) will not be
	* unescaped.
	*/
	const unescape = (s, { windowsPathsNoEscape = false, magicalBraces = true } = {}) => {
		if (magicalBraces) return windowsPathsNoEscape ? s.replace(/\[([^/\\])\]/g, "$1") : s.replace(/((?!\\).|^)\[([^/\\])\]/g, "$1$2").replace(/\\([^/])/g, "$1");
		return windowsPathsNoEscape ? s.replace(/\[([^/\\{}])\]/g, "$1") : s.replace(/((?!\\).|^)\[([^/\\{}])\]/g, "$1$2").replace(/\\([^/{}])/g, "$1");
	};
	exports.unescape = unescape;
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/ast.js
var require_ast = /* @__PURE__ */ __commonJSMin(((exports) => {
	var _a;
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AST = void 0;
	const brace_expressions_js_1 = require_brace_expressions();
	const unescape_js_1 = require_unescape();
	const types = /* @__PURE__ */ new Set([
		"!",
		"?",
		"+",
		"*",
		"@"
	]);
	const isExtglobType = (c) => types.has(c);
	const isExtglobAST = (c) => isExtglobType(c.type);
	const adoptionMap = /* @__PURE__ */ new Map([
		["!", ["@"]],
		["?", ["?", "@"]],
		["@", ["@"]],
		["*", [
			"*",
			"+",
			"?",
			"@"
		]],
		["+", ["+", "@"]]
	]);
	const adoptionWithSpaceMap = /* @__PURE__ */ new Map([
		["!", ["?"]],
		["@", ["?"]],
		["+", ["?", "*"]]
	]);
	const adoptionAnyMap = /* @__PURE__ */ new Map([
		["!", ["?", "@"]],
		["?", ["?", "@"]],
		["@", ["?", "@"]],
		["*", [
			"*",
			"+",
			"?",
			"@"
		]],
		["+", [
			"+",
			"@",
			"?",
			"*"
		]]
	]);
	const usurpMap = /* @__PURE__ */ new Map([
		["!", /* @__PURE__ */ new Map([["!", "@"]])],
		["?", /* @__PURE__ */ new Map([["*", "*"], ["+", "*"]])],
		["@", /* @__PURE__ */ new Map([
			["!", "!"],
			["?", "?"],
			["@", "@"],
			["*", "*"],
			["+", "+"]
		])],
		["+", /* @__PURE__ */ new Map([["?", "*"], ["*", "*"]])]
	]);
	const startNoTraversal = "(?!(?:^|/)\\.\\.?(?:$|/))";
	const startNoDot = "(?!\\.)";
	const addPatternStart = /* @__PURE__ */ new Set(["[", "."]);
	const justDots = /* @__PURE__ */ new Set(["..", "."]);
	const reSpecials = /* @__PURE__ */ new Set("().*{}+?[]^$\\!");
	const regExpEscape = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	const qmark = "[^/]";
	const star = "[^/]*?";
	const starNoEmpty = "[^/]+?";
	let ID = 0;
	var AST = class {
		type;
		#root;
		#hasMagic;
		#uflag = false;
		#parts = [];
		#parent;
		#parentIndex;
		#negs;
		#filledNegs = false;
		#options;
		#toString;
		#emptyExt = false;
		id = ++ID;
		get depth() {
			return (this.#parent?.depth ?? -1) + 1;
		}
		[Symbol.for("nodejs.util.inspect.custom")]() {
			return {
				"@@type": "AST",
				id: this.id,
				type: this.type,
				root: this.#root.id,
				parent: this.#parent?.id,
				depth: this.depth,
				partsLength: this.#parts.length,
				parts: this.#parts
			};
		}
		constructor(type, parent, options = {}) {
			this.type = type;
			if (type) this.#hasMagic = true;
			this.#parent = parent;
			this.#root = this.#parent ? this.#parent.#root : this;
			this.#options = this.#root === this ? options : this.#root.#options;
			this.#negs = this.#root === this ? [] : this.#root.#negs;
			if (type === "!" && !this.#root.#filledNegs) this.#negs.push(this);
			this.#parentIndex = this.#parent ? this.#parent.#parts.length : 0;
		}
		get hasMagic() {
			/* c8 ignore start */
			if (this.#hasMagic !== void 0) return this.#hasMagic;
			/* c8 ignore stop */
			for (const p of this.#parts) {
				if (typeof p === "string") continue;
				if (p.type || p.hasMagic) return this.#hasMagic = true;
			}
			return this.#hasMagic;
		}
		toString() {
			return this.#toString !== void 0 ? this.#toString : !this.type ? this.#toString = this.#parts.map((p) => String(p)).join("") : this.#toString = this.type + "(" + this.#parts.map((p) => String(p)).join("|") + ")";
		}
		#fillNegs() {
			/* c8 ignore start */
			if (this !== this.#root) throw new Error("should only call on root");
			if (this.#filledNegs) return this;
			/* c8 ignore stop */
			this.toString();
			this.#filledNegs = true;
			let n;
			while (n = this.#negs.pop()) {
				if (n.type !== "!") continue;
				let p = n;
				let pp = p.#parent;
				while (pp) {
					for (let i = p.#parentIndex + 1; !pp.type && i < pp.#parts.length; i++) for (const part of n.#parts) {
						/* c8 ignore start */
						if (typeof part === "string") throw new Error("string part in extglob AST??");
						/* c8 ignore stop */
						part.copyIn(pp.#parts[i]);
					}
					p = pp;
					pp = p.#parent;
				}
			}
			return this;
		}
		push(...parts) {
			for (const p of parts) {
				if (p === "") continue;
				/* c8 ignore start */
				if (typeof p !== "string" && !(p instanceof _a && p.#parent === this)) throw new Error("invalid part: " + p);
				/* c8 ignore stop */
				this.#parts.push(p);
			}
		}
		toJSON() {
			const ret = this.type === null ? this.#parts.slice().map((p) => typeof p === "string" ? p : p.toJSON()) : [this.type, ...this.#parts.map((p) => p.toJSON())];
			if (this.isStart() && !this.type) ret.unshift([]);
			if (this.isEnd() && (this === this.#root || this.#root.#filledNegs && this.#parent?.type === "!")) ret.push({});
			return ret;
		}
		isStart() {
			if (this.#root === this) return true;
			if (!this.#parent?.isStart()) return false;
			if (this.#parentIndex === 0) return true;
			const p = this.#parent;
			for (let i = 0; i < this.#parentIndex; i++) {
				const pp = p.#parts[i];
				if (!(pp instanceof _a && pp.type === "!")) return false;
			}
			return true;
		}
		isEnd() {
			if (this.#root === this) return true;
			if (this.#parent?.type === "!") return true;
			if (!this.#parent?.isEnd()) return false;
			if (!this.type) return this.#parent?.isEnd();
			/* c8 ignore start */
			const pl = this.#parent ? this.#parent.#parts.length : 0;
			/* c8 ignore stop */
			return this.#parentIndex === pl - 1;
		}
		copyIn(part) {
			if (typeof part === "string") this.push(part);
			else this.push(part.clone(this));
		}
		clone(parent) {
			const c = new _a(this.type, parent);
			for (const p of this.#parts) c.copyIn(p);
			return c;
		}
		static #parseAST(str, ast, pos, opt, extDepth) {
			const maxDepth = opt.maxExtglobRecursion ?? 2;
			let escaping = false;
			let inBrace = false;
			let braceStart = -1;
			let braceNeg = false;
			if (ast.type === null) {
				let i = pos;
				let acc = "";
				while (i < str.length) {
					const c = str.charAt(i++);
					if (escaping || c === "\\") {
						escaping = !escaping;
						acc += c;
						continue;
					}
					if (inBrace) {
						if (i === braceStart + 1) {
							if (c === "^" || c === "!") braceNeg = true;
						} else if (c === "]" && !(i === braceStart + 2 && braceNeg)) inBrace = false;
						acc += c;
						continue;
					} else if (c === "[") {
						inBrace = true;
						braceStart = i;
						braceNeg = false;
						acc += c;
						continue;
					}
					if (!opt.noext && isExtglobType(c) && str.charAt(i) === "(" && extDepth <= maxDepth) {
						ast.push(acc);
						acc = "";
						const ext = new _a(c, ast);
						i = _a.#parseAST(str, ext, i, opt, extDepth + 1);
						ast.push(ext);
						continue;
					}
					acc += c;
				}
				ast.push(acc);
				return i;
			}
			let i = pos + 1;
			let part = new _a(null, ast);
			const parts = [];
			let acc = "";
			while (i < str.length) {
				const c = str.charAt(i++);
				if (escaping || c === "\\") {
					escaping = !escaping;
					acc += c;
					continue;
				}
				if (inBrace) {
					if (i === braceStart + 1) {
						if (c === "^" || c === "!") braceNeg = true;
					} else if (c === "]" && !(i === braceStart + 2 && braceNeg)) inBrace = false;
					acc += c;
					continue;
				} else if (c === "[") {
					inBrace = true;
					braceStart = i;
					braceNeg = false;
					acc += c;
					continue;
				}
				/* c8 ignore stop */
				if (!opt.noext && isExtglobType(c) && str.charAt(i) === "(" && (extDepth <= maxDepth || ast && ast.#canAdoptType(c))) {
					const depthAdd = ast && ast.#canAdoptType(c) ? 0 : 1;
					part.push(acc);
					acc = "";
					const ext = new _a(c, part);
					part.push(ext);
					i = _a.#parseAST(str, ext, i, opt, extDepth + depthAdd);
					continue;
				}
				if (c === "|") {
					part.push(acc);
					acc = "";
					parts.push(part);
					part = new _a(null, ast);
					continue;
				}
				if (c === ")") {
					if (acc === "" && ast.#parts.length === 0) ast.#emptyExt = true;
					part.push(acc);
					acc = "";
					ast.push(...parts, part);
					return i;
				}
				acc += c;
			}
			ast.type = null;
			ast.#hasMagic = void 0;
			ast.#parts = [str.substring(pos - 1)];
			return i;
		}
		#canAdoptWithSpace(child) {
			return this.#canAdopt(child, adoptionWithSpaceMap);
		}
		#canAdopt(child, map = adoptionMap) {
			if (!child || typeof child !== "object" || child.type !== null || child.#parts.length !== 1 || this.type === null) return false;
			const gc = child.#parts[0];
			if (!gc || typeof gc !== "object" || gc.type === null) return false;
			return this.#canAdoptType(gc.type, map);
		}
		#canAdoptType(c, map = adoptionAnyMap) {
			return !!map.get(this.type)?.includes(c);
		}
		#adoptWithSpace(child, index) {
			const gc = child.#parts[0];
			const blank = new _a(null, gc, this.options);
			blank.#parts.push("");
			gc.push(blank);
			this.#adopt(child, index);
		}
		#adopt(child, index) {
			const gc = child.#parts[0];
			this.#parts.splice(index, 1, ...gc.#parts);
			for (const p of gc.#parts) if (typeof p === "object") p.#parent = this;
			this.#toString = void 0;
		}
		#canUsurpType(c) {
			return !!usurpMap.get(this.type)?.has(c);
		}
		#canUsurp(child) {
			if (!child || typeof child !== "object" || child.type !== null || child.#parts.length !== 1 || this.type === null || this.#parts.length !== 1) return false;
			const gc = child.#parts[0];
			if (!gc || typeof gc !== "object" || gc.type === null) return false;
			return this.#canUsurpType(gc.type);
		}
		#usurp(child) {
			const m = usurpMap.get(this.type);
			const gc = child.#parts[0];
			const nt = m?.get(gc.type);
			/* c8 ignore start - impossible */
			if (!nt) return false;
			/* c8 ignore stop */
			this.#parts = gc.#parts;
			for (const p of this.#parts) if (typeof p === "object") p.#parent = this;
			this.type = nt;
			this.#toString = void 0;
			this.#emptyExt = false;
		}
		static fromGlob(pattern, options = {}) {
			const ast = new _a(null, void 0, options);
			_a.#parseAST(pattern, ast, 0, options, 0);
			return ast;
		}
		toMMPattern() {
			/* c8 ignore start */
			if (this !== this.#root) return this.#root.toMMPattern();
			/* c8 ignore stop */
			const glob = this.toString();
			const [re, body, hasMagic, uflag] = this.toRegExpSource();
			if (!(hasMagic || this.#hasMagic || this.#options.nocase && !this.#options.nocaseMagicOnly && glob.toUpperCase() !== glob.toLowerCase())) return body;
			const flags = (this.#options.nocase ? "i" : "") + (uflag ? "u" : "");
			return Object.assign(new RegExp(`^${re}$`, flags), {
				_src: re,
				_glob: glob
			});
		}
		get options() {
			return this.#options;
		}
		toRegExpSource(allowDot) {
			const dot = allowDot ?? !!this.#options.dot;
			if (this.#root === this) {
				this.#flatten();
				this.#fillNegs();
			}
			if (!isExtglobAST(this)) {
				const noEmpty = this.isStart() && this.isEnd() && !this.#parts.some((s) => typeof s !== "string");
				const src = this.#parts.map((p) => {
					const [re, _, hasMagic, uflag] = typeof p === "string" ? _a.#parseGlob(p, this.#hasMagic, noEmpty) : p.toRegExpSource(allowDot);
					this.#hasMagic = this.#hasMagic || hasMagic;
					this.#uflag = this.#uflag || uflag;
					return re;
				}).join("");
				let start = "";
				if (this.isStart()) {
					if (typeof this.#parts[0] === "string") {
						if (!(this.#parts.length === 1 && justDots.has(this.#parts[0]))) {
							const aps = addPatternStart;
							const needNoTrav = dot && aps.has(src.charAt(0)) || src.startsWith("\\.") && aps.has(src.charAt(2)) || src.startsWith("\\.\\.") && aps.has(src.charAt(4));
							const needNoDot = !dot && !allowDot && aps.has(src.charAt(0));
							start = needNoTrav ? startNoTraversal : needNoDot ? startNoDot : "";
						}
					}
				}
				let end = "";
				if (this.isEnd() && this.#root.#filledNegs && this.#parent?.type === "!") end = "(?:$|\\/)";
				return [
					start + src + end,
					(0, unescape_js_1.unescape)(src),
					this.#hasMagic = !!this.#hasMagic,
					this.#uflag
				];
			}
			const repeated = this.type === "*" || this.type === "+";
			const start = this.type === "!" ? "(?:(?!(?:" : "(?:";
			let body = this.#partsToRegExp(dot);
			if (this.isStart() && this.isEnd() && !body && this.type !== "!") {
				const s = this.toString();
				const me = this;
				me.#parts = [s];
				me.type = null;
				me.#hasMagic = void 0;
				return [
					s,
					(0, unescape_js_1.unescape)(this.toString()),
					false,
					false
				];
			}
			let bodyDotAllowed = !repeated || allowDot || dot || false ? "" : this.#partsToRegExp(true);
			if (bodyDotAllowed === body) bodyDotAllowed = "";
			if (bodyDotAllowed) body = `(?:${body})(?:${bodyDotAllowed})*?`;
			let final = "";
			if (this.type === "!" && this.#emptyExt) final = (this.isStart() && !dot ? startNoDot : "") + starNoEmpty;
			else {
				const close = this.type === "!" ? "))" + (this.isStart() && !dot && !allowDot ? startNoDot : "") + "[^/]*?)" : this.type === "@" ? ")" : this.type === "?" ? ")?" : this.type === "+" && bodyDotAllowed ? ")" : this.type === "*" && bodyDotAllowed ? `)?` : `)${this.type}`;
				final = start + body + close;
			}
			return [
				final,
				(0, unescape_js_1.unescape)(body),
				this.#hasMagic = !!this.#hasMagic,
				this.#uflag
			];
		}
		#flatten() {
			if (!isExtglobAST(this)) {
				for (const p of this.#parts) if (typeof p === "object") p.#flatten();
			} else {
				let iterations = 0;
				let done = false;
				do {
					done = true;
					for (let i = 0; i < this.#parts.length; i++) {
						const c = this.#parts[i];
						if (typeof c === "object") {
							c.#flatten();
							if (this.#canAdopt(c)) {
								done = false;
								this.#adopt(c, i);
							} else if (this.#canAdoptWithSpace(c)) {
								done = false;
								this.#adoptWithSpace(c, i);
							} else if (this.#canUsurp(c)) {
								done = false;
								this.#usurp(c);
							}
						}
					}
				} while (!done && ++iterations < 10);
			}
			this.#toString = void 0;
		}
		#partsToRegExp(dot) {
			return this.#parts.map((p) => {
				/* c8 ignore start */
				if (typeof p === "string") throw new Error("string type in extglob ast??");
				/* c8 ignore stop */
				const [re, _, _hasMagic, uflag] = p.toRegExpSource(dot);
				this.#uflag = this.#uflag || uflag;
				return re;
			}).filter((p) => !(this.isStart() && this.isEnd()) || !!p).join("|");
		}
		static #parseGlob(glob, hasMagic, noEmpty = false) {
			let escaping = false;
			let re = "";
			let uflag = false;
			let inStar = false;
			for (let i = 0; i < glob.length; i++) {
				const c = glob.charAt(i);
				if (escaping) {
					escaping = false;
					re += (reSpecials.has(c) ? "\\" : "") + c;
					continue;
				}
				if (c === "*") {
					if (inStar) continue;
					inStar = true;
					re += noEmpty && /^[*]+$/.test(glob) ? starNoEmpty : star;
					hasMagic = true;
					continue;
				} else inStar = false;
				if (c === "\\") {
					if (i === glob.length - 1) re += "\\\\";
					else escaping = true;
					continue;
				}
				if (c === "[") {
					const [src, needUflag, consumed, magic] = (0, brace_expressions_js_1.parseClass)(glob, i);
					if (consumed) {
						re += src;
						uflag = uflag || needUflag;
						i += consumed - 1;
						hasMagic = hasMagic || magic;
						continue;
					}
				}
				if (c === "?") {
					re += qmark;
					hasMagic = true;
					continue;
				}
				re += regExpEscape(c);
			}
			return [
				re,
				(0, unescape_js_1.unescape)(glob),
				!!hasMagic,
				uflag
			];
		}
	};
	exports.AST = AST;
	_a = AST;
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/escape.js
var require_escape = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.escape = void 0;
	/**
	* Escape all magic characters in a glob pattern.
	*
	* If the {@link MinimatchOptions.windowsPathsNoEscape}
	* option is used, then characters are escaped by wrapping in `[]`, because
	* a magic character wrapped in a character class can only be satisfied by
	* that exact character.  In this mode, `\` is _not_ escaped, because it is
	* not interpreted as a magic character, but instead as a path separator.
	*
	* If the {@link MinimatchOptions.magicalBraces} option is used,
	* then braces (`{` and `}`) will be escaped.
	*/
	const escape = (s, { windowsPathsNoEscape = false, magicalBraces = false } = {}) => {
		if (magicalBraces) return windowsPathsNoEscape ? s.replace(/[?*()[\]{}]/g, "[$&]") : s.replace(/[?*()[\]\\{}]/g, "\\$&");
		return windowsPathsNoEscape ? s.replace(/[?*()[\]]/g, "[$&]") : s.replace(/[?*()[\]\\]/g, "\\$&");
	};
	exports.escape = escape;
}));
//#endregion
//#region node_modules/minimatch/dist/commonjs/index.js
var require_commonjs = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.unescape = exports.escape = exports.AST = exports.Minimatch = exports.match = exports.makeRe = exports.braceExpand = exports.defaults = exports.filter = exports.GLOBSTAR = exports.sep = exports.minimatch = void 0;
	const brace_expansion_1 = require_commonjs$1();
	const assert_valid_pattern_js_1 = require_assert_valid_pattern();
	const ast_js_1 = require_ast();
	const escape_js_1 = require_escape();
	const unescape_js_1 = require_unescape();
	const minimatch = (p, pattern, options = {}) => {
		(0, assert_valid_pattern_js_1.assertValidPattern)(pattern);
		if (!options.nocomment && pattern.charAt(0) === "#") return false;
		return new Minimatch(pattern, options).match(p);
	};
	exports.minimatch = minimatch;
	const starDotExtRE = /^\*+([^+@!?*[(]*)$/;
	const starDotExtTest = (ext) => (f) => !f.startsWith(".") && f.endsWith(ext);
	const starDotExtTestDot = (ext) => (f) => f.endsWith(ext);
	const starDotExtTestNocase = (ext) => {
		ext = ext.toLowerCase();
		return (f) => !f.startsWith(".") && f.toLowerCase().endsWith(ext);
	};
	const starDotExtTestNocaseDot = (ext) => {
		ext = ext.toLowerCase();
		return (f) => f.toLowerCase().endsWith(ext);
	};
	const starDotStarRE = /^\*+\.\*+$/;
	const starDotStarTest = (f) => !f.startsWith(".") && f.includes(".");
	const starDotStarTestDot = (f) => f !== "." && f !== ".." && f.includes(".");
	const dotStarRE = /^\.\*+$/;
	const dotStarTest = (f) => f !== "." && f !== ".." && f.startsWith(".");
	const starRE = /^\*+$/;
	const starTest = (f) => f.length !== 0 && !f.startsWith(".");
	const starTestDot = (f) => f.length !== 0 && f !== "." && f !== "..";
	const qmarksRE = /^\?+([^+@!?*[(]*)?$/;
	const qmarksTestNocase = ([$0, ext = ""]) => {
		const noext = qmarksTestNoExt([$0]);
		if (!ext) return noext;
		ext = ext.toLowerCase();
		return (f) => noext(f) && f.toLowerCase().endsWith(ext);
	};
	const qmarksTestNocaseDot = ([$0, ext = ""]) => {
		const noext = qmarksTestNoExtDot([$0]);
		if (!ext) return noext;
		ext = ext.toLowerCase();
		return (f) => noext(f) && f.toLowerCase().endsWith(ext);
	};
	const qmarksTestDot = ([$0, ext = ""]) => {
		const noext = qmarksTestNoExtDot([$0]);
		return !ext ? noext : (f) => noext(f) && f.endsWith(ext);
	};
	const qmarksTest = ([$0, ext = ""]) => {
		const noext = qmarksTestNoExt([$0]);
		return !ext ? noext : (f) => noext(f) && f.endsWith(ext);
	};
	const qmarksTestNoExt = ([$0]) => {
		const len = $0.length;
		return (f) => f.length === len && !f.startsWith(".");
	};
	const qmarksTestNoExtDot = ([$0]) => {
		const len = $0.length;
		return (f) => f.length === len && f !== "." && f !== "..";
	};
	/* c8 ignore start */
	const defaultPlatform = typeof process === "object" && process ? typeof process.env === "object" && process.env && process.env.__MINIMATCH_TESTING_PLATFORM__ || process.platform : "posix";
	const path = {
		win32: { sep: "\\" },
		posix: { sep: "/" }
	};
	/* c8 ignore stop */
	exports.sep = defaultPlatform === "win32" ? path.win32.sep : path.posix.sep;
	exports.minimatch.sep = exports.sep;
	exports.GLOBSTAR = Symbol("globstar **");
	exports.minimatch.GLOBSTAR = exports.GLOBSTAR;
	const star = "[^/]*?";
	const twoStarDot = "(?:(?!(?:\\/|^)(?:\\.{1,2})($|\\/)).)*?";
	const twoStarNoDot = "(?:(?!(?:\\/|^)\\.).)*?";
	const filter = (pattern, options = {}) => (p) => (0, exports.minimatch)(p, pattern, options);
	exports.filter = filter;
	exports.minimatch.filter = exports.filter;
	const ext = (a, b = {}) => Object.assign({}, a, b);
	const defaults = (def) => {
		if (!def || typeof def !== "object" || !Object.keys(def).length) return exports.minimatch;
		const orig = exports.minimatch;
		const m = (p, pattern, options = {}) => orig(p, pattern, ext(def, options));
		return Object.assign(m, {
			Minimatch: class Minimatch extends orig.Minimatch {
				constructor(pattern, options = {}) {
					super(pattern, ext(def, options));
				}
				static defaults(options) {
					return orig.defaults(ext(def, options)).Minimatch;
				}
			},
			AST: class AST extends orig.AST {
				/* c8 ignore start */
				constructor(type, parent, options = {}) {
					super(type, parent, ext(def, options));
				}
				/* c8 ignore stop */
				static fromGlob(pattern, options = {}) {
					return orig.AST.fromGlob(pattern, ext(def, options));
				}
			},
			unescape: (s, options = {}) => orig.unescape(s, ext(def, options)),
			escape: (s, options = {}) => orig.escape(s, ext(def, options)),
			filter: (pattern, options = {}) => orig.filter(pattern, ext(def, options)),
			defaults: (options) => orig.defaults(ext(def, options)),
			makeRe: (pattern, options = {}) => orig.makeRe(pattern, ext(def, options)),
			braceExpand: (pattern, options = {}) => orig.braceExpand(pattern, ext(def, options)),
			match: (list, pattern, options = {}) => orig.match(list, pattern, ext(def, options)),
			sep: orig.sep,
			GLOBSTAR: exports.GLOBSTAR
		});
	};
	exports.defaults = defaults;
	exports.minimatch.defaults = exports.defaults;
	const braceExpand = (pattern, options = {}) => {
		(0, assert_valid_pattern_js_1.assertValidPattern)(pattern);
		if (options.nobrace || !/\{(?:(?!\{).)*\}/.test(pattern)) return [pattern];
		return (0, brace_expansion_1.expand)(pattern, { max: options.braceExpandMax });
	};
	exports.braceExpand = braceExpand;
	exports.minimatch.braceExpand = exports.braceExpand;
	const makeRe = (pattern, options = {}) => new Minimatch(pattern, options).makeRe();
	exports.makeRe = makeRe;
	exports.minimatch.makeRe = exports.makeRe;
	const match = (list, pattern, options = {}) => {
		const mm = new Minimatch(pattern, options);
		list = list.filter((f) => mm.match(f));
		if (mm.options.nonull && !list.length) list.push(pattern);
		return list;
	};
	exports.match = match;
	exports.minimatch.match = exports.match;
	const globMagic = /[?*]|[+@!]\(.*?\)|\[|\]/;
	const regExpEscape = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	var Minimatch = class {
		options;
		set;
		pattern;
		windowsPathsNoEscape;
		nonegate;
		negate;
		comment;
		empty;
		preserveMultipleSlashes;
		partial;
		globSet;
		globParts;
		nocase;
		isWindows;
		platform;
		windowsNoMagicRoot;
		maxGlobstarRecursion;
		regexp;
		constructor(pattern, options = {}) {
			(0, assert_valid_pattern_js_1.assertValidPattern)(pattern);
			options = options || {};
			this.options = options;
			this.maxGlobstarRecursion = options.maxGlobstarRecursion ?? 200;
			this.pattern = pattern;
			this.platform = options.platform || defaultPlatform;
			this.isWindows = this.platform === "win32";
			const awe = "allowWindowsEscape";
			this.windowsPathsNoEscape = !!options.windowsPathsNoEscape || options[awe] === false;
			if (this.windowsPathsNoEscape) this.pattern = this.pattern.replace(/\\/g, "/");
			this.preserveMultipleSlashes = !!options.preserveMultipleSlashes;
			this.regexp = null;
			this.negate = false;
			this.nonegate = !!options.nonegate;
			this.comment = false;
			this.empty = false;
			this.partial = !!options.partial;
			this.nocase = !!this.options.nocase;
			this.windowsNoMagicRoot = options.windowsNoMagicRoot !== void 0 ? options.windowsNoMagicRoot : !!(this.isWindows && this.nocase);
			this.globSet = [];
			this.globParts = [];
			this.set = [];
			this.make();
		}
		hasMagic() {
			if (this.options.magicalBraces && this.set.length > 1) return true;
			for (const pattern of this.set) for (const part of pattern) if (typeof part !== "string") return true;
			return false;
		}
		debug(..._) {}
		make() {
			const pattern = this.pattern;
			const options = this.options;
			if (!options.nocomment && pattern.charAt(0) === "#") {
				this.comment = true;
				return;
			}
			if (!pattern) {
				this.empty = true;
				return;
			}
			this.parseNegate();
			this.globSet = [...new Set(this.braceExpand())];
			if (options.debug) this.debug = (...args) => console.error(...args);
			this.debug(this.pattern, this.globSet);
			const rawGlobParts = this.globSet.map((s) => this.slashSplit(s));
			this.globParts = this.preprocess(rawGlobParts);
			this.debug(this.pattern, this.globParts);
			let set = this.globParts.map((s, _, __) => {
				if (this.isWindows && this.windowsNoMagicRoot) {
					const isUNC = s[0] === "" && s[1] === "" && (s[2] === "?" || !globMagic.test(s[2])) && !globMagic.test(s[3]);
					const isDrive = /^[a-z]:/i.test(s[0]);
					if (isUNC) return [...s.slice(0, 4), ...s.slice(4).map((ss) => this.parse(ss))];
					else if (isDrive) return [s[0], ...s.slice(1).map((ss) => this.parse(ss))];
				}
				return s.map((ss) => this.parse(ss));
			});
			this.debug(this.pattern, set);
			this.set = set.filter((s) => s.indexOf(false) === -1);
			if (this.isWindows) for (let i = 0; i < this.set.length; i++) {
				const p = this.set[i];
				if (p[0] === "" && p[1] === "" && this.globParts[i][2] === "?" && typeof p[3] === "string" && /^[a-z]:$/i.test(p[3])) p[2] = "?";
			}
			this.debug(this.pattern, this.set);
		}
		preprocess(globParts) {
			if (this.options.noglobstar) {
				for (const partset of globParts) for (let j = 0; j < partset.length; j++) if (partset[j] === "**") partset[j] = "*";
			}
			const { optimizationLevel = 1 } = this.options;
			if (optimizationLevel >= 2) {
				globParts = this.firstPhasePreProcess(globParts);
				globParts = this.secondPhasePreProcess(globParts);
			} else if (optimizationLevel >= 1) globParts = this.levelOneOptimize(globParts);
			else globParts = this.adjascentGlobstarOptimize(globParts);
			return globParts;
		}
		adjascentGlobstarOptimize(globParts) {
			return globParts.map((parts) => {
				let gs = -1;
				while (-1 !== (gs = parts.indexOf("**", gs + 1))) {
					let i = gs;
					while (parts[i + 1] === "**") i++;
					if (i !== gs) parts.splice(gs, i - gs);
				}
				return parts;
			});
		}
		levelOneOptimize(globParts) {
			return globParts.map((parts) => {
				parts = parts.reduce((set, part) => {
					const prev = set[set.length - 1];
					if (part === "**" && prev === "**") return set;
					if (part === "..") {
						if (prev && prev !== ".." && prev !== "." && prev !== "**") {
							set.pop();
							return set;
						}
					}
					set.push(part);
					return set;
				}, []);
				return parts.length === 0 ? [""] : parts;
			});
		}
		levelTwoFileOptimize(parts) {
			if (!Array.isArray(parts)) parts = this.slashSplit(parts);
			let didSomething = false;
			do {
				didSomething = false;
				if (!this.preserveMultipleSlashes) {
					for (let i = 1; i < parts.length - 1; i++) {
						const p = parts[i];
						if (i === 1 && p === "" && parts[0] === "") continue;
						if (p === "." || p === "") {
							didSomething = true;
							parts.splice(i, 1);
							i--;
						}
					}
					if (parts[0] === "." && parts.length === 2 && (parts[1] === "." || parts[1] === "")) {
						didSomething = true;
						parts.pop();
					}
				}
				let dd = 0;
				while (-1 !== (dd = parts.indexOf("..", dd + 1))) {
					const p = parts[dd - 1];
					if (p && p !== "." && p !== ".." && p !== "**" && !(this.isWindows && /^[a-z]:$/i.test(p))) {
						didSomething = true;
						parts.splice(dd - 1, 2);
						dd -= 2;
					}
				}
			} while (didSomething);
			return parts.length === 0 ? [""] : parts;
		}
		firstPhasePreProcess(globParts) {
			let didSomething = false;
			do {
				didSomething = false;
				for (let parts of globParts) {
					let gs = -1;
					while (-1 !== (gs = parts.indexOf("**", gs + 1))) {
						let gss = gs;
						while (parts[gss + 1] === "**") gss++;
						if (gss > gs) parts.splice(gs + 1, gss - gs);
						let next = parts[gs + 1];
						const p = parts[gs + 2];
						const p2 = parts[gs + 3];
						if (next !== "..") continue;
						if (!p || p === "." || p === ".." || !p2 || p2 === "." || p2 === "..") continue;
						didSomething = true;
						parts.splice(gs, 1);
						const other = parts.slice(0);
						other[gs] = "**";
						globParts.push(other);
						gs--;
					}
					if (!this.preserveMultipleSlashes) {
						for (let i = 1; i < parts.length - 1; i++) {
							const p = parts[i];
							if (i === 1 && p === "" && parts[0] === "") continue;
							if (p === "." || p === "") {
								didSomething = true;
								parts.splice(i, 1);
								i--;
							}
						}
						if (parts[0] === "." && parts.length === 2 && (parts[1] === "." || parts[1] === "")) {
							didSomething = true;
							parts.pop();
						}
					}
					let dd = 0;
					while (-1 !== (dd = parts.indexOf("..", dd + 1))) {
						const p = parts[dd - 1];
						if (p && p !== "." && p !== ".." && p !== "**") {
							didSomething = true;
							const splin = dd === 1 && parts[dd + 1] === "**" ? ["."] : [];
							parts.splice(dd - 1, 2, ...splin);
							if (parts.length === 0) parts.push("");
							dd -= 2;
						}
					}
				}
			} while (didSomething);
			return globParts;
		}
		secondPhasePreProcess(globParts) {
			for (let i = 0; i < globParts.length - 1; i++) for (let j = i + 1; j < globParts.length; j++) {
				const matched = this.partsMatch(globParts[i], globParts[j], !this.preserveMultipleSlashes);
				if (matched) {
					globParts[i] = [];
					globParts[j] = matched;
					break;
				}
			}
			return globParts.filter((gs) => gs.length);
		}
		partsMatch(a, b, emptyGSMatch = false) {
			let ai = 0;
			let bi = 0;
			let result = [];
			let which = "";
			while (ai < a.length && bi < b.length) if (a[ai] === b[bi]) {
				result.push(which === "b" ? b[bi] : a[ai]);
				ai++;
				bi++;
			} else if (emptyGSMatch && a[ai] === "**" && b[bi] === a[ai + 1]) {
				result.push(a[ai]);
				ai++;
			} else if (emptyGSMatch && b[bi] === "**" && a[ai] === b[bi + 1]) {
				result.push(b[bi]);
				bi++;
			} else if (a[ai] === "*" && b[bi] && (this.options.dot || !b[bi].startsWith(".")) && b[bi] !== "**") {
				if (which === "b") return false;
				which = "a";
				result.push(a[ai]);
				ai++;
				bi++;
			} else if (b[bi] === "*" && a[ai] && (this.options.dot || !a[ai].startsWith(".")) && a[ai] !== "**") {
				if (which === "a") return false;
				which = "b";
				result.push(b[bi]);
				ai++;
				bi++;
			} else return false;
			return a.length === b.length && result;
		}
		parseNegate() {
			if (this.nonegate) return;
			const pattern = this.pattern;
			let negate = false;
			let negateOffset = 0;
			for (let i = 0; i < pattern.length && pattern.charAt(i) === "!"; i++) {
				negate = !negate;
				negateOffset++;
			}
			if (negateOffset) this.pattern = pattern.slice(negateOffset);
			this.negate = negate;
		}
		matchOne(file, pattern, partial = false) {
			let fileStartIndex = 0;
			let patternStartIndex = 0;
			if (this.isWindows) {
				const fileDrive = typeof file[0] === "string" && /^[a-z]:$/i.test(file[0]);
				const fileUNC = !fileDrive && file[0] === "" && file[1] === "" && file[2] === "?" && /^[a-z]:$/i.test(file[3]);
				const patternDrive = typeof pattern[0] === "string" && /^[a-z]:$/i.test(pattern[0]);
				const patternUNC = !patternDrive && pattern[0] === "" && pattern[1] === "" && pattern[2] === "?" && typeof pattern[3] === "string" && /^[a-z]:$/i.test(pattern[3]);
				const fdi = fileUNC ? 3 : fileDrive ? 0 : void 0;
				const pdi = patternUNC ? 3 : patternDrive ? 0 : void 0;
				if (typeof fdi === "number" && typeof pdi === "number") {
					const [fd, pd] = [file[fdi], pattern[pdi]];
					if (fd.toLowerCase() === pd.toLowerCase()) {
						pattern[pdi] = fd;
						patternStartIndex = pdi;
						fileStartIndex = fdi;
					}
				}
			}
			const { optimizationLevel = 1 } = this.options;
			if (optimizationLevel >= 2) file = this.levelTwoFileOptimize(file);
			if (pattern.includes(exports.GLOBSTAR)) return this.#matchGlobstar(file, pattern, partial, fileStartIndex, patternStartIndex);
			return this.#matchOne(file, pattern, partial, fileStartIndex, patternStartIndex);
		}
		#matchGlobstar(file, pattern, partial, fileIndex, patternIndex) {
			const firstgs = pattern.indexOf(exports.GLOBSTAR, patternIndex);
			const lastgs = pattern.lastIndexOf(exports.GLOBSTAR);
			const [head, body, tail] = partial ? [
				pattern.slice(patternIndex, firstgs),
				pattern.slice(firstgs + 1),
				[]
			] : [
				pattern.slice(patternIndex, firstgs),
				pattern.slice(firstgs + 1, lastgs),
				pattern.slice(lastgs + 1)
			];
			if (head.length) {
				const fileHead = file.slice(fileIndex, fileIndex + head.length);
				if (!this.#matchOne(fileHead, head, partial, 0, 0)) return false;
				fileIndex += head.length;
				patternIndex += head.length;
			}
			let fileTailMatch = 0;
			if (tail.length) {
				if (tail.length + fileIndex > file.length) return false;
				let tailStart = file.length - tail.length;
				if (this.#matchOne(file, tail, partial, tailStart, 0)) fileTailMatch = tail.length;
				else {
					if (file[file.length - 1] !== "" || fileIndex + tail.length === file.length) return false;
					tailStart--;
					if (!this.#matchOne(file, tail, partial, tailStart, 0)) return false;
					fileTailMatch = tail.length + 1;
				}
			}
			if (!body.length) {
				let sawSome = !!fileTailMatch;
				for (let i = fileIndex; i < file.length - fileTailMatch; i++) {
					const f = String(file[i]);
					sawSome = true;
					if (f === "." || f === ".." || !this.options.dot && f.startsWith(".")) return false;
				}
				return partial || sawSome;
			}
			const bodySegments = [[[], 0]];
			let currentBody = bodySegments[0];
			let nonGsParts = 0;
			const nonGsPartsSums = [0];
			for (const b of body) if (b === exports.GLOBSTAR) {
				nonGsPartsSums.push(nonGsParts);
				currentBody = [[], 0];
				bodySegments.push(currentBody);
			} else {
				currentBody[0].push(b);
				nonGsParts++;
			}
			let i = bodySegments.length - 1;
			const fileLength = file.length - fileTailMatch;
			for (const b of bodySegments) b[1] = fileLength - (nonGsPartsSums[i--] + b[0].length);
			return !!this.#matchGlobStarBodySections(file, bodySegments, fileIndex, 0, partial, 0, !!fileTailMatch);
		}
		#matchGlobStarBodySections(file, bodySegments, fileIndex, bodyIndex, partial, globStarDepth, sawTail) {
			const bs = bodySegments[bodyIndex];
			if (!bs) {
				for (let i = fileIndex; i < file.length; i++) {
					sawTail = true;
					const f = file[i];
					if (f === "." || f === ".." || !this.options.dot && f.startsWith(".")) return false;
				}
				return sawTail;
			}
			const [body, after] = bs;
			while (fileIndex <= after) {
				if (this.#matchOne(file.slice(0, fileIndex + body.length), body, partial, fileIndex, 0) && globStarDepth < this.maxGlobstarRecursion) {
					const sub = this.#matchGlobStarBodySections(file, bodySegments, fileIndex + body.length, bodyIndex + 1, partial, globStarDepth + 1, sawTail);
					if (sub !== false) return sub;
				}
				const f = file[fileIndex];
				if (f === "." || f === ".." || !this.options.dot && f.startsWith(".")) return false;
				fileIndex++;
			}
			return partial || null;
		}
		#matchOne(file, pattern, partial, fileIndex, patternIndex) {
			let fi;
			let pi;
			let pl;
			let fl;
			for (fi = fileIndex, pi = patternIndex, fl = file.length, pl = pattern.length; fi < fl && pi < pl; fi++, pi++) {
				this.debug("matchOne loop");
				let p = pattern[pi];
				let f = file[fi];
				this.debug(pattern, p, f);
				/* c8 ignore start */
				if (p === false || p === exports.GLOBSTAR) return false;
				/* c8 ignore stop */
				let hit;
				if (typeof p === "string") {
					hit = f === p;
					this.debug("string match", p, f, hit);
				} else {
					hit = p.test(f);
					this.debug("pattern match", p, f, hit);
				}
				if (!hit) return false;
			}
			if (fi === fl && pi === pl) return true;
			else if (fi === fl) return partial;
			else if (pi === pl) return fi === fl - 1 && file[fi] === "";
			else throw new Error("wtf?");
			/* c8 ignore stop */
		}
		braceExpand() {
			return (0, exports.braceExpand)(this.pattern, this.options);
		}
		parse(pattern) {
			(0, assert_valid_pattern_js_1.assertValidPattern)(pattern);
			const options = this.options;
			if (pattern === "**") return exports.GLOBSTAR;
			if (pattern === "") return "";
			let m;
			let fastTest = null;
			if (m = pattern.match(starRE)) fastTest = options.dot ? starTestDot : starTest;
			else if (m = pattern.match(starDotExtRE)) fastTest = (options.nocase ? options.dot ? starDotExtTestNocaseDot : starDotExtTestNocase : options.dot ? starDotExtTestDot : starDotExtTest)(m[1]);
			else if (m = pattern.match(qmarksRE)) fastTest = (options.nocase ? options.dot ? qmarksTestNocaseDot : qmarksTestNocase : options.dot ? qmarksTestDot : qmarksTest)(m);
			else if (m = pattern.match(starDotStarRE)) fastTest = options.dot ? starDotStarTestDot : starDotStarTest;
			else if (m = pattern.match(dotStarRE)) fastTest = dotStarTest;
			const re = ast_js_1.AST.fromGlob(pattern, this.options).toMMPattern();
			if (fastTest && typeof re === "object") Reflect.defineProperty(re, "test", { value: fastTest });
			return re;
		}
		makeRe() {
			if (this.regexp || this.regexp === false) return this.regexp;
			const set = this.set;
			if (!set.length) {
				this.regexp = false;
				return this.regexp;
			}
			const options = this.options;
			const twoStar = options.noglobstar ? star : options.dot ? twoStarDot : twoStarNoDot;
			const flags = new Set(options.nocase ? ["i"] : []);
			let re = set.map((pattern) => {
				const pp = pattern.map((p) => {
					if (p instanceof RegExp) for (const f of p.flags.split("")) flags.add(f);
					return typeof p === "string" ? regExpEscape(p) : p === exports.GLOBSTAR ? exports.GLOBSTAR : p._src;
				});
				pp.forEach((p, i) => {
					const next = pp[i + 1];
					const prev = pp[i - 1];
					if (p !== exports.GLOBSTAR || prev === exports.GLOBSTAR) return;
					if (prev === void 0) {
						if (next !== void 0 && next !== exports.GLOBSTAR) pp[i + 1] = "(?:\\/|" + twoStar + "\\/)?" + next;
						else pp[i] = twoStar;
					} else if (next === void 0) pp[i - 1] = prev + "(?:\\/|\\/" + twoStar + ")?";
					else if (next !== exports.GLOBSTAR) {
						pp[i - 1] = prev + "(?:\\/|\\/" + twoStar + "\\/)" + next;
						pp[i + 1] = exports.GLOBSTAR;
					}
				});
				const filtered = pp.filter((p) => p !== exports.GLOBSTAR);
				if (this.partial && filtered.length >= 1) {
					const prefixes = [];
					for (let i = 1; i <= filtered.length; i++) prefixes.push(filtered.slice(0, i).join("/"));
					return "(?:" + prefixes.join("|") + ")";
				}
				return filtered.join("/");
			}).join("|");
			const [open, close] = set.length > 1 ? ["(?:", ")"] : ["", ""];
			re = "^" + open + re + close + "$";
			if (this.partial) re = "^(?:\\/|" + open + re.slice(1, -1) + close + ")$";
			if (this.negate) re = "^(?!" + re + ").+$";
			try {
				this.regexp = new RegExp(re, [...flags].join(""));
			} catch {
				this.regexp = false;
			}
			/* c8 ignore stop */
			return this.regexp;
		}
		slashSplit(p) {
			if (this.preserveMultipleSlashes) return p.split("/");
			else if (this.isWindows && /^\/\/[^/]+/.test(p)) return ["", ...p.split(/\/+/)];
			else return p.split(/\/+/);
		}
		match(f, partial = this.partial) {
			this.debug("match", f, this.pattern);
			if (this.comment) return false;
			if (this.empty) return f === "";
			if (f === "/" && partial) return true;
			const options = this.options;
			if (this.isWindows) f = f.split("\\").join("/");
			const ff = this.slashSplit(f);
			this.debug(this.pattern, "split", ff);
			const set = this.set;
			this.debug(this.pattern, "set", set);
			let filename = ff[ff.length - 1];
			if (!filename) for (let i = ff.length - 2; !filename && i >= 0; i--) filename = ff[i];
			for (const pattern of set) {
				let file = ff;
				if (options.matchBase && pattern.length === 1) file = [filename];
				if (this.matchOne(file, pattern, partial)) {
					if (options.flipNegate) return true;
					return !this.negate;
				}
			}
			if (options.flipNegate) return false;
			return this.negate;
		}
		static defaults(def) {
			return exports.minimatch.defaults(def).Minimatch;
		}
	};
	exports.Minimatch = Minimatch;
	/* c8 ignore start */
	var ast_js_2 = require_ast();
	Object.defineProperty(exports, "AST", {
		enumerable: true,
		get: function() {
			return ast_js_2.AST;
		}
	});
	var escape_js_2 = require_escape();
	Object.defineProperty(exports, "escape", {
		enumerable: true,
		get: function() {
			return escape_js_2.escape;
		}
	});
	var unescape_js_2 = require_unescape();
	Object.defineProperty(exports, "unescape", {
		enumerable: true,
		get: function() {
			return unescape_js_2.unescape;
		}
	});
	/* c8 ignore stop */
	exports.minimatch.AST = ast_js_1.AST;
	exports.minimatch.Minimatch = Minimatch;
	exports.minimatch.escape = escape_js_1.escape;
	exports.minimatch.unescape = unescape_js_1.unescape;
}));
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/path/implementation.js
var import_matcher = (/* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* @param {string} pattern
	* @param {import("minimatch").MinimatchOptions} options
	* @returns {import("minimatch").Minimatch}
	*/
	exports.createMatcher = function createMatcher(pattern, options) {
		const { Minimatch } = require_commonjs();
		return new Minimatch(pattern, options);
	};
})))();
const ArrayPrototypeIncludes = (value, item) => value.includes(item);
const ArrayPrototypeJoin = (value, separator) => value.join(separator);
const ArrayPrototypePush = (value, ...items) => value.push(...items);
const ArrayPrototypeSlice = (value, start, end) => value.slice(start, end);
const FunctionPrototypeBind = (fn, receiver, separator) => fn.bind(receiver, separator);
const StringPrototypeCharCodeAt = (value, index) => value.charCodeAt(index);
const StringPrototypeIncludes = (value, search) => value.includes(search);
const StringPrototypeIndexOf = (value, search, from) => value.indexOf(search, from);
const StringPrototypeLastIndexOf = (value, search) => value.lastIndexOf(search);
const StringPrototypeRepeat = (value, count) => value.repeat(count);
const StringPrototypeReplace = (value, search, replacement) => value.replace(search, replacement);
const StringPrototypeSlice = (value, start, end) => value.slice(start, end);
const StringPrototypeSplit = (value, separator) => value.split(separator);
const StringPrototypeToLowerCase = (value) => value.toLowerCase();
const StringPrototypeToUpperCase = (value) => value.toUpperCase();
const CHAR_UPPERCASE_A = 65;
const CHAR_LOWERCASE_A = 97;
const CHAR_UPPERCASE_Z = 90;
const CHAR_LOWERCASE_Z = 122;
const CHAR_DOT = 46;
const CHAR_FORWARD_SLASH = 47;
const CHAR_BACKWARD_SLASH = 92;
const CHAR_COLON = 58;
const CHAR_QUESTION_MARK = 63;
const patternCache = /* @__PURE__ */ new Map();
function matchGlobPattern(path, pattern, windows) {
	validateString(path, "path");
	validateString(pattern, "pattern");
	const key = `${windows ? "win32" : "posix"}:${pattern}`;
	let matcher = patternCache.get(key);
	if (!matcher) {
		matcher = (0, import_matcher.createMatcher)(pattern, {
			nocase: false,
			windowsPathsNoEscape: true,
			nonegate: true,
			nocomment: true,
			optimizationLevel: 2,
			platform: windows ? "win32" : "linux",
			nocaseMagicOnly: true
		});
		patternCache.set(key, matcher);
		if (patternCache.size >= 250) {
			const oldest = patternCache.keys().next().value;
			if (oldest !== void 0) patternCache.delete(oldest);
		}
	}
	return matcher.match(path);
}
function isPathSeparator(code) {
	return code === CHAR_FORWARD_SLASH || code === CHAR_BACKWARD_SLASH;
}
function isPosixPathSeparator(code) {
	return code === CHAR_FORWARD_SLASH;
}
const WINDOWS_RESERVED_NAMES = [
	"CON",
	"PRN",
	"AUX",
	"NUL",
	"COM1",
	"COM2",
	"COM3",
	"COM4",
	"COM5",
	"COM6",
	"COM7",
	"COM8",
	"COM9",
	"LPT1",
	"LPT2",
	"LPT3",
	"LPT4",
	"LPT5",
	"LPT6",
	"LPT7",
	"LPT8",
	"LPT9",
	"COM¹",
	"COM²",
	"COM³",
	"LPT¹",
	"LPT²",
	"LPT³"
];
function isWindowsReservedName(path, colonIndex) {
	const devicePart = StringPrototypeToUpperCase(StringPrototypeSlice(path, 0, colonIndex));
	return ArrayPrototypeIncludes(WINDOWS_RESERVED_NAMES, devicePart);
}
function isWindowsDeviceRoot(code) {
	return code >= CHAR_UPPERCASE_A && code <= CHAR_UPPERCASE_Z || code >= CHAR_LOWERCASE_A && code <= CHAR_LOWERCASE_Z;
}
function normalizeString(path, allowAboveRoot, separator, isPathSeparator) {
	let res = "";
	let lastSegmentLength = 0;
	let lastSlash = -1;
	let dots = 0;
	let code = 0;
	for (let i = 0; i <= path.length; ++i) {
		if (i < path.length) code = StringPrototypeCharCodeAt(path, i);
		else if (isPathSeparator(code)) break;
		else code = CHAR_FORWARD_SLASH;
		if (isPathSeparator(code)) {
			if (lastSlash === i - 1 || dots === 1) {} else if (dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || StringPrototypeCharCodeAt(res, res.length - 1) !== CHAR_DOT || StringPrototypeCharCodeAt(res, res.length - 2) !== CHAR_DOT) {
					if (res.length > 2) {
						const lastSlashIndex = res.length - lastSegmentLength - 1;
						if (lastSlashIndex === -1) {
							res = "";
							lastSegmentLength = 0;
						} else {
							res = StringPrototypeSlice(res, 0, lastSlashIndex);
							lastSegmentLength = res.length - 1 - StringPrototypeLastIndexOf(res, separator);
						}
						lastSlash = i;
						dots = 0;
						continue;
					} else if (res.length !== 0) {
						res = "";
						lastSegmentLength = 0;
						lastSlash = i;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					res += res.length > 0 ? `${separator}..` : "..";
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0) res += `${separator}${StringPrototypeSlice(path, lastSlash + 1, i)}`;
				else res = StringPrototypeSlice(path, lastSlash + 1, i);
				lastSegmentLength = i - lastSlash - 1;
			}
			lastSlash = i;
			dots = 0;
		} else if (code === CHAR_DOT && dots !== -1) ++dots;
		else dots = -1;
	}
	return res;
}
function formatExt(ext) {
	return ext ? `${ext[0] === "." ? "" : "."}${ext}` : "";
}
/**
* @param {string} sep
* @param {{
*  dir?: string;
*  root?: string;
*  base?: string;
*  name?: string;
*  ext?: string;
*  }} pathObject
* @returns {string}
*/
function _format(sep, pathObject) {
	validateObject(pathObject, "pathObject");
	const dir = pathObject.dir || pathObject.root;
	const base = pathObject.base || `${pathObject.name || ""}${formatExt(pathObject.ext)}`;
	if (!dir) return base;
	return dir === pathObject.root ? `${dir}${base}` : `${dir}${sep}${base}`;
}
const forwardSlashRegExp = /\//g;
function createPathImplementation(providers) {
	const runtimeCwd = () => {
		const value = providers.initialCwd();
		if (value === void 0) throw new Error("node:path requires wasi:cli/environment initial-cwd");
		validateString(value, "initialCwd");
		return value;
	};
	const driveCwd = (device) => providers.getEnvironment().find(([key]) => key.toLowerCase() === `=${device.toLowerCase()}`)?.[1];
	const win32 = {
		/**
		* path.resolve([from ...], to)
		* @param {...string} args
		* @returns {string}
		*/
		resolve(...args) {
			let resolvedDevice = "";
			let resolvedTail = "";
			let resolvedAbsolute = false;
			for (let i = args.length - 1; i >= -1; i--) {
				let path;
				if (i >= 0) {
					path = args[i];
					validateString(path, `paths[${i}]`);
					if (path.length === 0) continue;
				} else if (resolvedDevice.length === 0) {
					path = runtimeCwd();
					if (args.length === 0 || args.length === 1 && (args[0] === "" || args[0] === ".") && isPathSeparator(StringPrototypeCharCodeAt(path, 0))) {
						path = StringPrototypeReplace(path, forwardSlashRegExp, "\\");
						return path;
					}
				} else {
					path = driveCwd(resolvedDevice) || runtimeCwd();
					if (path === void 0 || StringPrototypeToLowerCase(StringPrototypeSlice(path, 0, 2)) !== StringPrototypeToLowerCase(resolvedDevice) && StringPrototypeCharCodeAt(path, 2) === CHAR_BACKWARD_SLASH) path = `${resolvedDevice}\\`;
				}
				const len = path.length;
				let rootEnd = 0;
				let device = "";
				let isAbsolute = false;
				const code = StringPrototypeCharCodeAt(path, 0);
				if (len === 1) {
					if (isPathSeparator(code)) {
						rootEnd = 1;
						isAbsolute = true;
					}
				} else if (isPathSeparator(code)) {
					isAbsolute = true;
					if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
						let j = 2;
						let last = j;
						while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
						if (j < len && j !== last) {
							const firstPart = StringPrototypeSlice(path, last, j);
							last = j;
							while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
							if (j < len && j !== last) {
								last = j;
								while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
								if (j === len || j !== last) {
									if (firstPart !== "." && firstPart !== "?") {
										device = `\\\\${firstPart}\\${StringPrototypeSlice(path, last, j)}`;
										rootEnd = j;
									} else {
										device = `\\\\${firstPart}`;
										rootEnd = 4;
									}
								}
							}
						}
					} else rootEnd = 1;
				} else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
					device = StringPrototypeSlice(path, 0, 2);
					rootEnd = 2;
					if (len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
						isAbsolute = true;
						rootEnd = 3;
					}
				}
				if (device.length > 0) {
					if (resolvedDevice.length > 0) {
						if (StringPrototypeToLowerCase(device) !== StringPrototypeToLowerCase(resolvedDevice)) continue;
					} else resolvedDevice = device;
				}
				if (resolvedAbsolute) {
					if (resolvedDevice.length > 0) break;
				} else {
					resolvedTail = `${StringPrototypeSlice(path, rootEnd)}\\${resolvedTail}`;
					resolvedAbsolute = isAbsolute;
					if (isAbsolute && resolvedDevice.length > 0) break;
				}
			}
			resolvedTail = normalizeString(resolvedTail, !resolvedAbsolute, "\\", isPathSeparator);
			return resolvedAbsolute ? `${resolvedDevice}\\${resolvedTail}` : `${resolvedDevice}${resolvedTail}` || ".";
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		normalize(path) {
			validateString(path, "path");
			const len = path.length;
			if (len === 0) return ".";
			let rootEnd = 0;
			let device;
			let isAbsolute = false;
			const code = StringPrototypeCharCodeAt(path, 0);
			if (len === 1) return isPosixPathSeparator(code) ? "\\" : path;
			if (isPathSeparator(code)) {
				isAbsolute = true;
				if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
					let j = 2;
					let last = j;
					while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
					if (j < len && j !== last) {
						const firstPart = StringPrototypeSlice(path, last, j);
						last = j;
						while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
						if (j < len && j !== last) {
							last = j;
							while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
							if (j === len || j !== last) {
								if (firstPart === "." || firstPart === "?") {
									device = `\\\\${firstPart}`;
									rootEnd = 4;
									const colonIndex = StringPrototypeIndexOf(path, ":");
									const possibleDevice = StringPrototypeSlice(path, 4, colonIndex + 1);
									if (isWindowsReservedName(possibleDevice, possibleDevice.length - 1)) {
										device = `\\\\?\\${possibleDevice}`;
										rootEnd = 4 + possibleDevice.length;
									}
								} else if (j === len) return `\\\\${firstPart}\\${StringPrototypeSlice(path, last)}\\`;
								else {
									device = `\\\\${firstPart}\\${StringPrototypeSlice(path, last, j)}`;
									rootEnd = j;
								}
							}
						}
					}
				} else rootEnd = 1;
			} else {
				const colonIndex = StringPrototypeIndexOf(path, ":");
				if (colonIndex > 0) {
					if (isWindowsDeviceRoot(code) && colonIndex === 1) {
						device = StringPrototypeSlice(path, 0, 2);
						rootEnd = 2;
						if (len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
							isAbsolute = true;
							rootEnd = 3;
						}
					} else if (isWindowsReservedName(path, colonIndex)) {
						device = StringPrototypeSlice(path, 0, colonIndex + 1);
						rootEnd = colonIndex + 1;
					}
				}
			}
			let tail = rootEnd < len ? normalizeString(StringPrototypeSlice(path, rootEnd), !isAbsolute, "\\", isPathSeparator) : "";
			if (tail.length === 0 && !isAbsolute) tail = ".";
			if (tail.length > 0 && isPathSeparator(StringPrototypeCharCodeAt(path, len - 1))) tail += "\\";
			if (!isAbsolute && device === void 0 && StringPrototypeIncludes(path, ":")) {
				if (tail.length >= 2 && isWindowsDeviceRoot(StringPrototypeCharCodeAt(tail, 0)) && StringPrototypeCharCodeAt(tail, 1) === CHAR_COLON) return `.\\${tail}`;
				let index = StringPrototypeIndexOf(path, ":");
				do
					if (index === len - 1 || isPathSeparator(StringPrototypeCharCodeAt(path, index + 1))) return `.\\${tail}`;
				while ((index = StringPrototypeIndexOf(path, ":", index + 1)) !== -1);
			}
			if (isWindowsReservedName(path, StringPrototypeIndexOf(path, ":"))) return `.\\${device ?? ""}${tail}`;
			if (device === void 0) return isAbsolute ? `\\${tail}` : tail;
			return isAbsolute ? `${device}\\${tail}` : `${device}${tail}`;
		},
		/**
		* @param {string} path
		* @returns {boolean}
		*/
		isAbsolute(path) {
			validateString(path, "path");
			const len = path.length;
			if (len === 0) return false;
			const code = StringPrototypeCharCodeAt(path, 0);
			return isPathSeparator(code) || len > 2 && isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON && isPathSeparator(StringPrototypeCharCodeAt(path, 2));
		},
		/**
		* @param {...string} args
		* @returns {string}
		*/
		join(...args) {
			if (args.length === 0) return ".";
			const path = [];
			for (let i = 0; i < args.length; ++i) {
				const arg = args[i];
				validateString(arg, "path");
				if (arg.length > 0) ArrayPrototypePush(path, arg);
			}
			if (path.length === 0) return ".";
			const firstPart = path[0];
			let joined = ArrayPrototypeJoin(path, "\\");
			let needsReplace = true;
			let slashCount = 0;
			if (isPathSeparator(StringPrototypeCharCodeAt(firstPart, 0))) {
				++slashCount;
				const firstLen = firstPart.length;
				if (firstLen > 1 && isPathSeparator(StringPrototypeCharCodeAt(firstPart, 1))) {
					++slashCount;
					if (firstLen > 2) {
						if (isPathSeparator(StringPrototypeCharCodeAt(firstPart, 2))) ++slashCount;
						else needsReplace = false;
					}
				}
			}
			if (needsReplace) {
				while (slashCount < joined.length && isPathSeparator(StringPrototypeCharCodeAt(joined, slashCount))) slashCount++;
				if (slashCount >= 2) joined = `\\${StringPrototypeSlice(joined, slashCount)}`;
			}
			const parts = [];
			let part = "";
			for (let i = 0; i < joined.length; i++) if (joined[i] === "\\") {
				if (part) parts.push(part);
				part = "";
				while (i + 1 < joined.length && joined[i + 1] === "\\") i++;
			} else part += joined[i];
			if (part) parts.push(part);
			if (parts.some((p) => {
				const colonIndex = StringPrototypeIndexOf(p, ":");
				return colonIndex !== -1 && isWindowsReservedName(p, colonIndex);
			})) {
				let result = "";
				for (let i = 0; i < joined.length; i++) result += joined[i] === "/" ? "\\" : joined[i];
				return result;
			}
			return win32.normalize(joined);
		},
		/**
		* It will solve the relative path from `from` to `to`, for instance
		* from = 'C:\\orandea\\test\\aaa'
		* to = 'C:\\orandea\\impl\\bbb'
		* The output of the function should be: '..\\..\\impl\\bbb'
		* @param {string} from
		* @param {string} to
		* @returns {string}
		*/
		relative(from, to) {
			validateString(from, "from");
			validateString(to, "to");
			if (from === to) return "";
			const fromOrig = win32.resolve(from);
			const toOrig = win32.resolve(to);
			if (fromOrig === toOrig) return "";
			from = StringPrototypeToLowerCase(fromOrig);
			to = StringPrototypeToLowerCase(toOrig);
			if (from === to) return "";
			if (fromOrig.length !== from.length || toOrig.length !== to.length) {
				const fromSplit = StringPrototypeSplit(fromOrig, "\\");
				const toSplit = StringPrototypeSplit(toOrig, "\\");
				if (fromSplit[fromSplit.length - 1] === "") fromSplit.pop();
				if (toSplit[toSplit.length - 1] === "") toSplit.pop();
				const fromLen = fromSplit.length;
				const toLen = toSplit.length;
				const length = fromLen < toLen ? fromLen : toLen;
				let i = 0;
				for (; i < length; i++) if (StringPrototypeToLowerCase(fromSplit[i]) !== StringPrototypeToLowerCase(toSplit[i])) break;
				if (i === 0) return toOrig;
				else if (i === length) {
					if (toLen > length) return ArrayPrototypeJoin(ArrayPrototypeSlice(toSplit, i), "\\");
					if (fromLen > length) return StringPrototypeRepeat("..\\", fromLen - 1 - i) + "..";
					return "";
				}
				return StringPrototypeRepeat("..\\", fromLen - i) + ArrayPrototypeJoin(ArrayPrototypeSlice(toSplit, i), "\\");
			}
			let fromStart = 0;
			while (fromStart < from.length && StringPrototypeCharCodeAt(from, fromStart) === CHAR_BACKWARD_SLASH) fromStart++;
			let fromEnd = from.length;
			while (fromEnd - 1 > fromStart && StringPrototypeCharCodeAt(from, fromEnd - 1) === CHAR_BACKWARD_SLASH) fromEnd--;
			const fromLen = fromEnd - fromStart;
			let toStart = 0;
			while (toStart < to.length && StringPrototypeCharCodeAt(to, toStart) === CHAR_BACKWARD_SLASH) toStart++;
			let toEnd = to.length;
			while (toEnd - 1 > toStart && StringPrototypeCharCodeAt(to, toEnd - 1) === CHAR_BACKWARD_SLASH) toEnd--;
			const toLen = toEnd - toStart;
			const length = fromLen < toLen ? fromLen : toLen;
			let lastCommonSep = -1;
			let i = 0;
			for (; i < length; i++) {
				const fromCode = StringPrototypeCharCodeAt(from, fromStart + i);
				if (fromCode !== StringPrototypeCharCodeAt(to, toStart + i)) break;
				else if (fromCode === CHAR_BACKWARD_SLASH) lastCommonSep = i;
			}
			if (i !== length) {
				if (lastCommonSep === -1) return toOrig;
			} else {
				if (toLen > length) {
					if (StringPrototypeCharCodeAt(to, toStart + i) === CHAR_BACKWARD_SLASH) return StringPrototypeSlice(toOrig, toStart + i + 1);
					if (i === 2) return StringPrototypeSlice(toOrig, toStart + i);
				}
				if (fromLen > length) {
					if (StringPrototypeCharCodeAt(from, fromStart + i) === CHAR_BACKWARD_SLASH) lastCommonSep = i;
					else if (i === 2) lastCommonSep = 3;
				}
				if (lastCommonSep === -1) lastCommonSep = 0;
			}
			let out = "";
			for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) if (i === fromEnd || StringPrototypeCharCodeAt(from, i) === CHAR_BACKWARD_SLASH) out += out.length === 0 ? ".." : "\\..";
			toStart += lastCommonSep;
			if (out.length > 0) return `${out}${StringPrototypeSlice(toOrig, toStart, toEnd)}`;
			if (StringPrototypeCharCodeAt(toOrig, toStart) === CHAR_BACKWARD_SLASH) ++toStart;
			return StringPrototypeSlice(toOrig, toStart, toEnd);
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		toNamespacedPath(path) {
			if (typeof path !== "string" || path.length === 0) return path;
			const resolvedPath = win32.resolve(path);
			if (resolvedPath.length <= 2) return path;
			if (StringPrototypeCharCodeAt(resolvedPath, 0) === CHAR_BACKWARD_SLASH) {
				if (StringPrototypeCharCodeAt(resolvedPath, 1) === CHAR_BACKWARD_SLASH) {
					const code = StringPrototypeCharCodeAt(resolvedPath, 2);
					if (code !== CHAR_QUESTION_MARK && code !== CHAR_DOT) return `\\\\?\\UNC\\${StringPrototypeSlice(resolvedPath, 2)}`;
				}
			} else if (isWindowsDeviceRoot(StringPrototypeCharCodeAt(resolvedPath, 0)) && StringPrototypeCharCodeAt(resolvedPath, 1) === CHAR_COLON && StringPrototypeCharCodeAt(resolvedPath, 2) === CHAR_BACKWARD_SLASH) return `\\\\?\\${resolvedPath}`;
			return resolvedPath;
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		dirname(path) {
			validateString(path, "path");
			const len = path.length;
			if (len === 0) return ".";
			let rootEnd = -1;
			let offset = 0;
			const code = StringPrototypeCharCodeAt(path, 0);
			if (len === 1) return isPathSeparator(code) ? path : ".";
			if (isPathSeparator(code)) {
				rootEnd = offset = 1;
				if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
					let j = 2;
					let last = j;
					while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
					if (j < len && j !== last) {
						last = j;
						while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
						if (j < len && j !== last) {
							last = j;
							while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
							if (j === len) return path;
							if (j !== last) rootEnd = offset = j + 1;
						}
					}
				}
			} else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
				rootEnd = len > 2 && isPathSeparator(StringPrototypeCharCodeAt(path, 2)) ? 3 : 2;
				offset = rootEnd;
			}
			let end = -1;
			let matchedSlash = true;
			for (let i = len - 1; i >= offset; --i) if (isPathSeparator(StringPrototypeCharCodeAt(path, i))) {
				if (!matchedSlash) {
					end = i;
					break;
				}
			} else matchedSlash = false;
			if (end === -1) {
				if (rootEnd === -1) return ".";
				end = rootEnd;
			}
			return StringPrototypeSlice(path, 0, end);
		},
		/**
		* @param {string} path
		* @param {string} [suffix]
		* @returns {string}
		*/
		basename(path, suffix) {
			if (suffix !== void 0) validateString(suffix, "suffix");
			validateString(path, "path");
			let start = 0;
			let end = -1;
			let matchedSlash = true;
			if (path.length >= 2 && isWindowsDeviceRoot(StringPrototypeCharCodeAt(path, 0)) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) start = 2;
			if (suffix !== void 0 && suffix.length > 0 && suffix.length <= path.length) {
				if (suffix === path) return "";
				let extIdx = suffix.length - 1;
				let firstNonSlashEnd = -1;
				for (let i = path.length - 1; i >= start; --i) {
					const code = StringPrototypeCharCodeAt(path, i);
					if (isPathSeparator(code)) {
						if (!matchedSlash) {
							start = i + 1;
							break;
						}
					} else {
						if (firstNonSlashEnd === -1) {
							matchedSlash = false;
							firstNonSlashEnd = i + 1;
						}
						if (extIdx >= 0) {
							if (code === StringPrototypeCharCodeAt(suffix, extIdx)) {
								if (--extIdx === -1) end = i;
							} else {
								extIdx = -1;
								end = firstNonSlashEnd;
							}
						}
					}
				}
				if (start === end) end = firstNonSlashEnd;
				else if (end === -1) end = path.length;
				return StringPrototypeSlice(path, start, end);
			}
			for (let i = path.length - 1; i >= start; --i) if (isPathSeparator(StringPrototypeCharCodeAt(path, i))) {
				if (!matchedSlash) {
					start = i + 1;
					break;
				}
			} else if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (end === -1) return "";
			return StringPrototypeSlice(path, start, end);
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		extname(path) {
			validateString(path, "path");
			let start = 0;
			let startDot = -1;
			let startPart = 0;
			let end = -1;
			let matchedSlash = true;
			let preDotState = 0;
			if (path.length >= 2 && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON && isWindowsDeviceRoot(StringPrototypeCharCodeAt(path, 0))) start = startPart = 2;
			for (let i = path.length - 1; i >= start; --i) {
				const code = StringPrototypeCharCodeAt(path, i);
				if (isPathSeparator(code)) {
					if (!matchedSlash) {
						startPart = i + 1;
						break;
					}
					continue;
				}
				if (end === -1) {
					matchedSlash = false;
					end = i + 1;
				}
				if (code === CHAR_DOT) {
					if (startDot === -1) startDot = i;
					else if (preDotState !== 1) preDotState = 1;
				} else if (startDot !== -1) preDotState = -1;
			}
			if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) return "";
			return StringPrototypeSlice(path, startDot, end);
		},
		format: FunctionPrototypeBind(_format, null, "\\"),
		/**
		* @param {string} path
		* @returns {{
		*  dir: string;
		*  root: string;
		*  base: string;
		*  name: string;
		*  ext: string;
		*  }}
		*/
		parse(path) {
			validateString(path, "path");
			const ret = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (path.length === 0) return ret;
			const len = path.length;
			let rootEnd = 0;
			let code = StringPrototypeCharCodeAt(path, 0);
			if (len === 1) {
				if (isPathSeparator(code)) {
					ret.root = ret.dir = path;
					return ret;
				}
				ret.base = ret.name = path;
				return ret;
			}
			if (isPathSeparator(code)) {
				rootEnd = 1;
				if (isPathSeparator(StringPrototypeCharCodeAt(path, 1))) {
					let j = 2;
					let last = j;
					while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
					if (j < len && j !== last) {
						last = j;
						while (j < len && isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
						if (j < len && j !== last) {
							last = j;
							while (j < len && !isPathSeparator(StringPrototypeCharCodeAt(path, j))) j++;
							if (j === len) rootEnd = j;
							else if (j !== last) rootEnd = j + 1;
						}
					}
				}
			} else if (isWindowsDeviceRoot(code) && StringPrototypeCharCodeAt(path, 1) === CHAR_COLON) {
				if (len <= 2) {
					ret.root = ret.dir = path;
					return ret;
				}
				rootEnd = 2;
				if (isPathSeparator(StringPrototypeCharCodeAt(path, 2))) {
					if (len === 3) {
						ret.root = ret.dir = path;
						return ret;
					}
					rootEnd = 3;
				}
			}
			if (rootEnd > 0) ret.root = StringPrototypeSlice(path, 0, rootEnd);
			let startDot = -1;
			let startPart = rootEnd;
			let end = -1;
			let matchedSlash = true;
			let i = path.length - 1;
			let preDotState = 0;
			for (; i >= rootEnd; --i) {
				code = StringPrototypeCharCodeAt(path, i);
				if (isPathSeparator(code)) {
					if (!matchedSlash) {
						startPart = i + 1;
						break;
					}
					continue;
				}
				if (end === -1) {
					matchedSlash = false;
					end = i + 1;
				}
				if (code === CHAR_DOT) {
					if (startDot === -1) startDot = i;
					else if (preDotState !== 1) preDotState = 1;
				} else if (startDot !== -1) preDotState = -1;
			}
			if (end !== -1) {
				if (startDot === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) ret.base = ret.name = StringPrototypeSlice(path, startPart, end);
				else {
					ret.name = StringPrototypeSlice(path, startPart, startDot);
					ret.base = StringPrototypeSlice(path, startPart, end);
					ret.ext = StringPrototypeSlice(path, startDot, end);
				}
			}
			if (startPart > 0 && startPart !== rootEnd) ret.dir = StringPrototypeSlice(path, 0, startPart - 1);
			else ret.dir = ret.root;
			return ret;
		},
		matchesGlob(path, pattern) {
			return matchGlobPattern(path, pattern, true);
		},
		sep: "\\",
		delimiter: ";"
	};
	const posixCwd = (() => {
		return () => runtimeCwd();
	})();
	const posix = {
		/**
		* path.resolve([from ...], to)
		* @param {...string} args
		* @returns {string}
		*/
		resolve(...args) {
			if (args.length === 0 || args.length === 1 && (args[0] === "" || args[0] === ".")) {
				const cwd = posixCwd();
				if (StringPrototypeCharCodeAt(cwd, 0) === CHAR_FORWARD_SLASH) return cwd;
			}
			let resolvedPath = "";
			let resolvedAbsolute = false;
			for (let i = args.length - 1; i >= 0 && !resolvedAbsolute; i--) {
				const path = args[i];
				validateString(path, `paths[${i}]`);
				if (path.length === 0) continue;
				resolvedPath = `${path}/${resolvedPath}`;
				resolvedAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
			}
			if (!resolvedAbsolute) {
				const cwd = posixCwd();
				resolvedPath = `${cwd}/${resolvedPath}`;
				resolvedAbsolute = StringPrototypeCharCodeAt(cwd, 0) === CHAR_FORWARD_SLASH;
			}
			resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute, "/", isPosixPathSeparator);
			if (resolvedAbsolute) return `/${resolvedPath}`;
			return resolvedPath.length > 0 ? resolvedPath : ".";
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		normalize(path) {
			validateString(path, "path");
			if (path.length === 0) return ".";
			const isAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
			const trailingSeparator = StringPrototypeCharCodeAt(path, path.length - 1) === CHAR_FORWARD_SLASH;
			path = normalizeString(path, !isAbsolute, "/", isPosixPathSeparator);
			if (path.length === 0) {
				if (isAbsolute) return "/";
				return trailingSeparator ? "./" : ".";
			}
			if (trailingSeparator) path += "/";
			return isAbsolute ? `/${path}` : path;
		},
		/**
		* @param {string} path
		* @returns {boolean}
		*/
		isAbsolute(path) {
			validateString(path, "path");
			return path.length > 0 && StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
		},
		/**
		* @param {...string} args
		* @returns {string}
		*/
		join(...args) {
			if (args.length === 0) return ".";
			const path = [];
			for (let i = 0; i < args.length; ++i) {
				const arg = args[i];
				validateString(arg, "path");
				if (arg.length > 0) path.push(arg);
			}
			if (path.length === 0) return ".";
			return posix.normalize(ArrayPrototypeJoin(path, "/"));
		},
		/**
		* @param {string} from
		* @param {string} to
		* @returns {string}
		*/
		relative(from, to) {
			validateString(from, "from");
			validateString(to, "to");
			if (from === to) return "";
			from = posix.resolve(from);
			to = posix.resolve(to);
			if (from === to) return "";
			const fromStart = 1;
			const fromEnd = from.length;
			const fromLen = fromEnd - fromStart;
			const toStart = 1;
			const toLen = to.length - toStart;
			const length = fromLen < toLen ? fromLen : toLen;
			let lastCommonSep = -1;
			let i = 0;
			for (; i < length; i++) {
				const fromCode = StringPrototypeCharCodeAt(from, fromStart + i);
				if (fromCode !== StringPrototypeCharCodeAt(to, toStart + i)) break;
				else if (fromCode === CHAR_FORWARD_SLASH) lastCommonSep = i;
			}
			if (i === length) {
				if (toLen > length) {
					if (StringPrototypeCharCodeAt(to, toStart + i) === CHAR_FORWARD_SLASH) return StringPrototypeSlice(to, toStart + i + 1);
					if (i === 0) return StringPrototypeSlice(to, toStart + i);
				} else if (fromLen > length) {
					if (StringPrototypeCharCodeAt(from, fromStart + i) === CHAR_FORWARD_SLASH) lastCommonSep = i;
					else if (i === 0) lastCommonSep = 0;
				}
			}
			let out = "";
			for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) if (i === fromEnd || StringPrototypeCharCodeAt(from, i) === CHAR_FORWARD_SLASH) out += out.length === 0 ? ".." : "/..";
			return `${out}${StringPrototypeSlice(to, toStart + lastCommonSep)}`;
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		toNamespacedPath(path) {
			return path;
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		dirname(path) {
			validateString(path, "path");
			if (path.length === 0) return ".";
			const hasRoot = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
			let end = -1;
			let matchedSlash = true;
			for (let i = path.length - 1; i >= 1; --i) if (StringPrototypeCharCodeAt(path, i) === CHAR_FORWARD_SLASH) {
				if (!matchedSlash) {
					end = i;
					break;
				}
			} else matchedSlash = false;
			if (end === -1) return hasRoot ? "/" : ".";
			if (hasRoot && end === 1) return "//";
			return StringPrototypeSlice(path, 0, end);
		},
		/**
		* @param {string} path
		* @param {string} [suffix]
		* @returns {string}
		*/
		basename(path, suffix) {
			if (suffix !== void 0) validateString(suffix, "suffix");
			validateString(path, "path");
			let start = 0;
			let end = -1;
			let matchedSlash = true;
			if (suffix !== void 0 && suffix.length > 0 && suffix.length <= path.length) {
				if (suffix === path) return "";
				let extIdx = suffix.length - 1;
				let firstNonSlashEnd = -1;
				for (let i = path.length - 1; i >= 0; --i) {
					const code = StringPrototypeCharCodeAt(path, i);
					if (code === CHAR_FORWARD_SLASH) {
						if (!matchedSlash) {
							start = i + 1;
							break;
						}
					} else {
						if (firstNonSlashEnd === -1) {
							matchedSlash = false;
							firstNonSlashEnd = i + 1;
						}
						if (extIdx >= 0) {
							if (code === StringPrototypeCharCodeAt(suffix, extIdx)) {
								if (--extIdx === -1) end = i;
							} else {
								extIdx = -1;
								end = firstNonSlashEnd;
							}
						}
					}
				}
				if (start === end) end = firstNonSlashEnd;
				else if (end === -1) end = path.length;
				return StringPrototypeSlice(path, start, end);
			}
			for (let i = path.length - 1; i >= 0; --i) if (StringPrototypeCharCodeAt(path, i) === CHAR_FORWARD_SLASH) {
				if (!matchedSlash) {
					start = i + 1;
					break;
				}
			} else if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (end === -1) return "";
			return StringPrototypeSlice(path, start, end);
		},
		/**
		* @param {string} path
		* @returns {string}
		*/
		extname(path) {
			validateString(path, "path");
			let startDot = -1;
			let startPart = 0;
			let end = -1;
			let matchedSlash = true;
			let preDotState = 0;
			for (let i = path.length - 1; i >= 0; --i) {
				const char = path[i];
				if (char === "/") {
					if (!matchedSlash) {
						startPart = i + 1;
						break;
					}
					continue;
				}
				if (end === -1) {
					matchedSlash = false;
					end = i + 1;
				}
				if (char === ".") {
					if (startDot === -1) startDot = i;
					else if (preDotState !== 1) preDotState = 1;
				} else if (startDot !== -1) preDotState = -1;
			}
			if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) return "";
			return StringPrototypeSlice(path, startDot, end);
		},
		format: FunctionPrototypeBind(_format, null, "/"),
		/**
		* @param {string} path
		* @returns {{
		*   dir: string;
		*   root: string;
		*   base: string;
		*   name: string;
		*   ext: string;
		*   }}
		*/
		parse(path) {
			validateString(path, "path");
			const ret = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (path.length === 0) return ret;
			const isAbsolute = StringPrototypeCharCodeAt(path, 0) === CHAR_FORWARD_SLASH;
			let start;
			if (isAbsolute) {
				ret.root = "/";
				start = 1;
			} else start = 0;
			let startDot = -1;
			let startPart = 0;
			let end = -1;
			let matchedSlash = true;
			let i = path.length - 1;
			let preDotState = 0;
			for (; i >= start; --i) {
				const code = StringPrototypeCharCodeAt(path, i);
				if (code === CHAR_FORWARD_SLASH) {
					if (!matchedSlash) {
						startPart = i + 1;
						break;
					}
					continue;
				}
				if (end === -1) {
					matchedSlash = false;
					end = i + 1;
				}
				if (code === CHAR_DOT) {
					if (startDot === -1) startDot = i;
					else if (preDotState !== 1) preDotState = 1;
				} else if (startDot !== -1) preDotState = -1;
			}
			if (end !== -1) {
				const start = startPart === 0 && isAbsolute ? 1 : startPart;
				if (startDot === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) ret.base = ret.name = StringPrototypeSlice(path, start, end);
				else {
					ret.name = StringPrototypeSlice(path, start, startDot);
					ret.base = StringPrototypeSlice(path, start, end);
					ret.ext = StringPrototypeSlice(path, startDot, end);
				}
			}
			if (startPart > 0) ret.dir = StringPrototypeSlice(path, 0, startPart - 1);
			else if (isAbsolute) ret.dir = "/";
			return ret;
		},
		matchesGlob(path, pattern) {
			return matchGlobPattern(path, pattern, false);
		},
		sep: "/",
		delimiter: ":"
	};
	const completeWin32 = win32;
	const completePosix = posix;
	Object.assign(completeWin32, {
		win32: completeWin32,
		posix: completePosix
	});
	Object.assign(completePosix, {
		win32: completeWin32,
		posix: completePosix
	});
	Object.assign(completeWin32, { _makeLong: completeWin32.toNamespacedPath });
	return Object.assign(completePosix, { _makeLong: completePosix.toNamespacedPath });
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/path.js
/** Build Node's POSIX-default path namespaces over explicit WASI providers. */
function createPath(providers) {
	if (!providers || typeof providers.initialCwd !== "function" || typeof providers.getEnvironment !== "function") throw new TypeError("createPath requires initialCwd and getEnvironment providers");
	return createPathImplementation(providers);
}
//#endregion
export { createPath as t };
