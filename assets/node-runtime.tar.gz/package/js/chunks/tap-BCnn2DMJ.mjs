import { t as inspect } from "./inspect-fNEaW5tU.mjs";
import { a as codedError, g as outOfRange, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
import { s as validateNumber } from "./validation-qQPlCQ6g.mjs";
import { t as isObject } from "./shared-DSGRKwku.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/errors.js
/** ERR_TEST_FAILURE adapted from nodejs/node lib/internal/errors.js,
* v24.20.0, 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT (see LICENSE).
* Uses jco-std error codes and inspection instead of Node internal bindings. */
function failure(cause, failureType = "testCodeFailure") {
	const value = (isObject(cause) ? cause.message : void 0) ?? cause;
	const message = typeof value === "string" ? value : inspect(value);
	const error = Object.assign(codedError(new Error(message), "ERR_TEST_FAILURE"), { failureType });
	error.cause = cause;
	return error;
}
function unsupported(api, reason) {
	throw unsupportedNodeApi(`node:test ${api}`, reason);
}
function integer(value, name, min = 0) {
	validateNumber(value, name);
	if (!Number.isSafeInteger(value) || value < min) throw outOfRange(name, `>= ${min} and <= ${Number.MAX_SAFE_INTEGER}`, value);
}
function milliseconds(value, name) {
	validateNumber(value, name);
	if (Number.isNaN(value) || value < 0 || value > 2147483647) throw outOfRange(name, ">= 0 && <= 2147483647", value);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/tap.js
function tapEscape(input) {
	return input.replaceAll("\b", "\\b").replaceAll("\f", "\\f").replaceAll("	", "\\t").replaceAll("\n", "\\n").replaceAll("\r", "\\r").replaceAll("\v", "\\v").replaceAll("\\", "\\\\").replaceAll("#", "\\#");
}
function yaml(indent, name, value) {
	if (value === void 0) return "";
	if (typeof value === "string") return `${indent}  ${name}: ${JSON.stringify(value)}\n`;
	return `${indent}  ${name}: ${typeof value === "object" && value !== null ? JSON.stringify(inspect(value)) : String(value)}\n`;
}
function formatTap(event) {
	const { type, data } = event;
	switch (type) {
		case "test:pass":
		case "test:fail": {
			const indent = "    ".repeat(data.nesting);
			let line = `${indent}${type === "test:pass" ? "ok" : "not ok"} ${data.testNumber}`;
			if (data.name) line += ` ${tapEscape(`- ${data.name}`)}`;
			for (const [name, value] of [
				["SKIP", data.skip],
				["TODO", data.todo],
				["EXPECTED FAILURE", data.expectFailure]
			]) if (value !== void 0) {
				line += ` # ${name}${typeof value === "string" && value.length ? ` ${tapEscape(value)}` : ""}`;
				break;
			}
			line += `\n${indent}  ---\n`;
			line += yaml(indent, "duration_ms", data.details.duration_ms);
			line += yaml(indent, "type", data.details.type);
			const error = data.details.error;
			if (error) {
				line += yaml(indent, "failureType", error.failureType);
				line += yaml(indent, "error", error.message);
				line += yaml(indent, "code", error.code);
				if (error.cause !== void 0) line += yaml(indent, "cause", error.cause);
			}
			return `${line}${indent}  ...\n`;
		}
		case "test:start": return `${"    ".repeat(data.nesting)}# Subtest: ${tapEscape(data.name)}\n`;
		case "test:plan": return `${"    ".repeat(data.nesting)}1..${data.count}\n`;
		case "test:diagnostic":
		case "test:log": return `${"    ".repeat(data.nesting)}# ${tapEscape(data.message)}\n`;
		case "test:stdout":
		case "test:stderr": return data.message.split(/\n|\r\n/).filter(Boolean).map((line) => `# ${tapEscape(line)}\n`).join("");
		case "test:interrupted": return data.tests.map((test) => `# ${tapEscape(`Interrupted while running: ${test.name}${test.file ? ` at ${test.file}:${test.line}:${test.column}` : ""}`)}\n`).join("");
		case "test:coverage": return data.summary.files.map((file) => `# ${tapEscape(file.path)}: ${file.coveredLineCount}/${file.totalLineCount} lines covered\n`).join("");
		default: return "";
	}
}
async function* tap(source) {
	yield "TAP version 13\n";
	for await (const event of source) {
		const text = formatTap(event);
		if (text) yield text;
	}
}
//#endregion
export { milliseconds as a, integer as i, tap as n, unsupported as o, failure as r, formatTap as t };
