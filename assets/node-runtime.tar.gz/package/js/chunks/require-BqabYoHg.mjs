import { a as codedError, c as determineSpecificType, v as unsupportedNodeApi } from "./core-DGqXzKN-.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/builtins.js
/**
* Node 24's builtin module list, verbatim.
*
* Captured from the pinned release rather than written by hand:
*
* ```console
* node -e 'console.log(require("node:module").builtinModules.join("\n"))'
* ```
*
* This is a *classification*, not an availability list: it answers "is this a Node builtin?", which
* is the question `isBuiltin` asks. Whether Jco resolves a given builtin is a separate matter -- see
* the compatibility table in the docs for what a component can actually import.
*/
const builtinModules = Object.freeze([
	"_http_agent",
	"_http_client",
	"_http_common",
	"_http_incoming",
	"_http_outgoing",
	"_http_server",
	"_stream_duplex",
	"_stream_passthrough",
	"_stream_readable",
	"_stream_transform",
	"_stream_wrap",
	"_stream_writable",
	"_tls_common",
	"_tls_wrap",
	"assert",
	"assert/strict",
	"async_hooks",
	"buffer",
	"child_process",
	"cluster",
	"console",
	"constants",
	"crypto",
	"dgram",
	"diagnostics_channel",
	"dns",
	"dns/promises",
	"domain",
	"events",
	"fs",
	"fs/promises",
	"http",
	"http2",
	"https",
	"inspector",
	"inspector/promises",
	"module",
	"net",
	"os",
	"path",
	"path/posix",
	"path/win32",
	"perf_hooks",
	"process",
	"punycode",
	"querystring",
	"readline",
	"readline/promises",
	"repl",
	"stream",
	"stream/consumers",
	"stream/promises",
	"stream/web",
	"string_decoder",
	"sys",
	"timers",
	"timers/promises",
	"tls",
	"trace_events",
	"tty",
	"url",
	"util",
	"util/types",
	"v8",
	"vm",
	"wasi",
	"worker_threads",
	"zlib",
	"node:sea",
	"node:sqlite",
	"node:test",
	"node:test/reporters"
]);
/** Builtins reachable only as `node:x`, such as `node:test`. */
const PREFIXED = new Set(builtinModules.filter((name) => name.startsWith("node:")));
/** Builtins reachable without a scheme, such as `fs`. */
const BARE = new Set(builtinModules.filter((name) => !name.startsWith("node:")));
/**
* Node's `module.isBuiltin(name)`.
*
* A bare name matches only the scheme-less builtins: `isBuiltin("test")` is **false**, because
* `node:test` exists only under the prefix. A `node:`-prefixed name matches either set.
*
* @param name - the specifier to classify
*/
function isBuiltin(name) {
	if (!name.startsWith("node:")) return BARE.has(name);
	return PREFIXED.has(name) || BARE.has(name.slice(5));
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/errors.js
/**
* Errors for `node:module`.
*
* Two kinds. Node's own coded errors are reproduced where Jco can answer as Node would -- a
* `require.resolve` that finds nothing really is `MODULE_NOT_FOUND`. Everything that needs a module
* loader carries `ERR_JCO_UNSUPPORTED_NODE_API` and says why, so a refusal is never mistaken for a
* lookup that simply failed.
*
* The coded-error factory and the `Received ...` clause are the shared ones in `../errors/core.js`.
*/
/** Why the loading half of this module cannot exist here. Shared so every message agrees. */
const NO_LOADER = "a component has no module loader: `jco componentize` bundles the whole graph ahead of time, and the engine cannot compile or link a module that was not present at build time";
/**
* Refuse an entry point whose job is to load something.
*
* @param api - the entry point being used, as a user would write it
* @param instead - what to do instead, when there is something
*/
function unsupported(api, instead) {
	return unsupportedNodeApi(api, `${NO_LOADER}${instead ? `. ${instead}` : ""}`);
}
/** Node's `MODULE_NOT_FOUND`, for a specifier that genuinely resolves to nothing. */
function moduleNotFound(specifier) {
	return codedError(/* @__PURE__ */ new Error(`Cannot find module '${specifier}'`), "MODULE_NOT_FOUND");
}
/**
* Node's `ERR_INVALID_ARG_TYPE`.
*
* `expected` is a complete phrase ("an object", "a valid base64 VLQ string") rather than a type
* name, which is why this does not delegate to the shared `invalidArgType` and its
* "must be of type" template.
*/
function invalidArgType(name, expected, actual) {
	return codedError(/* @__PURE__ */ new TypeError(`The "${name}" argument must be ${expected}. Received ${determineSpecificType(actual)}`), "ERR_INVALID_ARG_TYPE");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/module-class.js
/**
* Node's `Module` class -- the object `require("node:module")` itself is.
*
* Constructing one is allowed and matches Node's own-property shape. It is cheap, harmless, and
* real code builds these for bookkeeping without ever loading anything. The methods are what need
* a loader, so that is where the refusal lives.
*/
var Module = class {
	id;
	path;
	exports;
	filename;
	loaded;
	children;
	constructor(id = "", parent) {
		this.id = id;
		this.path = ".";
		this.exports = {};
		this.filename = null;
		this.loaded = false;
		this.children = [];
	}
	/**
	* Node exposes the deprecated parent link on the prototype.
	*
	* `undefined`, not `null`: that is what Node 24 reports for a module with no parent, and the two
	* are distinguishable to a caller.
	*/
	get parent() {}
	/** Node reports whether a module is running during preload; nothing preloads here. */
	get isPreloading() {
		return false;
	}
	require(specifier) {
		throw unsupported(`module.require(${JSON.stringify(specifier)})`, "Use a static `import` instead, which the bundler can resolve at build time");
	}
	load(filename) {
		throw unsupported(`module.load(${JSON.stringify(filename)})`);
	}
	_compile(content, filename) {
		throw unsupported(`module._compile(..., ${JSON.stringify(filename)})`);
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/require.js
/**
* Node's `module.createRequire(filename)`.
*
* This **succeeds**, deliberately. Code routinely writes
* `const require = createRequire(import.meta.url)` at module top level and only calls it on some
* paths; refusing at creation would break modules that never require anything. The refusal belongs
* to the call that actually needs a loader.
*
* @param filename - the path or URL to resolve against, as Node takes it
*/
function createRequire(filename) {
	const require = ((specifier) => {
		throw unsupported(`require(${JSON.stringify(specifier)})`, "Use a static `import` instead, which the bundler can resolve at build time");
	});
	/**
	* `require.resolve` is not a refusal.
	*
	* For a builtin it answers exactly as Node does, returning the specifier in the form it was
	* given. For anything else it reports `MODULE_NOT_FOUND` -- which is the truth here, not a
	* stand-in for one: nothing else exists to resolve to.
	*/
	const resolve = ((specifier) => {
		if (isBuiltin(specifier)) return specifier;
		throw moduleNotFound(specifier);
	});
	resolve.paths = (specifier) => isBuiltin(specifier) ? null : [];
	require.resolve = resolve;
	require.cache = Object.create(null);
	require.extensions = Object.create(null);
	require.main = void 0;
	return require;
}
//#endregion
export { builtinModules as a, unsupported as i, Module as n, isBuiltin as o, invalidArgType as r, createRequire as t };
