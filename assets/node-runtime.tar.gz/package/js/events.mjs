import { a as defaultMaxListeners, c as getMaxListeners, d as on, f as setMaxListeners, i as captureRejections, l as init, m as import_events, n as addAbortListener, o as errorMonitor, p as usingDomains, r as captureRejectionSymbol, s as getEventListeners, t as EventEmitterAsyncResource, u as listenerCount } from "./chunks/events-KhrHxd6b.mjs";
var EventEmitter = import_events.EventEmitter;
var src_default = import_events.default;
var once = import_events.once;
export { EventEmitter, EventEmitterAsyncResource, addAbortListener, captureRejectionSymbol, captureRejections, src_default as default, defaultMaxListeners, errorMonitor, getEventListeners, getMaxListeners, init, listenerCount, on, once, setMaxListeners, usingDomains };
