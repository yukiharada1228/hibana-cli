module.exports = require('./string_decoder.mjs').default;
