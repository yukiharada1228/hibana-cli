import { n as punycode, t as init_punycode_es6 } from "./chunks/punycode.es6-CLnR-6HC.mjs";
//#region src/punycode.mjs
init_punycode_es6();
const { decode, encode, toASCII, toUnicode, ucs2, version } = punycode;
var punycode_default = punycode;
//#endregion
export { decode, punycode_default as default, encode, toASCII, toUnicode, ucs2, version };
