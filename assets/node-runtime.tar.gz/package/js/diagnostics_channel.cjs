module.exports = require('./diagnostics_channel.mjs').default;
