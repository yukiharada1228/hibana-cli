module.exports = require('./console.mjs').default;
