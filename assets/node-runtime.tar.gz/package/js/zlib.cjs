module.exports = require('./zlib.mjs').default;
