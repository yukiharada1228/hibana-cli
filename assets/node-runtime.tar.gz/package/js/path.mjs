import { t as createPath } from "./chunks/path-BF3uS3Wa.mjs";
import process from "./process.mjs";
//#region src/path.mjs
const path = createPath({
	initialCwd: () => process.cwd(),
	getEnvironment: () => Object.entries(process.env)
});
const { basename, dirname, extname, format, isAbsolute, join, normalize, parse, relative, resolve, sep, delimiter, posix, win32, toNamespacedPath, matchesGlob } = path;
path.posix._makeLong = (value) => value;
path.win32._makeLong = path.win32.toNamespacedPath;
path._makeLong = path.posix._makeLong;
const _makeLong = path._makeLong;
//#endregion
export { _makeLong, basename, path as default, delimiter, dirname, extname, format, isAbsolute, join, matchesGlob, normalize, parse, posix, relative, resolve, sep, toNamespacedPath, win32 };
