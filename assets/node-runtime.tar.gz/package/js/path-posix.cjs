module.exports = require('./path-posix.mjs').default;
