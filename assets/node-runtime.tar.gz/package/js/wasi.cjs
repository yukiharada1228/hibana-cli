module.exports = require('./wasi.mjs').default;
