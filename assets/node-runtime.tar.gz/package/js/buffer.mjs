import { a as __toESM } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { t as require_buffer } from "./chunks/buffer-Cijt-YWe.mjs";
//#region src/buffer.mjs
var import_buffer = /* @__PURE__ */ __toESM(require_buffer(), 1);
const { Buffer, SlowBuffer, INSPECT_MAX_BYTES, kMaxLength } = import_buffer.default;
const { Blob } = globalThis;
const File = globalThis.File ?? class File extends Blob {
	constructor(bits, name, options = {}) {
		super(bits, options);
		this.name = String(name);
		this.lastModified = options.lastModified ?? Date.now();
	}
};
const atob = globalThis.atob;
const btoa = globalThis.btoa;
const kStringMaxLength = 2 ** 29 - 24;
const constants = {
	MAX_LENGTH: kMaxLength,
	MAX_STRING_LENGTH: kStringMaxLength
};
function bytesOf(value) {
	if (typeof value === "string") return Buffer.from(value);
	if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
	if (value instanceof ArrayBuffer) return new Uint8Array(value);
	throw Object.assign(/* @__PURE__ */ new TypeError("The input must be a string or an ArrayBuffer view"), { code: "ERR_INVALID_ARG_TYPE" });
}
function isAscii(value) {
	const bytes = bytesOf(value);
	for (const byte of bytes) if (byte > 127) return false;
	return true;
}
function isUtf8(value) {
	try {
		new TextDecoder("utf-8", { fatal: true }).decode(bytesOf(value));
		return true;
	} catch {
		return false;
	}
}
const textEncodings = /* @__PURE__ */ new Set([
	"utf8",
	"utf-8",
	"ascii",
	"latin1",
	"binary",
	"utf16le",
	"ucs2"
]);
function transcode(source, fromEncoding, toEncoding) {
	const from = String(fromEncoding).toLowerCase();
	const to = String(toEncoding).toLowerCase();
	if (!textEncodings.has(from) || !textEncodings.has(to)) throw Object.assign(/* @__PURE__ */ new Error(`Unable to transcode from ${fromEncoding} to ${toEncoding}`), { code: "ERR_UNKNOWN_ENCODING" });
	const decoded = Buffer.from(bytesOf(source)).toString(from === "binary" ? "latin1" : from);
	return Buffer.from(decoded, to === "binary" ? "latin1" : to);
}
function resolveObjectURL() {}
const api = {
	...import_buffer.default,
	Blob,
	File,
	atob,
	btoa,
	constants,
	isAscii,
	isUtf8,
	kStringMaxLength,
	resolveObjectURL,
	transcode
};
//#endregion
export { Blob, Buffer, File, INSPECT_MAX_BYTES, SlowBuffer, atob, btoa, constants, api as default, isAscii, isUtf8, kMaxLength, kStringMaxLength, resolveObjectURL, transcode };
