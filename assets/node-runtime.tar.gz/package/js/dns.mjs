import { C as NOTIMP, D as TIMEOUT, E as SERVFAIL, O as V4MAPPED, S as NOTFOUND, T as REFUSED, _ as FORMERR, a as BADFAMILY, b as NOMEM, c as BADNAME, d as BADSTR, f as CANCELLED, g as FILE, h as EOF, i as ALL, l as BADQUERY, m as DESTRUCTION, n as ADDRCONFIG, o as BADFLAGS, p as CONNREFUSED, r as ADDRGETNETWORKPARAMS, s as BADHINTS, t as dns, u as BADRESP, v as LOADIPHLPAPI, w as NOTINITIALIZED, x as NONAME, y as NODATA } from "./chunks/dns-runtime-BeBkjK5h.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dns.js
const Resolver = dns.callback.Resolver;
const getDefaultResultOrder = dns.callback.getDefaultResultOrder;
const getServers = dns.callback.getServers;
const lookup = dns.callback.lookup;
const lookupService = dns.callback.lookupService;
const promises = Object.assign(dns.promises, {
	ADDRGETNETWORKPARAMS,
	BADFAMILY,
	BADFLAGS,
	BADHINTS,
	BADNAME,
	BADQUERY,
	BADRESP,
	BADSTR,
	CANCELLED,
	CONNREFUSED,
	DESTRUCTION,
	EOF: "EOF",
	FILE,
	FORMERR,
	LOADIPHLPAPI,
	NODATA,
	NOMEM,
	NONAME,
	NOTFOUND,
	NOTIMP,
	NOTINITIALIZED,
	REFUSED,
	SERVFAIL,
	TIMEOUT
});
const resolve = dns.callback.resolve;
const resolve4 = dns.callback.resolve4;
const resolve6 = dns.callback.resolve6;
const resolveAny = dns.callback.resolveAny;
const resolveCaa = dns.callback.resolveCaa;
const resolveCname = dns.callback.resolveCname;
const resolveMx = dns.callback.resolveMx;
const resolveNaptr = dns.callback.resolveNaptr;
const resolveNs = dns.callback.resolveNs;
const resolvePtr = dns.callback.resolvePtr;
const resolveSoa = dns.callback.resolveSoa;
const resolveSrv = dns.callback.resolveSrv;
const resolveTlsa = dns.callback.resolveTlsa;
const resolveTxt = dns.callback.resolveTxt;
const reverse = dns.callback.reverse;
const setDefaultResultOrder = dns.callback.setDefaultResultOrder;
const setServers = dns.callback.setServers;
var dns_default = {
	ADDRCONFIG: 32,
	ADDRGETNETWORKPARAMS,
	ALL: 16,
	BADFAMILY,
	BADFLAGS,
	BADHINTS,
	BADNAME,
	BADQUERY,
	BADRESP,
	BADSTR,
	CANCELLED,
	CONNREFUSED,
	DESTRUCTION,
	EOF: "EOF",
	FILE,
	FORMERR,
	LOADIPHLPAPI,
	NODATA,
	NOMEM,
	NONAME,
	NOTFOUND,
	NOTIMP,
	NOTINITIALIZED,
	REFUSED,
	Resolver,
	SERVFAIL,
	TIMEOUT,
	V4MAPPED: 8,
	getDefaultResultOrder,
	getServers,
	lookup,
	lookupService,
	promises,
	resolve,
	resolve4,
	resolve6,
	resolveAny,
	resolveCaa,
	resolveCname,
	resolveMx,
	resolveNaptr,
	resolveNs,
	resolvePtr,
	resolveSoa,
	resolveSrv,
	resolveTlsa,
	resolveTxt,
	reverse,
	setDefaultResultOrder,
	setServers
};
//#endregion
export { ADDRCONFIG, ADDRGETNETWORKPARAMS, ALL, BADFAMILY, BADFLAGS, BADHINTS, BADNAME, BADQUERY, BADRESP, BADSTR, CANCELLED, CONNREFUSED, DESTRUCTION, EOF, FILE, FORMERR, LOADIPHLPAPI, NODATA, NOMEM, NONAME, NOTFOUND, NOTIMP, NOTINITIALIZED, REFUSED, Resolver, SERVFAIL, TIMEOUT, V4MAPPED, dns_default as default, getDefaultResultOrder, getServers, lookup, lookupService, promises, resolve, resolve4, resolve6, resolveAny, resolveCaa, resolveCname, resolveMx, resolveNaptr, resolveNs, resolvePtr, resolveSoa, resolveSrv, resolveTlsa, resolveTxt, reverse, setDefaultResultOrder, setServers };
