import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { n as DEPRECATED_CODE, r as UNSUPPORTED_CODE, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { n as denyThrow, t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { t as EventEmitter } from "./chunks/event-emitter-D4b0qsct.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/cluster-host.js
var cluster_host_exports = /* @__PURE__ */ __exportAll({
	currentWorker: () => currentWorker,
	default: () => cluster_host_default,
	disconnectAll: () => disconnectAll,
	disconnectWorker: () => disconnectWorker,
	drainEvents: () => drainEvents,
	fork: () => fork$1,
	getSettings: () => getSettings,
	getWorker: () => getWorker,
	isPrimary: () => isPrimary,
	kill: () => kill,
	listWorkers: () => listWorkers,
	send: () => send,
	setSettings: () => setSettings
});
/**
* The default adapter intentionally grants no process-control capability.
*
* Declaring or generating the WIT import does not grant host access: an application must
* explicitly provide a host implementation, such as the separately exported Node adapter, when it
* maps or instantiates a component.
*/
const required = denyThrow("ERR_JCO_CLUSTER_ADAPTER_REQUIRED", adapterRequiredMessage("node:cluster"));
const isPrimary = () => required();
const currentWorker = () => required();
const fork$1 = () => required();
const listWorkers = () => required();
const getWorker = () => required();
const send = () => required();
const disconnectWorker = () => required();
const disconnectAll = () => required();
const kill = () => required();
const getSettings = () => required();
const setSettings = () => required();
const drainEvents = () => required();
var cluster_host_default = {
	isPrimary,
	currentWorker,
	fork: fork$1,
	listWorkers,
	getWorker,
	send,
	disconnectWorker,
	disconnectAll,
	kill,
	getSettings,
	setSettings,
	drainEvents
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/cluster/errors.js
/**
* Errors for parts of `node:cluster` that cannot be represented in a component.
*
* Each one names what was attempted and why it cannot work, rather than failing as a missing
* property would. Nothing here is a silent omission: every case has a test.
*
* The coded-error factory, codes, and message templates are the shared ones in
* `../errors/core.js`, so cluster errors carry the same identity, stack header, and `toString`
* as every other jco-std builtin.
*/
/**
* Thrown for cluster behavior that has no component equivalent.
*
* @param api - the public API being used, as a user would write it
* @param reason - why it cannot work here
*/
function unsupported(api, reason) {
	return unsupportedNodeApi(api, reason);
}
/**
* Thrown for APIs Node has deprecated.
*
* Callers must throw this before touching arguments, providers, or state.
*
* @param api - the deprecated API
* @param replacement - the API Node's documentation directs users to instead
*/
function deprecated(api, replacement) {
	return deprecatedNodeApi(api, replacement);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/cluster/worker.js
/**
* Guest-side view of a cluster worker, mirroring Node's `cluster.Worker`.
*
* State is not cached: every getter re-reads the host so a worker observed after an event
* reports what the host actually knows, the way Node's live worker objects do.
*/
var Worker$1 = class extends EventEmitter {
	/** Worker id, as assigned by the host's cluster primary. */
	id;
	#host;
	/** Last host snapshot, used only when the worker is gone and the host can no longer report. */
	#lastKnown;
	constructor(host, info) {
		super();
		this.#host = host;
		this.id = info.id;
		this.#lastKnown = info;
	}
	/** Refresh from the host, falling back to the last snapshot once the worker is gone. */
	#info() {
		try {
			this.#lastKnown = this.#host.getWorker(this.id);
		} catch {}
		return this.#lastKnown;
	}
	/** Record a host snapshot, so post-exit reads report the final state. */
	_update(info) {
		this.#lastKnown = info;
	}
	get state() {
		return this.#info().state;
	}
	get exitedAfterDisconnect() {
		return this.#info().exitedAfterDisconnect;
	}
	/**
	* Node exposes the worker's `ChildProcess` here.
	*
	* A `ChildProcess` is a live handle with streams, a pid, and its own event surface; none of
	* that can cross the component boundary, and returning a partial stand-in would fail later in
	* ways that look like bugs in user code.
	*/
	get process() {
		throw unsupported("worker.process", "it is a ChildProcess handle, which cannot cross the component boundary");
	}
	isConnected() {
		return this.#info().connected;
	}
	isDead() {
		return this.#info().dead;
	}
	/**
	* Send a message to this worker.
	*
	* WIT has no dynamic value type, so messages cross as JSON. Values JSON cannot represent
	* (functions, symbols, cycles, BigInt) are rejected here rather than arriving altered.
	*/
	send(message) {
		let json;
		try {
			json = JSON.stringify(message);
		} catch (cause) {
			throw unsupported("worker.send(message)", `messages cross the host boundary as JSON and this value cannot be serialized (${String(cause)})`);
		}
		if (json === void 0) throw unsupported("worker.send(message)", "messages cross the host boundary as JSON and this value has no JSON representation");
		this.#host.send(this.id, json);
		return true;
	}
	disconnect() {
		this.#host.disconnectWorker(this.id);
		return this;
	}
	kill(signal = "SIGTERM") {
		this.#host.kill(this.id, signal);
	}
	/** Node's `destroy` is an alias of `kill`. */
	destroy(signal = "SIGTERM") {
		this.kill(signal);
	}
};
/** Settings Node accepts but that describe the host runner rather than anything the guest owns. */
const HOST_OWNED_SETTINGS = [
	"exec",
	"execArgv",
	"stdio",
	"uid",
	"gid",
	"inspectPort",
	"serialization"
];
/**
* Build the `node:cluster` module surface over a host adapter.
*
* Nothing touches `host` until an API is called, so a component that imports `node:cluster`
* without using it never reaches the host.
*
* @param host - providers supplied by Jco's generated virtual adapter
*/
function createCluster(host) {
	const cluster = new EventEmitter();
	const workers = {};
	/** Track a worker from a snapshot the host already gave us. */
	const track = (info) => {
		const existing = workers[info.id];
		if (existing) {
			existing._update(info);
			return existing;
		}
		const worker = new Worker$1(host, info);
		workers[info.id] = worker;
		return worker;
	};
	/**
	* Track a worker known only by id, as events report it.
	*
	* Only the primary can look a worker up: a worker process has no `cluster.workers`, so the host
	* cannot answer there. Fall back to a minimal record rather than failing, which is what lets a
	* worker observe its own events.
	*/
	const trackById = (id) => {
		const existing = workers[id];
		if (existing) return existing;
		try {
			return track(host.getWorker(id));
		} catch {
			return track({
				id,
				state: "none",
				exitedAfterDisconnect: false,
				connected: false,
				dead: false
			});
		}
	};
	/**
	* Re-emit host events on both the cluster and the worker they concern.
	*
	* Node delivers these on its event loop. The guest has no way to be called back across the
	* host boundary, so they surface on the next interaction with the module instead. This is a
	* real difference from Node and is documented and tested as such.
	*/
	const pump = () => {
		for (const event of host.drainEvents()) dispatch(event);
	};
	const dispatch = (event) => {
		switch (event.tag) {
			case "fork": {
				const worker = trackById(event.val);
				cluster.emit("fork", worker);
				return;
			}
			case "online": {
				const worker = trackById(event.val);
				worker.emit("online");
				cluster.emit("online", worker);
				return;
			}
			case "disconnect": {
				const worker = trackById(event.val);
				worker.emit("disconnect");
				cluster.emit("disconnect", worker);
				return;
			}
			case "exit": {
				const worker = trackById(event.val.id);
				worker._update({
					id: event.val.id,
					state: "dead",
					exitedAfterDisconnect: event.val.signal === "",
					connected: false,
					dead: true
				});
				delete workers[event.val.id];
				const signal = event.val.signal === "" ? null : event.val.signal;
				worker.emit("exit", event.val.code, signal);
				cluster.emit("exit", worker, event.val.code, signal);
				return;
			}
			case "message": {
				const worker = trackById(event.val.id);
				const message = event.val.json === "" ? void 0 : JSON.parse(event.val.json);
				worker.emit("message", message);
				cluster.emit("message", worker, message);
				return;
			}
			case "setup":
				cluster.emit("setup", cluster.settings);
				return;
		}
	};
	const toHostSettings = (value) => {
		const current = host.getSettings();
		return {
			silent: value.silent ?? current.silent,
			args: value.args ?? current.args,
			cwd: value.cwd ?? current.cwd,
			schedulingPolicy: value.schedulingPolicy ?? current.schedulingPolicy
		};
	};
	Object.defineProperties(cluster, {
		SCHED_NONE: {
			value: 1,
			enumerable: true
		},
		SCHED_RR: {
			value: 2,
			enumerable: true
		},
		Worker: {
			value: Worker$1,
			enumerable: true
		},
		isPrimary: {
			enumerable: true,
			get: () => host.isPrimary()
		},
		isWorker: {
			enumerable: true,
			get: () => !host.isPrimary()
		},
		/**
		* Deprecated in Node in favour of `isPrimary`. A throwing getter rather than a value, so
		* reading it fails loudly instead of silently disagreeing with `isPrimary`.
		*/
		isMaster: {
			enumerable: true,
			get: () => {
				throw deprecated("cluster.isMaster", "cluster.isPrimary");
			}
		},
		workers: {
			enumerable: true,
			get: () => {
				pump();
				return workers;
			}
		},
		worker: {
			enumerable: true,
			get: () => {
				const info = host.currentWorker();
				if (!info) return;
				return track(info);
			}
		},
		settings: {
			enumerable: true,
			get: () => {
				const current = host.getSettings();
				return {
					silent: current.silent,
					args: [...current.args],
					cwd: current.cwd,
					schedulingPolicy: current.schedulingPolicy
				};
			},
			set: (value) => {
				host.setSettings(toHostSettings(value));
			}
		},
		schedulingPolicy: {
			enumerable: true,
			get: () => host.getSettings().schedulingPolicy,
			set: (value) => {
				host.setSettings({
					...host.getSettings(),
					schedulingPolicy: value
				});
			}
		}
	});
	cluster.fork = (env = {}) => {
		const info = host.fork(Object.entries(env));
		const worker = track(info);
		pump();
		return worker;
	};
	cluster.disconnect = (callback) => {
		host.disconnectAll();
		pump();
		if (callback) callback();
	};
	cluster.setupPrimary = (settings = {}) => {
		for (const key of HOST_OWNED_SETTINGS) if (key in settings) throw unsupported(`cluster.setupPrimary({ ${key} })`, "it configures the host runner that executes this component, not a guest file");
		host.setSettings(toHostSettings(settings));
		pump();
	};
	/** Deprecated in Node in favour of `setupPrimary`; throws before touching its argument. */
	cluster.setupMaster = () => {
		throw deprecated("cluster.setupMaster()", "cluster.setupPrimary()");
	};
	cluster.pump = pump;
	return cluster;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/cluster.js
/**
* `node:cluster`, backed by the host's own cluster over `jco:node/cluster@0.1.0`.
*
* WASI has no process model, so unlike Jco's portable builtins this forwards to the host. A
* transpiled component is itself a Node process, so a fork re-executes the entry and the worker
* runs this component again.
*/
const cluster = createCluster(cluster_host_exports);
const SCHED_NONE = cluster.SCHED_NONE;
const SCHED_RR = cluster.SCHED_RR;
const Worker = cluster.Worker;
const fork = (env) => cluster.fork(env);
const disconnect = (callback) => cluster.disconnect(callback);
const setupPrimary = (settings) => cluster.setupPrimary(settings);
const setupMaster = () => cluster.setupMaster();
//#endregion
export { DEPRECATED_CODE, SCHED_NONE, SCHED_RR, UNSUPPORTED_CODE, Worker, cluster as default, disconnect, fork, setupMaster, setupPrimary };
