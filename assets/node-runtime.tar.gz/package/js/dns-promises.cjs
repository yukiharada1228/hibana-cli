module.exports = require('./dns-promises.mjs').default;
