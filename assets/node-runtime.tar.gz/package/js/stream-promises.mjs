import { x as promises } from "./chunks/stream-BA_0bejK.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/stream/promises.js
const finished = promises.finished;
const pipeline = promises.pipeline;
var promises_default = promises;
//#endregion
export { promises_default as default, finished, pipeline };
