import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { c as validateObject, f as validateUint32, l as validateOneOf, r as validateBoolean, u as validateString } from "./chunks/validation-qQPlCQ6g.mjs";
import { Buffer } from "./buffer.mjs";
import { t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { r as Readable } from "./chunks/stream-BA_0bejK.mjs";
import { n as decodeErrno, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import { n as decodeMessage, t as createMessageCodec } from "./chunks/structured-value-BynNDS9b.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8-host.js
var v8_host_exports = /* @__PURE__ */ __exportAll({
	Profile: () => Profile,
	Reader: () => Reader,
	Writer: () => Writer,
	cachedDataVersionTag: () => cachedDataVersionTag$1,
	default: () => v8_host_default,
	getHeapSnapshot: () => getHeapSnapshot$1,
	openReader: () => openReader,
	openWriter: () => openWriter,
	releaseProfile: () => releaseProfile,
	releaseReader: () => releaseReader,
	releaseWriter: () => releaseWriter,
	setFlagsFromString: () => setFlagsFromString$1,
	setHeapSnapshotNearHeapLimit: () => setHeapSnapshotNearHeapLimit$1,
	startProfile: () => startProfile,
	statistics: () => statistics,
	stopCoverage: () => stopCoverage$1,
	takeCoverage: () => takeCoverage$1,
	writeHeapSnapshot: () => writeHeapSnapshot$1
});
function denied() {
	throw {
		name: "Error",
		message: adapterRequiredMessage("node:v8"),
		code: "ERR_JCO_V8_ADAPTER_REQUIRED"
	};
}
const cachedDataVersionTag$1 = denied;
const statistics = denied;
const getHeapSnapshot$1 = denied;
const writeHeapSnapshot$1 = denied;
const setFlagsFromString$1 = denied;
const takeCoverage$1 = denied;
const stopCoverage$1 = denied;
const setHeapSnapshotNearHeapLimit$1 = denied;
const openWriter = denied;
const openReader = denied;
const startProfile = denied;
const releaseWriter = denied;
const releaseReader = denied;
const releaseProfile = denied;
var v8_host_default = {
	cachedDataVersionTag: cachedDataVersionTag$1,
	statistics,
	getHeapSnapshot: getHeapSnapshot$1,
	writeHeapSnapshot: writeHeapSnapshot$1,
	setFlagsFromString: setFlagsFromString$1,
	takeCoverage: takeCoverage$1,
	stopCoverage: stopCoverage$1,
	setHeapSnapshotNearHeapLimit: setHeapSnapshotNearHeapLimit$1,
	openWriter,
	openReader,
	startProfile,
	releaseWriter,
	releaseReader,
	releaseProfile
};
var Writer = class {
	constructor() {
		denied();
	}
	writeHeader() {
		return denied();
	}
	writeValue(_graph) {
		return denied();
	}
	releaseBuffer() {
		return denied();
	}
	writeUint32(_value) {
		return denied();
	}
	writeUint64(_hi, _lo) {
		return denied();
	}
	writeDouble(_value) {
		return denied();
	}
	writeRawBytes(_data) {
		return denied();
	}
	setTreatViewsAsHostObjects(_flag) {
		return denied();
	}
};
var Reader = class {
	constructor() {
		denied();
	}
	readHeader() {
		return denied();
	}
	readValue() {
		return denied();
	}
	getWireFormatVersion() {
		return denied();
	}
	readUint32() {
		return denied();
	}
	readUint64() {
		return denied();
	}
	readDouble() {
		return denied();
	}
	readRawBytes(_length) {
		return denied();
	}
};
var Profile = class {
	constructor() {
		denied();
	}
	stop() {
		return denied();
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/errors.js
function call(operation) {
	return callHost(operation, restoreError);
}
function restoreError(record) {
	const constructors = {
		Error,
		TypeError,
		RangeError,
		SyntaxError
	};
	const error = new (Object.hasOwn(constructors, record.name) ? constructors[record.name] : Error)(record.message);
	error.name = record.name;
	if (record.errno !== void 0) Object.assign(error, { errno: decodeErrno(record.errno) });
	if (record.syscall !== void 0) Object.assign(error, { syscall: record.syscall });
	return record.code === void 0 ? error : codedError(error, record.code);
}
function unsupported(api) {
	throw unsupportedNodeApi(`v8.${api}`, "Guest engine objects, callbacks, shared memory and native serialization hooks cannot cross the V8 host boundary");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/bytes.js
function bytes(value, name = "buffer") {
	if (!ArrayBuffer.isView(value)) throw invalidArgType(name, [
		"Buffer",
		"TypedArray",
		"DataView"
	], value);
	return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/serializer.js
function codec() {
	return createMessageCodec({
		api: "v8 serialization",
		preserveBuffers: true,
		persistent: true,
		cloneError: (message) => new Error(message)
	});
}
/** Native resources retain the binary format and serialization identity table. */
function createSerializers(host) {
	class Serializer {
		#writer;
		#codec = codec();
		#defaults;
		#disposed = false;
		#treatViews;
		constructor() {
			if (new.target !== Serializer && new.target !== DefaultSerializer) unsupported("Serializer subclasses");
			this.#defaults = new.target === DefaultSerializer;
			this.#treatViews = this.#defaults;
			this.#writer = call(() => host.openWriter(this.#defaults));
		}
		#handle() {
			if (this.#disposed) throw codedError(/* @__PURE__ */ new Error("Serializer has been disposed"), "ERR_INVALID_STATE");
			if (!this.#writer) {
				const writer = call(() => host.openWriter(this.#defaults));
				try {
					call(() => writer.setTreatViewsAsHostObjects(this.#treatViews));
					this.#writer = writer;
				} catch (error) {
					host.releaseWriter(writer);
					throw error;
				}
			}
			return this.#writer;
		}
		writeHeader() {
			call(() => this.#handle().writeHeader());
		}
		writeValue(value) {
			if (this._getDataCloneError !== Error || "_getSharedArrayBufferId" in this) unsupported("Serializer custom callbacks");
			if ("_writeHostObject" in this && this._writeHostObject !== DefaultSerializer.prototype._writeHostObject) unsupported("Serializer._writeHostObject()");
			const handle = this.#handle();
			const graph = this.#codec.encode(value);
			return call(() => handle.writeValue(graph));
		}
		releaseBuffer() {
			const handle = this.#handle();
			const output = call(() => handle.releaseBuffer());
			host.releaseWriter(handle);
			this.#writer = void 0;
			this.#codec = codec();
			return Buffer.from(output);
		}
		transferArrayBuffer(_id, _arrayBuffer) {
			unsupported("Serializer.transferArrayBuffer()");
		}
		writeUint32(value) {
			call(() => this.#handle().writeUint32(value));
		}
		writeUint64(hi, lo) {
			call(() => this.#handle().writeUint64(hi, lo));
		}
		writeDouble(value) {
			call(() => this.#handle().writeDouble(value));
		}
		writeRawBytes(buffer) {
			const data = bytes(buffer);
			call(() => this.#handle().writeRawBytes(data));
		}
		_setTreatArrayBufferViewsAsHostObjects(flag) {
			call(() => this.#handle().setTreatViewsAsHostObjects(flag));
			this.#treatViews = flag;
		}
		/** Component extension: release an abandoned native serializer deterministically. */
		[Symbol.dispose]() {
			this.#disposed = true;
			this.#codec = codec();
			if (this.#writer) {
				host.releaseWriter(this.#writer);
				this.#writer = void 0;
			}
		}
	}
	Object.defineProperty(Serializer.prototype, "_getDataCloneError", {
		value: Error,
		writable: true,
		enumerable: true,
		configurable: true
	});
	for (const name of Object.getOwnPropertyNames(Serializer.prototype)) if (name !== "constructor") Object.defineProperty(Serializer.prototype, name, { enumerable: true });
	class DefaultSerializer extends Serializer {
		_writeHostObject(_object) {
			unsupported("DefaultSerializer._writeHostObject() direct calls");
		}
	}
	return {
		Serializer,
		DefaultSerializer
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/deserializer.js
/** Read native bytes while retaining guest identities across successive values. */
function createDeserializers(host) {
	class Deserializer {
		buffer;
		#reader;
		#session = { values: [] };
		constructor(buffer) {
			if (new.target !== Deserializer && new.target !== DefaultDeserializer) unsupported("Deserializer subclasses");
			this.buffer = buffer;
			this.#reader = call(() => host.openReader(bytes(buffer), new.target === DefaultDeserializer));
		}
		#handle() {
			if (!this.#reader) throw codedError(/* @__PURE__ */ new Error("Deserializer has been disposed"), "ERR_INVALID_STATE");
			return this.#reader;
		}
		readHeader() {
			return call(() => this.#handle().readHeader());
		}
		readValue() {
			if ("_readHostObject" in this && this._readHostObject !== DefaultDeserializer.prototype._readHostObject) unsupported("Deserializer._readHostObject()");
			return decodeMessage(call(() => this.#handle().readValue()), this.#session);
		}
		transferArrayBuffer(_id, _arrayBuffer) {
			unsupported("Deserializer.transferArrayBuffer()");
		}
		getWireFormatVersion() {
			return call(() => this.#handle().getWireFormatVersion()) >>> 0;
		}
		readUint32() {
			return call(() => this.#handle().readUint32()) >>> 0;
		}
		readUint64() {
			const [hi, lo] = call(() => this.#handle().readUint64());
			return [hi >>> 0, lo >>> 0];
		}
		readDouble() {
			return call(() => this.#handle().readDouble());
		}
		_readRawBytes(_length) {
			return unsupported("Deserializer._readRawBytes() native offsets");
		}
		readRawBytes(length) {
			return Buffer.from(call(() => this.#handle().readRawBytes(length)));
		}
		/** Component extension: release the native reader after consuming its values. */
		[Symbol.dispose]() {
			if (this.#reader) {
				host.releaseReader(this.#reader);
				this.#reader = void 0;
				this.#session.values = [];
			}
		}
	}
	for (const name of Object.getOwnPropertyNames(Deserializer.prototype)) if (name !== "constructor") Object.defineProperty(Deserializer.prototype, name, { enumerable: true });
	class DefaultDeserializer extends Deserializer {
		_readHostObject() {
			return unsupported("DefaultDeserializer._readHostObject() direct calls");
		}
	}
	return {
		Deserializer,
		DefaultDeserializer
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/serialization.js
function createSerialization(host) {
	const { Serializer, DefaultSerializer } = createSerializers(host);
	const { Deserializer, DefaultDeserializer } = createDeserializers(host);
	function serialize(value) {
		const serializer = new DefaultSerializer();
		try {
			serializer.writeHeader();
			serializer.writeValue(value);
			return serializer.releaseBuffer();
		} finally {
			serializer[Symbol.dispose]();
		}
	}
	function deserialize(buffer) {
		const deserializer = new DefaultDeserializer(buffer);
		try {
			deserializer.readHeader();
			return deserializer.readValue();
		} finally {
			deserializer[Symbol.dispose]();
		}
	}
	return {
		Serializer,
		Deserializer,
		DefaultSerializer,
		DefaultDeserializer,
		serialize,
		deserialize
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/profiles.js
function createProfiles(host) {
	class GCProfiler {
		#profile;
		start() {
			this.#profile ??= call(() => host.startProfile(false));
		}
		stop() {
			const profile = this.#profile;
			if (!profile) return;
			this.#profile = void 0;
			try {
				const result = call(() => profile.stop());
				return result === void 0 ? void 0 : JSON.parse(result);
			} finally {
				host.releaseProfile(profile);
			}
		}
		[Symbol.dispose]() {
			this.stop();
		}
	}
	function startCpuProfile() {
		const profile = call(() => host.startProfile(true));
		let stopped = false;
		return {
			stop() {
				if (stopped) return;
				stopped = true;
				try {
					return call(() => profile.stop());
				} finally {
					host.releaseProfile(profile);
				}
			},
			[Symbol.dispose]() {
				this.stop();
			}
		};
	}
	return {
		GCProfiler,
		startCpuProfile
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/unsupported.js
const promiseHooks$1 = {
	createHook(_callbacks = {}) {
		return unsupported("promiseHooks.createHook()");
	},
	onInit(_callback) {
		return unsupported("promiseHooks.onInit()");
	},
	onBefore(_callback) {
		return unsupported("promiseHooks.onBefore()");
	},
	onAfter(_callback) {
		return unsupported("promiseHooks.onAfter()");
	},
	onSettled(_callback) {
		return unsupported("promiseHooks.onSettled()");
	}
};
function notBuildingSnapshot() {
	throw codedError(/* @__PURE__ */ new Error("Operation cannot be invoked when not building startup snapshot"), "ERR_NOT_BUILDING_SNAPSHOT");
}
/** A component is never executing inside Node's startup-snapshot builder. */
const startupSnapshot$1 = {
	addDeserializeCallback(_callback, _data) {
		notBuildingSnapshot();
	},
	addSerializeCallback(_callback, _data) {
		notBuildingSnapshot();
	},
	setDeserializeMainFunction(_callback, _data) {
		notBuildingSnapshot();
	},
	isBuildingSnapshot() {
		return false;
	}
};
function queryObjects$1(_ctor, _options) {
	return unsupported("queryObjects()");
}
function isStringOneByteRepresentation$1(_content) {
	return unsupported("isStringOneByteRepresentation()");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8/core.js
/** Copy only native snapshot settings, preserving Node's validation before host access. */
function snapshotOptions(options = {}) {
	validateObject(options, "options");
	const { exposeInternals = false, exposeNumericValues = false } = options;
	validateBoolean(exposeInternals, "options.exposeInternals");
	validateBoolean(exposeNumericValues, "options.exposeNumericValues");
	return {
		exposeInternals,
		exposeNumericValues
	};
}
/** Importing the module never inspects or modifies the host V8 isolate. */
function createV8(host) {
	const serialization = createSerialization(host);
	const profiles = createProfiles(host);
	function cachedDataVersionTag() {
		return call(() => host.cachedDataVersionTag()) >>> 0;
	}
	function getHeapStatistics() {
		return JSON.parse(call(() => host.statistics("heap")));
	}
	function getHeapSpaceStatistics() {
		return JSON.parse(call(() => host.statistics("spaces")));
	}
	function getHeapCodeStatistics() {
		return JSON.parse(call(() => host.statistics("code")));
	}
	function getCppHeapStatistics(detailLevel = "detailed") {
		validateOneOf(detailLevel, "type", ["brief", "detailed"]);
		return JSON.parse(call(() => host.statistics(detailLevel === "brief" ? "cpp-brief" : "cpp-detailed")));
	}
	function getHeapSnapshot(options) {
		const settings = snapshotOptions(options);
		const data = call(() => host.getHeapSnapshot(settings));
		return Readable.from([Buffer.from(data)], { objectMode: false });
	}
	function writeHeapSnapshot(filename, options) {
		if (filename !== void 0) validateString(filename, "filename");
		const settings = snapshotOptions(options);
		return call(() => host.writeHeapSnapshot(filename, settings));
	}
	function setFlagsFromString(flags) {
		validateString(flags, "flags");
		call(() => host.setFlagsFromString(flags));
	}
	function takeCoverage() {
		call(() => host.takeCoverage());
	}
	function stopCoverage() {
		call(() => host.stopCoverage());
	}
	function setHeapSnapshotNearHeapLimit(limit) {
		validateUint32(limit, "limit", true);
		call(() => host.setHeapSnapshotNearHeapLimit(limit));
	}
	return {
		cachedDataVersionTag,
		getHeapSnapshot,
		getHeapStatistics,
		getHeapSpaceStatistics,
		getHeapCodeStatistics,
		getCppHeapStatistics,
		setFlagsFromString,
		...serialization,
		takeCoverage,
		stopCoverage,
		writeHeapSnapshot,
		promiseHooks: promiseHooks$1,
		queryObjects: queryObjects$1,
		startupSnapshot: startupSnapshot$1,
		setHeapSnapshotNearHeapLimit,
		...profiles,
		isStringOneByteRepresentation: isStringOneByteRepresentation$1
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/v8.js
const v8 = createV8(v8_host_exports);
const { cachedDataVersionTag, getHeapSnapshot, getHeapStatistics, getHeapSpaceStatistics, getHeapCodeStatistics, getCppHeapStatistics, setFlagsFromString, Serializer, Deserializer, DefaultSerializer, DefaultDeserializer, deserialize, takeCoverage, stopCoverage, serialize, writeHeapSnapshot, promiseHooks, queryObjects, startupSnapshot, setHeapSnapshotNearHeapLimit, GCProfiler, isStringOneByteRepresentation, startCpuProfile } = v8;
//#endregion
export { DefaultDeserializer, DefaultSerializer, Deserializer, GCProfiler, Serializer, cachedDataVersionTag, v8 as default, deserialize, getCppHeapStatistics, getHeapCodeStatistics, getHeapSnapshot, getHeapSpaceStatistics, getHeapStatistics, isStringOneByteRepresentation, promiseHooks, queryObjects, serialize, setFlagsFromString, setHeapSnapshotNearHeapLimit, startCpuProfile, startupSnapshot, stopCoverage, takeCoverage, writeHeapSnapshot };
