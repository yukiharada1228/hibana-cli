import path, { _makeLong, basename, delimiter, dirname, extname, format, isAbsolute, join, matchesGlob, normalize, parse, posix, relative, resolve, sep, toNamespacedPath, win32 } from "./path.mjs";
export { _makeLong, basename, path as default, delimiter, dirname, extname, format, isAbsolute, join, matchesGlob, normalize, parse, posix, relative, resolve, sep, toNamespacedPath, win32 };
