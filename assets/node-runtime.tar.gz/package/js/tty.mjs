import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { _ as systemError, a as codedError, d as invalidArgType } from "./chunks/core-DGqXzKN-.mjs";
import { o as validateInteger } from "./chunks/validation-qQPlCQ6g.mjs";
import { t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { t as Duplex } from "./chunks/stream-BA_0bejK.mjs";
import { n as decodeErrno, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import { i as moveCursor, n as clearScreenDown, r as cursorTo, t as clearLine } from "./chunks/callbacks-CB8KGxqT.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tty-host.js
var tty_host_exports = /* @__PURE__ */ __exportAll({
	close: () => close,
	default: () => host,
	environment: () => environment,
	isTty: () => isTty,
	open: () => open,
	read: () => read,
	setRawMode: () => setRawMode,
	windowSize: () => windowSize,
	write: () => write
});
/**
* JS bindings lower thrown records into the `err` case of WIT `result<T, error>`.
* The guest reconstructs the same structured error used by the explicit Node host.
*/
const denied = () => {
	throw {
		name: "Error",
		message: adapterRequiredMessage("node:tty"),
		code: "ERR_JCO_TTY_ADAPTER_REQUIRED"
	};
};
/**
* The default adapter intentionally grants no terminal. Every operation, including
* `isatty` on an in-range descriptor, is denied until the application maps a provider.
*/
const isTty = denied;
const open = denied;
const close = denied;
const windowSize = denied;
const setRawMode = denied;
const read = denied;
const write = denied;
const environment = denied;
const host = {
	isTty,
	open,
	close,
	windowSize,
	setRawMode,
	read,
	write,
	environment
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tty/colors.js
const COLORS_2 = 1;
const COLORS_16 = 4;
const COLORS_256 = 8;
const COLORS_16m = 24;
const TERM_ENVS = {
	eterm: COLORS_16,
	cons25: COLORS_16,
	console: COLORS_16,
	cygwin: COLORS_16,
	dtterm: COLORS_16,
	gnome: COLORS_16,
	hurd: COLORS_16,
	jfbterm: COLORS_16,
	konsole: COLORS_16,
	kterm: COLORS_16,
	mlterm: COLORS_16,
	mosh: COLORS_16m,
	putty: COLORS_16,
	st: COLORS_16,
	"rxvt-unicode-24bit": COLORS_16m,
	terminator: COLORS_16m,
	"xterm-kitty": COLORS_16m
};
const CI_ENVS_MAP = new Map(Object.entries({
	APPVEYOR: COLORS_256,
	BUILDKITE: COLORS_256,
	CIRCLECI: COLORS_16m,
	DRONE: COLORS_256,
	GITEA_ACTIONS: COLORS_16m,
	GITHUB_ACTIONS: COLORS_16m,
	GITLAB_CI: COLORS_256,
	TRAVIS: COLORS_256
}));
const TERM_ENVS_REG_EXP = [
	/ansi/,
	/color/,
	/linux/,
	/direct/,
	/^con[0-9]*x[0-9]/,
	/^rxvt/,
	/^screen/,
	/^xterm/,
	/^vt100/,
	/^vt220/
];
/** The `process` global when one exists; this module never imports `node:process`. */
function processGlobal() {
	const candidate = globalThis.process;
	return typeof candidate === "object" && candidate !== null ? candidate : void 0;
}
function hasOwn(env, name) {
	return Object.prototype.hasOwnProperty.call(env, name);
}
/**
* Build `getColorDepth` and `hasColors` over a lazily read default environment. Nothing is read
* from the provider until a call omits `env`, so an explicit environment never touches the host.
*/
function createColorFunctions(defaultEnvironment) {
	let warned = false;
	function warnOnDeactivatedColors(env) {
		if (warned) return;
		let name = "";
		if (env.NODE_DISABLE_COLORS !== void 0 && env.NODE_DISABLE_COLORS !== "") name = "NODE_DISABLE_COLORS";
		if (env.NO_COLOR !== void 0 && env.NO_COLOR !== "") {
			if (name !== "") name += "' and '";
			name += "NO_COLOR";
		}
		if (name !== "") {
			const emitWarning = processGlobal()?.emitWarning;
			if (typeof emitWarning === "function") emitWarning(`The '${name}' env is ignored due to the 'FORCE_COLOR' env being set.`, "Warning");
			warned = true;
		}
	}
	function getColorDepth(env = defaultEnvironment()) {
		if (env.FORCE_COLOR !== void 0) switch (env.FORCE_COLOR) {
			case "":
			case "1":
			case "true":
				warnOnDeactivatedColors(env);
				return COLORS_16;
			case "2":
				warnOnDeactivatedColors(env);
				return COLORS_256;
			case "3":
				warnOnDeactivatedColors(env);
				return COLORS_16m;
			default: return COLORS_2;
		}
		if (env.NODE_DISABLE_COLORS !== void 0 && env.NODE_DISABLE_COLORS !== "" || env.NO_COLOR !== void 0 && env.NO_COLOR !== "" || env.TERM === "dumb") return COLORS_2;
		if (processGlobal()?.platform === "win32") return COLORS_16;
		if (env.TMUX) return COLORS_16m;
		if (hasOwn(env, "TF_BUILD") && hasOwn(env, "AGENT_NAME")) return COLORS_16;
		if (hasOwn(env, "CI")) {
			for (const [envName, colors] of CI_ENVS_MAP) if (hasOwn(env, envName)) return colors;
			if (env.CI_NAME === "codeship") return COLORS_256;
			return COLORS_2;
		}
		if ("TEAMCITY_VERSION" in env) return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.exec(env.TEAMCITY_VERSION ?? "") !== null ? COLORS_16 : COLORS_2;
		switch (env.TERM_PROGRAM) {
			case "iTerm.app":
				if (!env.TERM_PROGRAM_VERSION || /^[0-2]\./.exec(env.TERM_PROGRAM_VERSION) !== null) return COLORS_256;
				return COLORS_16m;
			case "HyperTerm":
			case "MacTerm": return COLORS_16m;
			case "Apple_Terminal": return COLORS_256;
		}
		if (env.COLORTERM === "truecolor" || env.COLORTERM === "24bit") return COLORS_16m;
		if (env.TERM) {
			if (/truecolor/.exec(env.TERM) !== null) return COLORS_16m;
			if (/^xterm-256/.exec(env.TERM) !== null) return COLORS_256;
			const termEnv = env.TERM.toLowerCase();
			if (TERM_ENVS[termEnv]) return TERM_ENVS[termEnv];
			if (TERM_ENVS_REG_EXP.some((term) => term.exec(termEnv) !== null)) return COLORS_16;
		}
		if (env.COLORTERM) return COLORS_16;
		return COLORS_2;
	}
	function hasColors(count, env) {
		let colors;
		if (env === void 0 && (count === void 0 || typeof count === "object" && count !== null)) {
			env = count ?? void 0;
			colors = 16;
		} else {
			validateInteger(count, "count", 2);
			colors = count;
		}
		return colors <= 2 ** getColorDepth(env);
	}
	return {
		getColorDepth,
		hasColors
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tty/core.js
/** libuv's default terminal read allocation; the provider returns at most this much per pull. */
const READ_CHUNK_BYTES = 65536;
/** Node's `ERR_INVALID_FD`. */
function invalidFd(fd) {
	return codedError(/* @__PURE__ */ new RangeError(`"fd" must be a positive integer: ${String(fd)}`), "ERR_INVALID_FD");
}
/** Rebuild the error a provider serialized: Node's `ERR_TTY_INIT_FAILED` carries `info`. */
function providerError(record) {
	const info = record.info ? {
		errno: decodeErrno(record.info.errno),
		code: record.info.code,
		message: record.info.message,
		syscall: record.info.syscall
	} : void 0;
	const error = systemError({
		message: record.message,
		code: record.code ?? "ERR_JCO_TTY_HOST",
		errno: decodeErrno(record.errno),
		syscall: record.syscall,
		info
	});
	if (record.name !== "Error") error.name = record.name;
	return error;
}
function bytesOf(chunk) {
	if (chunk instanceof Uint8Array) return new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
	if (ArrayBuffer.isView(chunk)) return new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
	throw invalidArgType("chunk", [
		"string",
		"Buffer",
		"TypedArray",
		"DataView"
	], chunk);
}
/** Node's constructors are plain functions: calling one without `new` constructs. */
function constructible(target) {
	const callable = new Proxy(target, { apply(callee, _thisArgument, argumentsList) {
		return Reflect.construct(callee, argumentsList);
	} });
	Object.defineProperty(target.prototype, "constructor", {
		value: callable,
		writable: true,
		enumerable: false,
		configurable: true
	});
	return callable;
}
/** Node assigns these prototype members, so they are enumerable own keys of the prototype. */
function enumerable(prototype, keys) {
	for (const key of keys) {
		const descriptor = Object.getOwnPropertyDescriptor(prototype, key);
		if (descriptor) Object.defineProperty(prototype, key, {
			...descriptor,
			enumerable: true
		});
	}
}
/** Create the `node:tty` module over an explicit terminal provider. */
function createTty(host) {
	const call = (operation) => callHost(operation, providerError);
	function validateFd(fd) {
		if (fd >> 0 !== fd || fd < 0) throw invalidFd(fd);
	}
	function isatty(fd) {
		return Number.isInteger(fd) && fd >= 0 && fd <= 2147483647 && call(() => host.isTty(fd));
	}
	const { getColorDepth, hasColors } = createColorFunctions(() => Object.fromEntries(call(() => host.environment())));
	class TerminalInput extends Duplex {
		#fd;
		constructor(fd, options) {
			super({
				readableHighWaterMark: 0,
				...options,
				writable: false
			});
			this.#fd = fd;
		}
		get fd() {
			return this.#fd;
		}
		_read() {
			let bytes;
			try {
				bytes = call(() => host.read(this.fd, READ_CHUNK_BYTES));
			} catch (error) {
				this.destroy(error);
				return;
			}
			this.push(bytes.byteLength === 0 ? null : bytes);
		}
		_destroy(error, callback) {
			try {
				call(() => host.close(this.fd, "read"));
			} catch (closeError) {
				callback(error ?? closeError);
				return;
			}
			callback(error);
		}
	}
	class TerminalOutput extends Duplex {
		#fd;
		constructor(fd) {
			super({
				readableHighWaterMark: 0,
				readable: false
			});
			this.#fd = fd;
		}
		get fd() {
			return this.#fd;
		}
		_write(chunk, _encoding, callback) {
			try {
				const bytes = bytesOf(chunk);
				call(() => host.write(this.fd, bytes));
			} catch (error) {
				callback(error);
				return;
			}
			callback();
		}
		_destroy(error, callback) {
			try {
				call(() => host.close(this.fd, "write"));
			} catch (closeError) {
				callback(error ?? closeError);
				return;
			}
			callback(error);
		}
	}
	class ReadStream extends TerminalInput {
		isRaw = false;
		isTTY = true;
		constructor(fd, options) {
			validateFd(fd);
			call(() => host.open(fd, "read"));
			super(fd, options);
		}
		setRawMode(flag) {
			const enabled = !!flag;
			try {
				call(() => host.setRawMode(this.fd, enabled));
			} catch (error) {
				this.emit("error", error);
				return this;
			}
			this.isRaw = enabled;
			return this;
		}
	}
	class WriteStream extends TerminalOutput {
		constructor(fd) {
			validateFd(fd);
			call(() => host.open(fd, "write"));
			super(fd);
			const size = this.#windowSize();
			if (size) {
				this.columns = size.columns;
				this.rows = size.rows;
			}
		}
		#windowSize() {
			try {
				return call(() => host.windowSize(this.fd));
			} catch {
				return;
			}
		}
		getColorDepth(env) {
			return getColorDepth(env);
		}
		hasColors(count, env) {
			return hasColors(count, env);
		}
		_refreshSize() {
			const oldCols = this.columns;
			const oldRows = this.rows;
			let size;
			try {
				size = call(() => host.windowSize(this.fd));
			} catch (error) {
				this.emit("error", error);
				return;
			}
			const { columns: newCols, rows: newRows } = size;
			if (oldCols !== newCols || oldRows !== newRows) {
				this.columns = newCols;
				this.rows = newRows;
				this.emit("resize");
			}
		}
		cursorTo(x, y, callback) {
			return cursorTo(this, x, y, callback);
		}
		moveCursor(dx, dy, callback) {
			return moveCursor(this, dx, dy, callback);
		}
		clearLine(dir, callback) {
			return clearLine(this, dir, callback);
		}
		clearScreenDown(callback) {
			return clearScreenDown(this, callback);
		}
		getWindowSize() {
			return [this.columns, this.rows];
		}
	}
	Object.defineProperty(WriteStream.prototype, "isTTY", {
		value: true,
		writable: true,
		enumerable: true,
		configurable: true
	});
	enumerable(ReadStream.prototype, ["setRawMode"]);
	enumerable(WriteStream.prototype, [
		"getColorDepth",
		"hasColors",
		"_refreshSize",
		"cursorTo",
		"moveCursor",
		"clearLine",
		"clearScreenDown",
		"getWindowSize"
	]);
	return {
		isatty,
		ReadStream: constructible(ReadStream),
		WriteStream: constructible(WriteStream)
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tty.js
const tty = createTty(tty_host_exports);
const { isatty, ReadStream, WriteStream } = tty;
//#endregion
export { ReadStream, WriteStream, tty as default, isatty };
