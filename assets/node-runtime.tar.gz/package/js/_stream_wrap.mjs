//#region src/stream-wrap.mjs
const unsupported = () => {
	throw Object.assign(/* @__PURE__ */ new Error("node:_stream_wrap is a stub: it wraps Node's internal stream handles, which a component does not have"), { code: "ERR_NOT_SUPPORTED" });
};
var StreamWrap = class {
	constructor() {
		unsupported();
	}
};
//#endregion
export { StreamWrap, StreamWrap as default };
