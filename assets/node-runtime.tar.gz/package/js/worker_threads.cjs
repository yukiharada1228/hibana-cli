module.exports = require('./worker_threads.mjs').default;
