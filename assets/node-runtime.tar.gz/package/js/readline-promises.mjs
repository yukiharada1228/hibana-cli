import { i as Readline, n as createInterface, r as promises, t as Interface } from "./chunks/promises-BYqWMSui.mjs";
export { Interface, Readline, createInterface, promises as default };
