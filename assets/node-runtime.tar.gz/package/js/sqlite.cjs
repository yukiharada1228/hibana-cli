module.exports = require('./sqlite.mjs').default;
