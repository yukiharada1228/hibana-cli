module.exports = require('./assert.mjs').default;
