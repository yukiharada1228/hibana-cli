import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import "./chunks/core-DGqXzKN-.mjs";
import { Buffer } from "./buffer.mjs";
import { t as EventEmitter } from "./chunks/event-emitter-D4b0qsct.mjs";
import "./chunks/ip-DlsRrJdq.mjs";
import { t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import { n as OutgoingMessage, r as IncomingMessage, s as bodyBytes, t as parseListenArguments } from "./chunks/net-server-BNP7dcFI.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tls-host.js
var tls_host_exports = /* @__PURE__ */ __exportAll({
	ClientConnection: () => ClientConnection,
	ClientHandshake: () => ClientHandshake,
	FutureClientStreams: () => FutureClientStreams,
	isAvailable: () => isAvailable$1
});
/** Deny-by-default TLS capability; importing this module performs no IO. */
function denied$1() {
	throw Object.assign(/* @__PURE__ */ new Error("HTTPS over wasi:sockets requires an explicitly configured wasi:tls/types@0.2.0-draft host provider"), { code: "ERR_JCO_TLS_ADAPTER_REQUIRED" });
}
var ClientHandshake = class {
	constructor(_serverName, _input, _output) {
		denied$1();
	}
	static finish(_handshake) {
		return denied$1();
	}
};
var ClientConnection = class {
	closeOutput() {
		return denied$1();
	}
};
var FutureClientStreams = class {
	get() {
		return denied$1();
	}
	subscribe() {
		return denied$1();
	}
};
/** Availability query in Jco's local TLS contract. */
function isAvailable$1() {
	return false;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/errors.js
function codedError(name, code, message) {
	const error = name === "TypeError" ? new TypeError(message) : name === "RangeError" ? new RangeError(message) : new Error(message);
	error.name = name;
	return Object.assign(error, { code });
}
function invalidArgType(name, expected, value) {
	return codedError("TypeError", "ERR_INVALID_ARG_TYPE", `The "${name}" argument must be of type ${expected}. Received ${String(value)}`);
}
function invalidSetting(name, value) {
	return codedError("TypeError", "ERR_HTTP2_INVALID_SETTING_VALUE", `Invalid value for setting "${name}": ${String(value)}`);
}
function invalidPackedSettingsLength() {
	return codedError("RangeError", "ERR_HTTP2_INVALID_PACKED_SETTINGS_LENGTH", "Packed settings length must be a multiple of six");
}
function adapterRequired() {
	throw codedError("Error", "ERR_JCO_HTTP2_ADAPTER_REQUIRED", "node:http2 requires an HTTP/2 provider; map jco:node/http2@0.1.0 to an application host");
}
function unsupported(api, detail) {
	throw codedError("Error", "ERR_JCO_UNSUPPORTED_NODE_API", `${api} is not supported by the Jco component runtime${detail ? `: ${detail}` : ""}`);
}
function deprecated(api, replacement) {
	throw codedError("Error", "ERR_JCO_UNSUPPORTED_DEPRECATED_NODE_API", `${api} is deprecated and not supported by the Jco component runtime; use ${replacement} instead`);
}
function fromImplementationError(value) {
	const error = codedError(value.name === "TypeError" || value.name === "RangeError" ? value.name : "Error", value.code ?? "ERR_JCO_HTTP2_IMPLEMENTATION", value.message);
	error.errno = value.errno?.tag === "number" ? Number(value.errno.val) : value.errno?.val;
	error.syscall = value.syscall;
	error.hostname = value.hostname;
	error.address = value.address;
	error.port = value.port;
	return error;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2-host.js
var http2_host_exports = /* @__PURE__ */ __exportAll({
	ClientSession: () => ClientSession,
	Server: () => Server,
	default: () => http2_host_default
});
const ClientSession = class ClientSession {
	constructor() {
		adapterRequired();
	}
};
const Server = class Server {
	constructor() {
		adapterRequired();
	}
};
var http2_host_default = {
	ClientSession,
	Server
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/constants.js
/**
* HTTP/2 constants from Node.js v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae (MIT license), exposed by
* lib/internal/http2/core.js through the native nghttp2 binding.
*
* These values were captured from that exact runtime and checked against
* unenv@2.0.0-rc.24's generated constant table. No native behavior is copied.
*/
const constants$1 = {
	NGHTTP2_ERR_FRAME_SIZE_ERROR: -522,
	NGHTTP2_SESSION_SERVER: 0,
	NGHTTP2_SESSION_CLIENT: 1,
	NGHTTP2_STREAM_STATE_IDLE: 1,
	NGHTTP2_STREAM_STATE_OPEN: 2,
	NGHTTP2_STREAM_STATE_RESERVED_LOCAL: 3,
	NGHTTP2_STREAM_STATE_RESERVED_REMOTE: 4,
	NGHTTP2_STREAM_STATE_HALF_CLOSED_LOCAL: 5,
	NGHTTP2_STREAM_STATE_HALF_CLOSED_REMOTE: 6,
	NGHTTP2_STREAM_STATE_CLOSED: 7,
	NGHTTP2_FLAG_NONE: 0,
	NGHTTP2_FLAG_END_STREAM: 1,
	NGHTTP2_FLAG_END_HEADERS: 4,
	NGHTTP2_FLAG_ACK: 1,
	NGHTTP2_FLAG_PADDED: 8,
	NGHTTP2_FLAG_PRIORITY: 32,
	DEFAULT_SETTINGS_HEADER_TABLE_SIZE: 4096,
	DEFAULT_SETTINGS_ENABLE_PUSH: 1,
	DEFAULT_SETTINGS_MAX_CONCURRENT_STREAMS: 4294967295,
	DEFAULT_SETTINGS_INITIAL_WINDOW_SIZE: 65535,
	DEFAULT_SETTINGS_MAX_FRAME_SIZE: 16384,
	DEFAULT_SETTINGS_MAX_HEADER_LIST_SIZE: 65535,
	DEFAULT_SETTINGS_ENABLE_CONNECT_PROTOCOL: 0,
	MAX_MAX_FRAME_SIZE: 16777215,
	MIN_MAX_FRAME_SIZE: 16384,
	MAX_INITIAL_WINDOW_SIZE: 2147483647,
	NGHTTP2_SETTINGS_HEADER_TABLE_SIZE: 1,
	NGHTTP2_SETTINGS_ENABLE_PUSH: 2,
	NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS: 3,
	NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE: 4,
	NGHTTP2_SETTINGS_MAX_FRAME_SIZE: 5,
	NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE: 6,
	NGHTTP2_SETTINGS_ENABLE_CONNECT_PROTOCOL: 8,
	PADDING_STRATEGY_NONE: 0,
	PADDING_STRATEGY_ALIGNED: 1,
	PADDING_STRATEGY_MAX: 2,
	PADDING_STRATEGY_CALLBACK: 1,
	NGHTTP2_NO_ERROR: 0,
	NGHTTP2_PROTOCOL_ERROR: 1,
	NGHTTP2_INTERNAL_ERROR: 2,
	NGHTTP2_FLOW_CONTROL_ERROR: 3,
	NGHTTP2_SETTINGS_TIMEOUT: 4,
	NGHTTP2_STREAM_CLOSED: 5,
	NGHTTP2_FRAME_SIZE_ERROR: 6,
	NGHTTP2_REFUSED_STREAM: 7,
	NGHTTP2_CANCEL: 8,
	NGHTTP2_COMPRESSION_ERROR: 9,
	NGHTTP2_CONNECT_ERROR: 10,
	NGHTTP2_ENHANCE_YOUR_CALM: 11,
	NGHTTP2_INADEQUATE_SECURITY: 12,
	NGHTTP2_HTTP_1_1_REQUIRED: 13,
	NGHTTP2_DEFAULT_WEIGHT: 16,
	HTTP2_HEADER_STATUS: ":status",
	HTTP2_HEADER_METHOD: ":method",
	HTTP2_HEADER_AUTHORITY: ":authority",
	HTTP2_HEADER_SCHEME: ":scheme",
	HTTP2_HEADER_PATH: ":path",
	HTTP2_HEADER_PROTOCOL: ":protocol",
	HTTP2_HEADER_ACCEPT_ENCODING: "accept-encoding",
	HTTP2_HEADER_ACCEPT_LANGUAGE: "accept-language",
	HTTP2_HEADER_ACCEPT_RANGES: "accept-ranges",
	HTTP2_HEADER_ACCEPT: "accept",
	HTTP2_HEADER_ACCESS_CONTROL_ALLOW_CREDENTIALS: "access-control-allow-credentials",
	HTTP2_HEADER_ACCESS_CONTROL_ALLOW_HEADERS: "access-control-allow-headers",
	HTTP2_HEADER_ACCESS_CONTROL_ALLOW_METHODS: "access-control-allow-methods",
	HTTP2_HEADER_ACCESS_CONTROL_ALLOW_ORIGIN: "access-control-allow-origin",
	HTTP2_HEADER_ACCESS_CONTROL_EXPOSE_HEADERS: "access-control-expose-headers",
	HTTP2_HEADER_ACCESS_CONTROL_REQUEST_HEADERS: "access-control-request-headers",
	HTTP2_HEADER_ACCESS_CONTROL_REQUEST_METHOD: "access-control-request-method",
	HTTP2_HEADER_AGE: "age",
	HTTP2_HEADER_AUTHORIZATION: "authorization",
	HTTP2_HEADER_CACHE_CONTROL: "cache-control",
	HTTP2_HEADER_CONNECTION: "connection",
	HTTP2_HEADER_CONTENT_DISPOSITION: "content-disposition",
	HTTP2_HEADER_CONTENT_ENCODING: "content-encoding",
	HTTP2_HEADER_CONTENT_LENGTH: "content-length",
	HTTP2_HEADER_CONTENT_TYPE: "content-type",
	HTTP2_HEADER_COOKIE: "cookie",
	HTTP2_HEADER_DATE: "date",
	HTTP2_HEADER_ETAG: "etag",
	HTTP2_HEADER_FORWARDED: "forwarded",
	HTTP2_HEADER_HOST: "host",
	HTTP2_HEADER_IF_MODIFIED_SINCE: "if-modified-since",
	HTTP2_HEADER_IF_NONE_MATCH: "if-none-match",
	HTTP2_HEADER_IF_RANGE: "if-range",
	HTTP2_HEADER_LAST_MODIFIED: "last-modified",
	HTTP2_HEADER_LINK: "link",
	HTTP2_HEADER_LOCATION: "location",
	HTTP2_HEADER_RANGE: "range",
	HTTP2_HEADER_REFERER: "referer",
	HTTP2_HEADER_SERVER: "server",
	HTTP2_HEADER_SET_COOKIE: "set-cookie",
	HTTP2_HEADER_STRICT_TRANSPORT_SECURITY: "strict-transport-security",
	HTTP2_HEADER_TRANSFER_ENCODING: "transfer-encoding",
	HTTP2_HEADER_TE: "te",
	HTTP2_HEADER_UPGRADE_INSECURE_REQUESTS: "upgrade-insecure-requests",
	HTTP2_HEADER_UPGRADE: "upgrade",
	HTTP2_HEADER_USER_AGENT: "user-agent",
	HTTP2_HEADER_VARY: "vary",
	HTTP2_HEADER_X_CONTENT_TYPE_OPTIONS: "x-content-type-options",
	HTTP2_HEADER_X_FRAME_OPTIONS: "x-frame-options",
	HTTP2_HEADER_KEEP_ALIVE: "keep-alive",
	HTTP2_HEADER_PROXY_CONNECTION: "proxy-connection",
	HTTP2_HEADER_X_XSS_PROTECTION: "x-xss-protection",
	HTTP2_HEADER_ALT_SVC: "alt-svc",
	HTTP2_HEADER_CONTENT_SECURITY_POLICY: "content-security-policy",
	HTTP2_HEADER_EARLY_DATA: "early-data",
	HTTP2_HEADER_EXPECT_CT: "expect-ct",
	HTTP2_HEADER_ORIGIN: "origin",
	HTTP2_HEADER_PURPOSE: "purpose",
	HTTP2_HEADER_TIMING_ALLOW_ORIGIN: "timing-allow-origin",
	HTTP2_HEADER_X_FORWARDED_FOR: "x-forwarded-for",
	HTTP2_HEADER_PRIORITY: "priority",
	HTTP2_HEADER_ACCEPT_CHARSET: "accept-charset",
	HTTP2_HEADER_ACCESS_CONTROL_MAX_AGE: "access-control-max-age",
	HTTP2_HEADER_ALLOW: "allow",
	HTTP2_HEADER_CONTENT_LANGUAGE: "content-language",
	HTTP2_HEADER_CONTENT_LOCATION: "content-location",
	HTTP2_HEADER_CONTENT_MD5: "content-md5",
	HTTP2_HEADER_CONTENT_RANGE: "content-range",
	HTTP2_HEADER_DNT: "dnt",
	HTTP2_HEADER_EXPECT: "expect",
	HTTP2_HEADER_EXPIRES: "expires",
	HTTP2_HEADER_FROM: "from",
	HTTP2_HEADER_IF_MATCH: "if-match",
	HTTP2_HEADER_IF_UNMODIFIED_SINCE: "if-unmodified-since",
	HTTP2_HEADER_MAX_FORWARDS: "max-forwards",
	HTTP2_HEADER_PREFER: "prefer",
	HTTP2_HEADER_PROXY_AUTHENTICATE: "proxy-authenticate",
	HTTP2_HEADER_PROXY_AUTHORIZATION: "proxy-authorization",
	HTTP2_HEADER_REFRESH: "refresh",
	HTTP2_HEADER_RETRY_AFTER: "retry-after",
	HTTP2_HEADER_TRAILER: "trailer",
	HTTP2_HEADER_TK: "tk",
	HTTP2_HEADER_VIA: "via",
	HTTP2_HEADER_WARNING: "warning",
	HTTP2_HEADER_WWW_AUTHENTICATE: "www-authenticate",
	HTTP2_HEADER_HTTP2_SETTINGS: "http2-settings",
	HTTP2_METHOD_ACL: "ACL",
	HTTP2_METHOD_BASELINE_CONTROL: "BASELINE-CONTROL",
	HTTP2_METHOD_BIND: "BIND",
	HTTP2_METHOD_CHECKIN: "CHECKIN",
	HTTP2_METHOD_CHECKOUT: "CHECKOUT",
	HTTP2_METHOD_CONNECT: "CONNECT",
	HTTP2_METHOD_COPY: "COPY",
	HTTP2_METHOD_DELETE: "DELETE",
	HTTP2_METHOD_GET: "GET",
	HTTP2_METHOD_HEAD: "HEAD",
	HTTP2_METHOD_LABEL: "LABEL",
	HTTP2_METHOD_LINK: "LINK",
	HTTP2_METHOD_LOCK: "LOCK",
	HTTP2_METHOD_MERGE: "MERGE",
	HTTP2_METHOD_MKACTIVITY: "MKACTIVITY",
	HTTP2_METHOD_MKCALENDAR: "MKCALENDAR",
	HTTP2_METHOD_MKCOL: "MKCOL",
	HTTP2_METHOD_MKREDIRECTREF: "MKREDIRECTREF",
	HTTP2_METHOD_MKWORKSPACE: "MKWORKSPACE",
	HTTP2_METHOD_MOVE: "MOVE",
	HTTP2_METHOD_OPTIONS: "OPTIONS",
	HTTP2_METHOD_ORDERPATCH: "ORDERPATCH",
	HTTP2_METHOD_PATCH: "PATCH",
	HTTP2_METHOD_POST: "POST",
	HTTP2_METHOD_PRI: "PRI",
	HTTP2_METHOD_PROPFIND: "PROPFIND",
	HTTP2_METHOD_PROPPATCH: "PROPPATCH",
	HTTP2_METHOD_PUT: "PUT",
	HTTP2_METHOD_REBIND: "REBIND",
	HTTP2_METHOD_REPORT: "REPORT",
	HTTP2_METHOD_SEARCH: "SEARCH",
	HTTP2_METHOD_TRACE: "TRACE",
	HTTP2_METHOD_UNBIND: "UNBIND",
	HTTP2_METHOD_UNCHECKOUT: "UNCHECKOUT",
	HTTP2_METHOD_UNLINK: "UNLINK",
	HTTP2_METHOD_UNLOCK: "UNLOCK",
	HTTP2_METHOD_UPDATE: "UPDATE",
	HTTP2_METHOD_UPDATEREDIRECTREF: "UPDATEREDIRECTREF",
	HTTP2_METHOD_VERSION_CONTROL: "VERSION-CONTROL",
	HTTP_STATUS_CONTINUE: 100,
	HTTP_STATUS_SWITCHING_PROTOCOLS: 101,
	HTTP_STATUS_PROCESSING: 102,
	HTTP_STATUS_EARLY_HINTS: 103,
	HTTP_STATUS_OK: 200,
	HTTP_STATUS_CREATED: 201,
	HTTP_STATUS_ACCEPTED: 202,
	HTTP_STATUS_NON_AUTHORITATIVE_INFORMATION: 203,
	HTTP_STATUS_NO_CONTENT: 204,
	HTTP_STATUS_RESET_CONTENT: 205,
	HTTP_STATUS_PARTIAL_CONTENT: 206,
	HTTP_STATUS_MULTI_STATUS: 207,
	HTTP_STATUS_ALREADY_REPORTED: 208,
	HTTP_STATUS_IM_USED: 226,
	HTTP_STATUS_MULTIPLE_CHOICES: 300,
	HTTP_STATUS_MOVED_PERMANENTLY: 301,
	HTTP_STATUS_FOUND: 302,
	HTTP_STATUS_SEE_OTHER: 303,
	HTTP_STATUS_NOT_MODIFIED: 304,
	HTTP_STATUS_USE_PROXY: 305,
	HTTP_STATUS_TEMPORARY_REDIRECT: 307,
	HTTP_STATUS_PERMANENT_REDIRECT: 308,
	HTTP_STATUS_BAD_REQUEST: 400,
	HTTP_STATUS_UNAUTHORIZED: 401,
	HTTP_STATUS_PAYMENT_REQUIRED: 402,
	HTTP_STATUS_FORBIDDEN: 403,
	HTTP_STATUS_NOT_FOUND: 404,
	HTTP_STATUS_METHOD_NOT_ALLOWED: 405,
	HTTP_STATUS_NOT_ACCEPTABLE: 406,
	HTTP_STATUS_PROXY_AUTHENTICATION_REQUIRED: 407,
	HTTP_STATUS_REQUEST_TIMEOUT: 408,
	HTTP_STATUS_CONFLICT: 409,
	HTTP_STATUS_GONE: 410,
	HTTP_STATUS_LENGTH_REQUIRED: 411,
	HTTP_STATUS_PRECONDITION_FAILED: 412,
	HTTP_STATUS_PAYLOAD_TOO_LARGE: 413,
	HTTP_STATUS_URI_TOO_LONG: 414,
	HTTP_STATUS_UNSUPPORTED_MEDIA_TYPE: 415,
	HTTP_STATUS_RANGE_NOT_SATISFIABLE: 416,
	HTTP_STATUS_EXPECTATION_FAILED: 417,
	HTTP_STATUS_TEAPOT: 418,
	HTTP_STATUS_MISDIRECTED_REQUEST: 421,
	HTTP_STATUS_UNPROCESSABLE_ENTITY: 422,
	HTTP_STATUS_LOCKED: 423,
	HTTP_STATUS_FAILED_DEPENDENCY: 424,
	HTTP_STATUS_TOO_EARLY: 425,
	HTTP_STATUS_UPGRADE_REQUIRED: 426,
	HTTP_STATUS_PRECONDITION_REQUIRED: 428,
	HTTP_STATUS_TOO_MANY_REQUESTS: 429,
	HTTP_STATUS_REQUEST_HEADER_FIELDS_TOO_LARGE: 431,
	HTTP_STATUS_UNAVAILABLE_FOR_LEGAL_REASONS: 451,
	HTTP_STATUS_INTERNAL_SERVER_ERROR: 500,
	HTTP_STATUS_NOT_IMPLEMENTED: 501,
	HTTP_STATUS_BAD_GATEWAY: 502,
	HTTP_STATUS_SERVICE_UNAVAILABLE: 503,
	HTTP_STATUS_GATEWAY_TIMEOUT: 504,
	HTTP_STATUS_HTTP_VERSION_NOT_SUPPORTED: 505,
	HTTP_STATUS_VARIANT_ALSO_NEGOTIATES: 506,
	HTTP_STATUS_INSUFFICIENT_STORAGE: 507,
	HTTP_STATUS_LOOP_DETECTED: 508,
	HTTP_STATUS_BANDWIDTH_LIMIT_EXCEEDED: 509,
	HTTP_STATUS_NOT_EXTENDED: 510,
	HTTP_STATUS_NETWORK_AUTHENTICATION_REQUIRED: 511
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/headers.js
const PSEUDO_HEADERS = /* @__PURE__ */ new Set([
	":authority",
	":method",
	":path",
	":protocol",
	":scheme",
	":status"
]);
const TOKEN = /^[!#$%&'*+\-.^_`|~0-9a-z]+$/;
const INVALID_VALUE = /[\0\r\n]/;
function validateName(name) {
	if (typeof name !== "string") throw invalidArgType("header name", "string", name);
	const lower = name.toLowerCase();
	if (!(PSEUDO_HEADERS.has(lower) || TOKEN.test(lower))) {
		const error = /* @__PURE__ */ new TypeError(`Header name must be a valid HTTP token ["${name}"]`);
		Object.assign(error, { code: "ERR_INVALID_HTTP_TOKEN" });
		throw error;
	}
	return lower;
}
function strings(value) {
	return (Array.isArray(value) ? value : [value]).map(String);
}
function headersToFields(headers = {}) {
	const entries = [];
	if (Array.isArray(headers)) {
		if (headers.length % 2 !== 0) throw invalidArgType("headers", "an even-length array", headers);
		for (let index = 0; index < headers.length; index += 2) entries.push([headers[index], headers[index + 1]]);
	} else for (const [name, value] of Object.entries(headers)) if (value !== void 0) entries.push([name, value]);
	return entries.flatMap(([name, value]) => {
		const lower = validateName(name);
		return strings(value).map((item) => {
			if (INVALID_VALUE.test(item)) {
				const error = /* @__PURE__ */ new TypeError(`Invalid character in header content ["${name}"]`);
				Object.assign(error, { code: "ERR_INVALID_CHAR" });
				throw error;
			}
			return {
				name: lower,
				value: Uint8Array.from(item, (character) => character.charCodeAt(0) & 255)
			};
		});
	});
}
function fieldsToHeaders(fields) {
	const decoder = new TextDecoder("latin1");
	const headers = Object.create(null);
	const rawHeaders = [];
	for (const { name, value } of fields) {
		const text = decoder.decode(value);
		rawHeaders.push(name, text);
		const current = headers[name];
		if (current === void 0) headers[name] = name === "set-cookie" ? [text] : name === ":status" ? Number(text) : text;
		else if (name === "set-cookie") headers[name] = [...Array.isArray(current) ? current : [String(current)], text];
		else headers[name] = `${Array.isArray(current) ? current.join(", ") : current}, ${text}`;
	}
	return {
		headers,
		rawHeaders
	};
}
/** Validate trailers before they reach a host or are encoded as HTTP/2 frames. */
function trailersToFields(headers) {
	if (typeof headers !== "object" || headers === null || Array.isArray(headers)) throw invalidArgType("headers", "object", headers);
	const fields = headersToFields(headers);
	for (const { name } of fields) {
		if (name.startsWith(":")) throw codedError("TypeError", "ERR_HTTP2_INVALID_PSEUDOHEADER", `"${name}" is an invalid pseudoheader or is used incorrectly`);
		if ([
			"connection",
			"keep-alive",
			"proxy-connection",
			"transfer-encoding",
			"upgrade"
		].includes(name)) throw codedError("TypeError", "ERR_HTTP2_INVALID_CONNECTION_HEADERS", "HTTP/1 Connection specific headers are forbidden: " + name);
	}
	return fields;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/settings.js
/**
* Settings packing follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/internal/http2/core.js and
* lib/internal/http2/util.js (MIT license). Native buffer state is replaced by
* a portable RFC 9113 six-byte SETTINGS payload implementation.
*/
const settingIds = {
	headerTableSize: constants$1.NGHTTP2_SETTINGS_HEADER_TABLE_SIZE,
	enablePush: constants$1.NGHTTP2_SETTINGS_ENABLE_PUSH,
	maxConcurrentStreams: constants$1.NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS,
	initialWindowSize: constants$1.NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE,
	maxFrameSize: constants$1.NGHTTP2_SETTINGS_MAX_FRAME_SIZE,
	maxHeaderListSize: constants$1.NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE,
	enableConnectProtocol: constants$1.NGHTTP2_SETTINGS_ENABLE_CONNECT_PROTOCOL
};
function validateNumber(name, value) {
	const minimum = name === "maxFrameSize" ? constants$1.MIN_MAX_FRAME_SIZE : 0;
	const maximum = name === "initialWindowSize" ? constants$1.MAX_INITIAL_WINDOW_SIZE : name === "maxFrameSize" ? constants$1.MAX_MAX_FRAME_SIZE : 4294967295;
	if (typeof value !== "number" || !Number.isFinite(value) || value < minimum || value > maximum) throw invalidSetting(name, value);
	return Math.trunc(value);
}
function validateBoolean(name, value) {
	if (typeof value !== "boolean") throw invalidSetting(name, value);
	return value;
}
function validateSettings(settings) {
	if (typeof settings !== "object" || settings === null) throw invalidArgType("settings", "object", settings);
	const result = {};
	for (const name of [
		"headerTableSize",
		"initialWindowSize",
		"maxFrameSize",
		"maxConcurrentStreams",
		"maxHeaderListSize"
	]) if (settings[name] !== void 0) result[name] = validateNumber(name, settings[name]);
	if (settings.maxHeaderSize !== void 0) result.maxHeaderListSize = validateNumber("maxHeaderListSize", settings.maxHeaderSize);
	for (const name of ["enablePush", "enableConnectProtocol"]) if (settings[name] !== void 0) result[name] = validateBoolean(name, settings[name]);
	if (settings.customSettings !== void 0) {
		if (typeof settings.customSettings !== "object" || settings.customSettings === null) throw invalidSetting("customSettings", settings.customSettings);
		result.customSettings = {};
		for (const [idText, rawValue] of Object.entries(settings.customSettings)) {
			const id = Number(idText);
			if (!Number.isInteger(id) || id < 1 || id > 65535) throw invalidSetting(`customSettings.${idText}`, rawValue);
			const value = validateNumber("headerTableSize", rawValue);
			if (value === 0) throw invalidSetting(`customSettings.${idText}`, rawValue);
			result.customSettings[id] = value;
		}
	}
	return result;
}
function getDefaultSettings$1() {
	return Object.assign(Object.create(null), {
		headerTableSize: constants$1.DEFAULT_SETTINGS_HEADER_TABLE_SIZE,
		enablePush: Boolean(constants$1.DEFAULT_SETTINGS_ENABLE_PUSH),
		initialWindowSize: constants$1.DEFAULT_SETTINGS_INITIAL_WINDOW_SIZE,
		maxFrameSize: constants$1.DEFAULT_SETTINGS_MAX_FRAME_SIZE,
		maxConcurrentStreams: constants$1.DEFAULT_SETTINGS_MAX_CONCURRENT_STREAMS,
		maxHeaderSize: constants$1.DEFAULT_SETTINGS_MAX_HEADER_LIST_SIZE,
		maxHeaderListSize: constants$1.DEFAULT_SETTINGS_MAX_HEADER_LIST_SIZE,
		enableConnectProtocol: Boolean(constants$1.DEFAULT_SETTINGS_ENABLE_CONNECT_PROTOCOL)
	});
}
function entries(settings) {
	const value = validateSettings(settings);
	const result = [];
	for (const name of Object.keys(settingIds)) {
		const setting = value[name];
		if (setting !== void 0) result.push([settingIds[name], typeof setting === "boolean" ? Number(setting) : setting]);
	}
	for (const [id, setting] of Object.entries(value.customSettings ?? {})) {
		const numericId = Number(id);
		if (!result.some(([known]) => known === numericId)) result.push([numericId, setting]);
	}
	return result.sort(([left], [right]) => left - right);
}
function getPackedSettings$1(settings = {}) {
	const values = entries(settings);
	const packed = new Uint8Array(values.length * 6);
	const view = new DataView(packed.buffer);
	values.forEach(([id, value], index) => {
		view.setUint16(index * 6, id);
		view.setUint32(index * 6 + 2, value);
	});
	return Buffer.from(packed);
}
function getUnpackedSettings$1(buffer) {
	if (!ArrayBuffer.isView(buffer) || !("length" in buffer)) throw invalidArgType("buf", "Buffer or TypedArray", buffer);
	if (buffer.byteLength % 6 !== 0) throw invalidPackedSettingsLength();
	const settings = {};
	const customSettings = {};
	const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
	for (let offset = 0; offset < buffer.byteLength; offset += 6) {
		const id = view.getUint16(offset);
		const value = view.getUint32(offset + 2);
		switch (id) {
			case constants$1.NGHTTP2_SETTINGS_HEADER_TABLE_SIZE:
				settings.headerTableSize = value;
				break;
			case constants$1.NGHTTP2_SETTINGS_ENABLE_PUSH:
				settings.enablePush = value !== 0;
				break;
			case constants$1.NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS:
				settings.maxConcurrentStreams = value;
				break;
			case constants$1.NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE:
				settings.initialWindowSize = value;
				break;
			case constants$1.NGHTTP2_SETTINGS_MAX_FRAME_SIZE:
				settings.maxFrameSize = value;
				break;
			case constants$1.NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE:
				settings.maxHeaderListSize = value;
				settings.maxHeaderSize = value;
				break;
			case constants$1.NGHTTP2_SETTINGS_ENABLE_CONNECT_PROTOCOL:
				settings.enableConnectProtocol = value !== 0;
				break;
			default: customSettings[id] = value;
		}
	}
	if (Object.keys(customSettings).length > 0) settings.customSettings = customSettings;
	return settings;
}
function toDirectSettings(settings = {}) {
	const value = validateSettings(settings);
	return {
		headerTableSize: value.headerTableSize,
		enablePush: value.enablePush,
		initialWindowSize: value.initialWindowSize,
		maxFrameSize: value.maxFrameSize,
		maxConcurrentStreams: value.maxConcurrentStreams,
		maxHeaderListSize: value.maxHeaderListSize,
		enableConnectProtocol: value.enableConnectProtocol,
		customSettings: Object.entries(value.customSettings ?? {}).map(([id, setting]) => ({
			id: Number(id),
			value: setting
		}))
	};
}
function fromDirectSettings(settings) {
	const result = {
		headerTableSize: settings.headerTableSize,
		enablePush: settings.enablePush,
		initialWindowSize: settings.initialWindowSize,
		maxFrameSize: settings.maxFrameSize,
		maxConcurrentStreams: settings.maxConcurrentStreams,
		maxHeaderListSize: settings.maxHeaderListSize,
		maxHeaderSize: settings.maxHeaderListSize,
		enableConnectProtocol: settings.enableConnectProtocol
	};
	if (settings.customSettings.length > 0) result.customSettings = Object.fromEntries(settings.customSettings.map(({ id, value }) => [id, value]));
	return result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/stream.js
function createAccumulator() {
	let resolve;
	const completed = new Promise((done) => {
		resolve = done;
	});
	return {
		headers: void 0,
		trailers: void 0,
		chunks: [],
		ended: false,
		complete() {
			return completed;
		},
		finish() {
			const size = this.chunks.reduce((total, chunk) => total + chunk.byteLength, 0);
			const body = new Uint8Array(size);
			let offset = 0;
			for (const chunk of this.chunks) {
				body.set(chunk, offset);
				offset += chunk.byteLength;
			}
			resolve({
				headers: headersToFields(this.headers ?? { ":status": 200 }),
				trailers: trailersToFields(this.trailers ?? {}),
				body
			});
		}
	};
}
var Http2StreamBase = class extends EventEmitter {
	aborted = false;
	closed = false;
	destroyed = false;
	endAfterHeaders = false;
	pending = false;
	rstCode = constants$1.NGHTTP2_NO_ERROR;
	id;
	sentHeaders;
	sentInfoHeaders;
	sentTrailers;
	session;
	encoding;
	constructor(id, headers, session) {
		super();
		this.id = id;
		this.sentHeaders = headers;
		this.session = session;
	}
	get bufferSize() {
		return 0;
	}
	get state() {
		return unsupported("http2.Http2Stream.state", "server stream state is not exposed by the buffered callback boundary");
	}
	setEncoding(encoding) {
		this.encoding = encoding;
		return this;
	}
	priority(_options) {
		return deprecated("http2.Http2Stream.priority", "RFC 9218 extensible priorities");
	}
	setTimeout(milliseconds, callback) {
		if (milliseconds !== 0 || callback !== void 0) unsupported("http2.Http2Stream.setTimeout", "timeout callbacks cannot be retained across the typed component boundary");
		return this;
	}
	sendTrailers(_headers) {
		return unsupported("http2.Http2Stream.sendTrailers", "the buffered component boundary completes a stream in one response");
	}
};
var ClientHttp2Stream = class extends Http2StreamBase {
	#implementation;
	#ended = false;
	#body;
	readable = true;
	readableEnded = false;
	writable = true;
	writableEnded = false;
	writableFinished = false;
	constructor(implementation, headers, session) {
		super(implementation.id(), headers, session);
		this.#implementation = implementation;
	}
	get state() {
		return this.#implementation.state();
	}
	write(chunk, encodingOrCallback, callback) {
		if (this.#ended) throw codedError("Error", "ERR_STREAM_WRITE_AFTER_END", "write after end");
		const encoding = typeof encodingOrCallback === "string" ? encodingOrCallback : "utf8";
		const written = this.#implementation.write(bodyBytes(chunk, encoding));
		const done = typeof encodingOrCallback === "function" ? encodingOrCallback : callback;
		if (done) queueMicrotask(() => done());
		return written;
	}
	end(chunkOrCallback, encodingOrCallback, callback) {
		if (this.#ended) return this;
		const chunk = typeof chunkOrCallback === "function" ? void 0 : chunkOrCallback;
		const done = typeof chunkOrCallback === "function" ? chunkOrCallback : typeof encodingOrCallback === "function" ? encodingOrCallback : callback;
		if (chunk !== void 0) this.write(chunk, typeof encodingOrCallback === "string" ? encodingOrCallback : void 0);
		this.#ended = true;
		this.writable = false;
		this.writableEnded = true;
		try {
			const response = this.#implementation.finish();
			this.#acceptResponse(response, done);
		} catch (error) {
			const value = error instanceof Error ? error : new Error(String(error));
			queueMicrotask(() => {
				this.destroyed = true;
				this.emit("error", value);
				this.closed = true;
				this.emit("close");
				done?.(value);
			});
		}
		return this;
	}
	read() {
		if (!this.#body) return null;
		const value = this.#decode(this.#body);
		this.#body = void 0;
		return value;
	}
	close(code = constants$1.NGHTTP2_NO_ERROR, callback) {
		this.#implementation.close(code);
		this.rstCode = code;
		this.closed = true;
		queueMicrotask(() => {
			this.emit("close");
			callback?.();
		});
	}
	destroy(error) {
		if (this.destroyed) return this;
		this.destroyed = true;
		this.#implementation.close(error ? constants$1.NGHTTP2_INTERNAL_ERROR : constants$1.NGHTTP2_NO_ERROR);
		queueMicrotask(() => {
			if (error) this.emit("error", error);
			this.closed = true;
			this.emit("close");
		});
		return this;
	}
	#acceptResponse(response, callback) {
		const { headers, rawHeaders } = fieldsToHeaders(response.headers);
		const { headers: trailers } = fieldsToHeaders(response.trailers);
		this.#body = response.body.slice();
		queueMicrotask(() => {
			this.emit("response", headers, constants$1.NGHTTP2_FLAG_END_HEADERS, rawHeaders);
			if (response.body.byteLength > 0) {
				this.emit("data", this.#decode(response.body));
				this.#body = void 0;
			}
			if (response.trailers.length > 0) this.emit("trailers", trailers, constants$1.NGHTTP2_FLAG_END_HEADERS);
			this.readable = false;
			this.readableEnded = true;
			this.writableFinished = true;
			this.emit("finish");
			callback?.();
			this.emit("end");
			this.closed = true;
			this.emit("close");
		});
	}
	#decode(body) {
		return this.encoding ? new TextDecoder(this.encoding).decode(body) : body.slice();
	}
};
var ServerHttp2Stream = class extends Http2StreamBase {
	incomingHeaders;
	readableEnded = false;
	#request;
	#response;
	headersSent = false;
	pushAllowed = false;
	#read = false;
	#paused = false;
	#started = false;
	#waitForTrailers = false;
	#trailersReady = false;
	constructor(request, session, response = createAccumulator()) {
		const { headers } = fieldsToHeaders(request.headers);
		super(request.id, {}, session);
		this.#request = request;
		this.#response = response;
		this.incomingHeaders = headers;
	}
	respond(headers = { ":status": 200 }, options = {}) {
		if (this.#response.headers) throw codedError("Error", "ERR_HTTP2_HEADERS_SENT", "Response has already been initiated");
		this.#response.headers = { ...headers };
		this.#waitForTrailers = Boolean(options.waitForTrailers);
		Object.assign(this, { headersSent: true });
		if (options.endStream) this.end();
	}
	additionalHeaders(_headers) {
		return unsupported("http2.ServerHttp2Stream.additionalHeaders", "informational headers cannot cross the buffered response boundary");
	}
	sendTrailers(headers) {
		if (this.destroyed || this.closed) throw codedError("Error", "ERR_HTTP2_INVALID_STREAM", "The stream has been destroyed");
		if (this.sentTrailers) throw codedError("Error", "ERR_HTTP2_TRAILERS_ALREADY_SENT", "Trailing headers have already been sent");
		if (!this.#trailersReady) throw codedError("Error", "ERR_HTTP2_TRAILERS_NOT_READY", "Trailing headers cannot be sent until after the wantTrailers event is emitted");
		trailersToFields(headers);
		const trailers = { ...headers };
		this.sentTrailers = trailers;
		this.#response.trailers = trailers;
		this.#response.finish();
		queueMicrotask(() => {
			this.closed = true;
			this.emit("close");
		});
	}
	pushStream(_headers, _options, _callback) {
		return unsupported("http2.ServerHttp2Stream.pushStream", "server push is disabled by RFC 9113");
	}
	respondWithFD(_fd, _headers, _options) {
		return unsupported("http2.ServerHttp2Stream.respondWithFD", "guest file descriptors cannot cross the component boundary");
	}
	respondWithFile(_path, _headers, _options) {
		return unsupported("http2.ServerHttp2Stream.respondWithFile", "host filesystem paths cannot be opened by the HTTP/2 provider");
	}
	write(chunk, encodingOrCallback, callback) {
		if (this.#response.ended) throw codedError("Error", "ERR_STREAM_WRITE_AFTER_END", "write after end");
		if (!this.#response.headers) this.respond();
		const encoding = typeof encodingOrCallback === "string" ? encodingOrCallback : "utf8";
		this.#response.chunks.push(bodyBytes(chunk, encoding));
		const done = typeof encodingOrCallback === "function" ? encodingOrCallback : callback;
		if (done) queueMicrotask(() => done());
		return true;
	}
	end(chunkOrCallback, encodingOrCallback, callback) {
		if (this.#response.ended) return this;
		const chunk = typeof chunkOrCallback === "function" ? void 0 : chunkOrCallback;
		const done = typeof chunkOrCallback === "function" ? chunkOrCallback : typeof encodingOrCallback === "function" ? encodingOrCallback : callback;
		if (chunk !== void 0) this.write(chunk, typeof encodingOrCallback === "string" ? encodingOrCallback : void 0);
		if (!this.#response.headers) this.respond();
		this.#response.ended = true;
		if (!this.#waitForTrailers) this.#response.finish();
		queueMicrotask(() => {
			this.emit("finish");
			done?.();
			if (this.#waitForTrailers) {
				this.#trailersReady = true;
				if (!this.emit("wantTrailers")) this.sendTrailers({});
				return;
			}
			this.closed = true;
			this.emit("close");
		});
		return this;
	}
	read() {
		if (this.#read) return null;
		this.#read = true;
		return this.#decode(this.#request.body);
	}
	resume() {
		this.#paused = false;
		this.startReading();
		this.#emitBody();
		return this;
	}
	pause() {
		this.#paused = true;
		return this;
	}
	startReading() {
		if (this.#started) return;
		this.#started = true;
		queueMicrotask(() => this.#emitBody());
	}
	response() {
		return this.#response.complete();
	}
	accumulator() {
		return this.#response;
	}
	#decode(body) {
		return this.encoding ? new TextDecoder(this.encoding).decode(body) : body.slice();
	}
	#emitBody() {
		if (!this.#started || this.#paused || this.readableEnded) return;
		if (!this.#read && this.#request.body.byteLength > 0) {
			this.#read = true;
			this.emit("data", this.#decode(this.#request.body));
		}
		this.readableEnded = true;
		this.emit("end");
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/server.js
const SUPPORTED_SERVER_OPTIONS = /* @__PURE__ */ new Set([
	"settings",
	"key",
	"cert",
	"allowHTTP1",
	"strictFieldWhitespaceValidation"
]);
const DEPRECATED_SERVER_OPTIONS = /* @__PURE__ */ new Map([["Http1IncomingMessage", "http1Options.IncomingMessage"], ["Http1ServerResponse", "http1Options.ServerResponse"]]);
function validateServerOptions(secure, options) {
	if (typeof options !== "object" || options === null) throw invalidArgType("options", "object", options);
	for (const name of Object.keys(options)) {
		const replacement = DEPRECATED_SERVER_OPTIONS.get(name);
		if (replacement) deprecated(`http2 server option ${name}`, replacement);
		if (!SUPPORTED_SERVER_OPTIONS.has(name)) unsupported(`http2 server option ${name}`, "this option cannot be represented by the typed HTTP/2 provider boundary");
	}
	if (options.settings !== void 0) validateSettings(options.settings);
	if (options.allowHTTP1) unsupported("http2 secure server option allowHTTP1", "the callback boundary accepts HTTP/2 streams only");
	if (!secure && (options.key !== void 0 || options.cert !== void 0)) unsupported("http2.createServer TLS options", "cleartext h2c servers do not use TLS keys");
	return { ...options };
}
var ServerHttp2Session = class extends EventEmitter {
	type = constants$1.NGHTTP2_SESSION_SERVER;
	server;
	encrypted;
	alpnProtocol;
	closed = false;
	destroyed = false;
	pendingSettingsAck = false;
	localSettings;
	remoteSettings;
	constructor(server, secure, settings) {
		super();
		this.server = server;
		this.encrypted = secure;
		this.alpnProtocol = secure ? "h2" : "h2c";
		this.localSettings = settings;
		this.remoteSettings = {};
	}
	get socket() {
		return unsupported("http2.Http2Session.socket", "host net.Socket and TLSSocket objects cannot cross the component boundary");
	}
	close(_callback) {
		return unsupported("http2.ServerHttp2Session.close", "the buffered callback does not own the host connection session");
	}
	destroy(_error, _code) {
		return unsupported("http2.ServerHttp2Session.destroy", "the buffered callback does not own the host connection session");
	}
	settings(_settings, _callback) {
		return unsupported("http2.ServerHttp2Session.settings", "per-connection settings are unavailable at the buffered server boundary");
	}
	ping(_payloadOrCallback) {
		return unsupported("http2.ServerHttp2Session.ping", "per-connection ping is unavailable at the buffered server boundary");
	}
	goaway(_code, _lastStreamId, _opaqueData) {
		return unsupported("http2.ServerHttp2Session.goaway", "per-connection GOAWAY is unavailable at the buffered server boundary");
	}
	setLocalWindowSize(_windowSize) {
		return unsupported("http2.ServerHttp2Session.setLocalWindowSize", "flow-control windows are owned by the host HTTP/2 implementation");
	}
	altsvc(_alt, _originOrStream) {
		return unsupported("http2.ServerHttp2Session.altsvc", "ALTSVC frames are not exposed by WIT");
	}
	origin(..._origins) {
		return unsupported("http2.ServerHttp2Session.origin", "ORIGIN frames are not exposed by WIT");
	}
	ref() {
		this.server.ref();
	}
	unref() {
		this.server.unref();
	}
};
var Http2ServerRequest$1 = class extends IncomingMessage {
	stream;
	authority;
	scheme;
	constructor(data, stream) {
		const { headers } = fieldsToHeaders(data.headers);
		super({
			method: typeof headers[":method"] === "string" ? headers[":method"] : "GET",
			url: typeof headers[":path"] === "string" ? headers[":path"] : "/",
			httpVersion: "2.0",
			headers: data.headers,
			body: data.body,
			remoteAddress: data.remoteAddress,
			remotePort: data.remotePort
		});
		this.stream = stream;
		this.authority = typeof headers[":authority"] === "string" ? headers[":authority"] : void 0;
		this.scheme = typeof headers[":scheme"] === "string" ? headers[":scheme"] : void 0;
	}
	get connection() {
		return deprecated("http2.Http2ServerRequest.connection", "request.socket");
	}
};
var Http2ServerResponse$1 = class extends OutgoingMessage {
	req;
	stream;
	statusCode = 200;
	statusMessage = "";
	#trailers = Object.create(null);
	constructor(request) {
		super();
		this.req = request;
		this.stream = request.stream;
	}
	get connection() {
		return deprecated("http2.Http2ServerResponse.connection", "response.socket");
	}
	writeHead(statusCode, statusMessageOrHeaders, headers) {
		if (!Number.isInteger(statusCode) || statusCode < 100 || statusCode > 999) throw codedError("RangeError", "ERR_HTTP2_STATUS_INVALID", `Invalid status code: ${statusCode}`);
		this.statusCode = statusCode;
		if (typeof statusMessageOrHeaders === "string") this.statusMessage = statusMessageOrHeaders;
		else headers = statusMessageOrHeaders;
		for (const [name, value] of Object.entries(headers ?? {})) if (value !== void 0) this.setHeader(name, value);
		this.flushHeaders();
		return this;
	}
	appendHeader(name, value) {
		return super.appendHeader(name, value);
	}
	writeContinue() {
		return unsupported("http2.Http2ServerResponse.writeContinue", "informational headers cannot cross the buffered response boundary");
	}
	writeEarlyHints(_hints) {
		return unsupported("http2.Http2ServerResponse.writeEarlyHints", "informational headers cannot cross the buffered response boundary");
	}
	writeInformation(_statusCode, _headers) {
		return unsupported("http2.Http2ServerResponse.writeInformation", "informational headers cannot cross the buffered response boundary");
	}
	createPushResponse(_headers, _callback) {
		return unsupported("http2.Http2ServerResponse.createPushResponse", "server push is disabled by RFC 9113");
	}
	setTrailer(name, value) {
		if (typeof name !== "string") throw invalidArgType("name", "string", name);
		const normalized = name.trim().toLowerCase();
		if ([
			":status",
			":method",
			":path",
			":authority",
			":scheme"
		].includes(normalized)) throw codedError("TypeError", "ERR_HTTP2_PSEUDOHEADER_NOT_ALLOWED", "Cannot set HTTP/2 pseudo-headers");
		if (value === void 0 || value === null) throw codedError("TypeError", "ERR_HTTP2_INVALID_HEADER_VALUE", `Invalid value "${value}" for header "${normalized}"`);
		trailersToFields({ [normalized]: value });
		this.#trailers[normalized] = value;
	}
	addTrailers(headers) {
		for (const [name, value] of Object.entries(headers)) this.setTrailer(name, value);
	}
	_finalize(body) {
		this.stream.once("wantTrailers", () => this.stream.sendTrailers(this.#trailers));
		this.stream.respond({
			...this._headers.object(),
			":status": this.statusCode
		}, { waitForTrailers: true });
		this.stream.end(body);
	}
};
var Http2ServerBase = class extends EventEmitter {
	timeout = 0;
	secure;
	options;
	listening = false;
	#implementation;
	#sessions = /* @__PURE__ */ new Map();
	constructor(implementation, secure, options, listener) {
		super();
		this.secure = secure;
		this.options = validateServerOptions(secure, options);
		if (listener) this.on("request", listener);
		this.#implementation = implementation.createServer(secure, this.options, (stream) => this.#handle(stream), (error) => queueMicrotask(() => this.emit("sessionError", error)));
	}
	listen(...args) {
		const { options, callback } = parseListenArguments(args);
		if (options.signal !== void 0) unsupported("http2 server listen signal", "AbortSignal cannot be retained across the host-owned server resource");
		if (this.listening) throw codedError("Error", "ERR_SERVER_ALREADY_LISTEN", "Listen method has been called more than once without closing.");
		this.#implementation.listen(options);
		this.listening = true;
		queueMicrotask(() => {
			this.emit("listening");
			callback?.();
		});
		return this;
	}
	close(callback) {
		try {
			const wasListening = this.#implementation.close();
			this.listening = false;
			queueMicrotask(() => {
				if (wasListening) this.emit("close");
				callback?.();
			});
		} catch (error) {
			const value = error instanceof Error ? error : new Error(String(error));
			queueMicrotask(() => callback?.(value));
		}
		return this;
	}
	address() {
		return this.#implementation.address();
	}
	setTimeout(milliseconds = 0, callback) {
		if (milliseconds !== 0 || callback !== void 0) unsupported("http2 server setTimeout", "timeout callbacks cannot be retained across the typed component boundary");
		return this;
	}
	updateSettings(settings = {}) {
		this.#implementation.updateSettings(validateSettings(settings));
	}
	ref() {
		this.#implementation.ref();
		return this;
	}
	unref() {
		this.#implementation.unref();
		return this;
	}
	async [Symbol.asyncDispose]() {
		await new Promise((resolve, reject) => {
			this.close((error) => error ? reject(error) : resolve());
		});
	}
	async #handle(data) {
		let session = this.#sessions.get(data.sessionId);
		if (!session) {
			session = new ServerHttp2Session(this, this.secure, this.options.settings ?? {});
			this.#sessions.set(data.sessionId, session);
			this.emit("session", session);
		}
		const stream = new ServerHttp2Stream(data, session);
		const { headers, rawHeaders } = fieldsToHeaders(data.headers);
		const emittedStream = this.emit("stream", stream, headers, constants$1.NGHTTP2_FLAG_END_HEADERS, rawHeaders);
		const request = new Http2ServerRequest$1(data, stream);
		const response = new Http2ServerResponse$1(request);
		const emittedRequest = this.emit("request", request, response);
		if (!emittedStream && !emittedRequest) unsupported("http2 server stream", "the server has no stream or request listener");
		stream.startReading();
		request._start();
		return stream.response();
	}
};
function createServerConstructor(implementation, secure) {
	if (secure) return class Http2SecureServer extends Http2ServerBase {
		constructor(options = {}, listener) {
			super(implementation, true, options, listener);
		}
	};
	return class Http2Server extends Http2ServerBase {
		constructor(options = {}, listener) {
			super(implementation, false, options, listener);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/session.js
const SUPPORTED_CLIENT_OPTIONS = /* @__PURE__ */ new Set([
	"settings",
	"rejectUnauthorized",
	"servername",
	"ca",
	"protocol"
]);
function validateClientOptions(options) {
	if (typeof options !== "object" || options === null) throw invalidArgType("options", "object", options);
	for (const [name, value] of Object.entries(options)) if (value !== void 0 && !SUPPORTED_CLIENT_OPTIONS.has(name)) unsupported(`http2.connect option ${name}`, "this option cannot be represented by the typed HTTP/2 provider boundary");
	if (options.settings !== void 0) validateSettings(options.settings);
	if (options.protocol !== void 0 && options.protocol !== "http:" && options.protocol !== "https:") throw Object.assign(/* @__PURE__ */ new TypeError(`Protocol "${String(options.protocol)}" not supported.`), { code: "ERR_HTTP2_UNSUPPORTED_PROTOCOL" });
	return { ...options };
}
function authorityUrl(authority, options) {
	if (!(typeof authority === "string" || authority instanceof URL)) throw invalidArgType("authority", "string, object, or URL", authority);
	try {
		const value = authority instanceof URL ? new URL(authority.href) : new URL(authority);
		if (!value.protocol && options.protocol) value.protocol = options.protocol;
		if (value.protocol !== "http:" && value.protocol !== "https:") throw Object.assign(/* @__PURE__ */ new TypeError(`Protocol "${value.protocol}" not supported.`), { code: "ERR_HTTP2_UNSUPPORTED_PROTOCOL" });
		return value;
	} catch (error) {
		if (error instanceof Error && "code" in error) throw error;
		throw Object.assign(/* @__PURE__ */ new TypeError(`Invalid URL: ${String(authority)}`), { code: "ERR_INVALID_URL" });
	}
}
var ClientHttp2Session = class extends EventEmitter {
	type = constants$1.NGHTTP2_SESSION_CLIENT;
	connecting = true;
	closed = false;
	destroyed = false;
	pendingSettingsAck = false;
	alpnProtocol;
	encrypted;
	localSettings = {};
	remoteSettings = {};
	originSet;
	#authority;
	#implementation;
	constructor(implementation, authority, listener) {
		super();
		this.#implementation = implementation;
		this.#authority = authority;
		if (listener) this.once("connect", listener);
		queueMicrotask(() => {
			if (this.destroyed) return;
			try {
				this.#setInfo(implementation.ready());
				this.emit("connect", this, void 0);
			} catch (error) {
				this.connecting = false;
				this.destroyed = true;
				this.closed = true;
				this.emit("error", error instanceof Error ? error : new Error(String(error)));
				this.emit("close");
			}
		});
	}
	get socket() {
		return unsupported("http2.Http2Session.socket", "host net.Socket and TLSSocket objects cannot cross the component boundary");
	}
	get state() {
		return unsupported("http2.Http2Session.state", "the host session state is not exposed by the typed component boundary");
	}
	request(headers = {}, options = {}) {
		if (this.closed || this.destroyed) throw Object.assign(/* @__PURE__ */ new Error("The session has been destroyed"), { code: "ERR_HTTP2_INVALID_SESSION" });
		if (options.signal !== void 0) unsupported("http2.ClientHttp2Session.request signal", "AbortSignal cannot be retained by the host-owned stream resource");
		if (options.exclusive !== void 0 || options.parent !== void 0) unsupported("http2.ClientHttp2Session.request priority options", "HTTP/2 priority signaling is deprecated upstream");
		const requested = headersToFields(headers);
		const names = new Set(requested.map(({ name }) => name));
		const defaults = headersToFields({
			...names.has(":method") ? {} : { ":method": "GET" },
			...names.has(":path") ? {} : { ":path": "/" },
			...names.has(":scheme") ? {} : { ":scheme": this.#authority.protocol.slice(0, -1) },
			...names.has(":authority") ? {} : { ":authority": this.#authority.host }
		});
		const stream = new ClientHttp2Stream(this.#implementation.request([...defaults, ...requested], {
			endStream: options.endStream,
			waitForTrailers: options.waitForTrailers
		}), Object.fromEntries([...defaults, ...requested].map(({ name, value }) => [name, new TextDecoder("latin1").decode(value)])), this);
		if (options.endStream) stream.end();
		return stream;
	}
	close(callback) {
		if (this.closed) {
			if (callback) queueMicrotask(callback);
			return;
		}
		this.#implementation.close();
		this.closed = true;
		queueMicrotask(() => {
			callback?.();
			this.emit("close");
		});
	}
	destroy(error, code = error ? constants$1.NGHTTP2_INTERNAL_ERROR : constants$1.NGHTTP2_NO_ERROR) {
		if (this.destroyed) return;
		this.#implementation.destroy(code);
		this.destroyed = true;
		this.closed = true;
		queueMicrotask(() => {
			if (error) this.emit("error", error);
			this.emit("close");
		});
	}
	settings(settings = {}, callback) {
		const validated = validateSettings(settings);
		this.pendingSettingsAck = true;
		const started = Date.now();
		try {
			const accepted = this.#implementation.settings(validated);
			this.localSettings = accepted;
			this.pendingSettingsAck = false;
			queueMicrotask(() => {
				this.emit("localSettings", accepted);
				callback?.(null, accepted, Date.now() - started);
			});
		} catch (error) {
			this.pendingSettingsAck = false;
			const value = error instanceof Error ? error : new Error(String(error));
			queueMicrotask(() => callback?.(value, validated, Date.now() - started));
		}
	}
	ping(payloadOrCallback, callback) {
		const actualCallback = typeof payloadOrCallback === "function" ? payloadOrCallback : callback;
		if (!actualCallback) throw invalidArgType("callback", "function", actualCallback);
		const payload = typeof payloadOrCallback === "function" ? /* @__PURE__ */ new Uint8Array(8) : bodyBytes(payloadOrCallback);
		if (payload.byteLength !== 8) throw Object.assign(/* @__PURE__ */ new RangeError("HTTP2 ping payload must be 8 bytes"), { code: "ERR_HTTP2_PING_LENGTH" });
		try {
			const result = this.#implementation.ping(payload);
			queueMicrotask(() => {
				this.emit("ping", result.payload);
				actualCallback(null, result.durationMs, result.payload);
			});
			return true;
		} catch (error) {
			const value = error instanceof Error ? error : new Error(String(error));
			queueMicrotask(() => actualCallback(value, 0, payload));
			return false;
		}
	}
	goaway(code = constants$1.NGHTTP2_NO_ERROR, lastStreamId, opaqueData = /* @__PURE__ */ new Uint8Array()) {
		this.#implementation.goaway(code, lastStreamId, bodyBytes(opaqueData));
	}
	setLocalWindowSize(_windowSize) {
		return unsupported("http2.Http2Session.setLocalWindowSize", "flow-control windows are owned by the host HTTP/2 implementation");
	}
	setTimeout(milliseconds, callback) {
		if (milliseconds !== 0 || callback !== void 0) unsupported("http2.Http2Session.setTimeout", "timeout callbacks cannot be retained across the typed component boundary");
		return this;
	}
	ref() {
		this.#implementation.ref();
	}
	unref() {
		this.#implementation.unref();
	}
	#setInfo(info) {
		this.connecting = false;
		this.alpnProtocol = info.alpnProtocol;
		this.encrypted = info.encrypted;
		this.localSettings = info.localSettings;
		this.remoteSettings = info.remoteSettings;
	}
};
function createConnection(implementationFactory, authority, optionsOrListener = {}, listener) {
	const options = validateClientOptions(typeof optionsOrListener === "function" ? {} : optionsOrListener);
	const actualListener = typeof optionsOrListener === "function" ? optionsOrListener : listener;
	const url = authorityUrl(authority, options);
	return new ClientHttp2Session(implementationFactory(url.origin, options), url, actualListener);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/core.js
const sensitiveHeaders$1 = Symbol("nodejs.http2.sensitiveHeaders");
function createHttp2(implementation) {
	const Http2Server = createServerConstructor(implementation, false);
	const Http2SecureServer = createServerConstructor(implementation, true);
	function connect(authority, optionsOrListener = {}, listener) {
		return createConnection((normalizedAuthority, options) => implementation.connect(normalizedAuthority, options), authority, optionsOrListener, listener);
	}
	function createServer(optionsOrListener = {}, listener) {
		return new Http2Server(typeof optionsOrListener === "function" ? {} : optionsOrListener, typeof optionsOrListener === "function" ? optionsOrListener : listener);
	}
	function createSecureServer(optionsOrListener = {}, listener) {
		return new Http2SecureServer(typeof optionsOrListener === "function" ? {} : optionsOrListener, typeof optionsOrListener === "function" ? optionsOrListener : listener);
	}
	function performServerHandshake(_socket, _options) {
		return unsupported("http2.performServerHandshake", "an arbitrary guest Duplex stream cannot cross the component boundary");
	}
	return {
		connect,
		constants: constants$1,
		createServer,
		createSecureServer,
		getDefaultSettings: getDefaultSettings$1,
		getPackedSettings: getPackedSettings$1,
		getUnpackedSettings: getUnpackedSettings$1,
		performServerHandshake,
		sensitiveHeaders: sensitiveHeaders$1,
		Http2ServerRequest: Http2ServerRequest$1,
		Http2ServerResponse: Http2ServerResponse$1
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/wasi-sockets.js
function dispose(resource) {
	resource?.[Symbol.dispose]?.();
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tls/node-host.js
function denied() {
	throw Object.assign(/* @__PURE__ */ new Error("node:tls requires an explicitly configured jco:node/tls@0.1.0 host provider"), { code: "ERR_JCO_TLS_ADAPTER_REQUIRED" });
}
const isAvailable = () => false;
const startTls = (_name, input, output) => {
	try {
		denied();
	} finally {
		dispose(output);
		dispose(input);
	}
};
const query = denied;
const setDefaultCa = denied;
const createContext = denied;
const releaseContext = () => {};
var node_host_default = {
	isAvailable,
	startTls,
	query,
	setDefaultCa,
	createContext,
	releaseContext,
	connect: denied,
	createServer: denied,
	socketOperation: denied,
	serverOperation: denied,
	write: denied,
	end: denied,
	release: denied
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tls/wire.js
function encode(value) {
	const nodes = [];
	const seen = /* @__PURE__ */ new Map();
	function visit(value) {
		if (typeof value === "number" && (!Number.isFinite(value) || Object.is(value, -0))) return { number: Object.is(value, -0) ? "-0" : String(value) };
		if (value === void 0) return { undefined: true };
		if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number") return value;
		if (typeof value !== "object") throw new TypeError("TLS capability values must be data, not functions or native handles");
		const existing = seen.get(value);
		if (existing !== void 0) return { ref: existing };
		const ref = nodes.length;
		seen.set(value, ref);
		const node = ArrayBuffer.isView(value) ? {
			kind: "bytes",
			data: Array.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
		} : Array.isArray(value) ? {
			kind: "array",
			data: []
		} : {
			kind: "object",
			data: []
		};
		nodes.push(node);
		if (node.kind === "array") node.data = value.map(visit);
		if (node.kind === "object") {
			if (value instanceof Error) {
				node.error = value.name;
				node.data.push(["message", value.message]);
			}
			for (const [key, entry] of Object.entries(value)) node.data.push([key, visit(entry)]);
		}
		return { ref };
	}
	const root = visit(value);
	return JSON.stringify({
		root,
		nodes
	});
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/tls/errors.js
function hostCall(operation) {
	try {
		return operation();
	} catch (error) {
		const record = error;
		const value = record?.payload ?? record;
		if (!(error instanceof Error) || record?.payload !== void 0) {
			if (typeof value?.message === "string") {
				const result = value.name === "TypeError" ? new TypeError(value.message) : value.name === "RangeError" ? new RangeError(value.message) : new Error(value.message);
				Object.assign(result, value);
				throw result;
			}
		}
		throw error;
	}
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/impl/direct/shared.js
function unwrap(operation) {
	return callHost(operation, fromImplementationError);
}
function tlsBytes(value) {
	return value === void 0 ? void 0 : bodyBytes(value);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/impl/direct/client.js
function createDirectHttp2Client(host, authority, options, tls = node_host_default) {
	const tlsContext = new URL(authority).protocol === "https:" ? hostCall(() => tls.createContext(encode({
		ca: tlsBytes(options.ca),
		servername: options.servername,
		rejectUnauthorized: options.rejectUnauthorized
	}))) : void 0;
	let session;
	try {
		session = new host.ClientSession(authority, {
			settings: toDirectSettings(options.settings),
			tlsContext
		});
	} finally {
		if (tlsContext !== void 0) tls.releaseContext(tlsContext);
	}
	return {
		ready() {
			const info = unwrap(() => session.ready());
			return {
				...info,
				localSettings: fromDirectSettings(info.localSettings),
				remoteSettings: fromDirectSettings(info.remoteSettings)
			};
		},
		request(headers, requestOptions) {
			const stream = unwrap(() => session.request(headers, requestOptions));
			return {
				write: (chunk) => unwrap(() => stream.write(chunk)),
				finish: () => unwrap(() => stream.finish()),
				close: (code) => unwrap(() => stream.close(code)),
				id: () => stream.id(),
				state: () => stream.state()
			};
		},
		close: () => unwrap(() => session.close()),
		destroy: (code) => unwrap(() => session.destroy(code)),
		settings(value) {
			return fromDirectSettings(unwrap(() => session.settings(toDirectSettings(value))));
		},
		ping: (payload) => unwrap(() => session.ping(payload)),
		goaway: (code, lastStreamId, opaqueData) => unwrap(() => session.goaway(code, lastStreamId, opaqueData)),
		ref: () => session.ref(),
		unref: () => session.unref()
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/internal/http-host.js
function serializeNodeError(error) {
	const value = typeof error === "object" && error !== null ? error : {};
	const errno = typeof value.errno === "number" ? {
		tag: "number",
		val: BigInt(value.errno)
	} : typeof value.errno === "string" ? {
		tag: "symbolic",
		val: value.errno
	} : void 0;
	return {
		name: typeof value.name === "string" ? value.name : "Error",
		message: typeof value.message === "string" ? value.message : String(error),
		code: typeof value.code === "string" ? value.code : void 0,
		errno,
		syscall: typeof value.syscall === "string" ? value.syscall : void 0,
		hostname: typeof value.hostname === "string" ? value.hostname : void 0,
		address: typeof value.address === "string" ? value.address : void 0,
		port: typeof value.port === "number" ? value.port : void 0
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/impl/direct/server.js
var StreamListener = class {
	#handler;
	constructor(handler) {
		this.#handler = handler;
	}
	async handle(stream) {
		try {
			return await this.#handler(stream);
		} catch (error) {
			throw serializeNodeError(error);
		}
	}
	[Symbol.dispose]() {}
};
var ServerErrorListener = class {
	#handler;
	constructor(handler) {
		this.#handler = handler;
	}
	handle(reason) {
		this.#handler(fromImplementationError(reason));
	}
	[Symbol.dispose]() {}
};
function createHttp2CallbackRegistry() {
	let nextId = 1;
	const streams = /* @__PURE__ */ new Map();
	const errors = /* @__PURE__ */ new Map();
	return {
		allocate() {
			if (nextId > 4294967294) throw codedError("Error", "ERR_JCO_HTTP2_CALLBACK_LIMIT", "HTTP/2 callback registrations exhausted");
			return [nextId++, nextId++];
		},
		register(listener, errorListener, handler, onError) {
			streams.set(listener, new StreamListener(handler));
			errors.set(errorListener, new ServerErrorListener(onError));
		},
		release(listener, errorListener) {
			streams.delete(listener);
			errors.delete(errorListener);
		},
		exports: {
			StreamListener,
			ServerErrorListener,
			takeStreamListener(id) {
				const listener = streams.get(id);
				streams.delete(id);
				return listener;
			},
			takeServerErrorListener(id) {
				const listener = errors.get(id);
				errors.delete(id);
				return listener;
			}
		}
	};
}
function createDirectHttp2Server(host, registry, secure, options, handler, onError, tls = node_host_default) {
	const [listener, errorListener] = registry.allocate();
	const tlsContext = secure ? hostCall(() => tls.createContext(encode({
		key: tlsBytes(options.key),
		cert: tlsBytes(options.cert)
	}))) : void 0;
	let server;
	try {
		server = new host.Server({
			secure,
			tlsContext,
			settings: toDirectSettings(options.settings),
			allowHttp1: options.allowHTTP1,
			strictFieldWhitespaceValidation: options.strictFieldWhitespaceValidation
		}, listener, errorListener);
	} finally {
		if (tlsContext !== void 0) tls.releaseContext(tlsContext);
	}
	const address = (value) => value === void 0 ? null : value.tag === "tcp" ? {
		address: value.val.address,
		family: value.val.family === "IPv6" ? "IPv6" : "IPv4",
		port: value.val.port
	} : value.val;
	return {
		listen(listenOptions) {
			registry.register(listener, errorListener, handler, onError);
			try {
				return address(unwrap(() => server.listen(listenOptions)));
			} catch (error) {
				registry.release(listener, errorListener);
				throw error;
			}
		},
		close() {
			const result = unwrap(() => server.close());
			registry.release(listener, errorListener);
			return result;
		},
		address: () => address(server.address()),
		updateSettings: (settings) => unwrap(() => server.updateSettings(toDirectSettings(settings))),
		ref: () => server.ref(),
		unref: () => server.unref()
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2/impl/direct/index.js
function createDirectHttp2Implementation(host, tls) {
	const registry = createHttp2CallbackRegistry();
	return {
		http2Callbacks: registry.exports,
		connect: (authority, options) => createDirectHttp2Client(host, authority, options, tls),
		createServer: (secure, options, handler, onError) => createDirectHttp2Server(host, registry, secure, options, handler, onError, tls)
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/http2.js
const implementation = createDirectHttp2Implementation(http2_host_exports, tls_host_exports);
const http2 = createHttp2(implementation);
const http2Callbacks = implementation.http2Callbacks;
const connect = http2.connect;
const constants = http2.constants;
const createServer = http2.createServer;
const createSecureServer = http2.createSecureServer;
const getDefaultSettings = http2.getDefaultSettings;
const getPackedSettings = http2.getPackedSettings;
const getUnpackedSettings = http2.getUnpackedSettings;
const performServerHandshake = http2.performServerHandshake;
const sensitiveHeaders = http2.sensitiveHeaders;
const Http2ServerRequest = http2.Http2ServerRequest;
const Http2ServerResponse = http2.Http2ServerResponse;
//#endregion
export { Http2ServerRequest, Http2ServerResponse, connect, constants, createSecureServer, createServer, http2 as default, getDefaultSettings, getPackedSettings, getUnpackedSettings, http2Callbacks, performServerHandshake, sensitiveHeaders };
