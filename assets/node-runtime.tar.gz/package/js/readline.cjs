module.exports = require('./readline.mjs').default;
