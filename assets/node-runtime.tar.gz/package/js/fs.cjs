module.exports = require('./fs.mjs').default;
