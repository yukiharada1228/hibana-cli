module.exports = require('./querystring.mjs').default;
