module.exports = require('./dgram.mjs').default;
