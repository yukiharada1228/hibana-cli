import { Buffer } from "./buffer.mjs";
import { a as Transform, o as Writable } from "./chunks/stream-BA_0bejK.mjs";
import "./stream.mjs";
import { Cipher, DiffieHellman as DiffieHellman$1, Ecdh, Hash as Hash$1, Hmac as Hmac$1, ciphers, curves, generateKeyPair as generateKeyPair$1, hashes, hkdf as hkdf$1, importKey, keyAgreement, parseCertificate, pbkdf2 as pbkdf2$1, randomBytes as randomBytes$1, scrypt as scrypt$1, sign as sign$1, timingSafeEqual as timingSafeEqual$1, verify as verify$1 } from "hibana:node-crypto/api@0.5.0";
//#region src/crypto-keys.mjs
const kHandle = Symbol("hibana.keyHandle");
function fail(caught) {
	const payload = caught?.payload;
	if (!payload) return caught;
	return Object.assign(new Error(payload.message), {
		name: payload.name || "Error",
		code: payload.code
	});
}
function call(action) {
	try {
		return action();
	} catch (caught) {
		throw fail(caught);
	}
}
function toBuffer(value, encoding) {
	if (typeof value === "string") return Buffer.from(value, encoding);
	if (value instanceof ArrayBuffer) return Buffer.from(new Uint8Array(value));
	if (ArrayBuffer.isView(value)) return Buffer.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
	throw Object.assign(/* @__PURE__ */ new TypeError("Expected a string, Buffer, TypedArray, DataView, or ArrayBuffer"), { code: "ERR_INVALID_ARG_TYPE" });
}
function encode(bytes, encoding) {
	const buffer = Buffer.from(bytes);
	return encoding && encoding !== "buffer" ? buffer.toString(encoding) : buffer;
}
var KeyObject = class KeyObject {
	constructor(handle) {
		if (!handle) throw Object.assign(/* @__PURE__ */ new Error("KeyObject cannot be constructed directly"), { code: "ERR_OPERATION_FAILED" });
		this[kHandle] = handle;
	}
	get type() {
		return call(() => this[kHandle].keyType());
	}
	get asymmetricKeyType() {
		return call(() => this[kHandle].asymmetricKeyType()) ?? void 0;
	}
	get asymmetricKeyDetails() {
		const details = call(() => this[kHandle].asymmetricKeyDetails());
		if (!details) return void 0;
		const mapped = {
			modulusLength: details.modulusLength,
			publicExponent: details.publicExponent === void 0 ? void 0 : BigInt(`0x${Buffer.from(details.publicExponent).toString("hex")}`),
			hashAlgorithm: details.hashAlgorithm,
			mgf1HashAlgorithm: details.mgf1HashAlgorithm,
			saltLength: details.saltLength,
			namedCurve: details.namedCurve
		};
		return Object.fromEntries(Object.entries(mapped).filter(([, value]) => value !== void 0));
	}
	get symmetricKeySize() {
		return call(() => this[kHandle].symmetricKeySize()) ?? void 0;
	}
	equals(other) {
		if (!(other instanceof KeyObject)) throw Object.assign(/* @__PURE__ */ new TypeError("otherKey must be a KeyObject"), { code: "ERR_INVALID_ARG_TYPE" });
		return call(() => this[kHandle].equals(other[kHandle]));
	}
	export(options = {}) {
		if (this.type === "secret") {
			if (options.format === "jwk") return JSON.parse(Buffer.from(call(() => this[kHandle].export({ format: "jwk" }))).toString());
			return Buffer.from(call(() => this[kHandle].export({ format: "raw" })));
		}
		const format = options.format ?? "pem";
		if (format === "jwk") return JSON.parse(Buffer.from(call(() => this[kHandle].export({ format: "jwk" }))).toString());
		const bytes = call(() => this[kHandle].export({
			format,
			encoding: options.type,
			cipher: options.cipher,
			passphrase: options.passphrase === void 0 ? void 0 : toBuffer(options.passphrase)
		}));
		return format === "pem" ? Buffer.from(bytes).toString() : Buffer.from(bytes);
	}
	toCryptoKey() {
		throw Object.assign(/* @__PURE__ */ new Error("KeyObject.toCryptoKey is not supported in Workers"), { code: "ERR_NOT_SUPPORTED" });
	}
};
function wrap(handle) {
	return new KeyObject(handle);
}
function createSecretKey(value, encoding) {
	const bytes = value instanceof KeyObject ? value.export() : toBuffer(value, encoding);
	return wrap(call(() => importKey(bytes, {
		format: "raw",
		keyType: "secret"
	})));
}
function normalize(input, expected) {
	if (input instanceof KeyObject) return input;
	if (typeof input === "string" || ArrayBuffer.isView(input) || input instanceof ArrayBuffer) return { key: input };
	if (input && typeof input === "object" && "key" in input) return input;
	throw Object.assign(/* @__PURE__ */ new TypeError(`Invalid ${expected} key argument`), { code: "ERR_INVALID_ARG_TYPE" });
}
function fromOptions(options, keyType) {
	const { key, format = "pem", type, passphrase, encoding } = options;
	if (key instanceof KeyObject) return key;
	if (format === "jwk") {
		const document = typeof key === "string" ? key : JSON.stringify(key);
		return wrap(call(() => importKey(Buffer.from(document), {
			format: "jwk",
			keyType
		})));
	}
	return wrap(call(() => importKey(toBuffer(key, encoding), {
		format,
		encoding: type,
		passphrase: passphrase === void 0 ? void 0 : toBuffer(passphrase),
		keyType
	})));
}
function createPrivateKey(input) {
	const options = normalize(input, "private");
	return options instanceof KeyObject ? options : fromOptions(options, "private");
}
function createPublicKey(input) {
	if (input instanceof KeyObject) return input.type === "private" ? wrap(call(() => input[kHandle].public())) : input;
	const key = fromOptions(normalize(input, "public"), "public");
	return key.type === "private" ? wrap(call(() => key[kHandle].public())) : key;
}
function asKey(input, wantPublic) {
	if (input instanceof KeyObject) return input;
	return wantPublic ? createPublicKey(input) : createPrivateKey(input);
}
const GENERATE_ENCODINGS = ["publicKeyEncoding", "privateKeyEncoding"];
function generateKeyPairSync(type, options = {}) {
	const pair = call(() => generateKeyPair$1(type, {
		modulusLength: options.modulusLength,
		publicExponent: options.publicExponent,
		namedCurve: options.namedCurve,
		hashAlgorithm: options.hashAlgorithm,
		mgf1HashAlgorithm: options.mgf1HashAlgorithm,
		saltLength: options.saltLength
	}));
	let publicKey = wrap(pair.public);
	let privateKey = wrap(pair.private);
	const [publicEncoding, privateEncoding] = GENERATE_ENCODINGS.map((name) => options[name]);
	if (publicEncoding) publicKey = publicKey.export(publicEncoding);
	if (privateEncoding) privateKey = privateKey.export(privateEncoding);
	return {
		publicKey,
		privateKey
	};
}
function generateKeyPair(type, options, callback) {
	const done = typeof options === "function" ? options : callback;
	const settings = typeof options === "function" ? {} : options;
	queueMicrotask(() => {
		try {
			const { publicKey, privateKey } = generateKeyPairSync(type, settings);
			done(null, publicKey, privateKey);
		} catch (error) {
			done(error);
		}
	});
}
function generateKeySync(type, options = {}) {
	const length = type === "hmac" ? Math.ceil((options.length ?? 256) / 8) : (options.length ?? 256) / 8;
	if (!Number.isInteger(length) || length <= 0) throw Object.assign(/* @__PURE__ */ new RangeError("Invalid key length"), { code: "ERR_OUT_OF_RANGE" });
	return createSecretKey(Buffer.from(call(() => randomBytes$1(length))));
}
function generateKey(type, options, callback) {
	queueMicrotask(() => {
		try {
			callback(null, generateKeySync(type, options));
		} catch (error) {
			callback(error);
		}
	});
}
//#endregion
//#region src/crypto.mjs
const unsupported = (name, reason) => Object.assign(/* @__PURE__ */ new Error(`${name} is not supported: ${reason}`), { code: "ERR_NOT_SUPPORTED" });
const outOfRange = (name, range, value) => Object.assign(/* @__PURE__ */ new RangeError(`The value of "${name}" is out of range. It must be ${range}. Received ${value}`), { code: "ERR_OUT_OF_RANGE" });
/** Node exposes digests and ciphers as Transform streams. */
var CryptoTransform = class extends Transform {
	_transform(chunk, encoding, done) {
		try {
			this.update(chunk, encoding);
			done();
		} catch (error) {
			done(error);
		}
	}
	_flush(done) {
		try {
			done(null, this._result());
		} catch (error) {
			done(error);
		}
	}
};
var Hash = class Hash extends CryptoTransform {
	#state;
	constructor(algorithm, options = {}) {
		super(options);
		if (algorithm instanceof Hash$1) {
			this.#state = algorithm;
			return;
		}
		this.#state = new Hash$1(String(algorithm), options.outputLength);
		call(() => this.#state.update(/* @__PURE__ */ new Uint8Array()));
	}
	update(data, encoding) {
		call(() => this.#state.update(toBuffer(data, encoding)));
		return this;
	}
	digest(encoding) {
		return encode(call(() => this.#state.digest()), encoding);
	}
	copy(options = {}) {
		return new Hash(call(() => this.#state.copy(options.outputLength)), options);
	}
	_result() {
		return this.digest();
	}
};
var Hmac = class extends CryptoTransform {
	#state;
	constructor(algorithm, key, options = {}) {
		super(options);
		const material = key instanceof KeyObject ? key.export() : toBuffer(key, options.encoding);
		this.#state = new Hmac$1(String(algorithm), material);
		call(() => this.#state.update(/* @__PURE__ */ new Uint8Array()));
	}
	update(data, encoding) {
		call(() => this.#state.update(toBuffer(data, encoding)));
		return this;
	}
	digest(encoding) {
		return encode(call(() => this.#state.digest()), encoding);
	}
	_result() {
		return this.digest();
	}
};
const createHash = (algorithm, options) => new Hash(algorithm, options);
const createHmac = (algorithm, key, options) => new Hmac(algorithm, key, options);
const hash = (algorithm, data, outputEncoding = "hex") => new Hash(algorithm).update(data).digest(outputEncoding);
var CipherBase = class extends CryptoTransform {
	#state;
	#encoding;
	constructor(algorithm, key, iv, encrypt, options = {}) {
		super(options);
		const material = key instanceof KeyObject ? key.export() : toBuffer(key, options.encoding);
		this.#state = new Cipher(String(algorithm), material, iv === null || iv === void 0 ? void 0 : toBuffer(iv), encrypt, options.authTagLength);
		call(() => this.#state.setAutoPadding(true));
	}
	update(data, inputEncoding, outputEncoding) {
		const out = call(() => this.#state.update(toBuffer(data, inputEncoding)));
		this.#encoding = outputEncoding;
		return encode(out, outputEncoding);
	}
	final(outputEncoding) {
		return encode(call(() => this.#state.finish()), outputEncoding ?? this.#encoding);
	}
	setAAD(buffer, options = {}) {
		call(() => this.#state.setAad(toBuffer(buffer), options.plaintextLength));
		return this;
	}
	setAutoPadding(enabled = true) {
		call(() => this.#state.setAutoPadding(Boolean(enabled)));
		return this;
	}
	getAuthTag() {
		return Buffer.from(call(() => this.#state.authTag()));
	}
	setAuthTag(tag) {
		call(() => this.#state.setAuthTag(toBuffer(tag)));
		return this;
	}
	_result() {
		return this.final();
	}
};
var Cipheriv = class extends CipherBase {
	constructor(algorithm, key, iv, options) {
		super(algorithm, key, iv, true, options);
	}
};
var Decipheriv = class extends CipherBase {
	constructor(algorithm, key, iv, options) {
		super(algorithm, key, iv, false, options);
	}
};
const createCipheriv = (algorithm, key, iv, options) => new Cipheriv(algorithm, key, iv, options);
const createDecipheriv = (algorithm, key, iv, options) => new Decipheriv(algorithm, key, iv, options);
/** Node's Sign and Verify accumulate input as Writable streams. */
var SignatureBase = class extends Writable {
	_chunks = [];
	constructor(algorithm, options) {
		super(options);
		this._algorithm = algorithm === void 0 ? void 0 : String(algorithm);
	}
	update(data, encoding) {
		this._chunks.push(toBuffer(data, encoding));
		return this;
	}
	_write(chunk, encoding, done) {
		this.update(chunk, encoding);
		done();
	}
	_data() {
		return Buffer.concat(this._chunks);
	}
	_options(options) {
		return {
			padding: options?.padding,
			saltLength: options?.saltLength,
			dsaEncoding: options?.dsaEncoding
		};
	}
};
var Sign = class extends SignatureBase {
	sign(privateKey, outputEncoding) {
		const options = privateKey instanceof KeyObject ? {} : privateKey;
		const key = asKey(privateKey, false);
		return encode(call(() => sign$1(this._algorithm, this._data(), key[kHandle], this._options(options))), outputEncoding);
	}
};
var Verify = class extends SignatureBase {
	verify(publicKey, signature, signatureEncoding) {
		const options = publicKey instanceof KeyObject ? {} : publicKey;
		const key = asKey(publicKey, true);
		return call(() => verify$1(this._algorithm, this._data(), key[kHandle], toBuffer(signature, signatureEncoding), this._options(options)));
	}
};
const createSign = (algorithm, options) => new Sign(algorithm, options);
const createVerify = (algorithm, options) => new Verify(algorithm, options);
function sign(algorithm, data, key, callback) {
	const run = () => {
		const options = key instanceof KeyObject ? {} : key;
		const resolved = asKey(key, false);
		return Buffer.from(call(() => sign$1(algorithm === null ? void 0 : algorithm, toBuffer(data), resolved[kHandle], {
			padding: options?.padding,
			saltLength: options?.saltLength,
			dsaEncoding: options?.dsaEncoding
		})));
	};
	if (!callback) return run();
	queueMicrotask(() => {
		try {
			callback(null, run());
		} catch (error) {
			callback(error);
		}
	});
}
function verify(algorithm, data, key, signature, callback) {
	const run = () => {
		const options = key instanceof KeyObject ? {} : key;
		const resolved = asKey(key, true);
		return call(() => verify$1(algorithm === null ? void 0 : algorithm, toBuffer(data), resolved[kHandle], toBuffer(signature), {
			padding: options?.padding,
			saltLength: options?.saltLength,
			dsaEncoding: options?.dsaEncoding
		}));
	};
	if (!callback) return run();
	queueMicrotask(() => {
		try {
			callback(null, run());
		} catch (error) {
			callback(error);
		}
	});
}
function diffieHellman({ privateKey, publicKey }) {
	return Buffer.from(call(() => keyAgreement(privateKey[kHandle], publicKey[kHandle])));
}
var ECDH = class {
	#state;
	constructor(curve) {
		this.#state = new Ecdh(String(curve));
	}
	generateKeys(encoding, format) {
		const bytes = call(() => this.#state.generateKeys());
		return encode(format === "compressed" ? call(() => this.#state.publicKey(true)) : bytes, encoding);
	}
	computeSecret(other, inputEncoding, outputEncoding) {
		return encode(call(() => this.#state.computeSecret(toBuffer(other, inputEncoding))), outputEncoding);
	}
	getPrivateKey(encoding) {
		return encode(call(() => this.#state.privateKey()), encoding);
	}
	getPublicKey(encoding, format) {
		return encode(call(() => this.#state.publicKey(format === "compressed")), encoding);
	}
	setPrivateKey(key, encoding) {
		call(() => this.#state.setPrivateKey(toBuffer(key, encoding)));
		return this;
	}
	setPublicKey() {
		throw unsupported("ECDH.setPublicKey", "the public key is derived from the private key");
	}
	static convertKey() {
		throw unsupported("ECDH.convertKey", "point conversion is not exposed by the cryptography boundary");
	}
};
const createECDH = (curve) => new ECDH(curve);
var DiffieHellman = class {
	#state;
	constructor(prime, primeEncoding, generator = 2, generatorEncoding) {
		const modulus = typeof prime === "number" ? (() => {
			throw unsupported("createDiffieHellman with a prime length", "generating a safe prime is not available; pass a known group");
		})() : toBuffer(prime, primeEncoding);
		const base = typeof generator === "number" ? Buffer.from([generator]) : toBuffer(generator, generatorEncoding);
		this.#state = new DiffieHellman$1(modulus, base);
		this.verifyError = 0;
	}
	generateKeys(encoding) {
		return encode(call(() => this.#state.generateKeys()), encoding);
	}
	computeSecret(other, inputEncoding, outputEncoding) {
		return encode(call(() => this.#state.computeSecret(toBuffer(other, inputEncoding))), outputEncoding);
	}
	getPrime(encoding) {
		return encode(call(() => this.#state.prime()), encoding);
	}
	getGenerator(encoding) {
		return encode(call(() => this.#state.generator()), encoding);
	}
	getPrivateKey(encoding) {
		return encode(call(() => this.#state.privateKey()), encoding);
	}
	getPublicKey(encoding) {
		return encode(call(() => this.#state.publicKey()), encoding);
	}
	setPrivateKey(key, encoding) {
		call(() => this.#state.setPrivateKey(toBuffer(key, encoding)));
		return this;
	}
	setPublicKey() {
		throw unsupported("DiffieHellman.setPublicKey", "the public key is derived from the private key");
	}
};
const createDiffieHellman = (prime, a, generator, b) => new DiffieHellman(prime, a, generator, b);
const createDiffieHellmanGroup = () => {
	throw unsupported("createDiffieHellmanGroup", "named groups are not bundled; pass the prime explicitly");
};
const getDiffieHellman = createDiffieHellmanGroup;
var X509Certificate = class {
	#state;
	constructor(buffer) {
		this.#state = call(() => parseCertificate(toBuffer(buffer)));
	}
	get subject() {
		return call(() => this.#state.subject());
	}
	get issuer() {
		return call(() => this.#state.issuer());
	}
	get subjectAltName() {
		return call(() => this.#state.subjectAltName()) ?? void 0;
	}
	get infoAccess() {
		return call(() => this.#state.infoAccess()) ?? void 0;
	}
	get validFrom() {
		return call(() => this.#state.validFrom());
	}
	get validTo() {
		return call(() => this.#state.validTo());
	}
	get serialNumber() {
		return call(() => this.#state.serialNumber());
	}
	get raw() {
		return Buffer.from(call(() => this.#state.raw()));
	}
	get ca() {
		return call(() => this.#state.isCa());
	}
	get keyUsage() {
		return call(() => this.#state.keyUsage()) ?? void 0;
	}
	get publicKey() {
		return wrap(call(() => this.#state.publicKey()));
	}
	get fingerprint() {
		return colons(call(() => this.#state.fingerprint("sha1")));
	}
	get fingerprint256() {
		return colons(call(() => this.#state.fingerprint("sha256")));
	}
	get fingerprint512() {
		return colons(call(() => this.#state.fingerprint("sha512")));
	}
	checkHost(name) {
		return call(() => this.#state.checkHost(String(name))) ?? void 0;
	}
	checkEmail(address) {
		return call(() => this.#state.checkEmail(String(address))) ?? void 0;
	}
	checkIP() {}
	checkIssued(other) {
		return call(() => this.#state.checkIssued(other.#state));
	}
	verify(publicKey) {
		return call(() => this.#state.verify(publicKey[kHandle]));
	}
	toString() {
		return this.raw.toString("base64");
	}
	toJSON() {
		return this.toString();
	}
	toLegacyObject() {
		throw unsupported("X509Certificate.toLegacyObject", "the legacy certificate shape is not produced by the certificate parser");
	}
};
/** Node renders fingerprints as colon-separated uppercase pairs. */
function colons(bytes) {
	return Buffer.from(bytes).toString("hex").toUpperCase().replace(/..\B/g, "$&:");
}
function randomBytes(size, callback) {
	if (!Number.isInteger(size) || size < 0 || size > 4294967295) throw outOfRange("size", "an integer in [0, 2**32-1]", size);
	const run = () => Buffer.from(call(() => randomBytes$1(size)));
	if (!callback) return run();
	queueMicrotask(() => {
		try {
			callback(null, run());
		} catch (error) {
			callback(error);
		}
	});
}
function randomFillSync(buffer, offset = 0, size) {
	const view = new Uint8Array(buffer.buffer ?? buffer, buffer.byteOffset ?? 0, buffer.byteLength ?? buffer.length);
	const length = size ?? view.length - offset;
	view.set(call(() => randomBytes$1(length)), offset);
	return buffer;
}
function randomFill(buffer, offset, size, callback) {
	const done = [
		offset,
		size,
		callback
	].find((v) => typeof v === "function");
	const start = typeof offset === "number" ? offset : 0;
	const length = typeof size === "number" ? size : void 0;
	queueMicrotask(() => {
		try {
			done(null, randomFillSync(buffer, start, length));
		} catch (error) {
			done(error);
		}
	});
}
function randomInt(min, max, callback) {
	if (typeof max === "function") {
		callback = max;
		max = min;
		min = 0;
	}
	const range = max - min;
	if (!Number.isInteger(range) || range <= 0) throw outOfRange("max", "greater than min", max);
	const run = () => {
		const bytes = Math.ceil(Math.log2(range) / 8) || 1;
		const limit = Math.floor(2 ** (bytes * 8) / range) * range;
		for (;;) {
			let value = 0;
			for (const byte of call(() => randomBytes$1(bytes))) value = value * 256 + byte;
			if (value < limit) return min + value % range;
		}
	};
	if (!callback) return run();
	queueMicrotask(() => {
		try {
			callback(null, run());
		} catch (error) {
			callback(error);
		}
	});
}
const randomUUID = (options) => globalThis.crypto.randomUUID(options);
const getRandomValues = (array) => globalThis.crypto.getRandomValues(array);
function pbkdf2Sync(password, salt, iterations, keylen, digest) {
	if (digest === void 0) throw Object.assign(/* @__PURE__ */ new TypeError("The digest argument is required"), { code: "ERR_INVALID_ARG_TYPE" });
	return Buffer.from(call(() => pbkdf2$1(digest, toBuffer(password), toBuffer(salt), iterations, keylen)));
}
function pbkdf2(password, salt, iterations, keylen, digest, callback) {
	queueMicrotask(() => {
		try {
			callback(null, pbkdf2Sync(password, salt, iterations, keylen, digest));
		} catch (error) {
			callback(error);
		}
	});
}
function hkdfSync(digest, ikm, salt, info, keylen) {
	const key = ikm instanceof KeyObject ? ikm.export() : toBuffer(ikm);
	return Uint8Array.from(call(() => hkdf$1(digest, key, toBuffer(salt), toBuffer(info), keylen))).buffer;
}
function hkdf(digest, ikm, salt, info, keylen, callback) {
	queueMicrotask(() => {
		try {
			callback(null, hkdfSync(digest, ikm, salt, info, keylen));
		} catch (error) {
			callback(error);
		}
	});
}
const SCRYPT_DEFAULTS = {
	N: 16384,
	r: 8,
	p: 1,
	maxmem: 33554432
};
function scryptSync(password, salt, keylen, options = {}) {
	const { N, r, p, maxmem } = {
		...SCRYPT_DEFAULTS,
		...options
	};
	return Buffer.from(call(() => scrypt$1(toBuffer(password), toBuffer(salt), options.cost ?? N, options.blockSize ?? r, options.parallelization ?? p, keylen, BigInt(maxmem))));
}
function scrypt(password, salt, keylen, options, callback) {
	const done = typeof options === "function" ? options : callback;
	const settings = typeof options === "function" ? {} : options;
	queueMicrotask(() => {
		try {
			done(null, scryptSync(password, salt, keylen, settings));
		} catch (error) {
			done(error);
		}
	});
}
function timingSafeEqual(a, b) {
	return call(() => timingSafeEqual$1(toBuffer(a), toBuffer(b)));
}
const getCiphers = () => call(() => ciphers());
const getHashes = () => call(() => hashes());
const getCurves = () => call(() => curves());
const getCipherInfo = (name) => {
	return getCiphers().includes(String(name).toLowerCase()) ? { name: String(name).toLowerCase() } : void 0;
};
const webcrypto = globalThis.crypto;
const subtle = globalThis.crypto?.subtle;
const fips = false;
const getFips = () => 0;
const setFips = () => {
	throw unsupported("crypto.setFips", "FIPS mode cannot be toggled in Workers");
};
/** The subset of OpenSSL constants Node's own options refer to. */
const constants = Object.freeze({
	RSA_PKCS1_PADDING: 1,
	RSA_NO_PADDING: 3,
	RSA_PKCS1_OAEP_PADDING: 4,
	RSA_X931_PADDING: 5,
	RSA_PKCS1_PSS_PADDING: 6,
	RSA_PSS_SALTLEN_DIGEST: -1,
	RSA_PSS_SALTLEN_MAX_SIGN: -2,
	RSA_PSS_SALTLEN_AUTO: -2,
	POINT_CONVERSION_COMPRESSED: 2,
	POINT_CONVERSION_UNCOMPRESSED: 4,
	POINT_CONVERSION_HYBRID: 6,
	defaultCoreCipherList: "",
	defaultCipherList: ""
});
const refuse = (name, reason) => () => {
	throw unsupported(name, reason);
};
const NO_OPENSSL_ENVELOPE = "direct RSA encryption is not part of the component's cryptography";
const privateDecrypt = refuse("crypto.privateDecrypt", NO_OPENSSL_ENVELOPE);
const privateEncrypt = refuse("crypto.privateEncrypt", NO_OPENSSL_ENVELOPE);
const publicDecrypt = refuse("crypto.publicDecrypt", NO_OPENSSL_ENVELOPE);
const publicEncrypt = refuse("crypto.publicEncrypt", NO_OPENSSL_ENVELOPE);
const argon2 = refuse("crypto.argon2", "Argon2 is not in the Workers cryptography baseline");
const argon2Sync = argon2;
const checkPrime = refuse("crypto.checkPrime", "primality testing is not exposed by the cryptography boundary");
const checkPrimeSync = checkPrime;
const generatePrime = refuse("crypto.generatePrime", "prime generation is not exposed by the cryptography boundary");
const generatePrimeSync = generatePrime;
const setEngine = refuse("crypto.setEngine", "OpenSSL engines are not addressable from a component");
const secureHeapUsed = () => ({
	total: 0,
	min: 0,
	used: 0,
	utilization: 0
});
const crypto = {
	Cipheriv,
	Decipheriv,
	DiffieHellman,
	ECDH,
	Hash,
	Hmac,
	KeyObject,
	Sign,
	Verify,
	X509Certificate,
	argon2,
	argon2Sync,
	checkPrime,
	checkPrimeSync,
	constants,
	createCipheriv,
	createDecipheriv,
	createDiffieHellman,
	createDiffieHellmanGroup,
	createECDH,
	createHash,
	createHmac,
	createPrivateKey,
	createPublicKey,
	createSecretKey,
	createSign,
	createVerify,
	diffieHellman,
	fips: false,
	generateKey,
	generateKeyPair,
	generateKeyPairSync,
	generateKeySync,
	generatePrime,
	generatePrimeSync,
	getCipherInfo,
	getCiphers,
	getCurves,
	getDiffieHellman,
	getFips,
	getHashes,
	getRandomValues,
	hash,
	hkdf,
	hkdfSync,
	pbkdf2,
	pbkdf2Sync,
	privateDecrypt,
	privateEncrypt,
	publicDecrypt,
	publicEncrypt,
	randomBytes,
	randomFill,
	randomFillSync,
	randomInt,
	randomUUID,
	scrypt,
	scryptSync,
	secureHeapUsed,
	setEngine,
	setFips,
	sign,
	subtle,
	timingSafeEqual,
	verify,
	webcrypto
};
//#endregion
export { Cipheriv, Decipheriv, DiffieHellman, ECDH, Hash, Hmac, KeyObject, Sign, Verify, X509Certificate, argon2, argon2Sync, checkPrime, checkPrimeSync, constants, createCipheriv, createDecipheriv, createDiffieHellman, createDiffieHellmanGroup, createECDH, createHash, createHmac, createPrivateKey, createPublicKey, createSecretKey, createSign, createVerify, crypto as default, diffieHellman, fips, generateKey, generateKeyPair, generateKeyPairSync, generateKeySync, generatePrime, generatePrimeSync, getCipherInfo, getCiphers, getCurves, getDiffieHellman, getFips, getHashes, getRandomValues, hash, hkdf, hkdfSync, pbkdf2, pbkdf2Sync, privateDecrypt, privateEncrypt, publicDecrypt, publicEncrypt, randomBytes, randomFill, randomFillSync, randomInt, randomUUID, scrypt, scryptSync, secureHeapUsed, setEngine, setFips, sign, subtle, timingSafeEqual, verify, webcrypto };
