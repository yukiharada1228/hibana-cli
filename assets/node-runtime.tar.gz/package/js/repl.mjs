import { a as codedError, h as missingArgs, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { a as validateFunction } from "./chunks/validation-qQPlCQ6g.mjs";
import { m as import_events } from "./chunks/events-KhrHxd6b.mjs";
import { a as builtinModules, n as Module, t as createRequire } from "./chunks/require-BqabYoHg.mjs";
import { c as commonPrefix, f as defer, i as moveCursor, n as clearScreenDown, r as cursorTo, u as kSubstringSearch } from "./chunks/callbacks-CB8KGxqT.mjs";
import { c as kLastCommandErrored, f as kSetLine, g as History, l as kMultilinePrompt, s as kAddNewLineOnTTY } from "./chunks/promises-BYqWMSui.mjs";
import { t as Interface } from "./chunks/readline-BmG3sSja.mjs";
import { n as inspectDefaultOptions, t as inspect } from "./chunks/inspect-DXZXEVsB.mjs";
import { a as Parser, c as types$1, i as simple, n as base$1, o as acorn_exports, r as recursive } from "./chunks/walk-CkCAtcHQ.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/recoverable.js
const Recoverable = function Recoverable(err) {
	this.err = err;
};
Object.setPrototypeOf(Recoverable.prototype, SyntaxError.prototype);
Object.setPrototypeOf(Recoverable, SyntaxError);
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/await.js
const base = base$1;
function isTopLevelDeclaration(state) {
	return state.ancestors[state.ancestors.length - 2] === state.body;
}
const noop = () => {};
const visitorsWithoutAncestors = {
	ClassDeclaration(node, state, c) {
		const declaration = node;
		if (isTopLevelDeclaration(state)) {
			state.prepend(declaration, `${declaration.id.name}=`);
			state.hoistedDeclarationStatements.push(`let ${declaration.id.name}; `);
		}
		base.ClassDeclaration(node, state, c);
	},
	ForOfStatement(node, state, c) {
		if (node.await === true) state.containsAwait = true;
		base.ForOfStatement(node, state, c);
	},
	FunctionDeclaration(node, state) {
		const declaration = node;
		state.prepend(declaration, `this.${declaration.id.name} = ${declaration.id.name}; `);
		state.hoistedDeclarationStatements.push(`var ${declaration.id.name}; `);
	},
	FunctionExpression: noop,
	ArrowFunctionExpression: noop,
	MethodDefinition: noop,
	AwaitExpression(node, state, c) {
		state.containsAwait = true;
		base.AwaitExpression(node, state, c);
	},
	ReturnStatement(node, state, c) {
		state.containsReturn = true;
		base.ReturnStatement(node, state, c);
	},
	VariableDeclaration(node, state, c) {
		const declaration = node;
		const variableKind = declaration.kind;
		const isIterableForDeclaration = ["ForOfStatement", "ForInStatement"].includes(state.ancestors[state.ancestors.length - 2].type);
		if (variableKind === "var" || isTopLevelDeclaration(state)) {
			state.replace(declaration.start, declaration.start + variableKind.length + (isIterableForDeclaration ? 1 : 0), variableKind === "var" && isIterableForDeclaration ? "" : "void" + (declaration.declarations.length === 1 ? "" : " ("));
			if (!isIterableForDeclaration) {
				for (const decl of declaration.declarations) {
					state.prepend(decl, "(");
					state.append(decl, decl.init ? ")" : "=undefined)");
				}
				if (declaration.declarations.length !== 1) state.append(declaration.declarations[declaration.declarations.length - 1], ")");
			}
			const variableIdentifiersToHoist = [["var", []], ["let", []]];
			function registerVariableDeclarationIdentifiers(node) {
				switch (node?.type) {
					case "Identifier":
						variableIdentifiersToHoist[variableKind === "var" ? 0 : 1][1].push(node.name);
						break;
					case "ObjectPattern":
						for (const property of node.properties) registerVariableDeclarationIdentifiers(property.type === "RestElement" ? property.argument : property.value);
						break;
					case "ArrayPattern": for (const element of node.elements) registerVariableDeclarationIdentifiers(element);
				}
			}
			for (const decl of declaration.declarations) registerVariableDeclarationIdentifiers(decl.id);
			for (const [kind, identifiers] of variableIdentifiersToHoist) if (identifiers.length > 0) state.hoistedDeclarationStatements.push(`${kind} ${identifiers.join(", ")}; `);
		}
		base.VariableDeclaration(node, state, c);
	}
};
const visitors = {};
for (const nodeType of Object.keys(base)) {
	const callback = visitorsWithoutAncestors[nodeType] || base[nodeType];
	visitors[nodeType] = (node, state, c) => {
		const isNew = node !== state.ancestors[state.ancestors.length - 1];
		if (isNew) state.ancestors.push(node);
		callback(node, state, c);
		if (isNew) state.ancestors.pop();
	};
}
/**
* Rewrite a top-level `await` script into an async wrapper returning `{ value }`.
*
* Returns `null` when the source needs no rewriting, throws `Recoverable` for incomplete input,
* and re-throws parse failures as a `SyntaxError` in Node's message shape.
*/
function processTopLevelAwait(src) {
	const wrapped = `(async () => { ${src} })()`;
	const wrappedArray = wrapped.split("");
	let root;
	try {
		root = Parser.parse(wrapped, { ecmaVersion: "latest" });
	} catch (error) {
		const e = error;
		if (e.message.startsWith("Unterminated ")) throw new Recoverable(e);
		const awaitPos = src.indexOf("await");
		const errPos = e.pos - 15;
		if (awaitPos > errPos) return null;
		if (errPos === awaitPos + 6 && e.message.includes("Expecting Unicode escape sequence")) return null;
		if (errPos === awaitPos + 7 && e.message.includes("Unexpected token")) return null;
		const line = e.loc.line;
		const column = line === 1 ? e.loc.column - 15 : e.loc.column;
		let message = "\n" + src.split("\n", line)[line - 1] + "\n" + " ".repeat(column) + "^\n\n" + e.message.replace(/ \([^)]+\)/, "");
		if (message.endsWith("Unexpected token")) message += " '" + (src[e.pos - 15] ?? src[src.length - 1]) + "'";
		throw new SyntaxError(message);
	}
	const body = root.body[0].expression.callee.body;
	const state = {
		body,
		ancestors: [],
		hoistedDeclarationStatements: [],
		replace(from, to, str) {
			for (let i = from; i < to; i++) wrappedArray[i] = "";
			if (from === to) str += wrappedArray[from];
			wrappedArray[from] = str;
		},
		prepend(node, str) {
			wrappedArray[node.start] = str + wrappedArray[node.start];
		},
		append(node, str) {
			wrappedArray[node.end - 1] += str;
		},
		containsAwait: false,
		containsReturn: false
	};
	recursive(body, state, visitors);
	if (!state.containsAwait || state.containsReturn) return null;
	for (let i = body.body.length - 1; i >= 0; i--) {
		const node = body.body[i];
		if (node.type === "EmptyStatement") continue;
		if (node.type === "ExpressionStatement") {
			state.prepend(node.expression, "{ value: (");
			state.prepend(node, "return ");
			state.append(node.expression, ") }");
		}
		break;
	}
	return state.hoistedDeclarationStatements.join("") + wrappedArray.join("");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/utils.js
const REPL_MODE_SLOPPY = Symbol("repl-sloppy");
const REPL_MODE_STRICT = Symbol("repl-strict");
const kContextId = Symbol("contextId");
/** The `process` global when one exists; the REPL never imports `node:process`. */
function processGlobal() {
	const candidate = globalThis.process;
	return candidate !== null && typeof candidate === "object" ? candidate : void 0;
}
function env(name) {
	return processGlobal()?.env?.[name];
}
/** Parse `code` as Node's REPL compiles it: a classic script, latest ECMAScript. */
function parseScript(code, extra = {}) {
	return Parser.parse(code, {
		ecmaVersion: "latest",
		...extra
	});
}
function isAcornSyntaxError(error) {
	return error instanceof SyntaxError && typeof error.pos === "number";
}
const KEYWORDS = new Set("break case catch class const continue debugger default delete do else enum export extends false finally for function if import in instanceof new null return super switch this throw true try typeof var void while with yield let static await async of".split(" "));
/** V8's wording for an unexpected token at `pos`: identifier, number, string, keyword, or char. */
function describeUnexpectedToken(code, pos) {
	const char = code[pos];
	if (char === void 0) return "Unexpected end of input";
	if (/\d/.test(char)) return "Unexpected number";
	if (char === "'" || char === "\"") return "Unexpected string";
	if (char === "`") return "Unexpected template string";
	const word = /^[A-Za-z_$][\w$]*/.exec(code.slice(pos))?.[0];
	if (word === void 0) return `Unexpected token '${char}'`;
	return KEYWORDS.has(word) ? `Unexpected token '${word}'` : `Unexpected identifier '${word}'`;
}
/**
* Make an acorn parse error read like V8's: drop the trailing ` (line:column)`, and name the
* offending token the way V8's `Unexpected token '.'` and `Unexpected end of input` do.
*
* Mutates and returns the same error, so identity and the `Recoverable.err` link are kept.
*/
function normalizeAcornError(error, code) {
	if (isAcornSyntaxError(error)) {
		error.message = error.message.replace(/ \(\d+:\d+\)$/, "");
		if (error.message === "Unexpected token") error.message = describeUnexpectedToken(code, error.pos);
	}
	return error;
}
/**
* Rewrite top-level lexical declarations so they outlive the line.
*
* Node runs each line as a `vm.Script`, whose top-level `let`, `const` and `class` bindings live
* in the realm's script scope and stay visible to later lines. An indirect `eval` -- the only
* engine-neutral way to run a script here -- scopes those bindings to the eval itself, so
* `let x = 1` would be gone by the next prompt. Rewriting them to `var` (a `class` to a `var`
* initialised with the class expression) makes them global properties, which is exactly where
* an eval'd `var` lands. Only direct children of the program are touched; blocks, loops and
* function bodies keep their own scoping. The cost is that `const` is not enforced across lines
* and a redeclaration on a later line is silently accepted -- the same trade Node documents for
* lines containing `await`.
*/
function persistLexicalDeclarations(code, ast) {
	const edits = [];
	for (const node of ast.body) if (node.type === "VariableDeclaration" && node.kind !== "var") edits.push({
		start: node.start,
		end: node.start + node.kind.length,
		text: "var"
	});
	else if (node.type === "ClassDeclaration") edits.push({
		start: node.start,
		end: node.start,
		text: `var ${node.id.name} = `
	});
	if (edits.length === 0) return code;
	let result = "";
	let cursor = 0;
	for (const edit of edits) {
		result += code.slice(cursor, edit.start) + edit.text;
		cursor = edit.end;
	}
	return result + code.slice(cursor);
}
function isRecoverableError(e, code) {
	if (/^\s*\{/.test(code) && isRecoverableError(e, `(${code}`)) return true;
	let recoverable = false;
	const RecoverableParser = Parser.extend((Base) => {
		const Internal = Base;
		return class extends Internal {
			nextToken() {
				super.nextToken();
				if (this.type === types$1.eof) recoverable = true;
			}
			raise(pos, message) {
				switch (message) {
					case "Unterminated template":
					case "Unterminated comment":
						recoverable = true;
						break;
					case "Unterminated string constant": {
						const token = this.input.slice(this.lastTokStart, this.pos);
						if (/\\(?:\r\n?|\n|\u2028|\u2029)$/.test(token)) recoverable = true;
					}
				}
				return super.raise(pos, message);
			}
		};
	});
	try {
		RecoverableParser.parse(code, { ecmaVersion: "latest" });
		return false;
	} catch {
		return recoverable;
	}
}
const startsWithBraceRegExp = /^\s*{/;
const endsWithSemicolonRegExp = /;\s*$/;
function isValidSyntax(input) {
	try {
		Parser.parse(input, {
			ecmaVersion: "latest",
			allowAwaitOutsideFunction: true
		});
		return true;
	} catch {
		try {
			Parser.parse(`_=${input}`, {
				ecmaVersion: "latest",
				allowAwaitOutsideFunction: true
			});
			return true;
		} catch {
			return false;
		}
	}
}
/**
* Checks if some provided code represents an object literal.
* This is helpful to prevent confusing repl code evaluations where
* strings such as `{ a : 1 }` would get interpreted as block statements
* rather than object literals.
* @param {string} code the code to check
* @returns {boolean} true if the code represents an object literal, false otherwise
*/
function isObjectLiteral(code) {
	return startsWithBraceRegExp.test(code) && !endsWithSemicolonRegExp.test(code);
}
let nextREPLResourceNumber = 1;
function getREPLResourceName() {
	return `REPL${nextREPLResourceNumber++}`;
}
let _builtinLibs = builtinModules.filter((e) => e[0] !== "_" && !e.startsWith("node:"));
function getReplBuiltinLibs() {
	return _builtinLibs;
}
function setReplBuiltinLibs(value) {
	_builtinLibs = value;
}
/**
* Node's `shouldColorize`, minus the `internal/tty` color-depth probe: `FORCE_COLOR` follows
* Node's own parsing (only `0` and `false` disable), otherwise the stream decides.
*/
function shouldColorize(stream) {
	const forced = env("FORCE_COLOR");
	if (forced !== void 0) {
		const normalized = forced.trim().toLowerCase();
		return normalized !== "0" && normalized !== "false";
	}
	const candidate = stream;
	return !!candidate?.isTTY && (typeof candidate.getColorDepth === "function" ? candidate.getColorDepth() > 2 : true);
}
function setupReverseSearch(repl) {
	if (env("TERM") === "dumb") return { reverseSearch() {
		return false;
	} };
	const alreadyMatched = /* @__PURE__ */ new Set();
	const labels = {
		r: "bck-i-search: ",
		s: "fwd-i-search: "
	};
	let isInReverseSearch = false;
	let historyIndex = -1;
	let input = "";
	let cursor = -1;
	let dir = "r";
	let lastMatch = -1;
	let lastCursor = -1;
	let promptPos;
	function checkAndSetDirectionKey(keyName) {
		if (keyName === void 0 || !labels[keyName]) return false;
		if (dir !== keyName) {
			alreadyMatched.clear();
			dir = keyName;
		}
		return true;
	}
	function goToNextHistoryIndex() {
		alreadyMatched.add(repl.history[historyIndex]);
		historyIndex += dir === "r" ? 1 : -1;
		cursor = -1;
	}
	function search() {
		if (input === "") {
			print(repl.line, `${labels[dir]}_`);
			return;
		}
		if (dir === "r") {
			if (historyIndex < 0) historyIndex = 0;
		} else if (historyIndex >= repl.history.length) historyIndex = repl.history.length - 1;
		while (historyIndex >= 0 && historyIndex < repl.history.length) {
			let entry = repl.history[historyIndex];
			if (alreadyMatched.has(entry)) {
				historyIndex += dir === "r" ? 1 : -1;
				continue;
			}
			if (dir === "r") {
				if (cursor === -1) cursor = entry.length;
				cursor = entry.lastIndexOf(input, cursor - 1);
			} else cursor = entry.indexOf(input, cursor + 1);
			if (cursor === -1) goToNextHistoryIndex();
			else {
				if (repl.useColors) {
					const start = entry.slice(0, cursor);
					const end = entry.slice(cursor + input.length);
					entry = `${start}\x1B[4m${input}\x1B[24m${end}`;
				}
				print(entry, `${labels[dir]}${input}_`, cursor);
				lastMatch = historyIndex;
				lastCursor = cursor;
				if (dir === "r" && cursor === 0 || dir === "s" && entry.length === cursor + input.length) goToNextHistoryIndex();
				return;
			}
		}
		print(repl.line, `failed-${labels[dir]}${input}_`);
	}
	function print(outputLine, inputLine, cursor = repl.cursor) {
		let rows = 0;
		if (lastMatch !== -1) {
			const line = repl.history[lastMatch].slice(0, lastCursor);
			rows = repl._getDisplayPos(`${repl.getPrompt()}${line}`).rows;
			cursorTo(repl.output, promptPos.cols);
		} else if (isInReverseSearch && repl.line !== "") {
			rows = repl.getCursorPos().rows;
			cursorTo(repl.output, promptPos.cols);
		}
		if (rows !== 0) moveCursor(repl.output, 0, -rows);
		if (isInReverseSearch) {
			clearScreenDown(repl.output);
			repl.output?.write(`${outputLine}\n${inputLine}`);
		} else repl.output?.write(`\n${inputLine}`);
		lastMatch = -1;
		const prompt = repl.getPrompt();
		const cursorLine = prompt + outputLine.slice(0, cursor);
		const cursorPos = repl._getDisplayPos(cursorLine);
		const outputPos = repl._getDisplayPos(`${prompt}${outputLine}`);
		const inputPos = repl._getDisplayPos(inputLine);
		rows = -1 - (inputPos.rows - (inputPos.cols === 0 ? 1 : 0)) - (outputPos.rows - cursorPos.rows);
		moveCursor(repl.output, 0, rows);
		cursorTo(repl.output, cursorPos.cols);
	}
	function reset(string) {
		isInReverseSearch = string !== void 0;
		if (!isInReverseSearch) {
			if (lastMatch !== -1) {
				repl[kSetLine](repl.history[lastMatch]);
				repl.cursor = lastCursor;
				repl.historyIndex = lastMatch;
			}
			lastMatch = -1;
			cursorTo(repl.output, promptPos.cols);
			moveCursor(repl.output, 0, promptPos.rows);
			clearScreenDown(repl.output);
			if (repl.line !== "") {
				repl.output?.write(repl.line);
				if (repl.line.length !== repl.cursor) {
					const { cols, rows } = repl.getCursorPos();
					cursorTo(repl.output, cols);
					moveCursor(repl.output, 0, rows);
				}
			}
		}
		input = string || "";
		cursor = -1;
		historyIndex = repl.historyIndex;
		alreadyMatched.clear();
	}
	function reverseSearch(string, key) {
		if (!isInReverseSearch) {
			if (key.ctrl && checkAndSetDirectionKey(key.name)) {
				historyIndex = repl.historyIndex;
				promptPos = repl._getDisplayPos(`${repl.getPrompt()}`);
				print(repl.line, `${labels[dir]}_`);
				isInReverseSearch = true;
			}
		} else if (key.ctrl && checkAndSetDirectionKey(key.name)) search();
		else if (key.name === "backspace" || key.ctrl && (key.name === "h" || key.name === "w")) {
			reset(input.slice(0, input.length - 1));
			search();
		} else if (key.ctrl && key.name === "c" || key.name === "escape") {
			lastMatch = -1;
			reset();
			return true;
		} else if (key.ctrl || key.meta || key.name === "return" || key.name === "enter" || typeof string !== "string" || string === "") {
			reset();
			repl[kSubstringSearch] = "";
		} else {
			reset(`${input}${string}`);
			search();
		}
		return isInReverseSearch;
	}
	return { reverseSearch };
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/completion.js
const { isIdentifierChar, isIdentifierStart } = acorn_exports;
const importRE = /\bimport\s*\(\s*['"`](([\w@./:-]+\/)?(?:[\w@./:-]*))(?![^'"`])$/;
const requireRE = /\brequire\s*\(\s*['"`](([\w@./:-]+\/)?(?:[\w@./:-]*))(?![^'"`])$/;
const fsAutoCompleteRE = /fs(?:\.promises)?\.\s*[a-z][a-zA-Z]+\(\s*["'](.*)/;
/** Node's `node:`-scheme builtin names: every lib plus the scheme-only modules. */
const nodeSchemeBuiltinLibs = () => [...getReplBuiltinLibs().map((lib) => `node:${lib}`), ...builtinModules.filter((name) => name.startsWith("node:"))];
function isIdentifier(str) {
	if (str === "") return false;
	const first = str.codePointAt(0);
	if (!isIdentifierStart(first)) return false;
	const firstLen = first > 65535 ? 2 : 1;
	for (let i = firstLen; i < str.length; i += 1) {
		const cp = str.codePointAt(i);
		if (!isIdentifierChar(cp)) return false;
		if (cp > 65535) i += 1;
	}
	return true;
}
function isNotLegacyObjectPrototypeMethod(str) {
	return isIdentifier(str) && str !== "__defineGetter__" && str !== "__defineSetter__" && str !== "__lookupGetter__" && str !== "__lookupSetter__";
}
/** Node's `getOwnNonIndexProperties(obj, ALL_PROPERTIES | SKIP_SYMBOLS)`: string keys that are not array indices. */
function getOwnNonIndexProperties(obj) {
	return Object.getOwnPropertyNames(obj).filter((name) => !(/^(?:0|[1-9]\d*)$/.test(name) && Number(name) < 4294967295));
}
function filteredOwnPropertyNames(obj) {
	if (!obj || typeof obj !== "object" && typeof obj !== "function") return [];
	let isObjectPrototype = false;
	if (Object.getPrototypeOf(obj) === null) {
		const ctorDescriptor = Object.getOwnPropertyDescriptor(obj, "constructor");
		if (ctorDescriptor?.value) {
			const ctorProto = Object.getPrototypeOf(ctorDescriptor.value);
			isObjectPrototype = ctorProto !== null && Object.getPrototypeOf(ctorProto) === obj;
		}
	}
	return getOwnNonIndexProperties(obj).filter(isObjectPrototype ? isNotLegacyObjectPrototypeMethod : isIdentifier);
}
function addCommonWords(completionGroups) {
	completionGroups.push([
		"async",
		"await",
		"break",
		"case",
		"catch",
		"const",
		"continue",
		"debugger",
		"default",
		"delete",
		"do",
		"else",
		"export",
		"false",
		"finally",
		"for",
		"function",
		"if",
		"import",
		"in",
		"instanceof",
		"let",
		"new",
		"null",
		"return",
		"switch",
		"this",
		"throw",
		"true",
		"try",
		"typeof",
		"var",
		"void",
		"while",
		"with",
		"yield"
	]);
}
function complete(line, callback) {
	let completionGroups = [];
	let completeOn;
	line = line.trimStart();
	let filter = "";
	let match;
	if ((match = /^\s*\.(\w*)$/.exec(line)) !== null) {
		completionGroups.push(Object.keys(this.commands));
		completeOn = match[1];
		if (completeOn.length) filter = completeOn;
	} else if ((match = requireRE.exec(line)) !== null) {
		completeOn = match[1];
		filter = completeOn;
		completionGroups.push(getReplBuiltinLibs(), nodeSchemeBuiltinLibs());
	} else if ((match = importRE.exec(line)) !== null) {
		completeOn = match[1];
		filter = completeOn;
		completionGroups.push(getReplBuiltinLibs(), nodeSchemeBuiltinLibs());
	} else if ((match = fsAutoCompleteRE.exec(line)) !== null && this.allowBlockingCompletions) {
		const filePath = match[1];
		completeOn = filePath.slice(filePath.lastIndexOf("/") + 1);
		completionGroups = [[]];
	} else if (line.length === 0 || /\w|\.|\$/.test(line[line.length - 1])) {
		const completeTarget = line.length === 0 ? line : findExpressionCompleteTarget(line);
		if (line.length !== 0 && !completeTarget) {
			completionGroupsLoaded();
			return;
		}
		let expr = "";
		completeOn = completeTarget ?? "";
		if (line.endsWith(".")) expr = completeOn.slice(0, -1);
		else if (line.length !== 0) {
			const bits = completeOn.split(".");
			filter = bits.pop();
			expr = bits.join(".");
		}
		if (!expr) {
			let contextProto = this.context;
			while ((contextProto = Object.getPrototypeOf(contextProto)) !== null) completionGroups.push(filteredOwnPropertyNames(contextProto));
			const contextOwnNames = filteredOwnPropertyNames(this.context);
			completionGroups.push(contextOwnNames);
			if (filter !== "") addCommonWords(completionGroups);
			completionGroupsLoaded();
			return;
		}
		const parsableCompleteTarget = completeOn.endsWith(".") ? `${completeOn}x` : completeOn;
		let completeTargetAst;
		try {
			completeTargetAst = Parser.parse(parsableCompleteTarget, {
				sourceType: "module",
				ecmaVersion: "latest"
			});
		} catch {}
		if (!completeTargetAst) return completionGroupsLoaded();
		const statement = completeTargetAst.body[0];
		return includesProxiesOrGetters(statement.type === "ExpressionStatement" ? statement.expression : void 0, parsableCompleteTarget, this.eval.bind(this), this.context, (includes) => {
			if (includes) return completionGroupsLoaded();
			let chaining = ".";
			if (expr.endsWith("?")) {
				expr = expr.slice(0, -1);
				chaining = "?.";
			}
			const memberGroups = [];
			const evalExpr = `try { ${expr} } catch {}`;
			this.eval(evalExpr, this.context, getREPLResourceName(), (_e, obj) => {
				try {
					let p;
					if (typeof obj === "object" && obj !== null || typeof obj === "function") {
						memberGroups.push(filteredOwnPropertyNames(obj));
						p = Object.getPrototypeOf(obj);
					} else p = (obj?.constructor)?.prototype ?? null;
					let sentinel = 5;
					while (p !== null && sentinel-- !== 0) {
						memberGroups.push(filteredOwnPropertyNames(p));
						p = Object.getPrototypeOf(p);
					}
				} catch {}
				if (memberGroups.length) {
					expr += chaining;
					for (const group of memberGroups) completionGroups.push(group.map((member) => `${expr}${member}`));
					filter &&= `${expr}${filter}`;
				}
				completionGroupsLoaded();
			});
		});
	}
	return completionGroupsLoaded();
	function completionGroupsLoaded() {
		if (completionGroups.length && filter) {
			const newCompletionGroups = [];
			const lowerCaseFilter = filter.toLocaleLowerCase();
			for (const group of completionGroups) {
				const filteredGroup = group.filter((str) => {
					return str.toLocaleLowerCase().startsWith(lowerCaseFilter);
				});
				if (filteredGroup.length) newCompletionGroups.push(filteredGroup);
			}
			completionGroups = newCompletionGroups;
		}
		const completions = [];
		const uniqueSet = /* @__PURE__ */ new Set();
		uniqueSet.add("");
		for (const group of completionGroups) {
			group.sort((a, b) => b > a ? 1 : -1);
			const setSize = uniqueSet.size;
			for (const entry of group) if (!uniqueSet.has(entry)) {
				completions.unshift(entry);
				uniqueSet.add(entry);
			}
			if (uniqueSet.size !== setSize) completions.unshift("");
		}
		if (completions[0] === "") completions.shift();
		callback(null, [completions, completeOn ?? ""]);
	}
}
/**
* This function tries to extract a target for tab completion from code representing an expression.
*
* Such target is basically the last piece of the expression that can be evaluated for the potential
* tab completion.
*
* Some examples:
* - The complete target for `const a = obj.b` is `obj.b`
*   (because tab completion will evaluate and check the `obj.b` object)
* - The complete target for `tru` is `tru`
*   (since we'd ideally want to complete that to `true`)
* - The complete target for `{ a: tru` is `tru`
*   (like the last example, we'd ideally want that to complete to true)
* - There is no complete target for `{ a: true }`
*   (there is nothing to complete)
* @param {string} code the code representing the expression to analyze
* @returns {string|null} a substring of the code representing the complete target is there was one, `null` otherwise
*/
function findExpressionCompleteTarget(code) {
	if (!code) return null;
	if (code.at(-1) === ".") {
		if (code.at(-2) === "?") {
			const result = findExpressionCompleteTarget(code.slice(0, -2));
			return !result ? result : `${result}?.`;
		}
		const result = findExpressionCompleteTarget(code.slice(0, -1));
		return !result ? result : `${result}.`;
	}
	let ast;
	try {
		ast = Parser.parse(code, {
			sourceType: "module",
			ecmaVersion: "latest"
		});
	} catch {
		const keywords = code.split(" ");
		if (keywords.length > 1) return findExpressionCompleteTarget(keywords.at(-1));
		return null;
	}
	const lastBodyStatement = ast.body[ast.body.length - 1];
	if (!lastBodyStatement) return null;
	if (lastBodyStatement.type === "BlockStatement") return null;
	if (lastBodyStatement.type === "ExpressionStatement" && "right" in lastBodyStatement.expression) {
		const exprRight = lastBodyStatement.expression.right;
		return findExpressionCompleteTarget(code.slice(exprRight.start, exprRight.end));
	}
	if (lastBodyStatement.type === "VariableDeclaration") {
		const lastDeclarationInit = lastBodyStatement.declarations.at(-1).init;
		if (!lastDeclarationInit) return null;
		return findExpressionCompleteTarget(code.slice(lastDeclarationInit.start, lastDeclarationInit.end));
	}
	if (lastBodyStatement.type === "ExpressionStatement" && lastBodyStatement.expression.type === "UnaryExpression" && lastBodyStatement.expression.argument) {
		const argument = lastBodyStatement.expression.argument;
		return findExpressionCompleteTarget(code.slice(argument.start, argument.end));
	}
	if (lastBodyStatement.type === "ExpressionStatement" && lastBodyStatement.expression.type === "NewExpression" && lastBodyStatement.expression.callee) {
		const callee = lastBodyStatement.expression.callee;
		return findExpressionCompleteTarget(code.slice(callee.start, callee.end));
	}
	let isAllowed = true;
	const disallow = () => {
		isAllowed = false;
	};
	simple(lastBodyStatement, {
		ForInStatement: disallow,
		ForOfStatement: disallow,
		CallExpression: disallow,
		AssignmentExpression: disallow,
		UpdateExpression: disallow
	});
	if (!isAllowed) return null;
	return code.slice(lastBodyStatement.start, lastBodyStatement.end);
}
/**
* Utility used to determine if an expression includes object getters or proxies.
*
* Example: given `obj.foo`, the function lets you know if `foo` has a getter function
* associated to it, or if `obj` is a proxy
* @param {any} expr The expression, in AST format to analyze
* @param {string} exprStr The string representation of the expression
* @param {(str: string, ctx: any, resourceName: string, cb: (error, evaled) => void) => void} evalFn
*   Eval function to use
* @param {any} ctx The context to use for any code evaluation
* @param {(includes: boolean) => void} callback Callback that will be called with the result of the operation
* @returns {void}
*/
function includesProxiesOrGetters(expr, exprStr, evalFn, ctx, callback) {
	if (expr?.type !== "MemberExpression") return callback(false);
	if (expr.object.type === "MemberExpression") return includesProxiesOrGetters(expr.object, exprStr.slice(0, expr.object.end), evalFn, ctx, (includes, lastEvaledObj) => {
		if (includes) return callback(includes);
		return hasGetterOrIsProxy(lastEvaledObj, expr.property, (doesHaveGetterOrIsProxy) => {
			return callback(doesHaveGetterOrIsProxy);
		});
	});
	if (expr.object.type === "Identifier") return evalFn(`try { ${expr.object.name} } catch {}`, ctx, getREPLResourceName(), (err, obj) => {
		if (err) return callback(false);
		return hasGetterOrIsProxy(obj, expr.property, (doesHaveGetterOrIsProxy) => {
			if (doesHaveGetterOrIsProxy) return callback(true);
			return evalFn(`try { ${exprStr} } catch {} `, ctx, getREPLResourceName(), (err, obj) => {
				if (err) return callback(false);
				return callback(false, obj);
			});
		});
	});
	/**
	* Utility to see if a property has a getter associated to it or if
	* the property itself is a proxy object.
	* @returns {void}
	*/
	function hasGetterOrIsProxy(obj, astProp, cb) {
		if (!obj || !astProp) return cb(false);
		if (astProp.type === "Literal") return propHasGetter(obj, astProp.value, cb);
		if (astProp.type === "Identifier" && exprStr.at(astProp.start - 1) === ".") return propHasGetter(obj, astProp.name, cb);
		return evalFn(`try { ${exprStr.slice(astProp.start, astProp.end)} } catch {} `, ctx, getREPLResourceName(), (err, evaledProp) => {
			if (err) return cb(false);
			if (typeof evaledProp === "string") return propHasGetter(obj, evaledProp, cb);
			return cb(false);
		});
	}
	return callback(false);
}
/**
* Given an object and a property name, checks whether the property has a getter.
*
* Node also checks whether the value is a proxy, which needs a V8 binding; an engine offers no
* portable way to tell a proxy from its target, so that half of the check is absent here.
*/
function propHasGetter(obj, prop, cb) {
	if (obj === null || typeof obj !== "object" && typeof obj !== "function") return cb(false);
	cb(typeof Object.getOwnPropertyDescriptor(obj, prop)?.get === "function");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/server.js
const EventEmitter = import_events.EventEmitter;
const kBufferedCommandSymbol = Symbol("bufferedCommand");
const kLoadingSymbol = Symbol("loading");
/** Node's error for `breakEvalOnSigint` combined with a custom evaluator. */
function invalidReplEvalConfig() {
	return codedError(/* @__PURE__ */ new TypeError("Cannot specify both \"breakEvalOnSigint\" and \"eval\" for REPL"), "ERR_INVALID_REPL_EVAL_CONFIG");
}
const indirectEval = eval;
/**
* Run a script in the global scope, exactly as `vm.runInThisContext` does.
*
* An indirect `eval` is the engine-neutral equivalent. The `sourceURL` comment names the script
* the way Node names it (`REPL1`, `REPL2`, ...) on engines that honour it, and the function's own
* name marks where evaluated frames end so `trimEvalFrames` can cut the REPL's internals out.
*/
function runInThisContext(code, file) {
	return indirectEval(`${code}\n//# sourceURL=${file}`);
}
/**
* Keep only the stack frames that belong to evaluated code.
*
* Node trims everything below the REPL frame through V8's stack hook; here the boundary is the
* `runInThisContext` frame, which every engine names, plus the anonymous eval trampoline V8 and
* QuickJS put directly above it.
*/
function trimEvalFrames(stack) {
	const lines = stack.split("\n");
	const boundary = lines.findIndex((line, index) => index > 0 && line.includes("runInThisContext"));
	if (boundary === -1) return stack;
	const kept = lines.slice(0, boundary);
	if (/^\s*at eval \((?:<anonymous>|native)\)\s*$/.test(kept[kept.length - 1] ?? "")) kept.pop();
	if (/^(?:\s*at (?:eval|<eval>) \(|@)/.test(kept[kept.length - 1] ?? "")) kept.pop();
	return kept.join("\n");
}
/**
* Node decorates a compile error with the offending source line and a caret under the failing
* column. acorn reports the position, so the same decoration is built here and kept beside the
* error until it is printed.
*/
const arrowMessages = /* @__PURE__ */ new WeakMap();
function decorateSyntaxError(error, code) {
	if (!isAcornSyntaxError(error) || arrowMessages.has(error)) return;
	const line = code.split("\n")[error.loc.line - 1];
	if (line === void 0) return;
	arrowMessages.set(error, `${line}\n${" ".repeat(error.loc.column)}^\n\n`);
}
/**
* Whether the engine keeps the legacy `RegExp.$1`..`$9` statics the REPL saves and restores
* around each evaluation. SpiderMonkey has them; QuickJS does not.
*/
const legacyRegExpStatics = Object.prototype.hasOwnProperty.call(RegExp, "$1");
/**
* Stands in for the `node:domain` instance Node's REPL binds evaluation through.
*
* Synchronous exceptions from the evaluator are routed to `'error'`, which is what the REPL relies
* on. Errors thrown later by asynchronous work started from evaluated code are not: a domain
* captured those through async hooks, which a component does not have.
*/
var ReplDomain = class extends EventEmitter {
	bind(fn) {
		const domain = this;
		return function(...args) {
			try {
				return fn.apply(this, args);
			} catch (error) {
				domain.emit("error", error);
				return;
			}
		};
	}
	exit() {}
};
const writer = Object.assign((obj) => inspect(obj, writer.options), { options: {
	...inspectDefaultOptions,
	showProxy: true
} });
function isError(value) {
	return value instanceof Error;
}
/** acorn's message for a module-only statement in a script, standing in for V8's. */
const acornImportErrorStr = "'import' and 'export' may appear only with 'sourceType: module'";
const importErrorStr = "Cannot use import statement outside a module";
function toDynamicImport(codeLine) {
	let dynamicImportStatement = "";
	const ast = parseScript(codeLine, { sourceType: "module" });
	for (const node of ast.body) {
		if (node.type !== "ImportDeclaration") continue;
		const awaitDynamicImport = `await import(${JSON.stringify(node.source.value)});`;
		if (node.specifiers.length === 0) dynamicImportStatement += awaitDynamicImport;
		else if (node.specifiers.length === 1 && node.specifiers[0].type === "ImportNamespaceSpecifier") dynamicImportStatement += `const ${node.specifiers[0].local.name} = ${awaitDynamicImport}`;
		else {
			const importNames = node.specifiers.map((specifier) => {
				const local = specifier.local.name;
				const imported = specifier.type === "ImportSpecifier" ? specifier.imported.type === "Identifier" ? specifier.imported.name : String(specifier.imported.value) : void 0;
				return local === imported ? local : `${imported ?? "default"}: ${local}`;
			}).join(", ");
			dynamicImportStatement += `const { ${importNames} } = ${awaitDynamicImport}`;
		}
	}
	return dynamicImportStatement;
}
var ReplServerCore = class extends Interface {
	constructor(...args) {
		let [prompt, stream, eval_, useGlobal, ignoreUndefined, replMode] = args;
		let options;
		if (prompt !== null && typeof prompt === "object") {
			options = { ...prompt };
			stream = options.stream || options.socket;
			eval_ = options.eval;
			useGlobal = options.useGlobal;
			ignoreUndefined = options.ignoreUndefined;
			prompt = options.prompt;
			replMode = options.replMode;
		} else options = {};
		if (!options.input && !options.output) {
			const source = stream ?? processGlobal();
			if (source === void 0) throw unsupportedNodeApi("repl.start() without input and output streams", "there is no `process` global to supply stdin and stdout; pass the `input` and `output` options (or a `stream`) explicitly");
			options.input = source.stdin ?? source;
			options.output = source.stdout ?? source;
		}
		if (!options.input || !options.output) throw unsupportedNodeApi("repl.start() with only one of input and output", "a component REPL has no default stream to fill in the other side; pass both");
		if (options.terminal === void 0) options.terminal = options.output.isTTY;
		options.terminal = !!options.terminal;
		if (options.terminal && options.useColors === void 0) options.useColors = shouldColorize(options.output);
		if (options.breakEvalOnSigint && eval_) throw invalidReplEvalConfig();
		if (options.breakEvalOnSigint) throw unsupportedNodeApi("repl option breakEvalOnSigint", "a component has no signal watchdog that could interrupt a running evaluation");
		if (!useGlobal) throw unsupportedNodeApi("repl option useGlobal: false (Node's default)", "the platform cannot create a second realm for a separate REPL context; pass `useGlobal: true` to evaluate against the global scope, which is exact");
		if (replMode === REPL_MODE_STRICT) throw unsupportedNodeApi("repl option replMode: REPL_MODE_STRICT", "a strict-mode script evaluated through the engine's eval cannot bind declarations in the global scope, so nothing would persist between lines; use REPL_MODE_SLOPPY");
		const box = {};
		function completer(text, cb) {
			const repl = box.repl;
			complete.call(repl, text, repl.editorMode ? repl.completeOnEditorMode(cb) : cb);
		}
		super({
			input: options.input,
			output: options.output,
			completer: options.completer || completer,
			terminal: options.terminal,
			historySize: options.historySize,
			prompt
		});
		box.repl = this;
		const self = this;
		Object.defineProperty(this, "inputStream", {
			get: () => this.input,
			set: (val) => {
				this.input = val;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(this, "outputStream", {
			get: () => this.output,
			set: (val) => {
				this.output = val;
			},
			enumerable: false,
			configurable: true
		});
		this.allowBlockingCompletions = !!options.allowBlockingCompletions;
		this.useColors = !!options.useColors;
		this._domain = options.domain || new ReplDomain();
		this.useGlobal = !!useGlobal;
		this.ignoreUndefined = !!ignoreUndefined;
		this.replMode = replMode || REPL_MODE_SLOPPY;
		this.underscoreAssigned = false;
		this.last = void 0;
		this.underscoreErrAssigned = false;
		this.lastError = void 0;
		this.breakEvalOnSigint = !!options.breakEvalOnSigint;
		this.editorMode = false;
		this[kContextId] = void 0;
		this[kLastCommandErrored] = false;
		const savedRegExMatches = [
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			""
		];
		const sep = "\0\0\0";
		const regExMatcher = new RegExp(`^${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)${sep}(.*)$`);
		eval_ ||= defaultEval;
		const pausedBuffer = [];
		let paused = false;
		function pause() {
			paused = true;
		}
		function unpause() {
			if (!paused) return;
			paused = false;
			let entry;
			const tmpCompletionEnabled = self.isCompletionEnabled;
			while ((entry = pausedBuffer.shift()) !== void 0) {
				switch (entry[0]) {
					case "key": {
						const [d, key] = entry[1];
						self.isCompletionEnabled = entry[2];
						self._ttyWrite(d, key);
						break;
					}
					case "close": self.emit("exit");
				}
				if (paused) break;
			}
			self.isCompletionEnabled = tmpCompletionEnabled;
		}
		function defaultEval(code, context, file, cb) {
			let result;
			let wrappedErr;
			let err = null;
			let wrappedCmd = false;
			let awaitPromise = false;
			const input = code;
			if (isObjectLiteral(code) && isValidSyntax(code)) {
				code = `(${code.trim()})\n`;
				wrappedCmd = true;
			}
			if (code.includes("await")) try {
				const potentialWrappedCode = processTopLevelAwait(code);
				if (potentialWrappedCode !== null) {
					code = potentialWrappedCode;
					wrappedCmd = true;
					awaitPromise = true;
				}
			} catch (error) {
				const e = error;
				let recoverableError = false;
				if (e.name === "SyntaxError") {
					const fallbackCode = code.replace(/\bawait\b/g, "");
					try {
						parseScript(fallbackCode);
					} catch (fallbackError) {
						if (isRecoverableError(fallbackError, fallbackCode)) {
							recoverableError = true;
							err = new Recoverable(e);
						}
					}
				}
				if (!recoverableError) err = e;
			}
			if (code === "\n") return cb(null);
			if (err === null) while (true) {
				try {
					code = persistLexicalDeclarations(code, parseScript(code));
				} catch (error) {
					if (wrappedCmd) {
						wrappedCmd = false;
						awaitPromise = false;
						code = input;
						wrappedErr = error;
						continue;
					}
					const parseError = wrappedErr || error;
					const parsed = wrappedErr ? `(${input.trim()})\n` : code;
					decorateSyntaxError(parseError, parsed);
					normalizeAcornError(parseError, parsed);
					if (isRecoverableError(parseError, code)) err = new Recoverable(parseError);
					else err = parseError;
				}
				break;
			}
			if (legacyRegExpStatics) regExMatcher.exec(savedRegExMatches.join(sep));
			let finished = false;
			function finishExecution(err, result) {
				if (finished) return;
				finished = true;
				if (legacyRegExpStatics) for (let idx = 1; idx < savedRegExMatches.length; idx += 1) savedRegExMatches[idx] = RegExp[`$${idx}`];
				if (err) cb(err);
				else cb(null, result);
			}
			if (!err) {
				try {
					result = runInThisContext(code, file);
				} catch (error) {
					self._domain.emit("error", error);
					self._domain.exit();
					return;
				}
				if (awaitPromise) {
					pause();
					const promise = result;
					(async () => {
						try {
							const result = (await promise)?.value;
							finishExecution(null, result);
						} catch (error) {
							if (error) {
								self._domain.emit("error", error);
								self._domain.exit();
								return;
							}
							finishExecution(error);
						} finally {
							unpause();
						}
					})();
				}
			}
			if (!awaitPromise || err) finishExecution(err, result);
		}
		self.eval = self._domain.bind(eval_);
		self._domain.on("error", function debugDomainError(e) {
			let errStack = "";
			if (typeof e === "object" && e !== null) {
				if (isError(e)) {
					if (e.stack) {
						if (e.name === "SyntaxError") {
							e.stack = `${arrowMessages.get(e) ?? ""}${e.name}: ${e.message}\n`;
							if (e.message.includes(importErrorStr) || e.message.includes(acornImportErrorStr)) {
								e.message = "Cannot use import statement inside the Node.js REPL, alternatively use dynamic import: " + toDynamicImport(self.lines.at(-1) ?? "");
								e.stack = e.stack.replace(/SyntaxError:.*\n/, `SyntaxError: ${e.message}\n`);
							}
						} else e.stack = trimEvalFrames(e.stack);
					}
					errStack = self.writer(e);
					if (errStack[0] === "[" && errStack[errStack.length - 1] === "]") errStack = errStack.slice(1, -1);
				}
			}
			if (!self.underscoreErrAssigned) self.lastError = e;
			if (errStack === "") errStack = self.writer(e);
			const lines = errStack.split(/(?<=\n)/);
			let matched = false;
			errStack = "";
			for (const line of lines) if (!matched && /^\[?([A-Z][a-z0-9_]*)*Error/.test(line)) {
				errStack += (writer.options.breakLength ?? 0) >= line.length ? `Uncaught ${line}` : `Uncaught:\n${line}`;
				matched = true;
			} else errStack += line;
			if (!matched) errStack = `Uncaught${lines.length === 1 ? " " : ":\n"}${errStack}`;
			errStack += errStack.endsWith("\n") ? "" : "\n";
			self.output.write(errStack);
			self.clearBufferedCommand();
			self.lines.level = [];
			if (!self.closed) self.displayPrompt();
		});
		self.clearBufferedCommand();
		self.resetContext();
		this.commands = Object.create(null);
		defineDefaultCommands(this);
		self.writer = options.writer || writer;
		if (self.writer === writer) writer.options.colors = self.useColors;
		function _parseREPLKeyword(keyword, rest) {
			const cmd = this.commands[keyword];
			if (cmd) {
				cmd.action.call(this, rest);
				return true;
			}
			return false;
		}
		self.on("close", function emitExit() {
			if (paused) {
				pausedBuffer.push(["close"]);
				return;
			}
			self.emit("exit");
		});
		let sawSIGINT = false;
		let sawCtrlD = false;
		self.on("SIGINT", function onSigInt() {
			const empty = self.line.length === 0;
			self.clearLine();
			_turnOffEditorMode(self);
			const cmd = self[kBufferedCommandSymbol];
			if (!(cmd && cmd.length > 0) && empty) {
				if (sawSIGINT) {
					self.close();
					sawSIGINT = false;
					return;
				}
				self.output.write("(To exit, press Ctrl+C again or Ctrl+D or type .exit)\n");
				sawSIGINT = true;
			} else sawSIGINT = false;
			self.clearBufferedCommand();
			self.lines.level = [];
			self.displayPrompt();
		});
		self.on("line", function onLine(cmd) {
			cmd ||= "";
			sawSIGINT = false;
			if (self.editorMode) {
				self[kBufferedCommandSymbol] += cmd + "\n";
				const matches = self._sawKeyPress && !self[kLoadingSymbol] ? /^\s+/.exec(cmd) : null;
				if (matches) {
					const prefix = matches[0];
					self.write(prefix);
					self.line = prefix;
					self.cursor = prefix.length;
				}
				_memory.call(self, cmd);
				return;
			}
			const trimmedCmd = cmd.trim();
			if (trimmedCmd) {
				if (trimmedCmd.charAt(0) === "." && trimmedCmd.charAt(1) !== "." && Number.isNaN(Number.parseFloat(trimmedCmd))) {
					const matches = /^\.([^\s]+)\s*(.*)$/.exec(trimmedCmd);
					const keyword = matches?.[1] ?? "";
					const rest = matches?.[2] ?? "";
					if (_parseREPLKeyword.call(self, keyword, rest) === true) return;
					if (!self[kBufferedCommandSymbol]) {
						self.output.write("Invalid REPL keyword\n");
						finish(null);
						return;
					}
				}
			}
			const evalCmd = self[kBufferedCommandSymbol] + cmd + "\n";
			self.eval(evalCmd, self.context, getREPLResourceName(), finish);
			function finish(e, ...rest) {
				_memory.call(self, cmd);
				if (e && !self[kBufferedCommandSymbol] && cmd.trim().startsWith("npm ") && !(e instanceof Recoverable)) {
					self.output.write("npm should be run outside of the Node.js REPL, in your normal shell.\n(Press Ctrl+D to exit.)\n");
					self.displayPrompt();
					return;
				}
				if (e instanceof Recoverable && !sawCtrlD) {
					if (self.terminal) self[kAddNewLineOnTTY]();
					else {
						self[kBufferedCommandSymbol] += cmd + "\n";
						self.displayPrompt();
					}
					return;
				}
				if (e) {
					self._domain.emit("error", e.err || e);
					self[kLastCommandErrored] = true;
				}
				self.clearBufferedCommand();
				sawCtrlD = false;
				const ret = rest[0];
				if (!e && rest.length === 1 && (!self.ignoreUndefined || ret !== void 0)) {
					if (!self.underscoreAssigned) self.last = ret;
					self.output.write(self.writer(ret) + "\n");
				}
				if (!self.closed && !e) {
					self[kLastCommandErrored] = false;
					self.displayPrompt();
				}
			}
		});
		self.on("SIGCONT", function onSigCont() {
			if (self.editorMode) {
				self.output.write(`${self._initialPrompt}.editor\n`);
				self.output.write("// Entering editor mode (Ctrl+D to finish, Ctrl+C to cancel)\n");
				self.output.write(`${self[kBufferedCommandSymbol]}\n`);
				self.prompt(true);
			} else self.displayPrompt(true);
		});
		const { reverseSearch } = setupReverseSearch(this);
		const ttyWrite = self._ttyWrite.bind(self);
		self._ttyWrite = (d, key) => {
			key ||= {};
			if (paused) {
				pausedBuffer.push([
					"key",
					[d, key],
					self.isCompletionEnabled
				]);
				return;
			}
			if (!self.editorMode || !self.terminal) {
				if (key.ctrl && key.name === "d" && self.cursor === 0 && self.line.length === 0) self.clearLine();
				if (!reverseSearch(d, key)) ttyWrite(d, key);
				return;
			}
			if (key.ctrl && !key.shift) switch (key.name) {
				case "d":
					_turnOffEditorMode(self);
					sawCtrlD = true;
					ttyWrite(d, { name: "return" });
					break;
				case "n":
				case "p": break;
				default: ttyWrite(d, key);
			}
			else switch (key.name) {
				case "up":
				case "down": break;
				case "tab":
					self._previousKey = null;
					ttyWrite(d, key);
					break;
				default: ttyWrite(d, key);
			}
		};
		self.displayPrompt();
	}
	setupHistory(historyConfig = {}, cb) {
		const options = typeof historyConfig === "string" ? { filePath: historyConfig } : historyConfig;
		if (typeof cb === "function") options.onHistoryFileLoaded = cb;
		this.historyManager = new History(this, {
			history: [...this.history],
			size: options.size ?? this.historySize,
			removeHistoryDuplicates: options.removeHistoryDuplicates
		});
		if (options.filePath) this.output.write("\nError: Could not open history file.\nREPL session history will not be persisted.\n");
		options.onHistoryFileLoaded?.(null, this);
	}
	clearBufferedCommand() {
		this[kBufferedCommandSymbol] = "";
	}
	close() {
		if (this.terminal && this.historyManager.isFlushing && !this._closingOnFlush) {
			this._closingOnFlush = true;
			this.once("flushHistory", () => super.close());
			return;
		}
		defer(() => super.close());
	}
	createContext() {
		const context = globalThis;
		const replModule = new Module("<repl>");
		Object.defineProperty(context, "module", {
			configurable: true,
			writable: true,
			value: replModule
		});
		Object.defineProperty(context, "require", {
			configurable: true,
			writable: true,
			value: createRequire("<repl>")
		});
		return context;
	}
	resetContext() {
		this.context = this.createContext();
		this.underscoreAssigned = false;
		this.underscoreErrAssigned = false;
		this.lines = Object.assign([], { level: [] });
		Object.defineProperty(this.context, "_", {
			configurable: true,
			get: () => this.last,
			set: (value) => {
				this.last = value;
				if (!this.underscoreAssigned) {
					this.underscoreAssigned = true;
					this.output.write("Expression assignment to _ now disabled.\n");
				}
			}
		});
		Object.defineProperty(this.context, "_error", {
			configurable: true,
			get: () => this.lastError,
			set: (value) => {
				this.lastError = value;
				if (!this.underscoreErrAssigned) {
					this.underscoreErrAssigned = true;
					this.output.write("Expression assignment to _error now disabled.\n");
				}
			}
		});
		this.emit("reset", this.context);
	}
	displayPrompt(preserveCursor) {
		let prompt = this._initialPrompt;
		if (this[kBufferedCommandSymbol].length) prompt = kMultilinePrompt.description;
		super.setPrompt(prompt);
		this.prompt(preserveCursor);
	}
	setPrompt(prompt) {
		this._initialPrompt = prompt;
		super.setPrompt(prompt);
	}
	complete(line, callback) {
		this.completer.call(this, line, callback);
	}
	completeOnEditorMode(callback) {
		return (err, results) => {
			if (err) return callback(err);
			const [completions, completeOn = ""] = results;
			let result = completions.filter(Boolean);
			if (completeOn && result.length !== 0) result = [commonPrefix(result)];
			callback(null, [result, completeOn]);
		};
	}
	defineCommand(keyword, cmd) {
		let command;
		if (typeof cmd === "function") command = { action: cmd };
		else {
			validateFunction(cmd.action, "cmd.action");
			command = cmd;
		}
		this.commands[keyword] = command;
	}
};
function _memory(cmd) {
	this.lines ||= Object.assign([], { level: [] });
	this.lines.level ||= [];
	if (cmd) {
		const len = this.lines.level.length ? this.lines.level.length - 1 : 0;
		this.lines.push("  ".repeat(len) + cmd);
	} else this.lines.push("");
	if (!cmd) this.lines.level = [];
}
function _turnOnEditorMode(repl) {
	repl.editorMode = true;
	Interface.prototype.setPrompt.call(repl, "");
}
function _turnOffEditorMode(repl) {
	repl.editorMode = false;
	repl.setPrompt(repl._initialPrompt);
}
function defineDefaultCommands(repl) {
	repl.defineCommand("break", {
		help: "Sometimes you get stuck, this gets you out",
		action: function() {
			this.clearBufferedCommand();
			this.displayPrompt();
		}
	});
	repl.defineCommand("clear", {
		help: "Alias for .break",
		action: function() {
			this.clearBufferedCommand();
			this.displayPrompt();
		}
	});
	repl.defineCommand("exit", {
		help: "Exit the REPL",
		action: function() {
			this.close();
		}
	});
	repl.defineCommand("help", {
		help: "Print this help message",
		action: function() {
			const names = Object.keys(this.commands).sort();
			const longestNameLength = Math.max(...names.map((name) => name.length));
			for (const name of names) {
				const cmd = this.commands[name];
				const spaces = " ".repeat(longestNameLength - name.length + 3);
				const line = `.${name}${cmd.help ? spaces + cmd.help : ""}\n`;
				this.output.write(line);
			}
			this.output.write("\nPress Ctrl+C to abort current expression, Ctrl+D to exit the REPL\n");
			this.displayPrompt();
		}
	});
	repl.defineCommand("save", {
		help: "Save all evaluated commands in this REPL session to a file",
		action: function(file) {
			if (file === "") this.output.write(`${missingArgs("file").message}\n`);
			else this.output.write(`Failed to save: ${file}\n`);
			this.displayPrompt();
		}
	});
	repl.defineCommand("load", {
		help: "Load JS from a file into the REPL session",
		action: function(file) {
			if (file === "") this.output.write(`${missingArgs("file").message}\n`);
			else this.output.write(`Failed to load: ${file}\n`);
			this.displayPrompt();
		}
	});
	if (repl.terminal) repl.defineCommand("editor", {
		help: "Enter editor mode",
		action() {
			_turnOnEditorMode(this);
			this.output.write("// Entering editor mode (Ctrl+D to finish, Ctrl+C to cancel)\n");
		}
	});
}
/**
* Node's `REPLServer` is a plain function whose prototype chain is grafted onto `Interface`.
* Calling it without `new` is a runtime deprecation there (DEP0185) and a refusal here.
*/
const REPLServer = function REPLServer(prompt, stream, eval_, useGlobal, ignoreUndefined, replMode) {
	if (!new.target) throw deprecatedNodeApi("REPLServer() called without new (DEP0185)", "new REPLServer()");
	return Reflect.construct(ReplServerCore, [
		prompt,
		stream,
		eval_,
		useGlobal,
		ignoreUndefined,
		replMode
	], new.target);
};
REPLServer.prototype = ReplServerCore.prototype;
Object.defineProperty(REPLServer.prototype, "constructor", {
	value: REPLServer,
	writable: true,
	configurable: true
});
Object.setPrototypeOf(REPLServer, Interface);
function start(prompt, source, eval_, useGlobal, ignoreUndefined, replMode) {
	return new REPLServer(prompt, source, eval_, useGlobal, ignoreUndefined, replMode);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/repl/index.js
const repl = {
	start,
	writer,
	REPLServer,
	REPL_MODE_SLOPPY,
	REPL_MODE_STRICT,
	Recoverable,
	isValidSyntax
};
for (const name of ["builtinModules", "_builtinLibs"]) Object.defineProperty(repl, name, {
	get: () => getReplBuiltinLibs(),
	set: (value) => setReplBuiltinLibs(value),
	enumerable: false,
	configurable: true
});
//#endregion
export { REPLServer, REPL_MODE_SLOPPY, REPL_MODE_STRICT, Recoverable, repl as default, isValidSyntax, start, writer };
