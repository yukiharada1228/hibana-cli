import { d as invalidArgType, f as invalidArgValue, s as deprecatedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { a as validateFunction, c as validateObject, f as validateUint32, r as validateBoolean } from "./chunks/validation-qQPlCQ6g.mjs";
import { n as assert$2 } from "./chunks/assert-DUZYBMOh.mjs";
import { i as validateAbortSignal, n as isPromiseLike } from "./chunks/shared-DSGRKwku.mjs";
import { a as milliseconds, i as integer, o as unsupported, r as failure, t as formatTap } from "./chunks/tap-BCnn2DMJ.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/abort-globals.js
/**
* Adapt the legacy AbortSignal implementation embedded in ComponentizeJS 0.22.
* Keep native signal identities and dependency tracking. Engines with the
* standard sequence-taking any() implementation need no changes.
* Upstream fixes: bytecodealliance/StarlingMonkey#310.
*/
function installAbortCompatibility() {
	const Controller = globalThis.AbortController;
	const Signal = globalThis.AbortSignal;
	if (!Controller || !Signal || typeof Signal.any !== "function") return;
	const nativeAny = Signal.any;
	const aborted = Object.getOwnPropertyDescriptor(Signal.prototype, "aborted").get;
	const reason = Object.getOwnPropertyDescriptor(Signal.prototype, "reason").get;
	try {
		const probe = Reflect.apply(nativeAny, Signal, [new Controller().signal]);
		if (Reflect.apply(aborted, probe, []) !== false) return;
	} catch {
		return;
	}
	const nativeAbort = Signal.abort;
	const nativeControllerAbort = Controller.prototype.abort;
	const methods = {
		any(signals) {
			if (!Array.isArray(signals)) throw invalidArgType("signals", "Array", signals);
			const inputs = Array.from(signals);
			for (let index = 0; index < inputs.length; index++) try {
				Reflect.apply(aborted, inputs[index], []);
			} catch {
				throw invalidArgType(`signals[${index}]`, "AbortSignal", inputs[index]);
			}
			return inputs.length ? Reflect.apply(nativeAny, Signal, inputs) : new Controller().signal;
		},
		abort(value) {
			return Reflect.apply(nativeAbort, Signal, [value]);
		},
		throwIfAborted() {
			if (Reflect.apply(aborted, this, [])) throw Reflect.apply(reason, this, []);
		}
	};
	const controllerMethods = { abort(value) {
		if (value === void 0) {
			const defaults = new Controller();
			Reflect.apply(nativeControllerAbort, defaults, []);
			value = Reflect.apply(reason, defaults.signal, []);
		}
		Reflect.apply(nativeControllerAbort, this, [value]);
	} };
	Object.defineProperties(Signal, {
		any: {
			...Object.getOwnPropertyDescriptor(Signal, "any"),
			value: methods.any
		},
		abort: {
			...Object.getOwnPropertyDescriptor(Signal, "abort"),
			value: methods.abort
		}
	});
	Object.defineProperty(Signal.prototype, "throwIfAborted", {
		...Object.getOwnPropertyDescriptor(Signal.prototype, "throwIfAborted"),
		value: methods.throwIfAborted
	});
	Object.defineProperty(Controller.prototype, "abort", {
		...Object.getOwnPropertyDescriptor(Controller.prototype, "abort"),
		value: controllerMethods.abort
	});
}
installAbortCompatibility();
const AbortController = globalThis.AbortController;
globalThis.AbortSignal;
const assertionMap = new Map([
	"deepEqual",
	"deepStrictEqual",
	"doesNotMatch",
	"doesNotReject",
	"doesNotThrow",
	"equal",
	"fail",
	"ifError",
	"match",
	"notDeepEqual",
	"notDeepStrictEqual",
	"notEqual",
	"notStrictEqual",
	"partialDeepStrictEqual",
	"rejects",
	"strictEqual",
	"throws",
	"ok"
].map((name) => [name, assert$2[name]]));
const assert$1 = Object.assign(Object.create(null), { register(name, fn) {
	if (typeof name !== "string") throw invalidArgType("name", "string", name);
	validateFunction(fn, "fn");
	assertionMap.set(name, fn);
} });
const snapshot$1 = Object.assign(Object.create(null), {
	setDefaultSnapshotSerializers(_serializers) {
		unsupported("snapshot.setDefaultSnapshotSerializers()", "snapshot files and VM loading are unavailable");
	},
	setResolveSnapshotPath(_fn) {
		unsupported("snapshot.setResolveSnapshotPath()", "snapshot files and VM loading are unavailable");
	}
});
function createAssertions(context, count) {
	const assertions = Object.create(null);
	const map = new Map(assertionMap);
	if (!map.has("snapshot")) map.set("snapshot", () => unsupported("context.assert.snapshot()", "snapshot files and VM loading are unavailable"));
	if (!map.has("fileSnapshot")) map.set("fileSnapshot", () => unsupported("context.assert.fileSnapshot()", "snapshot files are unavailable"));
	for (const [name, method] of map) Object.defineProperty(assertions, name, {
		configurable: true,
		enumerable: true,
		writable: true,
		value: (...args) => {
			count();
			return Reflect.apply(method, context, args);
		}
	});
	return assertions;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/mock.js
/**
* Adapted from nodejs/node lib/internal/test_runner/mock/mock.js,
* v24.20.0, commit 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT (see LICENSE).
* Local changes: explicit TypeScript types, standard intrinsics and shared error
* helpers replace primordials/internal validators. Loader and native timer mocks
* fail immediately. Symbol methods restore like string methods (upstream fix).
* Types adapted from DefinitelyTyped @types/node 24.13.3 test.d.ts (MIT).
*/
const states = /* @__PURE__ */ new WeakMap();
var MockFunctionContext = class {
	#state;
	constructor(implementation, restore, times) {
		this.#state = {
			calls: [],
			mocks: /* @__PURE__ */ new Map(),
			implementation,
			restore,
			times
		};
		states.set(this, this.#state);
	}
	get calls() {
		return this.#state.calls.slice();
	}
	callCount() {
		return this.#state.calls.length;
	}
	mockImplementation(implementation) {
		validateFunction(implementation, "implementation");
		this.#state.implementation = implementation;
	}
	mockImplementationOnce(implementation, onCall) {
		validateFunction(implementation, "implementation");
		const call = onCall ?? this.callCount();
		integer(call, "onCall", this.callCount());
		this.#state.mocks.set(call, implementation);
	}
	restore() {
		const { object, methodName, descriptor, original } = this.#state.restore;
		if (methodName !== void 0 && object && descriptor) Object.defineProperty(object, methodName, { ...descriptor });
		else this.#state.implementation = original;
	}
	resetCalls() {
		this.#state.calls = [];
	}
};
var MockPropertyContext = class {
	#object;
	#propertyName;
	#originalValue;
	#descriptor;
	#value;
	#accesses = [];
	#onceValues = /* @__PURE__ */ new Map();
	constructor(object, propertyName, ...values) {
		this.#object = object;
		this.#propertyName = propertyName;
		this.#originalValue = Reflect.get(object, propertyName);
		this.#value = values.length ? values[0] : this.#originalValue;
		const descriptor = Object.getOwnPropertyDescriptor(object, propertyName);
		if (!descriptor) throw invalidArgValue("propertyName", propertyName, "is not a property of the object");
		this.#descriptor = descriptor;
		Object.defineProperty(object, propertyName, {
			configurable: descriptor.configurable,
			enumerable: descriptor.enumerable,
			get: () => {
				const value = this.#getAccessValue(this.#value);
				this.#accesses.push({
					type: "get",
					value,
					stack: /* @__PURE__ */ new Error()
				});
				return value;
			},
			set: this.mockImplementation.bind(this)
		});
	}
	get accesses() {
		return this.#accesses.slice();
	}
	accessCount() {
		return this.#accesses.length;
	}
	mockImplementation(value) {
		if (!this.#descriptor.writable) throw invalidArgValue("propertyName", this.#propertyName, "cannot be set");
		const next = this.#getAccessValue(value);
		this.#accesses.push({
			type: "set",
			value: next,
			stack: /* @__PURE__ */ new Error()
		});
		this.#value = next;
	}
	#getAccessValue(value) {
		const index = this.#accesses.length;
		if (!this.#onceValues.has(index)) return value;
		const next = this.#onceValues.get(index);
		this.#onceValues.delete(index);
		return next;
	}
	mockImplementationOnce(value, onAccess) {
		const index = onAccess ?? this.accessCount();
		integer(index, "onAccess", this.accessCount());
		this.#onceValues.set(index, value);
	}
	resetAccesses() {
		this.#accesses = [];
	}
	restore() {
		Object.defineProperty(this.#object, this.#propertyName, {
			...this.#descriptor,
			value: this.#originalValue
		});
	}
};
var MockTimers = class {
	enable(options) {
		if (Array.isArray(options)) throw deprecatedNodeApi("mock.timers.enable(timers)", "mock.timers.enable({ apis })");
		unsupported("mock.timers.enable()", "shared Node timer internals are unavailable");
	}
	tick(_milliseconds) {
		unsupported("mock.timers.tick()", "shared Node timer internals are unavailable");
	}
	runAll() {
		unsupported("mock.timers.runAll()", "shared Node timer internals are unavailable");
	}
	setTime(_milliseconds) {
		unsupported("mock.timers.setTime()", "shared Node timer internals are unavailable");
	}
	reset() {}
	[Symbol.dispose]() {
		this.reset();
	}
};
const defaultFunction = function() {};
function validateTimes(times) {
	if (times !== Infinity) integer(times, "options.times", 1);
}
function key(value, name) {
	if (typeof value !== "string" && typeof value !== "symbol") throw invalidArgType(name, ["string", "symbol"], value);
}
function descriptorInChain(object, name) {
	for (let host = object; host !== null; host = Object.getPrototypeOf(host)) {
		const descriptor = Object.getOwnPropertyDescriptor(host, name);
		if (descriptor) return descriptor;
	}
}
var MockTracker = class {
	#mocks = [];
	#timers;
	get timers() {
		return this.#timers ??= new MockTimers();
	}
	fn(original = function() {}, implementation = original, options = {}) {
		if (original !== null && typeof original === "object") {
			options = original;
			original = function() {};
			implementation = original;
		} else if (implementation !== null && typeof implementation === "object") {
			options = implementation;
			implementation = original;
		}
		validateFunction(original, "original");
		validateFunction(implementation, "implementation");
		validateObject(options, "options");
		const { times = Infinity } = options;
		validateTimes(times);
		return this.#setupMock(new MockFunctionContext(implementation, { original }, times), original);
	}
	method(object, methodName, implementation = defaultFunction, options = {}) {
		key(methodName, "methodName");
		if (typeof object !== "function") validateObject(object, "object");
		if (implementation !== null && typeof implementation === "object") {
			options = implementation;
			implementation = defaultFunction;
		}
		validateFunction(implementation, "implementation");
		validateObject(options, "options");
		const { getter = false, setter = false, times = Infinity } = options;
		validateBoolean(getter, "options.getter");
		validateBoolean(setter, "options.setter");
		validateTimes(times);
		if (getter && setter) throw invalidArgValue("options.setter", setter, "cannot be used with 'options.getter'");
		const descriptor = descriptorInChain(object, methodName);
		const original = getter ? descriptor?.get : setter ? descriptor?.set : descriptor?.value;
		if (typeof original !== "function") throw invalidArgValue("methodName", original, "must be a method");
		const fn = original;
		const context = new MockFunctionContext(implementation === defaultFunction ? fn : implementation, {
			original: fn,
			object,
			methodName,
			descriptor
		}, times);
		const mock = this.#setupMock(context, fn);
		const mockDescriptor = {
			configurable: descriptor.configurable,
			enumerable: descriptor.enumerable
		};
		if (getter) {
			mockDescriptor.get = mock;
			mockDescriptor.set = descriptor.set;
		} else if (setter) {
			mockDescriptor.get = descriptor.get;
			mockDescriptor.set = mock;
		} else {
			mockDescriptor.writable = descriptor.writable;
			mockDescriptor.value = mock;
		}
		Object.defineProperty(object, methodName, mockDescriptor);
		return mock;
	}
	getter(object, methodName, implementation, options) {
		if (implementation !== null && typeof implementation === "object") {
			options = implementation;
			implementation = void 0;
		}
		options ??= {};
		validateObject(options, "options");
		const { getter = true } = options;
		validateBoolean(getter, "options.getter");
		if (getter === false) throw invalidArgValue("options.getter", getter, "cannot be false");
		return this.method(object, methodName, implementation ?? defaultFunction, {
			...options,
			getter
		});
	}
	setter(object, methodName, implementation, options) {
		if (implementation !== null && typeof implementation === "object") {
			options = implementation;
			implementation = void 0;
		}
		options ??= {};
		validateObject(options, "options");
		const { setter = true } = options;
		validateBoolean(setter, "options.setter");
		if (setter === false) throw invalidArgValue("options.setter", setter, "cannot be false");
		return this.method(object, methodName, implementation ?? defaultFunction, {
			...options,
			setter
		});
	}
	property(object, propertyName, ...values) {
		validateObject(object, "object");
		key(propertyName, "propertyName");
		const context = new MockPropertyContext(object, propertyName, ...values);
		this.#mocks.push(context);
		return new Proxy(object, { get(target, property, receiver) {
			return property === "mock" ? context : Reflect.get(target, property, receiver);
		} });
	}
	module(_specifier, _options) {
		return unsupported("mock.module()", "component modules are linked before execution; runtime loader hooks are unavailable");
	}
	reset() {
		this.restoreAll();
		this.#timers?.reset();
		this.#mocks = [];
	}
	restoreAll() {
		for (const mock of this.#mocks) mock.restore();
	}
	#setupMock(context, original) {
		const state = states.get(context);
		const next = () => {
			const index = state.calls.length;
			const implementation = state.mocks.get(index) ?? state.implementation;
			if (index + 1 === state.times) context.restore();
			state.mocks.delete(index);
			return implementation;
		};
		const proxy = new Proxy(original, {
			apply(_target, thisArg, argumentsList) {
				const implementation = next();
				let result;
				let error;
				try {
					result = Reflect.apply(implementation, thisArg, argumentsList);
				} catch (caught) {
					error = caught;
					throw caught;
				} finally {
					state.calls.push({
						arguments: argumentsList,
						error,
						result,
						stack: /* @__PURE__ */ new Error(),
						target: void 0,
						this: thisArg
					});
				}
				return result;
			},
			construct(target, argumentsList, newTarget) {
				const implementation = next();
				let result;
				let error;
				try {
					result = Reflect.construct(implementation, argumentsList, newTarget);
				} catch (caught) {
					error = caught;
					throw caught;
				} finally {
					state.calls.push({
						arguments: argumentsList,
						error,
						result,
						stack: /* @__PURE__ */ new Error(),
						target,
						this: result
					});
				}
				return result;
			},
			get(target, property, receiver) {
				return property === "mock" ? context : Reflect.get(target, property, receiver);
			}
		});
		this.#mocks.push(context);
		return proxy;
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/context.js
/** Adapted from nodejs/node lib/internal/test_runner/test.js (TestContext,
* SuiteContext, TestPlan, waitFor), v24.20.0,
* 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT (see LICENSE).
* Local changes: typed component state, Web timers, no host file/worker lookup. */
var TestPlan = class {
	expected;
	actual = 0;
	wait;
	#resolve;
	#reject;
	#timer;
	constructor(count, options = {}) {
		validateUint32(count, "count");
		validateObject(options, "options");
		const { wait } = options;
		if (typeof wait === "number") milliseconds(wait, "options.wait");
		else if (wait !== void 0 && typeof wait !== "boolean") throw invalidArgType("options.wait", ["boolean", "number"], wait);
		this.expected = count;
		this.wait = wait;
	}
	count() {
		this.actual++;
		if (this.#resolve && this.actual >= this.expected) {
			if (this.actual === this.expected) this.#resolve();
			else this.#reject?.(this.#error());
			this.dispose();
		}
	}
	#error() {
		return failure(`plan expected ${this.expected} assertions but received ${this.actual}`);
	}
	check() {
		if (this.actual === this.expected) return;
		if (this.actual > this.expected || this.wait === void 0 || this.wait === false) throw this.#error();
		return new Promise((resolve, reject) => {
			this.#resolve = resolve;
			this.#reject = reject;
			if (typeof this.wait === "number") this.#timer = setTimeout(() => {
				reject(failure(`plan timed out after ${this.wait}ms with ${this.actual} assertions when expecting ${this.expected}`, "testTimeoutFailure"));
			}, this.wait);
		});
	}
	dispose() {
		clearTimeout(this.#timer);
		this.#resolve = void 0;
		this.#reject = void 0;
	}
};
var TestContextImplementation = class {
	#test;
	#assert;
	constructor(test) {
		this.#test = test;
	}
	get signal() {
		return this.#test.signal;
	}
	get name() {
		return this.#test.name;
	}
	get filePath() {}
	get fullName() {
		return this.#test.fullName;
	}
	get error() {
		return this.#test.error;
	}
	get passed() {
		return this.#test.passed;
	}
	get attempt() {
		return 0;
	}
	get tags() {
		return this.#test.tags;
	}
	get workerId() {}
	diagnostic(message) {
		this.#test.diagnostic(message);
	}
	log(message, data) {
		this.#test.log(message, data);
	}
	plan(count, options) {
		if (this.#test.plan !== null) throw failure("cannot set plan more than once");
		this.#test.plan = new TestPlan(count, options);
	}
	get assert() {
		const plan = this.#test.plan;
		return this.#assert ??= createAssertions(this, () => {
			plan?.count();
		});
	}
	get mock() {
		return this.#test.mock ??= new MockTracker();
	}
	runOnly(value) {
		this.#test.runOnly = !!value;
	}
	skip(message) {
		this.#test.skipped = message ?? true;
	}
	todo(message) {
		this.#test.todo = message ?? true;
	}
	test(name, options, fn) {
		this.#test.plan?.count();
		return this.#test.add(name, options, fn);
	}
	before(fn, options) {
		this.#test.hook("before", fn, options);
	}
	after(fn, options) {
		this.#test.hook("after", fn, options);
	}
	beforeEach(fn, options) {
		this.#test.hook("beforeEach", fn, options);
	}
	afterEach(fn, options) {
		this.#test.hook("afterEach", fn, options);
	}
	waitFor(condition, options = {}) {
		validateFunction(condition, "condition");
		validateObject(options, "options");
		const { interval = 50, timeout = 1e3 } = options;
		milliseconds(interval, "options.interval");
		milliseconds(timeout, "options.timeout");
		return new Promise((resolve, reject) => {
			const noError = Symbol();
			let cause = noError;
			let poller;
			let ended = false;
			const timer = setTimeout(() => {
				ended = true;
				clearTimeout(poller);
				const error = /* @__PURE__ */ new Error("waitFor() timed out");
				if (cause !== noError) error.cause = cause;
				reject(error);
			}, timeout);
			const poll = async () => {
				try {
					const result = await condition();
					if (ended) return;
					ended = true;
					clearTimeout(timer);
					resolve(result);
				} catch (error) {
					if (ended) return;
					cause = error;
					poller = setTimeout(poll, interval);
				}
			};
			poll();
		});
	}
};
Object.defineProperty(TestContextImplementation, "name", {
	value: "TestContext",
	configurable: true
});
const TestContext = TestContextImplementation;
var SuiteContext = class {
	#suite;
	constructor(suite) {
		this.#suite = suite;
	}
	get signal() {
		return this.#suite.signal;
	}
	get name() {
		return this.#suite.name;
	}
	get filePath() {}
	get fullName() {
		return this.#suite.fullName;
	}
	get passed() {
		return this.#suite.passed;
	}
	get attempt() {
		return 0;
	}
	diagnostic(message) {
		this.#suite.diagnostic(message);
	}
	log(message, data) {
		this.#suite.log(message, data);
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/runner.js
/**
* Component scheduler adapted from nodejs/node lib/internal/test_runner/
* {harness,test,tag_filter}.js at v24.20.0,
* 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT (see LICENSE).
* Keeps Node argument normalization, hook phases, test-failure resolution,
* expected failures and scoped contexts. Replaces process/AsyncResource bootstrap
* with a serial microtask queue. No implicit context propagation across await,
* file discovery, process exit handlers, or engine instrumentation is claimed.
*/
function normalize([name, options, fn], overrides) {
	if (typeof name === "function") fn = name;
	else if (name !== null && typeof name === "object") {
		fn = typeof options === "function" ? options : void 0;
		options = name;
	} else if (typeof options === "function") fn = options;
	if (options === null || typeof options !== "object") options = {};
	if (typeof fn !== "function") fn = () => {};
	return {
		name: typeof name === "string" && name !== "" ? name : fn.name || "<anonymous>",
		fn,
		options: {
			...options,
			...overrides
		}
	};
}
function tags(value, inherited) {
	if (value === void 0) return inherited;
	if (!Array.isArray(value)) throw invalidArgType("options.tags", "Array", value);
	const result = new Set(inherited);
	for (let i = 0; i < value.length; i++) {
		const tag = value[i];
		if (typeof tag !== "string") throw invalidArgType(`options.tags[${i}]`, "string", tag);
		if (tag.length === 0) throw invalidArgValue(`options.tags[${i}]`, tag, "must not be empty");
		result.add(tag.toLowerCase());
	}
	return Object.freeze([...result]);
}
function isFailure(error) {
	return error instanceof Error && "code" in error && error.code === "ERR_TEST_FAILURE";
}
function expectFailure$1(value) {
	if (value === void 0 || value === false) return;
	if (typeof value === "string") return { label: value };
	if (typeof value === "function" || value instanceof RegExp) return { match: value };
	if (typeof value !== "object") return {};
	if (value === null || Object.keys(value).length === 0) throw invalidArgValue("options.expectFailure", value, "must not be an empty object");
	if ("label" in value || "match" in value) return value;
	return { match: value };
}
function createTestHarness(options = {}) {
	let current;
	let currentContext;
	let asyncBodies = 0;
	let drainPromise;
	let rootBefore = false;
	let rootBeforeError;
	let rootAfter = false;
	const pending = [];
	const rootHooks = {
		before: [],
		after: [],
		beforeEach: [],
		afterEach: []
	};
	const report = options.report ?? (() => {});
	const globalMock = new MockTracker();
	const counts = {
		tests: 0,
		passed: 0,
		failed: 0,
		cancelled: 0,
		skipped: 0,
		todo: 0,
		suites: 0,
		topLevel: 0
	};
	let globalNumber = 0;
	const start = Date.now();
	function scope(node, context, fn) {
		const previous = current;
		const previousContext = currentContext;
		current = node;
		currentContext = context;
		try {
			return fn();
		} finally {
			current = previous;
			currentContext = previousContext;
		}
	}
	function registrationParent() {
		if (!current && asyncBodies) unsupported("implicit test context", "use t.test() and t hooks after await; the engine cannot propagate async context");
		return current;
	}
	function registerHook(target, fn, hookOptions = {}) {
		if (fn === void 0) fn = () => {};
		validateFunction(fn, "fn");
		validateObject(hookOptions, "options");
		validateAbortSignal(hookOptions.signal);
		if (hookOptions.timeout !== void 0 && hookOptions.timeout !== Infinity) milliseconds(hookOptions.timeout, "options.timeout");
		target.push({
			fn,
			options: hookOptions
		});
	}
	async function invoke(node, context, fn, hookOptions, cleanup = false) {
		let callbackResolve;
		let callbackReject;
		let calls = 0;
		const callback = new Promise((resolve, reject) => {
			callbackResolve = resolve;
			callbackReject = reject;
		});
		callback.catch(() => {});
		const done = (error) => {
			if (++calls > 1) {
				node.fail(failure("callback invoked multiple times", "multipleCallbackInvocations"));
				return;
			}
			if (error) callbackReject(error);
			else callbackResolve();
		};
		const result = scope(node, context, () => Reflect.apply(fn, context, fn.length === 2 ? [context, done] : [context]));
		let promise;
		if (fn.length === 2) {
			if (isPromiseLike(result)) {
				Promise.resolve(result).catch(() => {});
				throw failure("passed a callback but also returned a Promise", "callbackAndPromisePresent");
			}
			promise = callback;
		} else promise = Promise.resolve(result);
		asyncBodies++;
		try {
			await node.interruptible(promise, hookOptions, cleanup);
		} finally {
			asyncBodies--;
		}
	}
	async function hooks(node, records, cleanup = false) {
		for (const hook of records) try {
			await invoke(node, node.context, hook.fn, hook.options, cleanup);
		} catch (error) {
			throw failure(error, "hookFailed");
		}
	}
	class TestNode {
		name;
		fullName;
		parent;
		suite;
		body;
		config;
		controller = new AbortController();
		signal = this.controller.signal;
		context;
		suiteContext;
		children = [];
		hooks = {
			before: [],
			after: [],
			beforeEach: [],
			afterEach: []
		};
		tags;
		expected;
		number;
		nesting;
		done;
		diagnostics = [];
		#resolve;
		#childrenTail = Promise.resolve();
		#beforePromise;
		#outerAbort;
		#deadline;
		running = false;
		finished = false;
		passed = false;
		error = null;
		plan = null;
		mock = null;
		runOnly = false;
		skipped;
		todo;
		constructor(args, isSuite, overrides = {}, parent) {
			const parsed = normalize(args, overrides);
			this.config = parsed.options;
			this.name = parsed.name;
			this.body = parsed.fn;
			this.suite = isSuite;
			this.parent = parent;
			this.fullName = parent ? `${parent.fullName} > ${this.name}` : this.name;
			this.nesting = parent ? parent.nesting + 1 : 0;
			this.number = parent ? parent.children.length + 1 : ++globalNumber;
			const { concurrency, timeout, signal, skip, todo, plan } = this.config;
			if (concurrency != null) {
				if (typeof concurrency === "number") validateUint32(concurrency, "options.concurrency", true);
				else if (typeof concurrency !== "boolean") throw invalidArgType("options.concurrency", ["boolean", "number"], concurrency);
				if (concurrency === true || typeof concurrency === "number" && concurrency > 1) unsupported("options.concurrency", "concurrent tests require engine async-context support");
			}
			if (timeout != null && timeout !== Infinity) milliseconds(timeout, "options.timeout");
			validateAbortSignal(signal);
			this.tags = tags(this.config.tags, parent?.tags ?? Object.freeze([]));
			this.expected = expectFailure$1(this.config.expectFailure) ?? parent?.expected;
			this.skipped = skip !== void 0 && skip !== false ? skip : void 0;
			this.todo = todo !== void 0 && todo !== false ? todo : parent?.todo;
			if (options.only && !this.config.only && (parent?.runOnly || !parent)) this.skipped = "'only' option not set";
			if (!options.only && (this.config.only || parent?.runOnly)) this.diagnostic("'only' and 'runOnly' require the --test-only command-line option.");
			if (plan !== void 0) this.plan = new TestPlan(plan);
			this.context = new TestContext(this);
			this.suiteContext = new SuiteContext(this);
			this.done = new Promise((resolve) => {
				this.#resolve = resolve;
			});
			if (signal) {
				this.#outerAbort = () => {
					this.controller.abort(signal.reason);
				};
				if (signal.aborted) this.#outerAbort();
				else signal.addEventListener("abort", this.#outerAbort, { once: true });
			}
			report({
				type: "test:enqueue",
				data: this.location()
			});
		}
		location() {
			return {
				name: this.name,
				nesting: this.nesting
			};
		}
		build() {
			if (!this.suite || this.skipped !== void 0) return;
			try {
				const result = scope(this, this.suiteContext, () => Reflect.apply(this.body, this.suiteContext, [this.suiteContext]));
				if (isPromiseLike(result)) {
					Promise.resolve(result).catch(() => {});
					unsupported("async suite callback", "declare suites synchronously and use async test bodies with explicit contexts");
				}
			} catch (error) {
				this.fail(failure(error));
			}
		}
		add(name, options, fn) {
			return add([
				name,
				options,
				fn
			], false, {}, this);
		}
		hook(name, fn, options) {
			if (this.finished) throw failure("test could not be started because its parent finished", "parentAlreadyFinished");
			registerHook(this.hooks[name], fn, options);
			if (name === "before" && this.running) {
				const record = this.hooks.before.at(-1);
				const running = hooks(this, [record]);
				const prior = this.#beforePromise;
				this.#beforePromise = prior ? Promise.all([prior, running]).then(() => {}) : running;
				this.#beforePromise.catch((error) => {
					this.fail(isFailure(error) ? error : failure(error));
				});
			}
		}
		diagnostic(message) {
			this.diagnostics.push({
				type: "test:diagnostic",
				data: {
					nesting: this.nesting,
					message: String(message)
				}
			});
		}
		log(message, data) {
			if (typeof message !== "string") throw invalidArgType("message", "string", message);
			this.diagnostics.push({
				type: "test:log",
				data: {
					nesting: this.nesting,
					message,
					data
				}
			});
		}
		fail(error) {
			if (this.error) return;
			this.error = error;
			this.passed = false;
			if (this.expected) {
				if (this.expected.match !== void 0) try {
					assert$2.throws(() => {
						throw error.cause ?? error;
					}, this.expected.match);
				} catch (cause) {
					this.error = failure("The test failed, but the error did not match the expected validation");
					this.error.cause = cause;
					return;
				}
				this.passed = true;
			}
		}
		before() {
			return this.#beforePromise ??= hooks(this, this.hooks.before);
		}
		queue(child) {
			this.#childrenTail = this.#childrenTail.then(async () => {
				if (!this.running || this.finished || this.signal.aborted) child.fail(failure("test did not finish before its parent and was cancelled", "cancelledByParent"));
				else try {
					await this.before();
				} catch (error) {
					child.fail(isFailure(error) ? error : failure(error));
				}
				await child.execute();
			});
		}
		async interruptible(promise, hookOptions, cleanup = false) {
			const signal = hookOptions?.signal ?? (cleanup ? new AbortController().signal : this.signal);
			const timeout = hookOptions?.timeout;
			const remaining = timeout ?? (cleanup || this.#deadline === void 0 ? void 0 : Math.max(0, this.#deadline - Date.now()));
			if (signal.aborted) throw failure(signal.reason ?? "The operation was aborted", "testAborted");
			let timer;
			let abort;
			const stop = new Promise((_resolve, reject) => {
				abort = () => {
					reject(failure(signal.reason ?? "The operation was aborted", "testAborted"));
				};
				signal.addEventListener("abort", abort, { once: true });
				if (remaining !== void 0 && remaining !== Infinity) timer = setTimeout(() => {
					reject(failure(`test timed out after ${timeout ?? this.config.timeout ?? this.parent?.config.timeout}ms`, "testTimeoutFailure"));
				}, remaining);
			});
			try {
				return await Promise.race([promise, stop]);
			} finally {
				clearTimeout(timer);
				signal.removeEventListener("abort", abort);
			}
		}
		async execute() {
			if (this.running || this.finished) return this.done;
			this.running = true;
			const started = Date.now();
			const timeout = this.config.timeout ?? this.parent?.config.timeout;
			if (timeout !== void 0 && timeout !== Infinity) this.#deadline = started + timeout;
			report({
				type: "test:dequeue",
				data: this.location()
			});
			report({
				type: "test:start",
				data: this.location()
			});
			const ancestors = [];
			for (let parent = this.parent; parent; parent = parent.parent) ancestors.unshift(parent);
			let runAfterEach = false;
			try {
				if (this.signal.aborted) throw failure(this.signal.reason ?? "The operation was aborted", "testAborted");
				if (!this.error && this.skipped === void 0) {
					if (!this.suite) {
						runAfterEach = true;
						await hooks(this, rootHooks.beforeEach);
						for (const ancestor of ancestors) await hooks(this, ancestor.hooks.beforeEach);
						await invoke(this, this.context, this.body);
					} else {
						await this.before();
						for (const child of this.children) this.queue(child);
					}
					await this.interruptible(this.#childrenTail);
					await this.#beforePromise;
					await this.interruptible(Promise.resolve(this.plan?.check()));
					const failed = this.children.filter((child) => !child.passed && child.todo === void 0).length;
					if (failed) throw failure(`${failed} subtest${failed === 1 ? "" : "s"} failed`, "subtestsFailed");
				}
				if (!this.error) {
					if (this.expected && this.skipped === void 0) {
						this.fail(failure("test was expected to fail but passed", "expectedFailure"));
						this.passed = false;
					} else this.passed = true;
				}
			} catch (error) {
				this.fail(isFailure(error) ? error : failure(error));
			} finally {
				if (runAfterEach) {
					for (const ancestor of ancestors.reverse()) try {
						await hooks(this, ancestor.hooks.afterEach, true);
					} catch (error) {
						this.fail(isFailure(error) ? error : failure(error));
					}
					try {
						await hooks(this, rootHooks.afterEach, true);
					} catch (error) {
						this.fail(isFailure(error) ? error : failure(error));
					}
				}
				try {
					await hooks(this, this.hooks.after, true);
				} catch (error) {
					this.fail(isFailure(error) ? error : failure(error));
				}
				this.finished = true;
				this.controller.abort();
				for (const child of this.children) if (!child.finished) child.controller.abort();
				for (const child of this.children) if (!child.running) {
					child.fail(failure("test did not finish before its parent and was cancelled", "cancelledByParent"));
					await child.execute();
				}
				await this.#childrenTail;
				this.mock?.reset();
				this.plan?.dispose();
				if (this.#outerAbort) this.config.signal?.removeEventListener("abort", this.#outerAbort);
				if (this.children.length) report({
					type: "test:plan",
					data: {
						nesting: this.nesting + 1,
						count: this.children.length
					}
				});
				const result = {
					...this.location(),
					testNumber: this.number,
					details: {
						duration_ms: Date.now() - started,
						type: this.suite ? "suite" : "test"
					},
					tags: this.tags
				};
				if (this.error) result.details.error = this.error;
				if (this.skipped !== void 0) result.skip = this.skipped;
				if (this.todo !== void 0) result.todo = this.todo;
				if (this.expected) result.expectFailure = this.expected.label ?? true;
				if (this.suite) counts.suites++;
				else counts.tests++;
				if (!this.parent) counts.topLevel++;
				if (this.skipped !== void 0) counts.skipped++;
				else if (this.todo !== void 0) counts.todo++;
				else if (this.passed) counts.passed++;
				else {
					counts.failed++;
					if ([
						"testAborted",
						"cancelledByParent",
						"testTimeoutFailure"
					].includes(this.error?.failureType ?? "")) counts.cancelled++;
				}
				report({
					type: "test:complete",
					data: result
				});
				report({
					type: this.passed ? "test:pass" : "test:fail",
					data: result
				});
				for (const diagnostic of this.diagnostics) report(diagnostic);
				this.#resolve();
			}
		}
	}
	function add(args, suite, overrides = {}, parent = registrationParent()) {
		if (typeof AbortController !== "function") unsupported("test()", "this engine does not provide AbortController; mocks and reporters remain available");
		const node = new TestNode(args, suite, overrides, parent);
		if (parent) {
			parent.children.push(node);
			if (parent.finished || parent.suite && parent.running) node.fail(failure("test could not be started because its parent finished", "parentAlreadyFinished"));
		}
		node.build();
		if (parent?.suite && !parent.running) return Promise.resolve();
		if (parent) parent.queue(node);
		else {
			pending.push(node);
			schedule();
		}
		return suite ? Promise.resolve() : node.done;
	}
	async function drain() {
		while (pending.length) {
			const node = pending.shift();
			if (!rootBefore) {
				rootBefore = true;
				try {
					await hooks(node, rootHooks.before);
				} catch (error) {
					rootBeforeError = isFailure(error) ? error : failure(error);
				}
			}
			if (rootBeforeError) node.fail(rootBeforeError);
			await node.execute();
			await Promise.resolve();
			if (!pending.length && !rootAfter) {
				rootAfter = true;
				try {
					await hooks(node, rootHooks.after, true);
				} catch (error) {
					counts.failed++;
					report({
						type: "test:fail",
						data: {
							name: "after",
							nesting: 0,
							testNumber: ++globalNumber,
							details: {
								type: "test",
								duration_ms: 0,
								error: isFailure(error) ? error : failure(error)
							}
						}
					});
				}
			}
		}
		report({
			type: "test:plan",
			data: {
				nesting: 0,
				count: globalNumber
			}
		});
		report({
			type: "test:summary",
			data: {
				success: counts.failed === 0,
				counts: { ...counts },
				duration_ms: Date.now() - start
			}
		});
	}
	function schedule() {
		if (!drainPromise) drainPromise = Promise.resolve().then(drain).finally(() => {
			drainPromise = void 0;
			if (pending.length) schedule();
		});
	}
	function callable(isSuite) {
		const test = function(name, options, fn) {
			return add([
				name,
				options,
				fn
			], isSuite);
		};
		Object.defineProperty(test, "name", {
			value: "test",
			configurable: true
		});
		return Object.assign(test, {
			expectFailure: (...args) => add(args, isSuite, { expectFailure: true }),
			skip: (...args) => add(args, isSuite, { skip: true }),
			todo: (...args) => add(args, isSuite, { todo: true }),
			only: (...args) => add(args, isSuite, { only: true })
		});
	}
	function hook(name) {
		return (fn, options) => {
			const parent = registrationParent();
			if (parent) parent.hook(name, fn, options);
			else registerHook(rootHooks[name], fn, options);
		};
	}
	const test = callable(false);
	const suite = callable(true);
	const module = Object.assign(test, {
		after: hook("after"),
		afterEach: hook("afterEach"),
		before: hook("before"),
		beforeEach: hook("beforeEach"),
		describe: suite,
		getTestContext: () => currentContext,
		it: test,
		run: (_options) => unsupported("run()", "test file discovery, runtime imports, process isolation and coverage require a Node runtime"),
		suite,
		test
	});
	Object.defineProperties(module, {
		mock: {
			configurable: true,
			enumerable: true,
			get: () => globalMock
		},
		snapshot: {
			configurable: true,
			enumerable: true,
			get: () => snapshot$1
		},
		assert: {
			configurable: true,
			enumerable: true,
			get: () => assert$1
		}
	});
	return {
		module,
		drain: async () => {
			do
				await drainPromise;
			while (drainPromise);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/test/index.js
/** Node v24.20.0 public facade, adapted from nodejs/node lib/test.js,
* 71b8b174857e25106d39b61a9e6f30d927da8b01, MIT (see LICENSE).
* Component tests report TAP to the engine console without setting host exitCode. */
let started = false;
const test = createTestHarness({ report(event) {
	if (!started) {
		console.log("TAP version 13");
		started = true;
	}
	const text = formatTap(event);
	if (text) console.log(text.trimEnd());
} }).module;
const { after, afterEach, assert, before, beforeEach, describe, expectFailure, getTestContext, it, mock, only, run, skip, snapshot, suite, todo } = test;
//#endregion
export { after, afterEach, assert, before, beforeEach, test as default, test, describe, expectFailure, getTestContext, it, mock, only, run, skip, snapshot, suite, todo };
