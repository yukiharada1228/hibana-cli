import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, f as invalidArgValue, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { a as validateFunction, c as validateObject, n as validateArray, o as validateInteger, r as validateBoolean, u as validateString } from "./chunks/validation-qQPlCQ6g.mjs";
import { t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { n as decodeErrno, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/wasi-host.js
var wasi_host_exports = /* @__PURE__ */ __exportAll({
	default: () => host,
	init: () => init
});
/**
* JS bindings lower thrown records into the `err` case of WIT `result<T, error>`.
* The guest reconstructs the same structured error used by the explicit Node host.
*/
const denied = () => {
	throw {
		name: "Error",
		message: adapterRequiredMessage("node:wasi"),
		code: "ERR_JCO_WASI_ADAPTER_REQUIRED"
	};
};
/**
* The default adapter intentionally initialises nothing: `new WASI()` is refused until the
* application maps a provider. Note that a provider only makes construction behave as Node's;
* see `wasi/core.ts` for why no provider can run a module.
*/
const init = denied;
const host = { init };
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/wasi/syscalls.js
/**
* The WASI preview1 syscalls Node's `wasi` binding exposes on `wasiImport`, each with the
* parameter types its native implementation declares, from nodejs/node v24.19.0
* src/node_wasi.h (commit cdc1b38d40cb567b7ad0b39c86addf830a0af0ae). Both snapshots Node
* accepts, `unstable` and `preview1`, bind this same table. The parameter list also fixes each
* function's reported arity.
*/
const PREVIEW1_SYSCALLS = [
	["args_get", ["u32", "u32"]],
	["args_sizes_get", ["u32", "u32"]],
	["clock_res_get", ["u32", "u32"]],
	["clock_time_get", [
		"u32",
		"u64",
		"u32"
	]],
	["environ_get", ["u32", "u32"]],
	["environ_sizes_get", ["u32", "u32"]],
	["fd_advise", [
		"u32",
		"u64",
		"u64",
		"u32"
	]],
	["fd_allocate", [
		"u32",
		"u64",
		"u64"
	]],
	["fd_close", ["u32"]],
	["fd_datasync", ["u32"]],
	["fd_fdstat_get", ["u32", "u32"]],
	["fd_fdstat_set_flags", ["u32", "u32"]],
	["fd_fdstat_set_rights", [
		"u32",
		"u64",
		"u64"
	]],
	["fd_filestat_get", ["u32", "u32"]],
	["fd_filestat_set_size", ["u32", "u64"]],
	["fd_filestat_set_times", [
		"u32",
		"u64",
		"u64",
		"u32"
	]],
	["fd_pread", [
		"u32",
		"u32",
		"u32",
		"u64",
		"u32"
	]],
	["fd_prestat_get", ["u32", "u32"]],
	["fd_prestat_dir_name", [
		"u32",
		"u32",
		"u32"
	]],
	["fd_pwrite", [
		"u32",
		"u32",
		"u32",
		"u64",
		"u32"
	]],
	["fd_read", [
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["fd_readdir", [
		"u32",
		"u32",
		"u32",
		"u64",
		"u32"
	]],
	["fd_renumber", ["u32", "u32"]],
	["fd_seek", [
		"u32",
		"i64",
		"u32",
		"u32"
	]],
	["fd_sync", ["u32"]],
	["fd_tell", ["u32", "u32"]],
	["fd_write", [
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_create_directory", [
		"u32",
		"u32",
		"u32"
	]],
	["path_filestat_get", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_filestat_set_times", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u64",
		"u64",
		"u32"
	]],
	["path_link", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_open", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u64",
		"u64",
		"u32",
		"u32"
	]],
	["path_readlink", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_remove_directory", [
		"u32",
		"u32",
		"u32"
	]],
	["path_rename", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_symlink", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["path_unlink_file", [
		"u32",
		"u32",
		"u32"
	]],
	["poll_oneoff", [
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["proc_exit", ["u32"]],
	["proc_raise", ["u32"]],
	["random_get", ["u32", "u32"]],
	["sched_yield", []],
	["sock_accept", [
		"u32",
		"u32",
		"u32"
	]],
	["sock_recv", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["sock_send", [
		"u32",
		"u32",
		"u32",
		"u32",
		"u32"
	]],
	["sock_shutdown", ["u32", "u32"]]
];
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/wasi/core.js
const kExitCode = Symbol("kExitCode");
const kSetMemory = Symbol("kSetMemory");
const kStarted = Symbol("kStarted");
const kInstance = Symbol("kInstance");
const kBindingName = Symbol("kBindingName");
const kEmptyObject = Object.freeze(Object.create(null));
/**
* Why nothing past construction can work, stated once: this is the reason carried by every
* `ERR_JCO_UNSUPPORTED_NODE_API` the module raises and appended to the deny provider's refusal.
*/
const NESTED_INSTANTIATION_UNSUPPORTED = "a component cannot instantiate a nested WebAssembly module (the guest engine has no WebAssembly global), so there is no instance whose memory wasi.start(), wasi.initialize() or wasi.finalizeBindings() could bind, and a memory cannot cross the component boundary to a host. Compose the module with the component at build time, for example with wac or wasm-tools compose, or run it on the host instead";
function validateUndefined(value, name) {
	if (value !== void 0) throw invalidArgType(name, "undefined", value);
}
/** Node's `ERR_WASI_ALREADY_STARTED`. */
function alreadyStarted() {
	return codedError(/* @__PURE__ */ new Error("WASI instance has already started"), "ERR_WASI_ALREADY_STARTED");
}
/** Node's `ERR_WASI_NOT_STARTED`, raised by every syscall until `start()` binds a memory. */
function notStarted() {
	return codedError(/* @__PURE__ */ new Error("wasi.start() has not been called"), "ERR_WASI_NOT_STARTED");
}
/** The binding's own memory check, which Node raises without `internal/errors`' "The" prefix. */
function memoryTypeError() {
	return codedError(/* @__PURE__ */ new TypeError("\"instance.exports.memory\" property must be a WebAssembly.Memory object"), "ERR_INVALID_ARG_TYPE");
}
/**
* Stand-in for the binding's `_setMemory`. A memory that is not a `WebAssembly.Memory` is
* rejected as Node rejects it where that check is possible; a memory that is one, or any value
* in a guest with no `WebAssembly` global, is refused because it cannot be bound to anything.
*/
function setMemory(memory) {
	const wasm = globalThis.WebAssembly;
	if (typeof wasm?.Memory === "function" && !(memory instanceof wasm.Memory)) throw memoryTypeError();
	throw unsupportedNodeApi("Running a WebAssembly module through node:wasi", NESTED_INSTANTIATION_UNSUPPORTED);
}
/**
* Rebuild the error a provider serialized. A uvwasi failure is a plain `Error` whose own
* enumerable `errno`, `code` and `syscall` are defined in that order, as the binding sets them.
*/
function providerError(record) {
	const message = record.code === "ERR_JCO_WASI_ADAPTER_REQUIRED" ? `${record.message}. Mapping one only makes construction behave as Node's does: running a module through node:wasi is not supported in a WebAssembly component, because ${NESTED_INSTANTIATION_UNSUPPORTED}` : record.message;
	const error = new Error(message);
	const fields = [
		["errno", decodeErrno(record.errno ?? void 0)],
		["code", record.code ?? "ERR_JCO_WASI_HOST"],
		["syscall", record.syscall ?? void 0]
	];
	for (const [key, value] of fields) if (value !== void 0) Object.defineProperty(error, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	return error;
}
/** `UVWASI_EINVAL`, which the binding returns for a call whose arguments it cannot convert. */
const UVWASI_EINVAL = 28;
/** V8's `IsUint32` for a number and `IsBigInt` for the 64-bit parameters. */
function acceptsArgument(parameter, value) {
	if (parameter === "u32") return typeof value === "number" && Number.isInteger(value) && !Object.is(value, -0) && value >= 0 && value <= 4294967295;
	return typeof value === "bigint";
}
/**
* A syscall with Node's name, arity and pre-start behaviour. The binding checks the argument
* count and types first and answers `UVWASI_EINVAL` without throwing when they do not match;
* only a well-formed call reaches the memory, which in a component is never bound. The
* binding's methods are native, so `wasiImport` carries `Function.prototype.bind` copies named
* `bound <syscall>`; binding here reproduces both the names and the arities.
*/
function syscall(name, parameters) {
	const fn = { [name]: function(...args) {
		if (args.length !== parameters.length) return UVWASI_EINVAL;
		if (!parameters.every((parameter, index) => acceptsArgument(parameter, args[index]))) return UVWASI_EINVAL;
		throw notStarted();
	} }[name];
	Object.defineProperty(fn, "length", {
		value: parameters.length,
		configurable: true
	});
	return fn.bind(void 0);
}
/** Create the `node:wasi` module over an explicit initialisation provider. */
function createWasi(host) {
	const call = (operation) => callHost(operation, providerError);
	class WASI {
		wasiImport;
		[kBindingName];
		[kSetMemory];
		[kStarted];
		[kExitCode];
		[kInstance];
		constructor(options = kEmptyObject) {
			validateObject(options, "options");
			validateString(options.version, "options.version");
			let version;
			switch (options.version) {
				case "unstable":
					version = "unstable";
					this[kBindingName] = "wasi_unstable";
					break;
				case "preview1":
					version = "preview1";
					this[kBindingName] = "wasi_snapshot_preview1";
					break;
				default: throw invalidArgValue("options.version", options.version, "unsupported WASI version");
			}
			if (options.args !== void 0) validateArray(options.args, "options.args");
			const args = (options.args || []).map(String);
			const env = [];
			if (options.env !== void 0) {
				validateObject(options.env, "options.env");
				for (const [key, value] of Object.entries(options.env)) if (value !== void 0) env.push([key, `${value}`]);
			}
			const preopens = [];
			if (options.preopens !== void 0) {
				validateObject(options.preopens, "options.preopens");
				for (const [key, value] of Object.entries(options.preopens)) preopens.push([String(key), String(value)]);
			}
			const { stdin = 0, stdout = 1, stderr = 2 } = options;
			validateInteger(stdin, "options.stdin", 0, 2147483647);
			validateInteger(stdout, "options.stdout", 0, 2147483647);
			validateInteger(stderr, "options.stderr", 0, 2147483647);
			const initOptions = {
				version,
				args,
				env,
				preopens,
				stdin,
				stdout,
				stderr
			};
			call(() => host.init(initOptions));
			const wrap = Object.fromEntries(PREVIEW1_SYSCALLS.map(([name, parameters]) => [name, syscall(name, parameters)]));
			let returnOnExit = true;
			if (options.returnOnExit !== void 0) {
				validateBoolean(options.returnOnExit, "options.returnOnExit");
				returnOnExit = options.returnOnExit;
			}
			if (returnOnExit) wrap.proc_exit = wasiReturnOnProcExit.bind(this);
			this[kSetMemory] = setMemory;
			this.wasiImport = wrap;
			this[kStarted] = false;
			this[kExitCode] = 0;
			this[kInstance] = void 0;
		}
		finalizeBindings(instance, { memory = exportedMemory(instance) } = {}) {
			if (this[kStarted]) throw alreadyStarted();
			validateInstance(instance);
			this[kSetMemory](memory);
			this[kInstance] = instance;
			this[kStarted] = true;
		}
		start(instance) {
			this.finalizeBindings(instance);
			const { _start, _initialize } = startedExports(this[kInstance]);
			validateFunction(_start, "instance.exports._start");
			validateUndefined(_initialize, "instance.exports._initialize");
			try {
				_start();
			} catch (err) {
				if (err !== kExitCode) throw err;
			}
			return this[kExitCode];
		}
		initialize(instance) {
			this.finalizeBindings(instance);
			const { _start, _initialize } = startedExports(this[kInstance]);
			validateUndefined(_start, "instance.exports._start");
			if (_initialize !== void 0) {
				validateFunction(_initialize, "instance.exports._initialize");
				_initialize();
			}
		}
		getImportObject() {
			return { [this[kBindingName]]: this.wasiImport };
		}
	}
	function wasiReturnOnProcExit(rval) {
		this[kExitCode] = rval;
		throw kExitCode;
	}
	return { WASI };
}
/** The two object checks `finalizeBindings` makes, in Node's order. */
function validateInstance(instance) {
	validateObject(instance, "instance");
	validateObject(instance.exports, "instance.exports");
}
/** Node's `instance?.exports?.memory` default, evaluated before `instance` is validated. */
function exportedMemory(instance) {
	return instance?.exports?.memory;
}
/** The exports `finalizeBindings` recorded; it throws before recording any in a component. */
function startedExports(instance) {
	if (instance === void 0) throw notStarted();
	return instance.exports;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/wasi.js
const wasi = createWasi(wasi_host_exports);
const { WASI } = wasi;
//#endregion
export { WASI, wasi as default };
