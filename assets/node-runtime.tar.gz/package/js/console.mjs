//#region src/console.mjs
const methods = [
	"assert",
	"clear",
	"count",
	"countReset",
	"debug",
	"dir",
	"dirxml",
	"error",
	"group",
	"groupCollapsed",
	"groupEnd",
	"info",
	"log",
	"profile",
	"profileEnd",
	"table",
	"time",
	"timeEnd",
	"timeLog",
	"timeStamp",
	"trace",
	"warn"
];
function forward(name) {
	const method = globalThis.console?.[name];
	if (typeof method === "function") return method.bind(globalThis.console);
	return function unavailable() {
		throw Object.assign(/* @__PURE__ */ new Error(`console.${name} is not provided by this engine`), { code: "ERR_NOT_SUPPORTED" });
	};
}
const bound = Object.fromEntries(methods.map((name) => [name, forward(name)]));
var Console = class {
	constructor(stdout) {
		if (stdout == null) throw Object.assign(/* @__PURE__ */ new TypeError("Console expects a writable stream"), { code: "ERR_CONSOLE_WRITABLE_STREAM" });
	}
	log(...args) {
		return bound.log(...args);
	}
	info(...args) {
		return bound.info(...args);
	}
	warn(...args) {
		return bound.warn(...args);
	}
	error(...args) {
		return bound.error(...args);
	}
	debug(...args) {
		return bound.debug(...args);
	}
	trace(...args) {
		return bound.trace(...args);
	}
	dir(...args) {
		return bound.dir(...args);
	}
	table(...args) {
		return bound.table(...args);
	}
	time(label) {
		return bound.time(label);
	}
	timeEnd(label) {
		return bound.timeEnd(label);
	}
	timeLog(label, ...args) {
		return bound.timeLog(label, ...args);
	}
};
const { assert, clear, count, countReset, debug, dir, dirxml, error, group, groupCollapsed, groupEnd, info, log, profile, profileEnd, table, time, timeEnd, timeLog, timeStamp, trace, warn } = bound;
function createTask() {
	throw Object.assign(/* @__PURE__ */ new Error("console.createTask is not provided"), { code: "ERR_NOT_SUPPORTED" });
}
const context = globalThis.console;
var console_default = globalThis.console;
//#endregion
export { Console, assert, clear, context, count, countReset, createTask, debug, console_default as default, dir, dirxml, error, group, groupCollapsed, groupEnd, info, log, profile, profileEnd, table, time, timeEnd, timeLog, timeStamp, trace, warn };
