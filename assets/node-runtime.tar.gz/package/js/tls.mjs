import { Buffer } from "./buffer.mjs";
import { a as error, i as connectOptions, l as normalizeConnect, n as baseOptions, r as checkOptions, t as Socket } from "./chunks/socket-DEcwU0em.mjs";
import { createClient } from "hibana:tls/api@0.5.0";
//#region ../../extensions/node-tls/src/handle.mjs
const dispose = Symbol.dispose || Symbol.for("dispose");
var TlsHandle = class {
	constructor(tcp, options) {
		this.tcp = tcp;
		this.options = options;
		this.session = null;
		this.output = null;
		this.offset = 0;
		this.eof = false;
		this.ending = false;
		this.tcpEnded = false;
	}
	flush() {
		if (!this.output) {
			this.output = this.session.takeOutput();
			this.offset = 0;
		}
		if (this.output) {
			this.offset += this.tcp.write(this.output.subarray(this.offset));
			if (this.offset === this.output.length) this.output = null;
		}
	}
	status() {
		const tcp = this.tcp.status();
		if (!tcp.connected) return {
			...tcp,
			secure: false
		};
		this.session ??= createClient(this.options);
		this.flush();
		if (!this.eof && this.session.status().wantsInput) {
			const input = this.tcp.read();
			if (input != null) {
				if (input.length) this.session.receive(input);
				else {
					this.eof = true;
					this.session.receiveEof();
				}
			}
		}
		this.flush();
		const tls = this.session.status();
		if (this.ending && !this.tcpEnded && !this.output && !tls.wantsOutput) {
			this.tcp.end();
			this.tcpEnded = true;
		}
		return {
			...tcp,
			secure: tls.secure,
			alpn: tls.alpn
		};
	}
	read() {
		return this.session?.read();
	}
	write(data) {
		return this.session ? this.session.write(data) : 0;
	}
	end() {
		this.ending = true;
		this.session?.end();
	}
	keepAlive(...args) {
		return this.tcp.keepAlive(...args);
	}
	peerCertificate() {
		return this.session?.peerCertificate();
	}
	close() {
		try {
			this.session?.close();
			this.session?.[dispose]?.();
		} finally {
			this.session = null;
			this.output = null;
			try {
				this.tcp?.close();
			} finally {
				this.tcp?.[dispose]?.();
				this.tcp = null;
			}
		}
	}
};
//#endregion
//#region ../../extensions/node-tls/src/index.mjs
function unsupported(name) {
	throw error("ERR_METHOD_NOT_IMPLEMENTED", `${name} is not provided by @hibana/node-tls`);
}
const allowed = [
	...connectOptions,
	"socket",
	"servername",
	"ca",
	"ALPNProtocols",
	"rejectUnauthorized"
];
function tlsOptions(options, host) {
	if (options.rejectUnauthorized !== void 0 && options.rejectUnauthorized !== true) throw error("ERR_NOT_SUPPORTED", "TLS certificate verification is mandatory");
	const name = options.servername ?? host;
	if (typeof name !== "string" || !name.length) throw error("ERR_INVALID_ARG_VALUE", "A servername or host is required for certificate verification");
	let caPem;
	if (options.ca !== void 0) caPem = (Array.isArray(options.ca) ? options.ca : [options.ca]).map((cert) => {
		if (typeof cert === "string") return cert;
		if (cert instanceof Uint8Array) return Buffer.from(cert).toString("utf8");
		throw error("ERR_INVALID_ARG_TYPE", "CA must be PEM text or bytes");
	}).join("\n");
	const alpn = options.ALPNProtocols ?? [];
	if (!Array.isArray(alpn) || alpn.some((p) => typeof p !== "string" || !/^[\x21-\x7e]+$/.test(p))) throw error("ERR_NOT_SUPPORTED", "ALPNProtocols must be an array of ASCII protocol names");
	return {
		serverName: name,
		caPem,
		alpn
	};
}
var TLSSocket = class extends Socket {
	constructor(socket, options = {}) {
		checkOptions(options, allowed);
		if (socket && (!(socket instanceof Socket) || socket.encrypted)) throw error("ERR_TLS_INVALID_STATE", "STARTTLS requires a plain TCP socket");
		super({
			...Object.fromEntries(baseOptions.filter((key) => key in options).map((key) => [key, options[key]])),
			allowHalfOpen: socket ? socket.allowHalfOpen : options.allowHalfOpen
		});
		this._secure = false;
		this.encrypted = true;
		this.authorized = false;
		this.authorizationError = null;
		this.alpnProtocol = false;
		this._tlsOptions = tlsOptions(options, socket?._host ?? options.host ?? "localhost");
		if (socket) {
			if (options.timeout !== void 0) this.setTimeout(options.timeout);
			socket._transferTo(this);
			this._rawSocket = socket;
			socket.once("close", () => {
				if (!this.destroyed) this.destroy();
			});
		}
	}
	_wrapHandle(handle) {
		return new TlsHandle(handle, this._tlsOptions);
	}
	_canReadWrite() {
		return this._connected && this._secure;
	}
	_advanceConnection(state) {
		let progress = super._advanceConnection(state);
		if (!this._handle || this.destroyed) return progress;
		if (state.secure && !this._secure) {
			this._secure = true;
			this.authorized = true;
			this.alpnProtocol = state.alpn || false;
			this._activity();
			progress = true;
			this.emit("secureConnect");
		}
		return progress;
	}
	_destroy(cause, callback) {
		if (!this.authorized && cause) this.authorizationError = cause.code || cause.message;
		try {
			super._destroy(cause, callback);
		} finally {
			if (this._rawSocket && !this._rawSocket.destroyed) this._rawSocket.destroy();
		}
	}
	getPeerCertificate(detailed = false) {
		if (detailed) unsupported("Detailed peer certificate chains");
		if (this.destroyed || !this._handle) return null;
		if (!this.authorized) return {};
		const raw = this._handle.peerCertificate();
		return raw ? { raw: Buffer.from(raw) } : {};
	}
	renegotiate() {
		unsupported("TLS renegotiation");
	}
	getSession() {
		unsupported("TLS session export");
	}
};
function connect(...args) {
	const { options, callback } = normalizeConnect(args);
	checkOptions(options, allowed);
	const socket = new TLSSocket(options.socket, options);
	if (callback) socket.once("secureConnect", callback);
	if (!options.socket) {
		const plain = Object.fromEntries(connectOptions.filter((key) => key in options).map((key) => [key, options[key]]));
		socket.connect(plain);
	}
	return socket;
}
function createServer() {
	unsupported("TLS servers");
}
function createSecureContext() {
	unsupported("Reusable TLS contexts");
}
var Server = class {
	constructor() {
		unsupported("TLS servers");
	}
};
var SecureContext = class {
	constructor() {
		unsupported("Reusable TLS contexts");
	}
};
const CLIENT_RENEG_LIMIT = 3;
const CLIENT_RENEG_WINDOW = 600;
const DEFAULT_ECDH_CURVE = "auto";
const DEFAULT_MAX_VERSION = "TLSv1.3";
const DEFAULT_MIN_VERSION = "TLSv1.2";
const DEFAULT_CIPHERS = [
	"TLS_AES_256_GCM_SHA384",
	"TLS_CHACHA20_POLY1305_SHA256",
	"TLS_AES_128_GCM_SHA256"
].join(":");
function getCiphers() {
	return DEFAULT_CIPHERS.split(":");
}
const rootCertificates = [];
function getCACertificates() {
	return rootCertificates.slice();
}
function setDefaultCACertificates() {
	unsupported("Changing the default CA set");
}
function convertALPNProtocols(protocols) {
	if (protocols == null) return void 0;
	const list = Array.isArray(protocols) ? protocols : [protocols];
	return Buffer.concat(list.map((protocol) => Buffer.from(protocol)));
}
function namesOf(cert) {
	const names = [];
	if (typeof cert?.subjectaltname === "string") for (const part of cert.subjectaltname.split(", ")) {
		const match = /^(DNS|IP Address):(.+)$/.exec(part);
		if (match) names.push(match[2]);
	}
	if (names.length === 0 && typeof cert?.subject?.CN === "string") names.push(cert.subject.CN);
	return names;
}
function matchesHostname(hostname, pattern) {
	const host = hostname.toLowerCase().replace(/\.$/, "");
	const name = pattern.toLowerCase().replace(/\.$/, "");
	if (name.startsWith("*.")) {
		const suffix = name.slice(1);
		return host.length > suffix.length && host.endsWith(suffix) && !host.slice(0, host.length - suffix.length).includes(".");
	}
	return host === name;
}
function checkServerIdentity(hostname, cert) {
	if (typeof hostname !== "string") throw error("ERR_INVALID_ARG_TYPE", "hostname must be a string");
	if (namesOf(cert).some((name) => matchesHostname(hostname, name))) return void 0;
	return error("ERR_TLS_CERT_ALTNAME_INVALID", `Hostname/IP does not match certificate's altnames: ${hostname}`);
}
var src_default = {
	connect,
	TLSSocket,
	createServer,
	createSecureContext,
	Server,
	SecureContext,
	CLIENT_RENEG_LIMIT: 3,
	CLIENT_RENEG_WINDOW: 600,
	DEFAULT_CIPHERS,
	DEFAULT_ECDH_CURVE,
	DEFAULT_MAX_VERSION,
	DEFAULT_MIN_VERSION,
	getCiphers,
	rootCertificates,
	getCACertificates,
	setDefaultCACertificates,
	convertALPNProtocols,
	checkServerIdentity
};
//#endregion
export { CLIENT_RENEG_LIMIT, CLIENT_RENEG_WINDOW, DEFAULT_CIPHERS, DEFAULT_ECDH_CURVE, DEFAULT_MAX_VERSION, DEFAULT_MIN_VERSION, SecureContext, Server, TLSSocket, checkServerIdentity, connect, convertALPNProtocols, createSecureContext, createServer, src_default as default, getCACertificates, getCiphers, rootCertificates, setDefaultCACertificates };
