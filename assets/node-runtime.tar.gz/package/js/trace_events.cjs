module.exports = require('./trace_events.mjs').default;
