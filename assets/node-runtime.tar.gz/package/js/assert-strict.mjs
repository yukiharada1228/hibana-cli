import { y as strict } from "./chunks/assert-DUZYBMOh.mjs";
//#region src/assert-strict.mjs
const { Assert, AssertionError, CallTracker, deepEqual, deepStrictEqual, doesNotMatch, doesNotReject, doesNotThrow, equal, fail, ifError, match, notDeepEqual, notDeepStrictEqual, notEqual, notStrictEqual, ok, partialDeepStrictEqual, rejects, strictEqual, throws } = strict;
var assert_strict_default = strict;
//#endregion
export { Assert, AssertionError, CallTracker, deepEqual, deepStrictEqual, assert_strict_default as default, doesNotMatch, doesNotReject, doesNotThrow, equal, fail, ifError, match, notDeepEqual, notDeepStrictEqual, notEqual, notStrictEqual, ok, partialDeepStrictEqual, rejects, strictEqual, throws };
