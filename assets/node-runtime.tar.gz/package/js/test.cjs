module.exports = require('./test.mjs').default;
