module.exports = require('./dns.mjs').default;
