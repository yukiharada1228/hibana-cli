//#region src/timers-promises.mjs
function setTimeout(ms = 1, value, options = {}) {
	return new Promise((resolve, reject) => {
		const { signal } = options;
		const aborted = () => {
			globalThis.clearTimeout(timer);
			signal?.removeEventListener("abort", aborted);
			reject(Object.assign(new Error("The operation was aborted", { cause: signal?.reason }), {
				name: "AbortError",
				code: "ABORT_ERR"
			}));
		};
		let timer;
		if (signal?.aborted) return aborted();
		timer = globalThis.setTimeout(() => {
			signal?.removeEventListener("abort", aborted);
			resolve(value);
		}, ms);
		signal?.addEventListener("abort", aborted, { once: true });
	});
}
const setImmediate = (value, options) => setTimeout(0, value, options);
async function* setInterval(ms = 1, value, options) {
	while (true) yield await setTimeout(ms, value, options);
}
const scheduler = globalThis.scheduler ?? { wait: (delay, options) => setTimeout(delay, void 0, options) };
var timers_promises_default = {
	setTimeout,
	setImmediate,
	setInterval,
	scheduler
};
//#endregion
export { timers_promises_default as default, scheduler, setImmediate, setInterval, setTimeout };
