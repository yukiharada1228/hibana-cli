module.exports = require('./timers-promises.mjs').default;
