import { C as NOTIMP, D as TIMEOUT, E as SERVFAIL, S as NOTFOUND, T as REFUSED, _ as FORMERR, a as BADFAMILY, b as NOMEM, c as BADNAME, d as BADSTR, f as CANCELLED, g as FILE, h as EOF, l as BADQUERY, m as DESTRUCTION, o as BADFLAGS, p as CONNREFUSED, r as ADDRGETNETWORKPARAMS, s as BADHINTS, t as dns, u as BADRESP, v as LOADIPHLPAPI, w as NOTINITIALIZED, x as NONAME, y as NODATA } from "./chunks/dns-runtime-BeBkjK5h.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/dns-promises.js
const Resolver = dns.promises.Resolver;
const getDefaultResultOrder = dns.promises.getDefaultResultOrder;
const getServers = dns.promises.getServers;
const lookup = dns.promises.lookup;
const lookupService = dns.promises.lookupService;
const resolve = dns.promises.resolve;
const resolve4 = dns.promises.resolve4;
const resolve6 = dns.promises.resolve6;
const resolveAny = dns.promises.resolveAny;
const resolveCaa = dns.promises.resolveCaa;
const resolveCname = dns.promises.resolveCname;
const resolveMx = dns.promises.resolveMx;
const resolveNaptr = dns.promises.resolveNaptr;
const resolveNs = dns.promises.resolveNs;
const resolvePtr = dns.promises.resolvePtr;
const resolveSoa = dns.promises.resolveSoa;
const resolveSrv = dns.promises.resolveSrv;
const resolveTlsa = dns.promises.resolveTlsa;
const resolveTxt = dns.promises.resolveTxt;
const reverse = dns.promises.reverse;
const setDefaultResultOrder = dns.promises.setDefaultResultOrder;
const setServers = dns.promises.setServers;
var dns_promises_default = Object.assign(dns.promises, {
	ADDRGETNETWORKPARAMS,
	BADFAMILY,
	BADFLAGS,
	BADHINTS,
	BADNAME,
	BADQUERY,
	BADRESP,
	BADSTR,
	CANCELLED,
	CONNREFUSED,
	DESTRUCTION,
	EOF: "EOF",
	FILE,
	FORMERR,
	LOADIPHLPAPI,
	NODATA,
	NOMEM,
	NONAME,
	NOTFOUND,
	NOTIMP,
	NOTINITIALIZED,
	REFUSED,
	SERVFAIL,
	TIMEOUT
});
//#endregion
export { ADDRGETNETWORKPARAMS, BADFAMILY, BADFLAGS, BADHINTS, BADNAME, BADQUERY, BADRESP, BADSTR, CANCELLED, CONNREFUSED, DESTRUCTION, EOF, FILE, FORMERR, LOADIPHLPAPI, NODATA, NOMEM, NONAME, NOTFOUND, NOTIMP, NOTINITIALIZED, REFUSED, Resolver, SERVFAIL, TIMEOUT, dns_promises_default as default, getDefaultResultOrder, getServers, lookup, lookupService, resolve, resolve4, resolve6, resolveAny, resolveCaa, resolveCname, resolveMx, resolveNaptr, resolveNs, resolvePtr, resolveSoa, resolveSrv, resolveTlsa, resolveTxt, reverse, setDefaultResultOrder, setServers };
