module.exports = require('./stream-web.mjs').default;
