module.exports = require('./domain.mjs').default;
