module.exports = require('./os.mjs').default;
