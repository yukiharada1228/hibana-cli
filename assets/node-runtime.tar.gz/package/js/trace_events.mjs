import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType } from "./chunks/core-DGqXzKN-.mjs";
import { c as validateObject } from "./chunks/validation-qQPlCQ6g.mjs";
import { t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import { t as inspect } from "./chunks/inspect-DXZXEVsB.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/trace-events-host.js
var trace_events_host_exports = /* @__PURE__ */ __exportAll({
	TraceSession: () => TraceSession,
	default: () => trace_events_host_default,
	getEnabledCategories: () => getEnabledCategories$1,
	release: () => release
});
/** The WIT result carries this record back to the guest as a catchable error. */
function denied() {
	throw {
		name: "Error",
		code: "ERR_JCO_TRACE_EVENTS_ADAPTER_REQUIRED",
		message: adapterRequiredMessage("node:trace_events")
	};
}
/** Declaring the WIT import alone never grants access to host tracing. */
var TraceSession = class {
	static start = denied;
};
const getEnabledCategories$1 = denied;
const release = denied;
var trace_events_host_default = {
	TraceSession,
	getEnabledCategories: getEnabledCategories$1,
	release
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/trace-events/errors.js
/** Use the shared bridge for raw results and ComponentError.payload wrappers. */
function hostCall(operation) {
	return callHost(operation, fromHost);
}
function fromHost(failure) {
	let result;
	switch (failure.name) {
		case "TypeError":
			result = new TypeError(failure.message);
			break;
		case "RangeError":
			result = new RangeError(failure.message);
			break;
		default: result = new Error(failure.message);
	}
	if (result.name !== failure.name) Object.defineProperty(result, "name", {
		value: failure.name,
		configurable: true,
		writable: true
	});
	return failure.code === void 0 ? result : codedError(result, failure.code);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/trace-events/core.js
/**
* Adapted from Node.js lib/trace_events.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; shared errors and
* inspection replace internal utilities; a lazy WIT host resource replaces CategorySet.
* Host capture and warnings belong to the provider. Failed enable/disable calls leave
* guest state unchanged. Captured events describe the host, not the guest engine.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
/** Create one module instance with an explicitly supplied tracing capability. */
function createTraceEvents(host) {
	const enabledTracingObjects = /* @__PURE__ */ new Set();
	class Tracing {
		#handle;
		#categories;
		#capturedCategories = [];
		constructor(categories) {
			this.#categories = categories;
			for (let index = 0; index < categories.length; index++) this.#capturedCategories.push(`${categories[index]}`);
		}
		enable() {
			if (this.#handle !== void 0) return;
			this.#handle = hostCall(() => host.TraceSession.start(this.#capturedCategories));
			enabledTracingObjects.add(this);
		}
		disable() {
			if (this.#handle === void 0) return;
			const handle = this.#handle;
			hostCall(() => handle.stop());
			this.#handle = void 0;
			enabledTracingObjects.delete(this);
			host.release(handle);
		}
		get enabled() {
			return this.#handle !== void 0;
		}
		get categories() {
			return Array.prototype.join.call(this.#categories, ",");
		}
		[Symbol.for("nodejs.util.inspect.custom")](depth, _options) {
			if (typeof depth === "number" && depth < 0) return this;
			return `Tracing ${inspect({
				enabled: this.enabled,
				categories: this.categories
			})}`;
		}
	}
	function createTracing(options) {
		validateObject(options, "options");
		validateCategories(options.categories);
		if (options.categories.length === 0) throw codedError(/* @__PURE__ */ new TypeError("At least one category is required"), "ERR_TRACE_EVENTS_CATEGORY_REQUIRED");
		return new Tracing(options.categories);
	}
	function getEnabledCategories() {
		return hostCall(() => host.getEnabledCategories());
	}
	return {
		createTracing,
		getEnabledCategories
	};
}
function validateCategories(categories) {
	if (!Array.isArray(categories)) throw invalidArgType("options.categories", "Array", categories);
	for (let index = 0; index < categories.length; index++) if (typeof categories[index] !== "string") throw invalidArgType(`options.categories[${index}]`, "string", categories[index]);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/trace-events.js
const traceEvents = createTraceEvents(trace_events_host_exports);
const createTracing = traceEvents.createTracing;
const getEnabledCategories = traceEvents.getEnabledCategories;
//#endregion
export { createTracing, traceEvents as default, getEnabledCategories };
