//#region src/async-hooks.mjs
const hooks = globalThis.__hibanaAsyncContext;
delete globalThis.__hibanaAsyncContext;
const unavailable = (name) => Object.assign(/* @__PURE__ */ new Error(`${name} is not supported in Workers`), { code: "ERR_NOT_SUPPORTED" });
function frame() {
	if (!hooks) throw new Error("This artifact requires the Hibana async-context engine");
	return hooks.get();
}
function invoke(context, fn, thisArg, args) {
	if (typeof fn !== "function") throw new TypeError("callback must be a function");
	const previous = frame();
	hooks.set(context);
	try {
		return Reflect.apply(fn, thisArg, args);
	} finally {
		hooks.set(previous);
	}
}
var AsyncLocalStorage = class {
	#key = Symbol();
	#defaultValue;
	constructor(options = {}) {
		this.#defaultValue = options.defaultValue;
		this.name = options.name ?? "";
	}
	getStore() {
		const context = frame();
		return context && this.#key in context ? context[this.#key] : this.#defaultValue;
	}
	run(store, callback, ...args) {
		const context = Object.create(frame());
		Object.defineProperty(context, this.#key, { value: store });
		return invoke(context, callback, void 0, args);
	}
	exit(callback, ...args) {
		return this.run(void 0, callback, ...args);
	}
	disable() {
		throw unavailable("AsyncLocalStorage.disable");
	}
	enterWith() {
		throw unavailable("AsyncLocalStorage.enterWith");
	}
	static bind(fn) {
		if (typeof fn !== "function") throw new TypeError("fn must be a function");
		const context = frame();
		return function(...args) {
			return invoke(context, fn, this, args);
		};
	}
	static snapshot() {
		const context = frame();
		return (fn, ...args) => invoke(context, fn, void 0, args);
	}
};
var AsyncResource = class AsyncResource {
	#context = frame();
	runInAsyncScope(fn, thisArg, ...args) {
		return invoke(this.#context, fn, thisArg, args);
	}
	bind(fn, thisArg) {
		const context = this.#context;
		const fixedThis = arguments.length > 1;
		return function(...args) {
			return invoke(context, fn, fixedThis ? thisArg : this, args);
		};
	}
	static bind(fn, type, thisArg) {
		const resource = new AsyncResource(type);
		return arguments.length > 2 ? resource.bind(fn, thisArg) : resource.bind(fn);
	}
	emitDestroy() {
		return this;
	}
	asyncId() {
		throw unavailable("AsyncResource.asyncId");
	}
	triggerAsyncId() {
		throw unavailable("AsyncResource.triggerAsyncId");
	}
};
function createHook() {
	throw unavailable("async_hooks.createHook");
}
function executionAsyncId() {
	throw unavailable("async_hooks.executionAsyncId");
}
function executionAsyncResource() {
	throw unavailable("async_hooks.executionAsyncResource");
}
function triggerAsyncId() {
	throw unavailable("async_hooks.triggerAsyncId");
}
const asyncWrapProviders = Object.freeze({});
var async_hooks_default = {
	AsyncLocalStorage,
	AsyncResource,
	createHook,
	executionAsyncId,
	executionAsyncResource,
	triggerAsyncId,
	asyncWrapProviders
};
//#endregion
export { AsyncLocalStorage, AsyncResource, asyncWrapProviders, createHook, async_hooks_default as default, executionAsyncId, executionAsyncResource, triggerAsyncId };
