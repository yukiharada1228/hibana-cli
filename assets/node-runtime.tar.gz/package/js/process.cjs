module.exports = require('./process.mjs').default;
