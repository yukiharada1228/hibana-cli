module.exports = require('./fs-promises.mjs').default;
