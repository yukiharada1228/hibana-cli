import { f as unsupported } from "./chunks/net-server-BNP7dcFI.mjs";
import { C as implementation, E as Agent$2, T as createProtocolModule, c as STATUS_CODES, w as useStatusCodes } from "./chunks/http-B11vpZX5.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/https/agent.js
/**
* Agent for the portable node:https shim.
*
* The operation mapping follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/https.js (MIT license). The option defaults,
* the TLS session cache, and the full `getName()` field order are kept verbatim; socket
* pooling, TLS handshakes, and CONNECT proxy tunnelling are owned by the selected
* implementation and refuse rather than pretend.
*/
/**
* Builds the `pfx` field of an agent key.
*
* Ported from `getPfxAgentKey` in lib/https.js: a plain value contributes itself, while an
* array contributes `:buf:passphrase` per entry so distinct bundles get distinct keys. The
* falsy (`||`) fallbacks and the literal `undefined` for a missing passphrase are Node's own.
*/
function pfxAgentKey(pfx, passphrase) {
	if (!Array.isArray(pfx)) return String(pfx);
	let key = "";
	for (const value of pfx) {
		const raw = value?.buf || value;
		const pass = value?.passphrase || passphrase;
		key += `:${String(raw)}:${String(pass)}`;
	}
	return key;
}
var Agent$1 = class extends Agent$2 {
	maxCachedSessions;
	_sessionCache;
	constructor(options = {}) {
		super({
			...options,
			defaultPort: options.defaultPort ?? 443,
			protocol: options.protocol ?? "https:"
		});
		const configured = this.options.maxCachedSessions;
		this.maxCachedSessions = configured === void 0 ? 100 : configured;
		this._sessionCache = {
			map: {},
			list: []
		};
	}
	createConnection(..._args) {
		return unsupported("https.Agent.createConnection", "TLS handshakes and CONNECT tunnels are owned by the selected implementation");
	}
	/**
	* Own prototype member in Node so a per-request `checkServerIdentity` socket is never
	* pooled; the shim has no sockets, so it only preserves the shape and defers to the base.
	*/
	keepSocketAlive(socket) {
		return super.keepSocketAlive(socket);
	}
	/**
	* Appends the 19 TLS fields to the http agent key.
	*
	* The order, the `!== undefined` guards on `rejectUnauthorized`, `honorCipherOrder`, and
	* `secureOptions`, the `servername !== host` guard, and the `JSON.stringify` of `sigalgs`
	* are all load-bearing: they are what makes two option bags share or split a socket pool.
	*/
	getName(options = {}) {
		let name = super.getName(options);
		name += ":";
		if (options.ca) name += options.ca;
		name += ":";
		if (options.cert) name += options.cert;
		name += ":";
		if (options.clientCertEngine) name += options.clientCertEngine;
		name += ":";
		if (options.ciphers) name += options.ciphers;
		name += ":";
		if (options.key) name += options.key;
		name += ":";
		if (options.pfx) name += pfxAgentKey(options.pfx, options.passphrase);
		name += ":";
		if (options.rejectUnauthorized !== void 0) name += options.rejectUnauthorized;
		name += ":";
		if (options.servername && options.servername !== options.host) name += options.servername;
		name += ":";
		if (options.minVersion) name += options.minVersion;
		name += ":";
		if (options.maxVersion) name += options.maxVersion;
		name += ":";
		if (options.secureProtocol) name += options.secureProtocol;
		name += ":";
		if (options.crl) name += options.crl;
		name += ":";
		if (options.honorCipherOrder !== void 0) name += options.honorCipherOrder;
		name += ":";
		if (options.ecdhCurve) name += options.ecdhCurve;
		name += ":";
		if (options.dhparam) name += options.dhparam;
		name += ":";
		if (options.secureOptions !== void 0) name += options.secureOptions;
		name += ":";
		if (options.sessionIdContext) name += options.sessionIdContext;
		name += ":";
		if (options.sigalgs) name += JSON.stringify(options.sigalgs);
		name += ":";
		if (options.privateKeyIdentifier) name += options.privateKeyIdentifier;
		name += ":";
		if (options.privateKeyEngine) name += options.privateKeyEngine;
		return name;
	}
	_getSession(key) {
		return this._sessionCache.map[key];
	}
	_cacheSession(key, session) {
		if (this.maxCachedSessions === 0) return;
		if (this._sessionCache.map[key]) {
			this._sessionCache.map[key] = session;
			return;
		}
		if (this._sessionCache.list.length >= this.maxCachedSessions) {
			const oldKey = this._sessionCache.list.shift();
			if (oldKey !== void 0) delete this._sessionCache.map[oldKey];
		}
		this._sessionCache.list.push(key);
		this._sessionCache.map[key] = session;
	}
	_evictSession(key) {
		const index = this._sessionCache.list.indexOf(key);
		if (index === -1) return;
		this._sessionCache.list.splice(index, 1);
		delete this._sessionCache.map[key];
	}
};
const globalAgent$1 = new Agent$1({
	keepAlive: true,
	scheduling: "lifo",
	timeout: 5e3
});
const HTTPS_PROFILE = {
	module: "https",
	protocol: "https:",
	scheme: "https",
	defaultPort: 443,
	globalAgent: globalAgent$1
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/https/core.js
/**
* Module factory for the portable node:https shim.
*
* The export set follows nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/https.js (MIT license): `lib/https.js` reuses
* `_http_client` and `_http_server` unchanged and varies only the protocol, the default port,
* and the default agent, so this module reuses the node:http core through a profile rather
* than forking it.
*
* Deliberately absent, matching the upstream module's own export list: nothing here is
* deprecated at the pinned release, and the CONNECT proxy tunnelling added in Node 24
* (`getTunnelConfigForProxiedHttps`, `establishTunnel`, `ERR_PROXY_TUNNEL`) needs a raw
* socket, so a proxied agent refuses through `Agent.createConnection` rather than silently
* making a direct connection.
*/
function createHttps(implementation) {
	const protocol = createProtocolModule(implementation, HTTPS_PROFILE);
	return {
		Agent: Agent$1,
		Server: protocol.Server,
		createServer: protocol.createServer,
		get: protocol.get,
		globalAgent: globalAgent$1,
		request: protocol.request
	};
}
//#endregion
//#region src/https.mjs
useStatusCodes(STATUS_CODES);
const https = createHttps(implementation);
const Agent = https.Agent;
const Server = https.Server;
const createServer = https.createServer;
const get = https.get;
const globalAgent = https.globalAgent;
const request = https.request;
//#endregion
export { Agent, Server, createServer, https as default, get, globalAgent, request };
