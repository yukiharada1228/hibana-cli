module.exports = require('./v8.mjs').default;
