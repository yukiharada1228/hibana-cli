import { a as __toESM } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { t as require_string_decoder } from "./chunks/string_decoder-0oCrBGmc.mjs";
//#region src/string-decoder.mjs
var import_string_decoder = /* @__PURE__ */ __toESM(require_string_decoder(), 1);
const { StringDecoder } = import_string_decoder.default;
var string_decoder_default = import_string_decoder.default;
//#endregion
export { StringDecoder, string_decoder_default as default };
