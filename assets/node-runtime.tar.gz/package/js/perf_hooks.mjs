import { a as codedError, d as invalidArgType, h as missingArgs, m as invalidThis, s as deprecatedNodeApi, u as illegalConstructor, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { c as validateObject } from "./chunks/validation-qQPlCQ6g.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/internal.js
/**
* Adapted from Node.js lib/internal/perf/performance.js / usertiming.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
/** Refuse a perf_hooks API the engine cannot support, naming why. */
function unsupported(api, reason) {
	throw unsupportedNodeApi(`node:perf_hooks ${api}`, reason);
}
function timestamp(value) {
	if (typeof value !== "number") throw invalidArgType("startTime", "number", value);
	if (value < 0) throw codedError(/* @__PURE__ */ new TypeError(`${value} is not a valid timestamp`), "ERR_PERFORMANCE_INVALID_TIMESTAMP");
}
function enumerable(prototype, names, tag) {
	for (const name of names) Object.defineProperty(prototype, name, { enumerable: true });
	if (tag) Object.defineProperty(prototype, Symbol.toStringTag, {
		configurable: true,
		value: tag
	});
}
function now() {
	if (typeof globalThis.performance?.now !== "function") unsupported("performance.now", "the engine has no monotonic clock");
	return globalThis.performance.now();
}
function clone(value) {
	if (value == null) return null;
	if (typeof globalThis.structuredClone !== "function") unsupported("detail cloning", "the engine has no structuredClone");
	return globalThis.structuredClone(value);
}
const kSkipThrow = Symbol("kSkipThrow");
const brands = /* @__PURE__ */ new WeakMap();
function brand(value, name) {
	let names = brands.get(value);
	if (!names) {
		names = /* @__PURE__ */ new Set();
		brands.set(value, names);
	}
	names.add(name);
}
function check(value, name) {
	if (!brands.get(value)?.has(name)) throw invalidThis(name);
}
/** Narrow DOMException fallback for engines without the Web constructor. */
function domException(message, name) {
	if (typeof globalThis.DOMException === "function") return new globalThis.DOMException(message, name);
	const error = new Error(message);
	error.name = name;
	return Object.assign(error, { code: name === "SyntaxError" ? 12 : 13 });
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/entries.js
/**
* Adapted from Node.js lib/internal/perf/performance_entry.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
var PerformanceEntry = class {
	#name;
	#type;
	#start;
	#duration;
	constructor(token, name = "", type = "", start = 0, duration = 0) {
		if (token !== kSkipThrow) throw illegalConstructor();
		brand(this, "PerformanceEntry");
		this.#name = name;
		this.#type = type;
		this.#start = start;
		this.#duration = duration;
	}
	get name() {
		check(this, "PerformanceEntry");
		return this.#name;
	}
	get entryType() {
		check(this, "PerformanceEntry");
		return this.#type;
	}
	get startTime() {
		check(this, "PerformanceEntry");
		return this.#start;
	}
	get duration() {
		check(this, "PerformanceEntry");
		return this.#duration;
	}
	toJSON() {
		check(this, "PerformanceEntry");
		return {
			name: this.name,
			entryType: this.entryType,
			startTime: this.startTime,
			duration: this.duration
		};
	}
};
enumerable(PerformanceEntry.prototype, [
	"name",
	"entryType",
	"startTime",
	"duration",
	"toJSON"
]);
var PerformanceNodeEntry = class extends PerformanceEntry {
	#detail;
	constructor(token, name, type, start, duration, detail) {
		super(token, name, type, start, duration);
		brand(this, "PerformanceNodeEntry");
		this.#detail = detail;
	}
	get detail() {
		check(this, "PerformanceNodeEntry");
		return this.#detail;
	}
	get kind() {
		throw deprecatedNodeApi("PerformanceNodeEntry.kind", "detail.kind");
	}
	get flags() {
		throw deprecatedNodeApi("PerformanceNodeEntry.flags", "detail.flags");
	}
	set kind(_value) {
		throw deprecatedNodeApi("PerformanceNodeEntry.kind", "detail.kind");
	}
	set flags(_value) {
		throw deprecatedNodeApi("PerformanceNodeEntry.flags", "detail.flags");
	}
	toJSON() {
		check(this, "PerformanceNodeEntry");
		return {
			...super.toJSON(),
			detail: this.detail
		};
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/observe.js
/**
* Adapted from Node.js lib/internal/perf/observe.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
const supported = Object.freeze([
	"function",
	"mark",
	"measure",
	"resource"
]);
const noEntryTypes = Object.freeze([]);
const observers = /* @__PURE__ */ new Set();
const pending = /* @__PURE__ */ new Set();
let queued = false;
let entries = [];
let resourceLimit = 250;
let resourcePending = false;
let secondary = [];
let dispatchBufferFull = () => {};
function setDispatchBufferFull(fn) {
	dispatchBufferFull = fn;
}
function schedule() {
	if (queued) return;
	queued = true;
	setTimeout(() => {
		queued = false;
		const dispatch = [...pending];
		pending.clear();
		for (const observer of dispatch) observer[dispatchRecords]();
	}, 0);
}
function filterEntries(name, type) {
	return [
		"mark",
		"measure",
		"resource"
	].flatMap((kind) => entries.filter((entry) => entry.entryType === kind)).filter((entry) => (name === void 0 || entry.name === name) && (type === void 0 || entry.entryType === type)).sort((a, b) => a.startTime - b.startTime);
}
function clearEntries(type, name) {
	entries = entries.filter((entry) => entry.entryType !== type || name !== void 0 && entry.name !== name);
}
function setResourceTimingBufferSize(size) {
	resourceLimit = size;
}
function bufferEntry(entry) {
	if (entry.entryType !== "resource" || !resourcePending && filterEntries(void 0, "resource").length < resourceLimit) {
		entries.push(entry);
		return;
	}
	if (typeof globalThis.setTimeout !== "function" || typeof globalThis.Event !== "function") unsupported("resource timing buffer overflow", "the engine has no event dispatch or task scheduler");
	secondary.push(entry);
	if (resourcePending) return;
	resourcePending = true;
	setTimeout(() => {
		try {
			while (secondary.length) {
				dispatchBufferFull();
				const count = Math.max(0, Math.min(resourceLimit - filterEntries(void 0, "resource").length, secondary.length));
				if (!count) {
					secondary = [];
					break;
				}
				entries.push(...secondary.splice(0, count));
			}
		} finally {
			resourcePending = false;
		}
	}, 0);
}
var PerformanceObserverEntryList = class {
	#entries;
	constructor(token, entries = []) {
		if (token !== kSkipThrow) throw illegalConstructor();
		brand(this, "PerformanceObserverEntryList");
		this.#entries = entries.sort((a, b) => a.startTime - b.startTime);
	}
	getEntries() {
		check(this, "PerformanceObserverEntryList");
		return this.#entries.slice();
	}
	getEntriesByType(type) {
		check(this, "PerformanceObserverEntryList");
		if (!arguments.length) throw missingArgs("type");
		type = `${type}`;
		return this.#entries.filter((entry) => entry.entryType === type);
	}
	getEntriesByName(name, type) {
		check(this, "PerformanceObserverEntryList");
		if (!arguments.length) throw missingArgs("name");
		name = `${name}`;
		return this.#entries.filter((entry) => entry.name === name && (type == null || entry.entryType === type));
	}
};
enumerable(PerformanceObserverEntryList.prototype, [
	"getEntries",
	"getEntriesByName",
	"getEntriesByType"
], "PerformanceObserverEntryList");
const buffer = Symbol("buffer");
const dispatchRecords = Symbol("dispatch");
var PerformanceObserver = class {
	#buffer = [];
	#types = /* @__PURE__ */ new Set();
	#mode;
	#callback;
	constructor(callback) {
		if (typeof callback !== "function") throw invalidArgType("callback", "function", callback);
		brand(this, "PerformanceObserver");
		this.#callback = callback;
	}
	static get supportedEntryTypes() {
		return typeof globalThis.setTimeout === "function" ? supported : noEntryTypes;
	}
	observe(options = {}) {
		check(this, "PerformanceObserver");
		if (typeof globalThis.setTimeout !== "function") unsupported("PerformanceObserver.observe", "the engine has no task scheduler");
		validateObject(options, "options");
		const { entryTypes, type, buffered } = { ...options };
		if (entryTypes === void 0 && type === void 0) throw missingArgs("options.entryTypes", "options.type");
		if (entryTypes != null && type != null) throw codedError(/* @__PURE__ */ new TypeError("options.entryTypes can not set with options.type together"), "ERR_INVALID_ARG_VALUE");
		if (this.#mode === "single" && entryTypes !== void 0) throw domException("PerformanceObserver can not change to multiple observations", "InvalidModificationError");
		if (this.#mode === "multiple" && type !== void 0) throw domException("PerformanceObserver can not change to single observation", "InvalidModificationError");
		this.#mode ??= entryTypes !== void 0 ? "multiple" : "single";
		if (this.#mode === "multiple") {
			if (!Array.isArray(entryTypes)) throw invalidArgType("options.entryTypes", "string[]", entryTypes);
			this.#types.clear();
			for (const entryType of entryTypes) if (supported.includes(entryType)) this.#types.add(entryType);
		} else {
			if (typeof type !== "string" || !supported.includes(type)) return;
			this.#types.add(type);
			if (buffered) {
				this.#buffer.push(...filterEntries(void 0, type));
				pending.add(this);
				schedule();
			}
		}
		if (this.#types.size) observers.add(this);
		else this.disconnect();
	}
	disconnect() {
		check(this, "PerformanceObserver");
		observers.delete(this);
		pending.delete(this);
		this.#buffer = [];
		this.#types.clear();
		this.#mode = void 0;
	}
	takeRecords() {
		check(this, "PerformanceObserver");
		const records = this.#buffer;
		this.#buffer = [];
		return records;
	}
	[buffer](entry) {
		if (!this.#types.has(entry.entryType)) return;
		this.#buffer.push(entry);
		pending.add(this);
		schedule();
	}
	[dispatchRecords]() {
		this.#callback(new PerformanceObserverEntryList(kSkipThrow, this.takeRecords()), this);
	}
};
enumerable(PerformanceObserver.prototype, [
	"observe",
	"disconnect",
	"takeRecords"
], "PerformanceObserver");
function enqueue(entry) {
	for (const observer of observers) observer[buffer](entry);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/usertiming.js
/**
* Adapted from Node.js lib/internal/perf/usertiming.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
const markTimings = /* @__PURE__ */ new Map();
const reserved = /* @__PURE__ */ new Set([
	"nodeStart",
	"v8Start",
	"environment",
	"loopStart",
	"loopExit",
	"bootstrapComplete"
]);
function checkName(name) {
	if (reserved.has(name)) throw codedError(/* @__PURE__ */ new TypeError(`The argument 'name' is invalid. Received '${name}'`), "ERR_INVALID_ARG_VALUE");
}
function getMark(value) {
	if (typeof value === "number") {
		timestamp(value);
		return value;
	}
	const name = `${value}`;
	if (reserved.has(name)) unsupported(`performance.nodeTiming.${name}`, "Node process milestones are unavailable");
	const ts = markTimings.get(name);
	if (ts === void 0) throw domException(`The "${name}" performance mark has not been set`, "SyntaxError");
	return ts;
}
var PerformanceMark = class extends PerformanceEntry {
	#detail;
	constructor(name, options) {
		if (!arguments.length) throw missingArgs("name");
		name = `${name}`;
		checkName(name);
		if (options != null) validateObject(options, "options");
		const start = options?.startTime ?? now();
		timestamp(start);
		markTimings.set(name, start);
		const detail = clone(options?.detail);
		super(kSkipThrow, name, "mark", start, 0);
		brand(this, "PerformanceMark");
		this.#detail = detail;
	}
	get detail() {
		check(this, "PerformanceMark");
		return this.#detail;
	}
	toJSON() {
		check(this, "PerformanceMark");
		return {
			...super.toJSON(),
			detail: this.detail
		};
	}
};
enumerable(PerformanceMark.prototype, ["detail"], "PerformanceMark");
var PerformanceMeasure = class extends PerformanceEntry {
	#detail;
	constructor(token, name = "", start = 0, duration = 0, detail = null) {
		if (token !== kSkipThrow) throw illegalConstructor();
		super(token, name, "measure", start, duration);
		brand(this, "PerformanceMeasure");
		this.#detail = detail;
	}
	get detail() {
		check(this, "PerformanceMeasure");
		return this.#detail;
	}
	toJSON() {
		check(this, "PerformanceMeasure");
		return {
			...super.toJSON(),
			detail: this.detail
		};
	}
};
enumerable(PerformanceMeasure.prototype, ["detail"], "PerformanceMeasure");
function mark(name, options) {
	const entry = new PerformanceMark(name, options);
	enqueue(entry);
	bufferEntry(entry);
	return entry;
}
function measure(name, options, endMark) {
	if (typeof name !== "string") throw invalidArgType("name", "string", name);
	let start;
	let end;
	let duration;
	if (options !== null && typeof options === "object") ({start, end, duration} = options);
	const valid = start !== void 0 || end !== void 0;
	if (valid && (endMark !== void 0 || start !== void 0 && end !== void 0 && duration !== void 0)) throw codedError(/* @__PURE__ */ new TypeError(endMark !== void 0 ? "endMark must not be specified" : "Must not have options.start, options.end, and options.duration specified"), "ERR_PERFORMANCE_MEASURE_INVALID_OPTIONS");
	const finish = endMark !== void 0 ? getMark(endMark) : valid && end !== void 0 ? getMark(end) : valid && start !== void 0 && duration !== void 0 ? getMark(start) + getMark(duration) : now();
	const begin = typeof options === "string" ? getMark(options) : valid && start !== void 0 ? getMark(start) : valid && duration !== void 0 && end !== void 0 ? finish - getMark(duration) : 0;
	const detail = clone(typeof options === "object" ? options?.detail : void 0);
	const entry = new PerformanceMeasure(kSkipThrow, name, begin, finish - begin, detail);
	enqueue(entry);
	bufferEntry(entry);
	return entry;
}
function clearMarkTimings(name) {
	if (name !== void 0) {
		checkName(name);
		markTimings.delete(name);
	} else markTimings.clear();
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/resource-timing.js
/**
* Adapted from Node.js lib/internal/perf/resource_timing.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
var PerformanceResourceTiming = class extends PerformanceEntry {
	#timing;
	#cache;
	#initiator;
	#delivery;
	#status;
	constructor(token, name = "", timing, cache = "", initiator = "", status = 0, delivery = "") {
		if (token !== kSkipThrow || !timing) throw illegalConstructor();
		super(token, name, "resource");
		brand(this, "PerformanceResourceTiming");
		this.#timing = timing;
		this.#cache = cache;
		this.#initiator = initiator;
		this.#status = status;
		this.#delivery = delivery;
	}
	get startTime() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.startTime;
	}
	get duration() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.endTime - this.#timing.startTime;
	}
	get initiatorType() {
		check(this, "PerformanceResourceTiming");
		return this.#initiator;
	}
	get workerStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalServiceWorkerStartTime;
	}
	get redirectStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.redirectStartTime;
	}
	get redirectEnd() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.redirectEndTime;
	}
	get fetchStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.postRedirectStartTime;
	}
	get domainLookupStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.domainLookupStartTime;
	}
	get domainLookupEnd() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.domainLookupEndTime;
	}
	get connectStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.connectionStartTime;
	}
	get connectEnd() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.connectionEndTime;
	}
	get secureConnectionStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.secureConnectionStartTime;
	}
	get nextHopProtocol() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalConnectionTimingInfo?.ALPNNegotiatedProtocol;
	}
	get requestStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalNetworkRequestStartTime;
	}
	get responseStart() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.finalNetworkResponseStartTime;
	}
	get responseEnd() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.endTime;
	}
	get encodedBodySize() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.encodedBodySize;
	}
	get decodedBodySize() {
		check(this, "PerformanceResourceTiming");
		return this.#timing.decodedBodySize;
	}
	get transferSize() {
		check(this, "PerformanceResourceTiming");
		return this.#cache === "local" ? 0 : this.#timing.encodedBodySize + 300;
	}
	get deliveryType() {
		check(this, "PerformanceResourceTiming");
		return this.#delivery;
	}
	get responseStatus() {
		check(this, "PerformanceResourceTiming");
		return this.#status;
	}
	toJSON() {
		check(this, "PerformanceResourceTiming");
		return {
			...super.toJSON(),
			startTime: this.startTime,
			duration: this.duration,
			initiatorType: this.initiatorType,
			workerStart: this.workerStart,
			redirectStart: this.redirectStart,
			redirectEnd: this.redirectEnd,
			fetchStart: this.fetchStart,
			domainLookupStart: this.domainLookupStart,
			domainLookupEnd: this.domainLookupEnd,
			connectStart: this.connectStart,
			connectEnd: this.connectEnd,
			secureConnectionStart: this.secureConnectionStart,
			nextHopProtocol: this.nextHopProtocol,
			requestStart: this.requestStart,
			responseStart: this.responseStart,
			responseEnd: this.responseEnd,
			encodedBodySize: this.encodedBodySize,
			decodedBodySize: this.decodedBodySize,
			transferSize: this.transferSize,
			deliveryType: this.deliveryType,
			responseStatus: this.responseStatus
		};
	}
};
enumerable(PerformanceResourceTiming.prototype, [
	"initiatorType",
	"workerStart",
	"redirectStart",
	"redirectEnd",
	"fetchStart",
	"domainLookupStart",
	"domainLookupEnd",
	"connectStart",
	"connectEnd",
	"secureConnectionStart",
	"nextHopProtocol",
	"requestStart",
	"responseStart",
	"responseEnd",
	"encodedBodySize",
	"decodedBodySize",
	"transferSize",
	"deliveryType",
	"responseStatus",
	"toJSON"
], "PerformanceResourceTiming");
function markResourceTiming(timing, requestedUrl, initiatorType, _global, cacheMode, _bodyInfo, responseStatus, deliveryType = "") {
	if (cacheMode !== "" && cacheMode !== "local") throw codedError(/* @__PURE__ */ new Error("cache must be an empty string or 'local'"), "ERR_INTERNAL_ASSERTION");
	const entry = new PerformanceResourceTiming(kSkipThrow, requestedUrl, timing, cacheMode, initiatorType, responseStatus, deliveryType);
	bufferEntry(entry);
	enqueue(entry);
	return entry;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/timerify.js
/**
* Adapted from Node.js lib/internal/perf/timerify.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
function timerify(fn, options = {}) {
	if (typeof fn !== "function") throw invalidArgType("fn", "function", fn);
	validateObject(options, "options");
	if (options.histogram !== void 0) throw invalidArgType("options.histogram", "RecordableHistogram", options.histogram);
	function complete(start, args) {
		const entry = new PerformanceNodeEntry(kSkipThrow, fn.name, "function", start, now() - start, args);
		Object.assign(entry, args);
		enqueue(entry);
	}
	function timerified(...args) {
		const start = now();
		const result = new.target ? Reflect.construct(fn, args, fn) : Reflect.apply(fn, this, args);
		const finish = new.target ? void 0 : result?.finally;
		if (typeof finish === "function") return Reflect.apply(finish, result, [() => complete(start, args)]);
		complete(start, args);
		return result;
	}
	Object.defineProperties(timerified, {
		length: {
			configurable: false,
			enumerable: true,
			value: fn.length
		},
		name: {
			configurable: false,
			enumerable: true,
			value: `timerified ${fn.name}`
		}
	});
	return timerified;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/perf-hooks/index.js
/**
* Adapted from Node.js lib/internal/perf/performance.js and lib/perf_hooks.js at v24.20.0,
* commit 71b8b174857e25106d39b61a9e6f30d927da8b01.
* TypeScript adaptation: ECMAScript builtins replace primordials; runtime clocks,
* cloning and scheduling replace Node internals. Native telemetry is unsupported.
*
* Copyright Node.js contributors. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
function createHistogram(_options) {
	return unsupported("createHistogram", "a native HDR histogram is required");
}
function monitorEventLoopDelay(_options) {
	return unsupported("monitorEventLoopDelay", "event-loop instrumentation is required");
}
function eventLoopUtilization(_first, _second) {
	return unsupported("eventLoopUtilization", "event-loop instrumentation is required");
}
const token = Symbol("Performance");
var MissingEventTarget = class {
	addEventListener(_type, _callback, _options) {
		return unsupported("performance.addEventListener", "the engine has no EventTarget");
	}
	removeEventListener(_type, _callback, _options) {
		return unsupported("performance.removeEventListener", "the engine has no EventTarget");
	}
	dispatchEvent(_event) {
		return unsupported("performance.dispatchEvent", "the engine has no EventTarget");
	}
};
const RuntimeEventTarget = globalThis.EventTarget ?? MissingEventTarget;
var Performance = class extends RuntimeEventTarget {
	constructor(key) {
		if (key !== token) throw illegalConstructor();
		super();
		brand(this, "Performance");
	}
	clearMarks(name) {
		check(this, "Performance");
		if (name !== void 0) name = `${name}`;
		clearMarkTimings(name);
		clearEntries("mark", name);
	}
	clearMeasures(name) {
		check(this, "Performance");
		clearEntries("measure", name === void 0 ? void 0 : `${name}`);
	}
	clearResourceTimings(name) {
		check(this, "Performance");
		clearEntries("resource", name === void 0 ? void 0 : `${name}`);
	}
	getEntries() {
		check(this, "Performance");
		return filterEntries();
	}
	getEntriesByName(name, type) {
		check(this, "Performance");
		if (!arguments.length) throw missingArgs("name");
		return filterEntries(`${name}`, type === void 0 ? void 0 : `${type}`);
	}
	getEntriesByType(type) {
		check(this, "Performance");
		if (!arguments.length) throw missingArgs("type");
		return filterEntries(void 0, `${type}`);
	}
	mark(name, options) {
		check(this, "Performance");
		if (!arguments.length) throw missingArgs("name");
		return mark(name, options);
	}
	measure(name, options, endMark) {
		check(this, "Performance");
		if (!arguments.length) throw missingArgs("name");
		return measure(name, options, endMark);
	}
	now() {
		check(this, "Performance");
		return now();
	}
	get timeOrigin() {
		check(this, "Performance");
		if (typeof globalThis.performance?.timeOrigin !== "number") unsupported("performance.timeOrigin", "the engine has no clock");
		return globalThis.performance.timeOrigin;
	}
	setResourceTimingBufferSize(maxSize) {
		check(this, "Performance");
		if (!arguments.length) throw missingArgs("maxSize");
		setResourceTimingBufferSize(+maxSize >>> 0);
	}
	get nodeTiming() {
		check(this, "Performance");
		return unsupported("performance.nodeTiming", "Node process milestones are unavailable");
	}
	toJSON() {
		check(this, "Performance");
		return unsupported("performance.toJSON", "Node process telemetry is unavailable");
	}
	get onresourcetimingbufferfull() {
		check(this, "Performance");
		return this.#onfull;
	}
	set onresourcetimingbufferfull(callback) {
		check(this, "Performance");
		if (this.#onfull) this.removeEventListener("resourcetimingbufferfull", this.#onfull);
		this.#onfull = typeof callback === "function" ? callback : null;
		if (this.#onfull) this.addEventListener("resourcetimingbufferfull", this.#onfull);
	}
	#onfull = null;
};
Object.defineProperties(Performance.prototype, {
	eventLoopUtilization: {
		configurable: true,
		writable: true,
		value: eventLoopUtilization
	},
	timerify: {
		configurable: true,
		writable: true,
		value: timerify
	},
	markResourceTiming: {
		configurable: true,
		writable: true,
		value: markResourceTiming
	}
});
enumerable(Performance.prototype, [
	"clearMarks",
	"clearMeasures",
	"clearResourceTimings",
	"getEntries",
	"getEntriesByName",
	"getEntriesByType",
	"mark",
	"measure",
	"now",
	"timeOrigin",
	"toJSON",
	"setResourceTimingBufferSize",
	"onresourcetimingbufferfull"
], "Performance");
const performance = new Performance(token);
setDispatchBufferFull(() => performance.dispatchEvent(new Event("resourcetimingbufferfull")));
const publicConstants = {
	NODE_PERFORMANCE_GC_MAJOR: 4,
	NODE_PERFORMANCE_GC_MINOR: 1,
	NODE_PERFORMANCE_GC_MINOR_MARK_SWEEP: 2,
	NODE_PERFORMANCE_GC_INCREMENTAL: 8,
	NODE_PERFORMANCE_GC_WEAKCB: 16,
	NODE_PERFORMANCE_GC_FLAGS_NO: 0,
	NODE_PERFORMANCE_GC_FLAGS_CONSTRUCT_RETAINED: 2,
	NODE_PERFORMANCE_GC_FLAGS_FORCED: 4,
	NODE_PERFORMANCE_GC_FLAGS_SYNCHRONOUS_PHANTOM_PROCESSING: 8,
	NODE_PERFORMANCE_GC_FLAGS_ALL_AVAILABLE_GARBAGE: 16,
	NODE_PERFORMANCE_GC_FLAGS_ALL_EXTERNAL_MEMORY: 32,
	NODE_PERFORMANCE_GC_FLAGS_SCHEDULE_IDLE: 64
};
for (const [key, value] of Object.entries({
	NODE_PERFORMANCE_ENTRY_TYPE_GC: 0,
	NODE_PERFORMANCE_ENTRY_TYPE_HTTP: 1,
	NODE_PERFORMANCE_ENTRY_TYPE_HTTP2: 2,
	NODE_PERFORMANCE_ENTRY_TYPE_NET: 3,
	NODE_PERFORMANCE_ENTRY_TYPE_DNS: 4,
	NODE_PERFORMANCE_ENTRY_TYPE_QUIC: 5,
	NODE_PERFORMANCE_MILESTONE_TIME_ORIGIN_TIMESTAMP: 0,
	NODE_PERFORMANCE_MILESTONE_TIME_ORIGIN: 1,
	NODE_PERFORMANCE_MILESTONE_ENVIRONMENT: 2,
	NODE_PERFORMANCE_MILESTONE_NODE_START: 3,
	NODE_PERFORMANCE_MILESTONE_V8_START: 4,
	NODE_PERFORMANCE_MILESTONE_LOOP_START: 5,
	NODE_PERFORMANCE_MILESTONE_LOOP_EXIT: 6,
	NODE_PERFORMANCE_MILESTONE_BOOTSTRAP_COMPLETE: 7
})) Object.defineProperty(publicConstants, key, { value });
const constants = Object.freeze(publicConstants);
const perfHooks = {
	Performance,
	PerformanceEntry,
	PerformanceMark,
	PerformanceMeasure,
	PerformanceObserver,
	PerformanceObserverEntryList,
	PerformanceResourceTiming,
	monitorEventLoopDelay,
	eventLoopUtilization,
	timerify,
	createHistogram,
	performance,
	constants
};
Object.defineProperty(perfHooks, "constants", {
	configurable: false,
	writable: false,
	enumerable: true,
	value: constants
});
//#endregion
export { Performance, PerformanceEntry, PerformanceMark, PerformanceMeasure, PerformanceObserver, PerformanceObserverEntryList, PerformanceResourceTiming, constants, createHistogram, perfHooks as default, eventLoopUtilization, monitorEventLoopDelay, performance, timerify };
