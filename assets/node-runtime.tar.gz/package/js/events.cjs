module.exports = require('./events.mjs').default;
