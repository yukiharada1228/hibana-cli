import { d as invalidArgType, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { c as validateObject, o as validateInteger, r as validateBoolean, u as validateString } from "./chunks/validation-qQPlCQ6g.mjs";
import { i as simple, s as parse, t as ancestor } from "./chunks/walk-CkCAtcHQ.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/unsupported.js
function unsupported(api, reason) {
	throw unsupportedNodeApi(api, reason);
}
function unsupportedContext(api) {
	return unsupported(api, "the guest engine does not expose separate JavaScript realms");
}
function unsupportedModules(api) {
	return unsupported(api, "the guest engine does not expose VM module records or a dynamic module loader");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/source.js
function isFunction(node) {
	return node.type === "FunctionDeclaration" || node.type === "FunctionExpression" || node.type === "ArrowFunctionExpression";
}
/** Parse as Script, not as a Function body: top-level return must be a syntax error. */
function parseScript(source) {
	let sourceURL;
	let sourceMapURL;
	const program = parse(source, {
		ecmaVersion: "latest",
		sourceType: "script",
		onComment(block, text) {
			if (block) return;
			const match = /^[#@]\s+source(Mapping)?URL=([^\s'"`]+)\s*$/.exec(text);
			if (match?.[1]) sourceMapURL = match[2];
			else if (match) sourceURL = match[2];
		}
	});
	rejectDynamicImports(program);
	return {
		sourceURL,
		sourceMapURL,
		hasGlobalDeclarations: hasGlobalDeclarations(program)
	};
}
/** An eval cannot create the persistent global bindings of a native vm.Script. */
function hasGlobalDeclarations(program) {
	let found = program.body.some((node) => node.type === "VariableDeclaration" || node.type === "ClassDeclaration" || node.type === "FunctionDeclaration");
	ancestor(program, {
		VariableDeclaration(node, _state, parents) {
			if (node.kind === "var" && !parents.some(isFunction)) found = true;
		},
		FunctionDeclaration(_node, _state, parents) {
			if (!parents.slice(0, -1).some(isFunction)) found = true;
		}
	});
	return found;
}
function rejectGlobalDeclarations(parsed) {
	if (parsed.hasGlobalDeclarations) unsupported("vm.Script global declarations", "indirect eval cannot preserve native VM global bindings; use globalThis properties or compileFunction() for local declarations");
}
function rejectDynamicImports(program) {
	simple(program, { ImportExpression() {
		unsupportedModules("vm dynamic import()");
	} });
}
/** Keep a caller-supplied filename from adding executable lines to the source. */
function namedSource(source, filename) {
	return `${source}\n//# sourceURL=${filename.replace(/[\r\n\u2028\u2029]/g, " ")}`;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/options.js
/** Dispatch deprecated options before coercing source or reading option getters. */
function rejectDeprecatedCacheOption(options) {
	if (options !== null && typeof options === "object" && "produceCachedData" in options) throw deprecatedNodeApi("vm.Script options.produceCachedData", "Use script.createCachedData() instead");
}
function scriptOptions(options = {}) {
	if (typeof options === "string") return { filename: options };
	validateObject(options, "options");
	return options;
}
function validateSourceOptions(options, defaultFilename) {
	const { filename = defaultFilename, lineOffset = 0, columnOffset = 0 } = options;
	validateString(filename, "options.filename");
	validateInteger(lineOffset, "options.lineOffset", -2147483648, 2147483647);
	validateInteger(columnOffset, "options.columnOffset", -2147483648, 2147483647);
	if (lineOffset !== 0 || columnOffset !== 0) unsupported("vm compilation offsets", "the guest engine cannot apply V8 stack trace offsets");
	return filename;
}
function rejectCachedData(cachedData) {
	if (cachedData === void 0) return;
	if (!ArrayBuffer.isView(cachedData)) throw invalidArgType("options.cachedData", [
		"Buffer",
		"TypedArray",
		"DataView"
	], cachedData);
	unsupported("vm options.cachedData", "V8 bytecode caches cannot be used by the guest engine");
}
function rejectDynamicLoader(loader) {
	if (loader !== void 0) unsupportedModules("vm options.importModuleDynamically");
}
/** Never accept a watchdog option and then execute without its promised limit. */
function validateRunOptions(options = {}) {
	validateObject(options, "options");
	const { timeout, displayErrors = true, breakOnSigint = false } = options;
	if (timeout !== void 0) validateInteger(timeout, "options.timeout", 1, 4294967295);
	validateBoolean(displayErrors, "options.displayErrors");
	validateBoolean(breakOnSigint, "options.breakOnSigint");
	if (timeout !== void 0) unsupported("vm options.timeout", "the guest engine has no synchronous execution watchdog");
	if (breakOnSigint) unsupported("vm options.breakOnSigint", "host signals cannot interrupt guest JavaScript evaluation");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/script.js
const evaluate = eval;
var Script = class {
	#source;
	#filename;
	#parsed;
	sourceURL;
	sourceMapURL;
	constructor(code, options = {}) {
		rejectDeprecatedCacheOption(options);
		const source = `${code}`;
		const settings = scriptOptions(options);
		this.#filename = validateSourceOptions(settings, "evalmachine.<anonymous>");
		rejectCachedData(settings.cachedData);
		rejectDynamicLoader(settings.importModuleDynamically);
		this.#parsed = parseScript(source);
		this.#source = source;
		this.sourceURL = this.#parsed.sourceURL;
		this.sourceMapURL = this.#parsed.sourceMapURL;
	}
	runInThisContext(options) {
		validateRunOptions(options);
		rejectGlobalDeclarations(this.#parsed);
		return evaluate(namedSource(this.#source, this.#parsed.sourceURL ?? this.#filename));
	}
	runInContext(_contextifiedObject, _options) {
		return unsupportedContext("vm.Script.runInContext()");
	}
	runInNewContext(_contextObject, _options) {
		return unsupportedContext("vm.Script.runInNewContext()");
	}
	createCachedData() {
		return unsupported("vm.Script.createCachedData()", "the guest engine does not expose V8 bytecode caches");
	}
};
function createScript(code, options) {
	return new Script(code, options);
}
function runInThisContext(code, options) {
	return createScript(code, options).runInThisContext(typeof options === "string" ? { filename: options } : options);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/compile-function.js
const compile = Function;
function readParameters(params) {
	if (!Array.isArray(params)) throw invalidArgType("params", "Array", params);
	const parameters = [];
	for (let index = 0; index < params.length; index++) {
		const parameter = params[index];
		validateString(parameter, `params[${index}]`);
		const statement = parse(`(${parameter})`, { ecmaVersion: "latest" }).body[0];
		if (statement?.type !== "ExpressionStatement" || statement.expression.type !== "Identifier" || statement.expression.name !== parameter) throw new SyntaxError("vm.compileFunction parameters must be identifier names");
		parameters.push(parameter);
	}
	return parameters;
}
function validateContextOptions(options) {
	const { parsingContext, contextExtensions = [] } = options;
	if (parsingContext !== void 0) unsupportedContext("vm.compileFunction options.parsingContext");
	if (!Array.isArray(contextExtensions)) throw invalidArgType("options.contextExtensions", "Array", contextExtensions);
	if (contextExtensions.length !== 0) unsupportedContext("vm.compileFunction options.contextExtensions");
}
function compileFunction(code, params, options = {}) {
	validateString(code, "code");
	validateObject(options, "options");
	const parameters = params === void 0 ? [] : readParameters(params);
	const filename = validateSourceOptions(options, "");
	rejectCachedData(options.cachedData);
	const { produceCachedData = false } = options;
	validateBoolean(produceCachedData, "options.produceCachedData");
	if (produceCachedData) unsupported("vm.compileFunction options.produceCachedData", "the guest engine does not expose V8 bytecode caches");
	validateContextOptions(options);
	rejectDynamicLoader(options.importModuleDynamically);
	rejectDynamicImports(parse(`(function(${parameters.join(",")}) {\n${code}\n})`, {
		ecmaVersion: "latest",
		sourceType: "script"
	}));
	const result = compile(...parameters, namedSource(code, filename));
	Object.defineProperty(result, "name", {
		value: "",
		configurable: true
	});
	return result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/constants.js
/** These identify Node options; neither option grants a realm or a module loader. */
const constants = Object.freeze({
	__proto__: null,
	USE_MAIN_CONTEXT_DEFAULT_LOADER: Symbol("vm_dynamic_import_main_context_default"),
	DONT_CONTEXTIFY: Symbol("vm_context_no_contextify")
});
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/contexts.js
function createContext(_contextObject = {}, _options) {
	return unsupportedContext("vm.createContext()");
}
function isContext(object) {
	validateObject(object, "object", { allowArray: true });
	return false;
}
function runInContext(_code, _contextifiedObject, _options) {
	return unsupportedContext("vm.runInContext()");
}
function runInNewContext(_code, _contextObject, _options) {
	return unsupportedContext("vm.runInNewContext()");
}
function measureMemory(_options = {}) {
	return unsupported("vm.measureMemory()", "V8 per-context heap accounting is unavailable in the guest engine");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/modules.js
/** Preserve the experimental module hierarchy without manufacturing inert modules. */
var Module = class {
	constructor(_options) {
		unsupportedModules(new.target.prototype === SourceTextModule.prototype ? "vm.SourceTextModule" : new.target.prototype === SyntheticModule.prototype ? "vm.SyntheticModule" : "vm.Module");
	}
	get identifier() {
		return unsupportedModules("vm.Module.identifier");
	}
	get context() {
		return unsupportedModules("vm.Module.context");
	}
	get namespace() {
		return unsupportedModules("vm.Module.namespace");
	}
	get status() {
		return unsupportedModules("vm.Module.status");
	}
	get error() {
		return unsupportedModules("vm.Module.error");
	}
	link(_linker) {
		return unsupportedModules("vm.Module.link()");
	}
	evaluate(_options = {}) {
		return unsupportedModules("vm.Module.evaluate()");
	}
};
var SourceTextModule = class extends Module {
	constructor(_code, _options = {}) {
		super();
	}
	linkRequests(_modules) {
		return unsupportedModules("vm.SourceTextModule.linkRequests()");
	}
	instantiate() {
		return unsupportedModules("vm.SourceTextModule.instantiate()");
	}
	get dependencySpecifiers() {
		return unsupportedModules("vm.SourceTextModule.dependencySpecifiers");
	}
	get moduleRequests() {
		return unsupportedModules("vm.SourceTextModule.moduleRequests");
	}
	get status() {
		return unsupportedModules("vm.SourceTextModule.status");
	}
	get error() {
		return unsupportedModules("vm.SourceTextModule.error");
	}
	hasAsyncGraph() {
		return unsupportedModules("vm.SourceTextModule.hasAsyncGraph()");
	}
	hasTopLevelAwait() {
		return unsupportedModules("vm.SourceTextModule.hasTopLevelAwait()");
	}
	createCachedData() {
		return unsupportedModules("vm.SourceTextModule.createCachedData()");
	}
};
var SyntheticModule = class extends Module {
	constructor(_exportNames, _evaluateCallback, _options = {}) {
		super();
	}
	link(_linker = void 0) {
		return unsupportedModules("vm.SyntheticModule.link()");
	}
	setExport(_name, _value) {
		return unsupportedModules("vm.SyntheticModule.setExport()");
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/vm/index.js
const vm = {
	Script,
	createContext,
	createScript,
	runInContext,
	runInNewContext,
	runInThisContext,
	isContext,
	compileFunction,
	measureMemory,
	constants,
	Module,
	SourceTextModule,
	SyntheticModule
};
//#endregion
export { Module, Script, SourceTextModule, SyntheticModule, compileFunction, constants, createContext, createScript, vm as default, isContext, measureMemory, runInContext, runInNewContext, runInThisContext };
