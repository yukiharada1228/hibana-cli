import { r as UNSUPPORTED_CODE } from "./chunks/core-DGqXzKN-.mjs";
import { a as builtinModules, i as unsupported, n as Module, o as isBuiltin, r as invalidArgType, t as createRequire } from "./chunks/require-BqabYoHg.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/source-map.js
/** Reverse lookup for base64 VLQ digits, built once. */
const DIGITS = new Map(Array.from("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", (character, index) => [character, index]));
/**
* Decode one base64 VLQ value, advancing the cursor.
*
* Continuation bit is 0x20; the low bit of the assembled value is the sign.
*/
function decodeValue(segment, cursor) {
	let result = 0;
	let shift = 0;
	let digit;
	do {
		const character = segment[cursor.at++];
		const value = DIGITS.get(character);
		if (value === void 0) throw invalidArgType("payload.mappings", "a valid base64 VLQ string", segment);
		digit = value;
		result += (digit & 31) << shift;
		shift += 5;
	} while (digit & 32);
	return result & 1 ? -(result >> 1) : result >> 1;
}
/**
* Decode a `mappings` string into the flat, generated-order list Node searches.
*
* Fields are deltas: generated column resets per line, the rest carry across lines.
*/
function decodeMappings(mappings) {
	const decoded = [];
	let generatedLine = 0;
	let generatedColumn = 0;
	let source = 0;
	let originalLine = 0;
	let originalColumn = 0;
	let name = 0;
	for (const line of mappings.split(";")) {
		generatedColumn = 0;
		if (line.length === 0) {
			generatedLine += 1;
			continue;
		}
		for (const segment of line.split(",")) {
			if (segment.length === 0) continue;
			const cursor = { at: 0 };
			generatedColumn += decodeValue(segment, cursor);
			const mapping = {
				generatedLine,
				generatedColumn
			};
			if (cursor.at < segment.length) {
				source += decodeValue(segment, cursor);
				originalLine += decodeValue(segment, cursor);
				originalColumn += decodeValue(segment, cursor);
				mapping.originalSource = source;
				mapping.originalLine = originalLine;
				mapping.originalColumn = originalColumn;
				if (cursor.at < segment.length) {
					name += decodeValue(segment, cursor);
					mapping.name = name;
				}
			}
			decoded.push(mapping);
		}
		generatedLine += 1;
	}
	return decoded;
}
/** Order two generated positions. */
function before(line, column, mapping) {
	return mapping.generatedLine < line || mapping.generatedLine === line && mapping.generatedColumn <= column;
}
var SourceMap = class {
	#payload;
	#mappings;
	#lineLengths;
	constructor(payload, options) {
		if (typeof payload !== "object" || payload === null) throw invalidArgType("payload", "an object", payload);
		this.#payload = { ...payload };
		this.#mappings = decodeMappings(payload.mappings ?? "");
		this.#lineLengths = options?.lineLengths;
	}
	get payload() {
		return this.#payload;
	}
	get lineLengths() {
		return this.#lineLengths;
	}
	/**
	* Node's `findEntry(lineOffset, columnOffset)`, both zero-based.
	*
	* Searches the whole flattened list rather than one line, so a position past the last mapping
	* answers with the last entry rather than nothing -- matching Node, which surprises people.
	*/
	findEntry(lineOffset, columnOffset) {
		let low = 0;
		let high = this.#mappings.length - 1;
		let found = -1;
		while (low <= high) {
			const middle = low + high >> 1;
			if (before(lineOffset, columnOffset, this.#mappings[middle])) {
				found = middle;
				low = middle + 1;
			} else high = middle - 1;
		}
		if (found < 0) return {};
		const mapping = this.#mappings[found];
		const entry = {
			generatedLine: mapping.generatedLine,
			generatedColumn: mapping.generatedColumn
		};
		if (mapping.originalSource !== void 0) {
			entry.originalSource = this.#payload.sources?.[mapping.originalSource];
			entry.originalLine = mapping.originalLine;
			entry.originalColumn = mapping.originalColumn;
		}
		if (mapping.name !== void 0) entry.name = this.#payload.names?.[mapping.name];
		return entry;
	}
	/**
	* Node's `findOrigin(lineNumber, columnNumber)`, one-based on both axes in and out.
	*
	* Not simply the matched entry's origin: Node keeps the caller's offset *within* the mapped
	* region, so the result is the entry's original position shifted by how far the query sat past
	* the entry's generated position. A query beyond the last mapping therefore extrapolates, and can
	* report a negative column -- which is Node's behaviour, verified against it, not a rounding slip.
	*
	* @param lineNumber - one-based line in the generated source
	* @param columnNumber - one-based column in the generated source
	*/
	findOrigin(lineNumber, columnNumber) {
		const entry = this.findEntry(lineNumber - 1, columnNumber - 1);
		if (entry.originalSource === void 0) return {};
		return {
			name: entry.name,
			fileName: entry.originalSource,
			lineNumber: lineNumber - (entry.generatedLine ?? 0) + (entry.originalLine ?? 0),
			columnNumber: columnNumber - (entry.generatedColumn ?? 0) + (entry.originalColumn ?? 0)
		};
	}
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/module/index.js
/**
* Node's `module.constants`.
*
* Null-prototype, as Node's is. That is observable -- `assert.deepStrictEqual` compares prototypes
* -- so a plain object literal here would be a visible difference.
*/
const constants = Object.freeze(Object.assign(Object.create(null), { compileCacheStatus: Object.freeze(Object.assign(Object.create(null), {
	FAILED: 0,
	ENABLED: 1,
	ALREADY_ENABLED: 2,
	DISABLED: 3
})) }));
/**
* Node's `module.globalPaths`.
*
* Empty, and that is a true statement rather than a refusal: a component has no `$HOME/.node_modules`
* and no installation `lib/node` to search.
*/
const globalPaths = Object.freeze([]);
/**
* Node's `module.findSourceMap(path)`.
*
* Always `undefined` -- which is exactly what Node returns for a file with no registered source
* map. Nothing can register one here, so the answer is honest rather than a stub.
*/
function findSourceMap(path) {}
/**
* Node's `module.getSourceMapsSupport()`.
*
* All false, accurately: the engine applies no source maps to stack traces here.
*/
function getSourceMapsSupport() {
	return Object.assign(Object.create(null), {
		enabled: false,
		nodeModules: false,
		generatedCode: false
	});
}
/**
* Node's `module.setSourceMapsSupport(enabled, options)`.
*
* Refused rather than accepted-and-ignored: it asks the runtime to rewrite stack traces, and
* silently not doing that would leave a caller believing traces are mapped when they are not.
*/
function setSourceMapsSupport(enabled, options) {
	throw unsupported("module.setSourceMapsSupport()", "Source maps are not applied to stack traces in a component");
}
/**
* Node's `module.enableCompileCache()`.
*
* Reports failure through Node's own status protocol instead of throwing, so callers that branch on
* `status` keep working. There is no V8 compile cache and no filesystem to hold one.
*/
function enableCompileCache(cacheDir) {
	return {
		status: constants.compileCacheStatus.FAILED,
		message: "the compile cache needs a filesystem, which a component does not have"
	};
}
/**
* Node's `module.getCompileCacheDir()`.
*
* `undefined`, as Node returns when the cache was never enabled.
*/
function getCompileCacheDir() {}
/**
* Node's `module.flushCompileCache()`.
*
* A no-op, as Node documents when the cache is not enabled.
*/
function flushCompileCache() {}
/**
* Node's `module.syncBuiltinESMExports()`.
*
* A no-op. It exists to push mutations of CJS builtin exports into their ESM bindings; nothing here
* can mutate a builtin, so there is nothing to flush.
*/
function syncBuiltinESMExports() {}
/**
* Node's `module.wrapper`: the two halves of the CJS function wrapper.
*
* Deprecated upstream, and pure string data -- no loader involved -- so it is real rather than
* refused. Mutable, and `wrap` reads it live, which is the behaviour Node has and which code that
* pokes at it depends on.
*/
const wrapper = ["(function (exports, require, module, __filename, __dirname) { ", "\n});"];
/**
* Node's `module.wrap(script)`.
*
* Deprecated upstream, and pure concatenation. It only builds the wrapper text; nothing here
* compiles or runs the result, so it works exactly as it does on Node.
*
* @param script - the source to wrap
*/
function wrap(script) {
	return `${wrapper[0]}${script}${wrapper[1]}`;
}
/** Build an entry point that refuses, for the half of this module that needs a loader. */
function refusing(api, instead) {
	return (() => {
		throw unsupported(api, instead);
	});
}
const STATIC_IMPORT = "Use a static `import` instead, which the bundler can resolve at build time";
const register = refusing("module.register()", "Loader hooks run inside a module loader, and there is none");
const registerHooks = refusing("module.registerHooks()", "Loader hooks run inside a module loader, and there is none");
const runMain = refusing("module.runMain()");
const findPackageJSON = refusing("module.findPackageJSON()", "It reads package.json from disk, and a component has no filesystem");
const stripTypeScriptTypes = refusing("module.stripTypeScriptTypes()", "It needs Node's TypeScript parser, which is not bundled into a component");
/**
* The CJS loader internals.
*
* Node marks these private and mostly deprecated, but real code reaches for them, so they exist and
* explain themselves rather than being absent. Every one is part of resolving or loading a file.
*/
const _cache = Object.create(null);
const _pathCache = Object.create(null);
const _extensions = Object.create(null);
const _debug = refusing("module._debug()");
const _findPath = refusing("module._findPath()");
const _initPaths = refusing("module._initPaths()");
const _load = refusing("module._load()", STATIC_IMPORT);
const _nodeModulePaths = refusing("module._nodeModulePaths()");
const _preloadModules = refusing("module._preloadModules()");
const _readPackage = refusing("module._readPackage()");
const _resolveFilename = refusing("module._resolveFilename()");
const _resolveLookupPaths = refusing("module._resolveLookupPaths()");
const _stat = refusing("module._stat()");
/**
* The module object, matching what `require("node:module")` yields.
*
* Node's module object **is** the `Module` class, so the surface is hung off it as statics and
* `module === module.Module` holds. Defined rather than assigned: a class has non-writable
* `name` and `length`, and `Module` itself must point back at the class.
*/
const moduleSurface = {
	Module,
	SourceMap,
	_cache,
	_debug,
	_extensions,
	_findPath,
	_initPaths,
	_load,
	_nodeModulePaths,
	_pathCache,
	_preloadModules,
	_readPackage,
	_resolveFilename,
	_resolveLookupPaths,
	_stat,
	builtinModules,
	constants,
	createRequire,
	enableCompileCache,
	findPackageJSON,
	findSourceMap,
	flushCompileCache,
	getCompileCacheDir,
	getSourceMapsSupport,
	globalPaths,
	isBuiltin,
	register,
	registerHooks,
	runMain,
	setSourceMapsSupport,
	stripTypeScriptTypes,
	syncBuiltinESMExports,
	wrap,
	wrapper
};
for (const [name, value] of Object.entries(moduleSurface)) Object.defineProperty(Module, name, {
	configurable: true,
	enumerable: true,
	value,
	writable: true
});
var module_default = Module;
//#endregion
export { Module, SourceMap, UNSUPPORTED_CODE, _cache, _debug, _extensions, _findPath, _initPaths, _load, _nodeModulePaths, _pathCache, _preloadModules, _readPackage, _resolveFilename, _resolveLookupPaths, _stat, builtinModules, constants, createRequire, module_default as default, enableCompileCache, findPackageJSON, findSourceMap, flushCompileCache, getCompileCacheDir, getSourceMapsSupport, globalPaths, isBuiltin, register, registerHooks, runMain, setSourceMapsSupport, stripTypeScriptTypes, syncBuiltinESMExports, unsupported, wrap, wrapper };
