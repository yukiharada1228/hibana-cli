import { a as __toESM, r as __exportAll, t as __commonJSMin } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, f as invalidArgValue, g as outOfRange, s as deprecatedNodeApi, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { a as validateFunction, c as validateObject, d as validateStringArray, i as validateBooleanArray, n as validateArray, r as validateBoolean, u as validateString } from "./chunks/validation-qQPlCQ6g.mjs";
import { n as isDeepStrictEqual$1 } from "./chunks/comparisons-ErKmZlxv.mjs";
import { t as nextTick } from "./chunks/scheduler-C8tFqnQW.mjs";
import { i as validateAbortSignal } from "./chunks/shared-DSGRKwku.mjs";
import { t as inspect$2 } from "./chunks/inspect-DXZXEVsB.mjs";
import { I as isStringObject, c as isBigIntObject, d as isBoxedPrimitive, k as isNumberObject, t as types$1, u as isBooleanObject } from "./chunks/util-types-zWaCaHoi.mjs";
//#region node_modules/has-symbols/shams.js
var require_shams$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./shams')} */
	module.exports = function hasSymbols() {
		if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") return false;
		if (typeof Symbol.iterator === "symbol") return true;
		/** @type {{ [k in symbol]?: unknown }} */
		var obj = {};
		var sym = Symbol("test");
		var symObj = Object(sym);
		if (typeof sym === "string") return false;
		if (Object.prototype.toString.call(sym) !== "[object Symbol]") return false;
		if (Object.prototype.toString.call(symObj) !== "[object Symbol]") return false;
		var symVal = 42;
		obj[sym] = symVal;
		for (var _ in obj) return false;
		if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) return false;
		if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) return false;
		var syms = Object.getOwnPropertySymbols(obj);
		if (syms.length !== 1 || syms[0] !== sym) return false;
		if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) return false;
		if (typeof Object.getOwnPropertyDescriptor === "function") {
			var descriptor = Object.getOwnPropertyDescriptor(obj, sym);
			if (descriptor.value !== symVal || descriptor.enumerable !== true) return false;
		}
		return true;
	};
}));
//#endregion
//#region node_modules/has-tostringtag/shams.js
var require_shams = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasSymbols = require_shams$1();
	/** @type {import('.')} */
	module.exports = function hasToStringTagShams() {
		return hasSymbols() && !!Symbol.toStringTag;
	};
}));
//#endregion
//#region node_modules/es-object-atoms/index.js
var require_es_object_atoms = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = Object;
}));
//#endregion
//#region node_modules/es-errors/index.js
var require_es_errors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = Error;
}));
//#endregion
//#region node_modules/es-errors/eval.js
var require_eval = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./eval')} */
	module.exports = EvalError;
}));
//#endregion
//#region node_modules/es-errors/range.js
var require_range = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./range')} */
	module.exports = RangeError;
}));
//#endregion
//#region node_modules/es-errors/ref.js
var require_ref = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./ref')} */
	module.exports = ReferenceError;
}));
//#endregion
//#region node_modules/es-errors/syntax.js
var require_syntax = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./syntax')} */
	module.exports = SyntaxError;
}));
//#endregion
//#region node_modules/es-errors/type.js
var require_type = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./type')} */
	module.exports = TypeError;
}));
//#endregion
//#region node_modules/es-errors/uri.js
var require_uri = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./uri')} */
	module.exports = URIError;
}));
//#endregion
//#region node_modules/math-intrinsics/abs.js
var require_abs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./abs')} */
	module.exports = Math.abs;
}));
//#endregion
//#region node_modules/math-intrinsics/floor.js
var require_floor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./floor')} */
	module.exports = Math.floor;
}));
//#endregion
//#region node_modules/math-intrinsics/max.js
var require_max = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./max')} */
	module.exports = Math.max;
}));
//#endregion
//#region node_modules/math-intrinsics/min.js
var require_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./min')} */
	module.exports = Math.min;
}));
//#endregion
//#region node_modules/math-intrinsics/pow.js
var require_pow = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./pow')} */
	module.exports = Math.pow;
}));
//#endregion
//#region node_modules/math-intrinsics/round.js
var require_round = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./round')} */
	module.exports = Math.round;
}));
//#endregion
//#region node_modules/math-intrinsics/isNaN.js
var require_isNaN = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./isNaN')} */
	module.exports = Number.isNaN || function isNaN(a) {
		return a !== a;
	};
}));
//#endregion
//#region node_modules/math-intrinsics/sign.js
var require_sign = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $isNaN = require_isNaN();
	/** @type {import('./sign')} */
	module.exports = function sign(number) {
		if ($isNaN(number) || number === 0) return number;
		return number < 0 ? -1 : 1;
	};
}));
//#endregion
//#region node_modules/gopd/gOPD.js
var require_gOPD = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./gOPD')} */
	module.exports = Object.getOwnPropertyDescriptor;
}));
//#endregion
//#region node_modules/gopd/index.js
var require_gopd = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	var $gOPD = require_gOPD();
	if ($gOPD) try {
		$gOPD([], "length");
	} catch (e) {
		$gOPD = null;
	}
	module.exports = $gOPD;
}));
//#endregion
//#region node_modules/es-define-property/index.js
var require_es_define_property = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	var $defineProperty = Object.defineProperty || false;
	if ($defineProperty) try {
		$defineProperty({}, "a", { value: 1 });
	} catch (e) {
		$defineProperty = false;
	}
	module.exports = $defineProperty;
}));
//#endregion
//#region node_modules/has-symbols/index.js
var require_has_symbols = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var origSymbol = typeof Symbol !== "undefined" && Symbol;
	var hasSymbolSham = require_shams$1();
	/** @type {import('.')} */
	module.exports = function hasNativeSymbols() {
		if (typeof origSymbol !== "function") return false;
		if (typeof Symbol !== "function") return false;
		if (typeof origSymbol("foo") !== "symbol") return false;
		if (typeof Symbol("bar") !== "symbol") return false;
		return hasSymbolSham();
	};
}));
//#endregion
//#region node_modules/get-proto/Reflect.getPrototypeOf.js
var require_Reflect_getPrototypeOf = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./Reflect.getPrototypeOf')} */
	module.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
}));
//#endregion
//#region node_modules/get-proto/Object.getPrototypeOf.js
var require_Object_getPrototypeOf = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./Object.getPrototypeOf')} */
	module.exports = require_es_object_atoms().getPrototypeOf || null;
}));
//#endregion
//#region node_modules/function-bind/implementation.js
var require_implementation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
	var toStr = Object.prototype.toString;
	var max = Math.max;
	var funcType = "[object Function]";
	var concatty = function concatty(a, b) {
		var arr = [];
		for (var i = 0; i < a.length; i += 1) arr[i] = a[i];
		for (var j = 0; j < b.length; j += 1) arr[j + a.length] = b[j];
		return arr;
	};
	var slicy = function slicy(arrLike, offset) {
		var arr = [];
		for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) arr[j] = arrLike[i];
		return arr;
	};
	var joiny = function(arr, joiner) {
		var str = "";
		for (var i = 0; i < arr.length; i += 1) {
			str += arr[i];
			if (i + 1 < arr.length) str += joiner;
		}
		return str;
	};
	module.exports = function bind(that) {
		var target = this;
		if (typeof target !== "function" || toStr.apply(target) !== funcType) throw new TypeError(ERROR_MESSAGE + target);
		var args = slicy(arguments, 1);
		var bound;
		var binder = function() {
			if (this instanceof bound) {
				var result = target.apply(this, concatty(args, arguments));
				if (Object(result) === result) return result;
				return this;
			}
			return target.apply(that, concatty(args, arguments));
		};
		var boundLength = max(0, target.length - args.length);
		var boundArgs = [];
		for (var i = 0; i < boundLength; i++) boundArgs[i] = "$" + i;
		bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
		if (target.prototype) {
			var Empty = function Empty() {};
			Empty.prototype = target.prototype;
			bound.prototype = new Empty();
			Empty.prototype = null;
		}
		return bound;
	};
}));
//#endregion
//#region node_modules/function-bind/index.js
var require_function_bind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var implementation = require_implementation();
	module.exports = Function.prototype.bind || implementation;
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/functionCall.js
var require_functionCall = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./functionCall')} */
	module.exports = Function.prototype.call;
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/functionApply.js
var require_functionApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./functionApply')} */
	module.exports = Function.prototype.apply;
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/reflectApply.js
var require_reflectApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./reflectApply')} */
	module.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/actualApply.js
var require_actualApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $apply = require_functionApply();
	var $call = require_functionCall();
	/** @type {import('./actualApply')} */
	module.exports = require_reflectApply() || bind.call($call, $apply);
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/index.js
var require_call_bind_apply_helpers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $TypeError = require_type();
	var $call = require_functionCall();
	var $actualApply = require_actualApply();
	/** @type {(args: [Function, thisArg?: unknown, ...args: unknown[]]) => Function} TODO FIXME, find a way to use import('.') */
	module.exports = function callBindBasic(args) {
		if (args.length < 1 || typeof args[0] !== "function") throw new $TypeError("a function is required");
		return $actualApply(bind, $call, args);
	};
}));
//#endregion
//#region node_modules/dunder-proto/get.js
var require_get = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var callBind = require_call_bind_apply_helpers();
	var gOPD = require_gopd();
	var hasProtoAccessor;
	try {
		hasProtoAccessor = [].__proto__ === Array.prototype;
	} catch (e) {
		if (!e || typeof e !== "object" || !("code" in e) || e.code !== "ERR_PROTO_ACCESS") throw e;
	}
	var desc = !!hasProtoAccessor && gOPD && gOPD(Object.prototype, "__proto__");
	var $Object = Object;
	var $getPrototypeOf = $Object.getPrototypeOf;
	/** @type {import('./get')} */
	module.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? function getDunder(value) {
		return $getPrototypeOf(value == null ? value : $Object(value));
	} : false;
}));
//#endregion
//#region node_modules/get-proto/index.js
var require_get_proto = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var reflectGetProto = require_Reflect_getPrototypeOf();
	var originalGetProto = require_Object_getPrototypeOf();
	var getDunderProto = require_get();
	/** @type {import('.')} */
	module.exports = reflectGetProto ? function getProto(O) {
		return reflectGetProto(O);
	} : originalGetProto ? function getProto(O) {
		if (!O || typeof O !== "object" && typeof O !== "function") throw new TypeError("getProto: not an object");
		return originalGetProto(O);
	} : getDunderProto ? function getProto(O) {
		return getDunderProto(O);
	} : null;
}));
//#endregion
//#region node_modules/hasown/index.js
var require_hasown = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var call = Function.prototype.call;
	var $hasOwn = Object.prototype.hasOwnProperty;
	/** @type {import('.')} */
	module.exports = require_function_bind().call(call, $hasOwn);
}));
//#endregion
//#region node_modules/get-intrinsic/index.js
var require_get_intrinsic = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var undefined;
	var $Object = require_es_object_atoms();
	var $Error = require_es_errors();
	var $EvalError = require_eval();
	var $RangeError = require_range();
	var $ReferenceError = require_ref();
	var $SyntaxError = require_syntax();
	var $TypeError = require_type();
	var $URIError = require_uri();
	var abs = require_abs();
	var floor = require_floor();
	var max = require_max();
	var min = require_min();
	var pow = require_pow();
	var round = require_round();
	var sign = require_sign();
	var $Function = Function;
	var getEvalledConstructor = function(expressionSyntax) {
		try {
			return $Function("\"use strict\"; return (" + expressionSyntax + ").constructor;")();
		} catch (e) {}
	};
	var $gOPD = require_gopd();
	var $defineProperty = require_es_define_property();
	var throwTypeError = function() {
		throw new $TypeError();
	};
	var ThrowTypeError = $gOPD ? function() {
		try {
			arguments.callee;
			return throwTypeError;
		} catch (calleeThrows) {
			try {
				return $gOPD(arguments, "callee").get;
			} catch (gOPDthrows) {
				return throwTypeError;
			}
		}
	}() : throwTypeError;
	var hasSymbols = require_has_symbols()();
	var getProto = require_get_proto();
	var $ObjectGPO = require_Object_getPrototypeOf();
	var $ReflectGPO = require_Reflect_getPrototypeOf();
	var $apply = require_functionApply();
	var $call = require_functionCall();
	var needsEval = {};
	var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined : getProto(Uint8Array);
	var INTRINSICS = {
		__proto__: null,
		"%AggregateError%": typeof AggregateError === "undefined" ? undefined : AggregateError,
		"%Array%": Array,
		"%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined : ArrayBuffer,
		"%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined,
		"%AsyncFromSyncIteratorPrototype%": undefined,
		"%AsyncFunction%": needsEval,
		"%AsyncGenerator%": needsEval,
		"%AsyncGeneratorFunction%": needsEval,
		"%AsyncIteratorPrototype%": needsEval,
		"%Atomics%": typeof Atomics === "undefined" ? undefined : Atomics,
		"%BigInt%": typeof BigInt === "undefined" ? undefined : BigInt,
		"%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined : BigInt64Array,
		"%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined : BigUint64Array,
		"%Boolean%": Boolean,
		"%DataView%": typeof DataView === "undefined" ? undefined : DataView,
		"%Date%": Date,
		"%decodeURI%": decodeURI,
		"%decodeURIComponent%": decodeURIComponent,
		"%encodeURI%": encodeURI,
		"%encodeURIComponent%": encodeURIComponent,
		"%Error%": $Error,
		"%eval%": eval,
		"%EvalError%": $EvalError,
		"%Float16Array%": typeof Float16Array === "undefined" ? undefined : Float16Array,
		"%Float32Array%": typeof Float32Array === "undefined" ? undefined : Float32Array,
		"%Float64Array%": typeof Float64Array === "undefined" ? undefined : Float64Array,
		"%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined : FinalizationRegistry,
		"%Function%": $Function,
		"%GeneratorFunction%": needsEval,
		"%Int8Array%": typeof Int8Array === "undefined" ? undefined : Int8Array,
		"%Int16Array%": typeof Int16Array === "undefined" ? undefined : Int16Array,
		"%Int32Array%": typeof Int32Array === "undefined" ? undefined : Int32Array,
		"%isFinite%": isFinite,
		"%isNaN%": isNaN,
		"%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined,
		"%JSON%": typeof JSON === "object" ? JSON : undefined,
		"%Map%": typeof Map === "undefined" ? undefined : Map,
		"%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
		"%Math%": Math,
		"%Number%": Number,
		"%Object%": $Object,
		"%Object.getOwnPropertyDescriptor%": $gOPD,
		"%parseFloat%": parseFloat,
		"%parseInt%": parseInt,
		"%Promise%": typeof Promise === "undefined" ? undefined : Promise,
		"%Proxy%": typeof Proxy === "undefined" ? undefined : Proxy,
		"%RangeError%": $RangeError,
		"%ReferenceError%": $ReferenceError,
		"%Reflect%": typeof Reflect === "undefined" ? undefined : Reflect,
		"%RegExp%": RegExp,
		"%Set%": typeof Set === "undefined" ? undefined : Set,
		"%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
		"%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined : SharedArrayBuffer,
		"%String%": String,
		"%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined,
		"%Symbol%": hasSymbols ? Symbol : undefined,
		"%SyntaxError%": $SyntaxError,
		"%ThrowTypeError%": ThrowTypeError,
		"%TypedArray%": TypedArray,
		"%TypeError%": $TypeError,
		"%Uint8Array%": typeof Uint8Array === "undefined" ? undefined : Uint8Array,
		"%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined : Uint8ClampedArray,
		"%Uint16Array%": typeof Uint16Array === "undefined" ? undefined : Uint16Array,
		"%Uint32Array%": typeof Uint32Array === "undefined" ? undefined : Uint32Array,
		"%URIError%": $URIError,
		"%WeakMap%": typeof WeakMap === "undefined" ? undefined : WeakMap,
		"%WeakRef%": typeof WeakRef === "undefined" ? undefined : WeakRef,
		"%WeakSet%": typeof WeakSet === "undefined" ? undefined : WeakSet,
		"%Function.prototype.call%": $call,
		"%Function.prototype.apply%": $apply,
		"%Object.defineProperty%": $defineProperty,
		"%Object.getPrototypeOf%": $ObjectGPO,
		"%Math.abs%": abs,
		"%Math.floor%": floor,
		"%Math.max%": max,
		"%Math.min%": min,
		"%Math.pow%": pow,
		"%Math.round%": round,
		"%Math.sign%": sign,
		"%Reflect.getPrototypeOf%": $ReflectGPO
	};
	if (getProto) try {
		null.error;
	} catch (e) {
		INTRINSICS["%Error.prototype%"] = getProto(getProto(e));
	}
	var doEval = function doEval(name) {
		var value;
		if (name === "%AsyncFunction%") value = getEvalledConstructor("async function () {}");
		else if (name === "%GeneratorFunction%") value = getEvalledConstructor("function* () {}");
		else if (name === "%AsyncGeneratorFunction%") value = getEvalledConstructor("async function* () {}");
		else if (name === "%AsyncGenerator%") {
			var fn = doEval("%AsyncGeneratorFunction%");
			if (fn) value = fn.prototype;
		} else if (name === "%AsyncIteratorPrototype%") {
			var gen = doEval("%AsyncGenerator%");
			if (gen && getProto) value = getProto(gen.prototype);
		}
		INTRINSICS[name] = value;
		return value;
	};
	var LEGACY_ALIASES = {
		__proto__: null,
		"%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
		"%ArrayPrototype%": ["Array", "prototype"],
		"%ArrayProto_entries%": [
			"Array",
			"prototype",
			"entries"
		],
		"%ArrayProto_forEach%": [
			"Array",
			"prototype",
			"forEach"
		],
		"%ArrayProto_keys%": [
			"Array",
			"prototype",
			"keys"
		],
		"%ArrayProto_values%": [
			"Array",
			"prototype",
			"values"
		],
		"%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
		"%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
		"%AsyncGeneratorPrototype%": [
			"AsyncGeneratorFunction",
			"prototype",
			"prototype"
		],
		"%BooleanPrototype%": ["Boolean", "prototype"],
		"%DataViewPrototype%": ["DataView", "prototype"],
		"%DatePrototype%": ["Date", "prototype"],
		"%ErrorPrototype%": ["Error", "prototype"],
		"%EvalErrorPrototype%": ["EvalError", "prototype"],
		"%Float32ArrayPrototype%": ["Float32Array", "prototype"],
		"%Float64ArrayPrototype%": ["Float64Array", "prototype"],
		"%FunctionPrototype%": ["Function", "prototype"],
		"%Generator%": ["GeneratorFunction", "prototype"],
		"%GeneratorPrototype%": [
			"GeneratorFunction",
			"prototype",
			"prototype"
		],
		"%Int8ArrayPrototype%": ["Int8Array", "prototype"],
		"%Int16ArrayPrototype%": ["Int16Array", "prototype"],
		"%Int32ArrayPrototype%": ["Int32Array", "prototype"],
		"%JSONParse%": ["JSON", "parse"],
		"%JSONStringify%": ["JSON", "stringify"],
		"%MapPrototype%": ["Map", "prototype"],
		"%NumberPrototype%": ["Number", "prototype"],
		"%ObjectPrototype%": ["Object", "prototype"],
		"%ObjProto_toString%": [
			"Object",
			"prototype",
			"toString"
		],
		"%ObjProto_valueOf%": [
			"Object",
			"prototype",
			"valueOf"
		],
		"%PromisePrototype%": ["Promise", "prototype"],
		"%PromiseProto_then%": [
			"Promise",
			"prototype",
			"then"
		],
		"%Promise_all%": ["Promise", "all"],
		"%Promise_reject%": ["Promise", "reject"],
		"%Promise_resolve%": ["Promise", "resolve"],
		"%RangeErrorPrototype%": ["RangeError", "prototype"],
		"%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
		"%RegExpPrototype%": ["RegExp", "prototype"],
		"%SetPrototype%": ["Set", "prototype"],
		"%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
		"%StringPrototype%": ["String", "prototype"],
		"%SymbolPrototype%": ["Symbol", "prototype"],
		"%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
		"%TypedArrayPrototype%": ["TypedArray", "prototype"],
		"%TypeErrorPrototype%": ["TypeError", "prototype"],
		"%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
		"%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
		"%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
		"%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
		"%URIErrorPrototype%": ["URIError", "prototype"],
		"%WeakMapPrototype%": ["WeakMap", "prototype"],
		"%WeakSetPrototype%": ["WeakSet", "prototype"]
	};
	var bind = require_function_bind();
	var hasOwn = require_hasown();
	var $concat = bind.call($call, Array.prototype.concat);
	var $spliceApply = bind.call($apply, Array.prototype.splice);
	var $replace = bind.call($call, String.prototype.replace);
	var $strSlice = bind.call($call, String.prototype.slice);
	var $exec = bind.call($call, RegExp.prototype.exec);
	var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
	var reEscapeChar = /\\(\\)?/g;
	var stringToPath = function stringToPath(string) {
		var first = $strSlice(string, 0, 1);
		var last = $strSlice(string, -1);
		if (first === "%" && last !== "%") throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
		else if (last === "%" && first !== "%") throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
		var result = [];
		$replace(string, rePropName, function(match, number, quote, subString) {
			result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
		});
		return result;
	};
	var getBaseIntrinsic = function getBaseIntrinsic(name, allowMissing) {
		var intrinsicName = name;
		var alias;
		if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
			alias = LEGACY_ALIASES[intrinsicName];
			intrinsicName = "%" + alias[0] + "%";
		}
		if (hasOwn(INTRINSICS, intrinsicName)) {
			var value = INTRINSICS[intrinsicName];
			if (value === needsEval) value = doEval(intrinsicName);
			if (typeof value === "undefined" && !allowMissing) throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
			return {
				alias,
				name: intrinsicName,
				value
			};
		}
		throw new $SyntaxError("intrinsic " + name + " does not exist!");
	};
	module.exports = function GetIntrinsic(name, allowMissing) {
		if (typeof name !== "string" || name.length === 0) throw new $TypeError("intrinsic name must be a non-empty string");
		if (arguments.length > 1 && typeof allowMissing !== "boolean") throw new $TypeError("\"allowMissing\" argument must be a boolean");
		if ($exec(/^%?[^%]*%?$/, name) === null) throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
		var parts = stringToPath(name);
		var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
		var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
		var intrinsicRealName = intrinsic.name;
		var value = intrinsic.value;
		var skipFurtherCaching = false;
		var alias = intrinsic.alias;
		if (alias) {
			intrinsicBaseName = alias[0];
			$spliceApply(parts, $concat([0, 1], alias));
		}
		for (var i = 1, isOwn = true; i < parts.length; i += 1) {
			var part = parts[i];
			var first = $strSlice(part, 0, 1);
			var last = $strSlice(part, -1);
			if ((first === "\"" || first === "'" || first === "`" || last === "\"" || last === "'" || last === "`") && first !== last) throw new $SyntaxError("property names with quotes must have matching quotes");
			if (part === "constructor" || !isOwn) skipFurtherCaching = true;
			intrinsicBaseName += "." + part;
			intrinsicRealName = "%" + intrinsicBaseName + "%";
			if (hasOwn(INTRINSICS, intrinsicRealName)) value = INTRINSICS[intrinsicRealName];
			else if (value != null) {
				if (!(part in value)) {
					if (!allowMissing) throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
					return;
				}
				if ($gOPD && i + 1 >= parts.length) {
					var desc = $gOPD(value, part);
					isOwn = !!desc;
					if (isOwn && "get" in desc && !("originalValue" in desc.get)) value = desc.get;
					else value = value[part];
				} else {
					isOwn = hasOwn(value, part);
					value = value[part];
				}
				if (isOwn && !skipFurtherCaching) INTRINSICS[intrinsicRealName] = value;
			}
		}
		return value;
	};
}));
//#endregion
//#region node_modules/call-bound/index.js
var require_call_bound = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var GetIntrinsic = require_get_intrinsic();
	var callBindBasic = require_call_bind_apply_helpers();
	/** @type {(thisArg: string, searchString: string, position?: number) => number} */
	var $indexOf = callBindBasic([GetIntrinsic("%String.prototype.indexOf%")]);
	/** @type {import('.')} */
	module.exports = function callBoundIntrinsic(name, allowMissing) {
		var intrinsic = GetIntrinsic(name, !!allowMissing);
		if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) return callBindBasic([intrinsic]);
		return intrinsic;
	};
}));
//#endregion
//#region node_modules/is-arguments/index.js
var require_is_arguments = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasToStringTag = require_shams()();
	var $toString = require_call_bound()("Object.prototype.toString");
	/** @type {import('.')} */
	var isStandardArguments = function isArguments(value) {
		if (hasToStringTag && value && typeof value === "object" && Symbol.toStringTag in value) return false;
		return $toString(value) === "[object Arguments]";
	};
	/** @type {import('.')} */
	var isLegacyArguments = function isArguments(value) {
		if (isStandardArguments(value)) return true;
		return value !== null && typeof value === "object" && "length" in value && typeof value.length === "number" && value.length >= 0 && $toString(value) !== "[object Array]" && "callee" in value && $toString(value.callee) === "[object Function]";
	};
	var supportsStandardArguments = function() {
		return isStandardArguments(arguments);
	}();
	isStandardArguments.isLegacyArguments = isLegacyArguments;
	/** @type {import('.')} */
	module.exports = supportsStandardArguments ? isStandardArguments : isLegacyArguments;
}));
//#endregion
//#region node_modules/is-regex/index.js
var require_is_regex = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var callBound = require_call_bound();
	var hasToStringTag = require_shams()();
	var hasOwn = require_hasown();
	var gOPD = require_gopd();
	/** @type {import('.')} */
	var fn;
	if (hasToStringTag) {
		/** @type {(receiver: ThisParameterType<typeof RegExp.prototype.exec>, ...args: Parameters<typeof RegExp.prototype.exec>) => ReturnType<typeof RegExp.prototype.exec>} */
		var $exec = callBound("RegExp.prototype.exec");
		/** @type {object} */
		var isRegexMarker = {};
		var throwRegexMarker = function() {
			throw isRegexMarker;
		};
		/** @type {{ toString(): never, valueOf(): never, [Symbol.toPrimitive]?(): never }} */
		var badStringifier = {
			toString: throwRegexMarker,
			valueOf: throwRegexMarker
		};
		if (typeof Symbol.toPrimitive === "symbol") badStringifier[Symbol.toPrimitive] = throwRegexMarker;
		/** @type {import('.')} */
		fn = function isRegex(value) {
			if (!value || typeof value !== "object") return false;
			var descriptor = gOPD(value, "lastIndex");
			if (!(descriptor && hasOwn(descriptor, "value"))) return false;
			try {
				$exec(value, badStringifier);
			} catch (e) {
				return e === isRegexMarker;
			}
		};
	} else {
		/** @type {(receiver: ThisParameterType<typeof Object.prototype.toString>, ...args: Parameters<typeof Object.prototype.toString>) => ReturnType<typeof Object.prototype.toString>} */
		var $toString = callBound("Object.prototype.toString");
		/** @const @type {'[object RegExp]'} */
		var regexClass = "[object RegExp]";
		/** @type {import('.')} */
		fn = function isRegex(value) {
			if (!value || typeof value !== "object" && typeof value !== "function") return false;
			return $toString(value) === regexClass;
		};
	}
	module.exports = fn;
}));
//#endregion
//#region node_modules/safe-regex-test/index.js
var require_safe_regex_test = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var callBound = require_call_bound();
	var isRegex = require_is_regex();
	var $exec = callBound("RegExp.prototype.exec");
	var $TypeError = require_type();
	/** @type {import('.')} */
	module.exports = function regexTester(regex) {
		if (!isRegex(regex)) throw new $TypeError("`regex` must be a RegExp");
		return function test(s) {
			return $exec(regex, s) !== null;
		};
	};
}));
//#endregion
//#region node_modules/generator-function/index.js
var require_generator_function = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	const cached = function* () {}.constructor;
	/** @type {import('.')} */
	module.exports = () => cached;
}));
//#endregion
//#region node_modules/is-generator-function/index.js
var require_is_generator_function = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var callBound = require_call_bound();
	var isFnRegex = require_safe_regex_test()(/^\s*(?:function)?\*/);
	var hasToStringTag = require_shams()();
	var getProto = require_get_proto();
	var toStr = callBound("Object.prototype.toString");
	var fnToStr = callBound("Function.prototype.toString");
	var getGeneratorFunction = require_generator_function();
	/** @type {import('.')} */
	module.exports = function isGeneratorFunction(fn) {
		if (typeof fn !== "function") return false;
		if (isFnRegex(fnToStr(fn))) return true;
		if (!hasToStringTag) return toStr(fn) === "[object GeneratorFunction]";
		if (!getProto) return false;
		var GeneratorFunction = getGeneratorFunction();
		return GeneratorFunction && getProto(fn) === GeneratorFunction.prototype;
	};
}));
//#endregion
//#region node_modules/is-callable/index.js
var require_is_callable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var fnToStr = Function.prototype.toString;
	var reflectApply = typeof Reflect === "object" && Reflect !== null && Reflect.apply;
	var badArrayLike;
	var isCallableMarker;
	if (typeof reflectApply === "function" && typeof Object.defineProperty === "function") try {
		badArrayLike = Object.defineProperty({}, "length", { get: function() {
			throw isCallableMarker;
		} });
		isCallableMarker = {};
		reflectApply(function() {
			throw 42;
		}, null, badArrayLike);
	} catch (_) {
		if (_ !== isCallableMarker) reflectApply = null;
	}
	else reflectApply = null;
	var constructorRegex = /^\s*class\b/;
	var isES6ClassFn = function isES6ClassFunction(value) {
		try {
			var fnStr = fnToStr.call(value);
			return constructorRegex.test(fnStr);
		} catch (e) {
			return false;
		}
	};
	var tryFunctionObject = function tryFunctionToStr(value) {
		try {
			if (isES6ClassFn(value)) return false;
			fnToStr.call(value);
			return true;
		} catch (e) {
			return false;
		}
	};
	var toStr = Object.prototype.toString;
	var objectClass = "[object Object]";
	var fnClass = "[object Function]";
	var genClass = "[object GeneratorFunction]";
	var ddaClass = "[object HTMLAllCollection]";
	var ddaClass2 = "[object HTML document.all class]";
	var ddaClass3 = "[object HTMLCollection]";
	var hasToStringTag = typeof Symbol === "function" && !!Symbol.toStringTag;
	var isIE68 = !(0 in [,]);
	var isDDA = function isDocumentDotAll() {
		return false;
	};
	if (typeof document === "object") {
		var all = document.all;
		if (toStr.call(all) === toStr.call(document.all)) isDDA = function isDocumentDotAll(value) {
			if ((isIE68 || !value) && (typeof value === "undefined" || typeof value === "object")) try {
				var str = toStr.call(value);
				return (str === ddaClass || str === ddaClass2 || str === ddaClass3 || str === objectClass) && value("") == null;
			} catch (e) {}
			return false;
		};
	}
	module.exports = reflectApply ? function isCallable(value) {
		if (isDDA(value)) return true;
		if (!value) return false;
		if (typeof value !== "function" && typeof value !== "object") return false;
		try {
			reflectApply(value, null, badArrayLike);
		} catch (e) {
			if (e !== isCallableMarker) return false;
		}
		return !isES6ClassFn(value) && tryFunctionObject(value);
	} : function isCallable(value) {
		if (isDDA(value)) return true;
		if (!value) return false;
		if (typeof value !== "function" && typeof value !== "object") return false;
		if (hasToStringTag) return tryFunctionObject(value);
		if (isES6ClassFn(value)) return false;
		var strClass = toStr.call(value);
		if (strClass !== fnClass && strClass !== genClass && !/^\[object HTML/.test(strClass)) return false;
		return tryFunctionObject(value);
	};
}));
//#endregion
//#region node_modules/for-each/index.js
var require_for_each = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isCallable = require_is_callable();
	var toStr = Object.prototype.toString;
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	/** @type {<This, A extends readonly unknown[]>(arr: A, iterator: (this: This | void, value: A[number], index: number, arr: A) => void, receiver: This | undefined) => void} */
	var forEachArray = function forEachArray(array, iterator, receiver) {
		for (var i = 0, len = array.length; i < len; i++) if (hasOwnProperty.call(array, i)) {
			if (receiver == null) iterator(array[i], i, array);
			else iterator.call(receiver, array[i], i, array);
		}
	};
	/** @type {<This, S extends string>(string: S, iterator: (this: This | void, value: S[number], index: number, string: S) => void, receiver: This | undefined) => void} */
	var forEachString = function forEachString(string, iterator, receiver) {
		for (var i = 0, len = string.length; i < len; i++) if (receiver == null) iterator(string.charAt(i), i, string);
		else iterator.call(receiver, string.charAt(i), i, string);
	};
	/** @type {<This, O>(obj: O, iterator: (this: This | void, value: O[keyof O], index: keyof O, obj: O) => void, receiver: This | undefined) => void} */
	var forEachObject = function forEachObject(object, iterator, receiver) {
		for (var k in object) if (hasOwnProperty.call(object, k)) {
			if (receiver == null) iterator(object[k], k, object);
			else iterator.call(receiver, object[k], k, object);
		}
	};
	/** @type {(x: unknown) => x is readonly unknown[]} */
	function isArray(x) {
		return toStr.call(x) === "[object Array]";
	}
	/** @type {import('.')._internal} */
	module.exports = function forEach(list, iterator, thisArg) {
		if (!isCallable(iterator)) throw new TypeError("iterator must be a function");
		var receiver;
		if (arguments.length >= 3) receiver = thisArg;
		if (isArray(list)) forEachArray(list, iterator, receiver);
		else if (typeof list === "string") forEachString(list, iterator, receiver);
		else forEachObject(list, iterator, receiver);
	};
}));
//#endregion
//#region node_modules/possible-typed-array-names/index.js
var require_possible_typed_array_names = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = [
		"Float16Array",
		"Float32Array",
		"Float64Array",
		"Int8Array",
		"Int16Array",
		"Int32Array",
		"Uint8Array",
		"Uint8ClampedArray",
		"Uint16Array",
		"Uint32Array",
		"BigInt64Array",
		"BigUint64Array"
	];
}));
//#endregion
//#region node_modules/available-typed-arrays/index.js
var require_available_typed_arrays = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var possibleNames = require_possible_typed_array_names();
	var g = typeof globalThis === "undefined" ? global : globalThis;
	/** @type {import('.')} */
	module.exports = function availableTypedArrays() {
		var out = [];
		for (var i = 0; i < possibleNames.length; i++) if (typeof g[possibleNames[i]] === "function") out[out.length] = possibleNames[i];
		return out;
	};
}));
//#endregion
//#region node_modules/define-data-property/index.js
var require_define_data_property = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $defineProperty = require_es_define_property();
	var $SyntaxError = require_syntax();
	var $TypeError = require_type();
	var gopd = require_gopd();
	/** @type {import('.')} */
	module.exports = function defineDataProperty(obj, property, value) {
		if (!obj || typeof obj !== "object" && typeof obj !== "function") throw new $TypeError("`obj` must be an object or a function`");
		if (typeof property !== "string" && typeof property !== "symbol") throw new $TypeError("`property` must be a string or a symbol`");
		if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) throw new $TypeError("`nonEnumerable`, if provided, must be a boolean or null");
		if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) throw new $TypeError("`nonWritable`, if provided, must be a boolean or null");
		if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) throw new $TypeError("`nonConfigurable`, if provided, must be a boolean or null");
		if (arguments.length > 6 && typeof arguments[6] !== "boolean") throw new $TypeError("`loose`, if provided, must be a boolean");
		var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
		var nonWritable = arguments.length > 4 ? arguments[4] : null;
		var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
		var loose = arguments.length > 6 ? arguments[6] : false;
		var desc = !!gopd && gopd(obj, property);
		if ($defineProperty) $defineProperty(obj, property, {
			configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
			enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
			value,
			writable: nonWritable === null && desc ? desc.writable : !nonWritable
		});
		else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) obj[property] = value;
		else throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
	};
}));
//#endregion
//#region node_modules/has-property-descriptors/index.js
var require_has_property_descriptors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $defineProperty = require_es_define_property();
	var hasPropertyDescriptors = function hasPropertyDescriptors() {
		return !!$defineProperty;
	};
	hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
		if (!$defineProperty) return null;
		try {
			return $defineProperty([], "length", { value: 1 }).length !== 1;
		} catch (e) {
			return true;
		}
	};
	module.exports = hasPropertyDescriptors;
}));
//#endregion
//#region node_modules/set-function-length/index.js
var require_set_function_length = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var GetIntrinsic = require_get_intrinsic();
	var define = require_define_data_property();
	var hasDescriptors = require_has_property_descriptors()();
	var gOPD = require_gopd();
	var $TypeError = require_type();
	var $floor = GetIntrinsic("%Math.floor%");
	/** @type {import('.')} */
	module.exports = function setFunctionLength(fn, length) {
		if (typeof fn !== "function") throw new $TypeError("`fn` is not a function");
		if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) throw new $TypeError("`length` must be a positive 32-bit integer");
		var loose = arguments.length > 2 && !!arguments[2];
		var functionLengthIsConfigurable = true;
		var functionLengthIsWritable = true;
		if ("length" in fn && gOPD) {
			var desc = gOPD(fn, "length");
			if (desc && !desc.configurable) functionLengthIsConfigurable = false;
			if (desc && !desc.writable) functionLengthIsWritable = false;
		}
		if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) {
			if (hasDescriptors) define(fn, "length", length, true, true);
			else define(fn, "length", length);
		}
		return fn;
	};
}));
//#endregion
//#region node_modules/call-bind-apply-helpers/applyBind.js
var require_applyBind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $apply = require_functionApply();
	var actualApply = require_actualApply();
	/** @type {import('./applyBind')} */
	module.exports = function applyBind() {
		return actualApply(bind, $apply, arguments);
	};
}));
//#endregion
//#region node_modules/call-bind/index.js
var require_call_bind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var setFunctionLength = require_set_function_length();
	var $defineProperty = require_es_define_property();
	var callBindBasic = require_call_bind_apply_helpers();
	var applyBind = require_applyBind();
	module.exports = function callBind(originalFunction) {
		var func = callBindBasic(arguments);
		var adjustedLength = 1 + originalFunction.length - (arguments.length - 1);
		return setFunctionLength(func, adjustedLength > 0 ? adjustedLength : 0, true);
	};
	if ($defineProperty) $defineProperty(module.exports, "apply", { value: applyBind });
	else module.exports.apply = applyBind;
}));
//#endregion
//#region node_modules/which-typed-array/index.js
var require_which_typed_array = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var forEach = require_for_each();
	var availableTypedArrays = require_available_typed_arrays();
	var callBind = require_call_bind();
	var callBound = require_call_bound();
	var gOPD = require_gopd();
	var getProto = require_get_proto();
	var $toString = callBound("Object.prototype.toString");
	var hasToStringTag = require_shams()();
	var g = typeof globalThis === "undefined" ? global : globalThis;
	var typedArrays = availableTypedArrays();
	var $slice = callBound("String.prototype.slice");
	/** @import { BoundSet, BoundSlice, Cache, Getter } from './types' */
	/** @import { TypedArrayName } from '.' */
	/** @type {<T = unknown>(array: readonly T[], value: unknown) => number} */
	var $indexOf = callBound("Array.prototype.indexOf", true) || function indexOf(array, value) {
		for (var i = 0; i < array.length; i += 1) if (array[i] === value) return i;
		return -1;
	};
	/** @type {Cache} */
	var cache = { __proto__: null };
	if (hasToStringTag && gOPD && getProto) forEach(typedArrays, function(typedArray) {
		var arr = new g[typedArray]();
		if (Symbol.toStringTag in arr && getProto) {
			var proto = getProto(arr);
			var descriptor = gOPD(proto, Symbol.toStringTag);
			if (!descriptor && proto) descriptor = gOPD(getProto(proto), Symbol.toStringTag);
			if (descriptor && descriptor.get) {
				var bound = callBind(descriptor.get);
				cache["$" + typedArray] = bound;
			}
		}
	});
	else forEach(typedArrays, function(typedArray) {
		var arr = new g[typedArray]();
		var fn = arr.slice || arr.set;
		if (fn) {
			var bound = callBind(fn);
			cache["$" + typedArray] = bound;
		}
	});
	/** @type {(value: object) => false | TypedArrayName} */
	function tryTypedArrays(value) {
		/** @type {ReturnType<typeof tryTypedArrays>} */ var found = false;
		forEach(
			cache,
			/** @param {Getter} getter @param {`$${TypedArrayName}`} typedArray */
			function(getter, typedArray) {
				if (!found) try {
					if ("$" + getter(value) === typedArray) found = $slice(typedArray, 1);
				} catch (e) {}
			}
		);
		return found;
	}
	/** @type {(value: object) => false | TypedArrayName} */
	function trySlices(value) {
		/** @type {ReturnType<typeof trySlices>} */ var found = false;
		forEach(
			cache,
			/** @param {Getter} getter @param {`$${TypedArrayName}`} name */
			function(getter, name) {
				if (!found) try {
					getter(value);
					found = $slice(name, 1);
				} catch (e) {}
			}
		);
		return found;
	}
	/** @type {(tag: unknown) => tag is typeof typedArrays[number]} */
	function isTATag(tag) {
		return $indexOf(typedArrays, tag) > -1;
	}
	/** @type {(value: unknown) => ReturnType<typeof import('.')>} */
	function whichTypedArray(value) {
		if (!value || typeof value !== "object") return false;
		if (!hasToStringTag) {
			var tag = $slice($toString(value), 8, -1);
			if (isTATag(tag)) return tag;
			if (tag !== "Object") return false;
			return trySlices(value);
		}
		if (!gOPD) return null;
		return tryTypedArrays(value);
	}
	module.exports = whichTypedArray;
}));
//#endregion
//#region node_modules/is-typed-array/index.js
var require_is_typed_array = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var whichTypedArray = require_which_typed_array();
	/** @type {import('.')} */
	module.exports = function isTypedArray(value) {
		return !!whichTypedArray(value);
	};
}));
//#endregion
//#region node_modules/util/support/types.js
var require_types = /* @__PURE__ */ __commonJSMin(((exports) => {
	var isArgumentsObject = require_is_arguments();
	var isGeneratorFunction = require_is_generator_function();
	var whichTypedArray = require_which_typed_array();
	var isTypedArray = require_is_typed_array();
	function uncurryThis(f) {
		return f.call.bind(f);
	}
	var BigIntSupported = typeof BigInt !== "undefined";
	var SymbolSupported = typeof Symbol !== "undefined";
	var ObjectToString = uncurryThis(Object.prototype.toString);
	var numberValue = uncurryThis(Number.prototype.valueOf);
	var stringValue = uncurryThis(String.prototype.valueOf);
	var booleanValue = uncurryThis(Boolean.prototype.valueOf);
	if (BigIntSupported) var bigIntValue = uncurryThis(BigInt.prototype.valueOf);
	if (SymbolSupported) var symbolValue = uncurryThis(Symbol.prototype.valueOf);
	function checkBoxedPrimitive(value, prototypeValueOf) {
		if (typeof value !== "object") return false;
		try {
			prototypeValueOf(value);
			return true;
		} catch (e) {
			return false;
		}
	}
	exports.isArgumentsObject = isArgumentsObject;
	exports.isGeneratorFunction = isGeneratorFunction;
	exports.isTypedArray = isTypedArray;
	function isPromise(input) {
		return typeof Promise !== "undefined" && input instanceof Promise || input !== null && typeof input === "object" && typeof input.then === "function" && typeof input.catch === "function";
	}
	exports.isPromise = isPromise;
	function isArrayBufferView(value) {
		if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) return ArrayBuffer.isView(value);
		return isTypedArray(value) || isDataView(value);
	}
	exports.isArrayBufferView = isArrayBufferView;
	function isUint8Array(value) {
		return whichTypedArray(value) === "Uint8Array";
	}
	exports.isUint8Array = isUint8Array;
	function isUint8ClampedArray(value) {
		return whichTypedArray(value) === "Uint8ClampedArray";
	}
	exports.isUint8ClampedArray = isUint8ClampedArray;
	function isUint16Array(value) {
		return whichTypedArray(value) === "Uint16Array";
	}
	exports.isUint16Array = isUint16Array;
	function isUint32Array(value) {
		return whichTypedArray(value) === "Uint32Array";
	}
	exports.isUint32Array = isUint32Array;
	function isInt8Array(value) {
		return whichTypedArray(value) === "Int8Array";
	}
	exports.isInt8Array = isInt8Array;
	function isInt16Array(value) {
		return whichTypedArray(value) === "Int16Array";
	}
	exports.isInt16Array = isInt16Array;
	function isInt32Array(value) {
		return whichTypedArray(value) === "Int32Array";
	}
	exports.isInt32Array = isInt32Array;
	function isFloat32Array(value) {
		return whichTypedArray(value) === "Float32Array";
	}
	exports.isFloat32Array = isFloat32Array;
	function isFloat64Array(value) {
		return whichTypedArray(value) === "Float64Array";
	}
	exports.isFloat64Array = isFloat64Array;
	function isBigInt64Array(value) {
		return whichTypedArray(value) === "BigInt64Array";
	}
	exports.isBigInt64Array = isBigInt64Array;
	function isBigUint64Array(value) {
		return whichTypedArray(value) === "BigUint64Array";
	}
	exports.isBigUint64Array = isBigUint64Array;
	function isMapToString(value) {
		return ObjectToString(value) === "[object Map]";
	}
	isMapToString.working = typeof Map !== "undefined" && isMapToString(/* @__PURE__ */ new Map());
	function isMap(value) {
		if (typeof Map === "undefined") return false;
		return isMapToString.working ? isMapToString(value) : value instanceof Map;
	}
	exports.isMap = isMap;
	function isSetToString(value) {
		return ObjectToString(value) === "[object Set]";
	}
	isSetToString.working = typeof Set !== "undefined" && isSetToString(/* @__PURE__ */ new Set());
	function isSet(value) {
		if (typeof Set === "undefined") return false;
		return isSetToString.working ? isSetToString(value) : value instanceof Set;
	}
	exports.isSet = isSet;
	function isWeakMapToString(value) {
		return ObjectToString(value) === "[object WeakMap]";
	}
	isWeakMapToString.working = typeof WeakMap !== "undefined" && isWeakMapToString(/* @__PURE__ */ new WeakMap());
	function isWeakMap(value) {
		if (typeof WeakMap === "undefined") return false;
		return isWeakMapToString.working ? isWeakMapToString(value) : value instanceof WeakMap;
	}
	exports.isWeakMap = isWeakMap;
	function isWeakSetToString(value) {
		return ObjectToString(value) === "[object WeakSet]";
	}
	isWeakSetToString.working = typeof WeakSet !== "undefined" && isWeakSetToString(/* @__PURE__ */ new WeakSet());
	function isWeakSet(value) {
		return isWeakSetToString(value);
	}
	exports.isWeakSet = isWeakSet;
	function isArrayBufferToString(value) {
		return ObjectToString(value) === "[object ArrayBuffer]";
	}
	isArrayBufferToString.working = typeof ArrayBuffer !== "undefined" && isArrayBufferToString(/* @__PURE__ */ new ArrayBuffer());
	function isArrayBuffer(value) {
		if (typeof ArrayBuffer === "undefined") return false;
		return isArrayBufferToString.working ? isArrayBufferToString(value) : value instanceof ArrayBuffer;
	}
	exports.isArrayBuffer = isArrayBuffer;
	function isDataViewToString(value) {
		return ObjectToString(value) === "[object DataView]";
	}
	isDataViewToString.working = typeof ArrayBuffer !== "undefined" && typeof DataView !== "undefined" && isDataViewToString(new DataView(/* @__PURE__ */ new ArrayBuffer(1), 0, 1));
	function isDataView(value) {
		if (typeof DataView === "undefined") return false;
		return isDataViewToString.working ? isDataViewToString(value) : value instanceof DataView;
	}
	exports.isDataView = isDataView;
	var SharedArrayBufferCopy = typeof SharedArrayBuffer !== "undefined" ? SharedArrayBuffer : void 0;
	function isSharedArrayBufferToString(value) {
		return ObjectToString(value) === "[object SharedArrayBuffer]";
	}
	function isSharedArrayBuffer(value) {
		if (typeof SharedArrayBufferCopy === "undefined") return false;
		if (typeof isSharedArrayBufferToString.working === "undefined") isSharedArrayBufferToString.working = isSharedArrayBufferToString(new SharedArrayBufferCopy());
		return isSharedArrayBufferToString.working ? isSharedArrayBufferToString(value) : value instanceof SharedArrayBufferCopy;
	}
	exports.isSharedArrayBuffer = isSharedArrayBuffer;
	function isAsyncFunction(value) {
		return ObjectToString(value) === "[object AsyncFunction]";
	}
	exports.isAsyncFunction = isAsyncFunction;
	function isMapIterator(value) {
		return ObjectToString(value) === "[object Map Iterator]";
	}
	exports.isMapIterator = isMapIterator;
	function isSetIterator(value) {
		return ObjectToString(value) === "[object Set Iterator]";
	}
	exports.isSetIterator = isSetIterator;
	function isGeneratorObject(value) {
		return ObjectToString(value) === "[object Generator]";
	}
	exports.isGeneratorObject = isGeneratorObject;
	function isWebAssemblyCompiledModule(value) {
		return ObjectToString(value) === "[object WebAssembly.Module]";
	}
	exports.isWebAssemblyCompiledModule = isWebAssemblyCompiledModule;
	function isNumberObject(value) {
		return checkBoxedPrimitive(value, numberValue);
	}
	exports.isNumberObject = isNumberObject;
	function isStringObject(value) {
		return checkBoxedPrimitive(value, stringValue);
	}
	exports.isStringObject = isStringObject;
	function isBooleanObject(value) {
		return checkBoxedPrimitive(value, booleanValue);
	}
	exports.isBooleanObject = isBooleanObject;
	function isBigIntObject(value) {
		return BigIntSupported && checkBoxedPrimitive(value, bigIntValue);
	}
	exports.isBigIntObject = isBigIntObject;
	function isSymbolObject(value) {
		return SymbolSupported && checkBoxedPrimitive(value, symbolValue);
	}
	exports.isSymbolObject = isSymbolObject;
	function isBoxedPrimitive(value) {
		return isNumberObject(value) || isStringObject(value) || isBooleanObject(value) || isBigIntObject(value) || isSymbolObject(value);
	}
	exports.isBoxedPrimitive = isBoxedPrimitive;
	function isAnyArrayBuffer(value) {
		return typeof Uint8Array !== "undefined" && (isArrayBuffer(value) || isSharedArrayBuffer(value));
	}
	exports.isAnyArrayBuffer = isAnyArrayBuffer;
	[
		"isProxy",
		"isExternal",
		"isModuleNamespaceObject"
	].forEach(function(method) {
		Object.defineProperty(exports, method, {
			enumerable: false,
			value: function() {
				throw new Error(method + " is not supported in userland");
			}
		});
	});
}));
//#endregion
//#region node_modules/util/support/isBufferBrowser.js
var require_isBufferBrowser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function isBuffer(arg) {
		return arg && typeof arg === "object" && typeof arg.copy === "function" && typeof arg.fill === "function" && typeof arg.readUInt8 === "function";
	};
}));
//#endregion
//#region node_modules/inherits/inherits_browser.js
var require_inherits_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	if (typeof Object.create === "function") module.exports = function inherits(ctor, superCtor) {
		if (superCtor) {
			ctor.super_ = superCtor;
			ctor.prototype = Object.create(superCtor.prototype, { constructor: {
				value: ctor,
				enumerable: false,
				writable: true,
				configurable: true
			} });
		}
	};
	else module.exports = function inherits(ctor, superCtor) {
		if (superCtor) {
			ctor.super_ = superCtor;
			var TempCtor = function() {};
			TempCtor.prototype = superCtor.prototype;
			ctor.prototype = new TempCtor();
			ctor.prototype.constructor = ctor;
		}
	};
}));
//#endregion
//#region node_modules/inherits/inherits.js
var require_inherits = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	try {
		var util = require_util();
		/* istanbul ignore next */
		if (typeof util.inherits !== "function") throw "";
		module.exports = util.inherits;
	} catch (e) {
		/* istanbul ignore next */
		module.exports = require_inherits_browser();
	}
}));
//#endregion
//#region node_modules/util/util.js
var require_util = /* @__PURE__ */ __commonJSMin(((exports) => {
	var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors(obj) {
		var keys = Object.keys(obj);
		var descriptors = {};
		for (var i = 0; i < keys.length; i++) descriptors[keys[i]] = Object.getOwnPropertyDescriptor(obj, keys[i]);
		return descriptors;
	};
	var formatRegExp = /%[sdj%]/g;
	exports.format = function(f) {
		if (!isString(f)) {
			var objects = [];
			for (var i = 0; i < arguments.length; i++) objects.push(inspect(arguments[i]));
			return objects.join(" ");
		}
		var i = 1;
		var args = arguments;
		var len = args.length;
		var str = String(f).replace(formatRegExp, function(x) {
			if (x === "%%") return "%";
			if (i >= len) return x;
			switch (x) {
				case "%s": return String(args[i++]);
				case "%d": return Number(args[i++]);
				case "%j": try {
					return JSON.stringify(args[i++]);
				} catch (_) {
					return "[Circular]";
				}
				default: return x;
			}
		});
		for (var x = args[i]; i < len; x = args[++i]) if (isNull(x) || !isObject(x)) str += " " + x;
		else str += " " + inspect(x);
		return str;
	};
	exports.deprecate = function(fn, msg) {
		if (typeof process !== "undefined" && process.noDeprecation === true) return fn;
		if (typeof process === "undefined") return function() {
			return exports.deprecate(fn, msg).apply(this, arguments);
		};
		var warned = false;
		function deprecated() {
			if (!warned) {
				if (process.throwDeprecation) throw new Error(msg);
				else if (process.traceDeprecation) console.trace(msg);
				else console.error(msg);
				warned = true;
			}
			return fn.apply(this, arguments);
		}
		return deprecated;
	};
	var debugs = {};
	var debugEnvRegex = /^$/;
	if (process.env.NODE_DEBUG) {
		var debugEnv = process.env.NODE_DEBUG;
		debugEnv = debugEnv.replace(/[|\\{}()[\]^$+?.]/g, "\\$&").replace(/\*/g, ".*").replace(/,/g, "$|^").toUpperCase();
		debugEnvRegex = new RegExp("^" + debugEnv + "$", "i");
	}
	exports.debuglog = function(set) {
		set = set.toUpperCase();
		if (!debugs[set]) {
			if (debugEnvRegex.test(set)) {
				var pid = process.pid;
				debugs[set] = function() {
					var msg = exports.format.apply(exports, arguments);
					console.error("%s %d: %s", set, pid, msg);
				};
			} else debugs[set] = function() {};
		}
		return debugs[set];
	};
	/**
	* Echos the value of a value. Trys to print the value out
	* in the best way possible given the different types.
	*
	* @param {Object} obj The object to print out.
	* @param {Object} opts Optional options object that alters the output.
	*/
	function inspect(obj, opts) {
		var ctx = {
			seen: [],
			stylize: stylizeNoColor
		};
		if (arguments.length >= 3) ctx.depth = arguments[2];
		if (arguments.length >= 4) ctx.colors = arguments[3];
		if (isBoolean(opts)) ctx.showHidden = opts;
		else if (opts) exports._extend(ctx, opts);
		if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
		if (isUndefined(ctx.depth)) ctx.depth = 2;
		if (isUndefined(ctx.colors)) ctx.colors = false;
		if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
		if (ctx.colors) ctx.stylize = stylizeWithColor;
		return formatValue(ctx, obj, ctx.depth);
	}
	exports.inspect = inspect;
	inspect.colors = {
		"bold": [1, 22],
		"italic": [3, 23],
		"underline": [4, 24],
		"inverse": [7, 27],
		"white": [37, 39],
		"grey": [90, 39],
		"black": [30, 39],
		"blue": [34, 39],
		"cyan": [36, 39],
		"green": [32, 39],
		"magenta": [35, 39],
		"red": [31, 39],
		"yellow": [33, 39]
	};
	inspect.styles = {
		"special": "cyan",
		"number": "yellow",
		"boolean": "yellow",
		"undefined": "grey",
		"null": "bold",
		"string": "green",
		"date": "magenta",
		"regexp": "red"
	};
	function stylizeWithColor(str, styleType) {
		var style = inspect.styles[styleType];
		if (style) return "\x1B[" + inspect.colors[style][0] + "m" + str + "\x1B[" + inspect.colors[style][1] + "m";
		else return str;
	}
	function stylizeNoColor(str, styleType) {
		return str;
	}
	function arrayToHash(array) {
		var hash = {};
		array.forEach(function(val, idx) {
			hash[val] = true;
		});
		return hash;
	}
	function formatValue(ctx, value, recurseTimes) {
		if (ctx.customInspect && value && isFunction(value.inspect) && value.inspect !== exports.inspect && !(value.constructor && value.constructor.prototype === value)) {
			var ret = value.inspect(recurseTimes, ctx);
			if (!isString(ret)) ret = formatValue(ctx, ret, recurseTimes);
			return ret;
		}
		var primitive = formatPrimitive(ctx, value);
		if (primitive) return primitive;
		var keys = Object.keys(value);
		var visibleKeys = arrayToHash(keys);
		if (ctx.showHidden) keys = Object.getOwnPropertyNames(value);
		if (isError(value) && (keys.indexOf("message") >= 0 || keys.indexOf("description") >= 0)) return formatError(value);
		if (keys.length === 0) {
			if (isFunction(value)) {
				var name = value.name ? ": " + value.name : "";
				return ctx.stylize("[Function" + name + "]", "special");
			}
			if (isRegExp(value)) return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
			if (isDate(value)) return ctx.stylize(Date.prototype.toString.call(value), "date");
			if (isError(value)) return formatError(value);
		}
		var base = "", array = false, braces = ["{", "}"];
		if (isArray(value)) {
			array = true;
			braces = ["[", "]"];
		}
		if (isFunction(value)) base = " [Function" + (value.name ? ": " + value.name : "") + "]";
		if (isRegExp(value)) base = " " + RegExp.prototype.toString.call(value);
		if (isDate(value)) base = " " + Date.prototype.toUTCString.call(value);
		if (isError(value)) base = " " + formatError(value);
		if (keys.length === 0 && (!array || value.length == 0)) return braces[0] + base + braces[1];
		if (recurseTimes < 0) {
			if (isRegExp(value)) return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
			else return ctx.stylize("[Object]", "special");
		}
		ctx.seen.push(value);
		var output;
		if (array) output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
		else output = keys.map(function(key) {
			return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
		});
		ctx.seen.pop();
		return reduceToSingleString(output, base, braces);
	}
	function formatPrimitive(ctx, value) {
		if (isUndefined(value)) return ctx.stylize("undefined", "undefined");
		if (isString(value)) {
			var simple = "'" + JSON.stringify(value).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, "\"") + "'";
			return ctx.stylize(simple, "string");
		}
		if (isNumber(value)) return ctx.stylize("" + value, "number");
		if (isBoolean(value)) return ctx.stylize("" + value, "boolean");
		if (isNull(value)) return ctx.stylize("null", "null");
	}
	function formatError(value) {
		return "[" + Error.prototype.toString.call(value) + "]";
	}
	function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
		var output = [];
		for (var i = 0, l = value.length; i < l; ++i) if (hasOwnProperty(value, String(i))) output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, String(i), true));
		else output.push("");
		keys.forEach(function(key) {
			if (!key.match(/^\d+$/)) output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, key, true));
		});
		return output;
	}
	function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
		var name, str, desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
		if (desc.get) {
			if (desc.set) str = ctx.stylize("[Getter/Setter]", "special");
			else str = ctx.stylize("[Getter]", "special");
		} else if (desc.set) str = ctx.stylize("[Setter]", "special");
		if (!hasOwnProperty(visibleKeys, key)) name = "[" + key + "]";
		if (!str) {
			if (ctx.seen.indexOf(desc.value) < 0) {
				if (isNull(recurseTimes)) str = formatValue(ctx, desc.value, null);
				else str = formatValue(ctx, desc.value, recurseTimes - 1);
				if (str.indexOf("\n") > -1) {
					if (array) str = str.split("\n").map(function(line) {
						return "  " + line;
					}).join("\n").slice(2);
					else str = "\n" + str.split("\n").map(function(line) {
						return "   " + line;
					}).join("\n");
				}
			} else str = ctx.stylize("[Circular]", "special");
		}
		if (isUndefined(name)) {
			if (array && key.match(/^\d+$/)) return str;
			name = JSON.stringify("" + key);
			if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
				name = name.slice(1, -1);
				name = ctx.stylize(name, "name");
			} else {
				name = name.replace(/'/g, "\\'").replace(/\\"/g, "\"").replace(/(^"|"$)/g, "'");
				name = ctx.stylize(name, "string");
			}
		}
		return name + ": " + str;
	}
	function reduceToSingleString(output, base, braces) {
		var numLinesEst = 0;
		if (output.reduce(function(prev, cur) {
			numLinesEst++;
			if (cur.indexOf("\n") >= 0) numLinesEst++;
			return prev + cur.replace(/\u001b\[\d\d?m/g, "").length + 1;
		}, 0) > 60) return braces[0] + (base === "" ? "" : base + "\n ") + " " + output.join(",\n  ") + " " + braces[1];
		return braces[0] + base + " " + output.join(", ") + " " + braces[1];
	}
	exports.types = require_types();
	function isArray(ar) {
		return Array.isArray(ar);
	}
	exports.isArray = isArray;
	function isBoolean(arg) {
		return typeof arg === "boolean";
	}
	exports.isBoolean = isBoolean;
	function isNull(arg) {
		return arg === null;
	}
	exports.isNull = isNull;
	function isNullOrUndefined(arg) {
		return arg == null;
	}
	exports.isNullOrUndefined = isNullOrUndefined;
	function isNumber(arg) {
		return typeof arg === "number";
	}
	exports.isNumber = isNumber;
	function isString(arg) {
		return typeof arg === "string";
	}
	exports.isString = isString;
	function isSymbol(arg) {
		return typeof arg === "symbol";
	}
	exports.isSymbol = isSymbol;
	function isUndefined(arg) {
		return arg === void 0;
	}
	exports.isUndefined = isUndefined;
	function isRegExp(re) {
		return isObject(re) && objectToString(re) === "[object RegExp]";
	}
	exports.isRegExp = isRegExp;
	exports.types.isRegExp = isRegExp;
	function isObject(arg) {
		return typeof arg === "object" && arg !== null;
	}
	exports.isObject = isObject;
	function isDate(d) {
		return isObject(d) && objectToString(d) === "[object Date]";
	}
	exports.isDate = isDate;
	exports.types.isDate = isDate;
	function isError(e) {
		return isObject(e) && (objectToString(e) === "[object Error]" || e instanceof Error);
	}
	exports.isError = isError;
	exports.types.isNativeError = isError;
	function isFunction(arg) {
		return typeof arg === "function";
	}
	exports.isFunction = isFunction;
	function isPrimitive(arg) {
		return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || typeof arg === "undefined";
	}
	exports.isPrimitive = isPrimitive;
	exports.isBuffer = require_isBufferBrowser();
	function objectToString(o) {
		return Object.prototype.toString.call(o);
	}
	function pad(n) {
		return n < 10 ? "0" + n.toString(10) : n.toString(10);
	}
	var months = [
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	];
	function timestamp() {
		var d = /* @__PURE__ */ new Date();
		var time = [
			pad(d.getHours()),
			pad(d.getMinutes()),
			pad(d.getSeconds())
		].join(":");
		return [
			d.getDate(),
			months[d.getMonth()],
			time
		].join(" ");
	}
	exports.log = function() {
		console.log("%s - %s", timestamp(), exports.format.apply(exports, arguments));
	};
	/**
	* Inherit the prototype methods from one constructor into another.
	*
	* The Function.prototype.inherits from lang.js rewritten as a standalone
	* function (not on Function.prototype). NOTE: If this file is to be loaded
	* during bootstrapping this function needs to be rewritten using some native
	* functions as prototype setup using normal JavaScript does not work as
	* expected during bootstrapping (see mirror.js in r114903).
	*
	* @param {function} ctor Constructor function which needs to inherit the
	*     prototype.
	* @param {function} superCtor Constructor function to inherit prototype from.
	*/
	exports.inherits = require_inherits();
	exports._extend = function(origin, add) {
		if (!add || !isObject(add)) return origin;
		var keys = Object.keys(add);
		var i = keys.length;
		while (i--) origin[keys[i]] = add[keys[i]];
		return origin;
	};
	function hasOwnProperty(obj, prop) {
		return Object.prototype.hasOwnProperty.call(obj, prop);
	}
	var kCustomPromisifiedSymbol = typeof Symbol !== "undefined" ? Symbol("util.promisify.custom") : void 0;
	exports.promisify = function promisify(original) {
		if (typeof original !== "function") throw new TypeError("The \"original\" argument must be of type Function");
		if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
			var fn = original[kCustomPromisifiedSymbol];
			if (typeof fn !== "function") throw new TypeError("The \"util.promisify.custom\" argument must be of type Function");
			Object.defineProperty(fn, kCustomPromisifiedSymbol, {
				value: fn,
				enumerable: false,
				writable: false,
				configurable: true
			});
			return fn;
		}
		function fn() {
			var promiseResolve, promiseReject;
			var promise = new Promise(function(resolve, reject) {
				promiseResolve = resolve;
				promiseReject = reject;
			});
			var args = [];
			for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
			args.push(function(err, value) {
				if (err) promiseReject(err);
				else promiseResolve(value);
			});
			try {
				original.apply(this, args);
			} catch (err) {
				promiseReject(err);
			}
			return promise;
		}
		Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
		if (kCustomPromisifiedSymbol) Object.defineProperty(fn, kCustomPromisifiedSymbol, {
			value: fn,
			enumerable: false,
			writable: false,
			configurable: true
		});
		return Object.defineProperties(fn, getOwnPropertyDescriptors(original));
	};
	exports.promisify.custom = kCustomPromisifiedSymbol;
	function callbackifyOnRejected(reason, cb) {
		if (!reason) {
			var newReason = /* @__PURE__ */ new Error("Promise was rejected with a falsy value");
			newReason.reason = reason;
			reason = newReason;
		}
		return cb(reason);
	}
	function callbackify(original) {
		if (typeof original !== "function") throw new TypeError("The \"original\" argument must be of type Function");
		function callbackified() {
			var args = [];
			for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
			var maybeCb = args.pop();
			if (typeof maybeCb !== "function") throw new TypeError("The last argument must be of type Function");
			var self = this;
			var cb = function() {
				return maybeCb.apply(self, arguments);
			};
			original.apply(this, args).then(function(ret) {
				process.nextTick(cb.bind(null, null, ret));
			}, function(rej) {
				process.nextTick(callbackifyOnRejected.bind(null, rej, cb));
			});
		}
		Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
		Object.defineProperties(callbackified, getOwnPropertyDescriptors(original));
		return callbackified;
	}
	exports.callbackify = callbackify;
}));
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/mime.js
var import_util = /* @__PURE__ */ __toESM(require_util(), 1);
function mimeError(production, str, invalidIndex) {
	return codedError(/* @__PURE__ */ new TypeError(`The MIME syntax for a ${production} in "${str}" is invalid${invalidIndex !== -1 ? ` at ${invalidIndex}` : ""}`), "ERR_INVALID_MIME_SYNTAX");
}
const NOT_HTTP_TOKEN_CODE_POINT = /[^!#$%&'*+\-.^_`|~A-Za-z0-9]/g;
const NOT_HTTP_QUOTED_STRING_CODE_POINT = /[^\t\u0020-~\u0080-\u00FF]/g;
const END_BEGINNING_WHITESPACE = /[^\r\n\t ]|$/;
const START_ENDING_WHITESPACE = /[\r\n\t ]*$/;
function toASCIILower(str) {
	if (!/[^\x00-\x7f]/.test(str)) return str.toLowerCase();
	let result = "";
	for (let i = 0; i < str.length; i++) {
		const char = str[i];
		result += char >= "A" && char <= "Z" ? char.toLowerCase() : char;
	}
	return result;
}
const SOLIDUS = "/";
const SEMICOLON = ";";
function parseTypeAndSubtype(str) {
	let position = str.search(END_BEGINNING_WHITESPACE);
	const typeEnd = str.indexOf(SOLIDUS, position);
	const trimmedType = typeEnd === -1 ? str.slice(position) : str.slice(position, typeEnd);
	const invalidTypeIndex = trimmedType.search(NOT_HTTP_TOKEN_CODE_POINT);
	if (trimmedType === "" || invalidTypeIndex !== -1 || typeEnd === -1) throw mimeError("type", str, invalidTypeIndex);
	position = typeEnd + 1;
	const type = toASCIILower(trimmedType);
	const subtypeEnd = str.indexOf(SEMICOLON, position);
	const rawSubtype = subtypeEnd === -1 ? str.slice(position) : str.slice(position, subtypeEnd);
	position += rawSubtype.length;
	if (subtypeEnd !== -1) position += 1;
	const trimmedSubtype = rawSubtype.slice(0, rawSubtype.search(START_ENDING_WHITESPACE));
	const invalidSubtypeIndex = trimmedSubtype.search(NOT_HTTP_TOKEN_CODE_POINT);
	if (trimmedSubtype === "" || invalidSubtypeIndex !== -1) throw mimeError("subtype", str, invalidSubtypeIndex);
	return [
		type,
		toASCIILower(trimmedSubtype),
		position
	];
}
const EQUALS_SEMICOLON_OR_END = /[;=]|$/;
const QUOTED_VALUE_PATTERN = /^(?:([\\]$)|[\\][\s\S]|[^"])*(?:(")|$)/u;
function removeBackslashes(str) {
	let ret = "";
	let i = 0;
	for (; i < str.length - 1; i++) {
		const c = str[i];
		if (c === "\\") {
			i++;
			ret += str[i];
		} else ret += c;
	}
	if (i === str.length - 1) ret += str[i];
	return ret;
}
function escapeQuoteOrSolidus(str) {
	let result = "";
	for (let i = 0; i < str.length; i++) {
		const char = str[i];
		result += char === "\"" || char === "\\" ? `\\${char}` : char;
	}
	return result;
}
const encode = (value) => {
	if (value.length === 0) return "\"\"";
	if (!(value.search(NOT_HTTP_TOKEN_CODE_POINT) !== -1)) return value;
	return `"${escapeQuoteOrSolidus(value)}"`;
};
let instantiateMimeParams;
var MIMEParams$1 = class MIMEParams$1 {
	#data = /* @__PURE__ */ new Map();
	#processed = true;
	#string = "";
	/**
	* Used to instantiate a MIMEParams object within the MIMEType class and
	* to allow it to be parsed lazily.
	* @returns {MIMEParams}
	*/
	static {
		instantiateMimeParams = (str) => {
			const instance = new MIMEParams$1();
			instance.#string = str;
			instance.#processed = false;
			return instance;
		};
	}
	/**
	* @param {string} name
	* @returns {void}
	*/
	delete(name) {
		this.#parse();
		this.#data.delete(toASCIILower(`${name}`));
	}
	get(name) {
		this.#parse();
		const data = this.#data;
		name = toASCIILower(`${name}`);
		if (data.has(name)) return data.get(name);
		return null;
	}
	has(name) {
		this.#parse();
		return this.#data.has(toASCIILower(`${name}`));
	}
	set(name, value) {
		this.#parse();
		const data = this.#data;
		name = toASCIILower(`${name}`);
		value = `${value}`;
		const invalidNameIndex = name.search(NOT_HTTP_TOKEN_CODE_POINT);
		if (name.length === 0 || invalidNameIndex !== -1) throw mimeError("parameter name", name, invalidNameIndex);
		const invalidValueIndex = value.search(NOT_HTTP_QUOTED_STRING_CODE_POINT);
		if (invalidValueIndex !== -1) throw mimeError("parameter value", value, invalidValueIndex);
		data.set(name, value);
	}
	*entries() {
		this.#parse();
		yield* this.#data.entries();
	}
	*keys() {
		this.#parse();
		yield* this.#data.keys();
	}
	*values() {
		this.#parse();
		yield* this.#data.values();
	}
	toString() {
		this.#parse();
		let ret = "";
		for (const { 0: key, 1: value } of this.#data) {
			const encoded = encode(value);
			if (ret.length) ret += ";";
			ret += `${key}=${encoded}`;
		}
		return ret;
	}
	#parse() {
		if (this.#processed) return;
		const paramsMap = this.#data;
		let position = 0;
		const str = this.#string;
		const endOfSource = str.slice(position).search(START_ENDING_WHITESPACE) + position;
		while (position < endOfSource) {
			position += str.slice(position).search(END_BEGINNING_WHITESPACE);
			const afterParameterName = str.slice(position).search(EQUALS_SEMICOLON_OR_END) + position;
			const parameterString = toASCIILower(str.slice(position, afterParameterName));
			position = afterParameterName;
			if (position < endOfSource) {
				const char = str.charAt(position);
				position += 1;
				if (char === ";") continue;
			}
			if (position >= endOfSource) break;
			const char = str.charAt(position);
			let parameterValue = null;
			if (char === "\"") {
				position += 1;
				const insideMatch = QUOTED_VALUE_PATTERN.exec(str.slice(position));
				position += insideMatch[0].length;
				parameterValue = removeBackslashes(insideMatch[1] || insideMatch[2] ? insideMatch[0].slice(0, -1) : insideMatch[0]);
				if (insideMatch[1]) parameterValue += "\\";
			} else {
				const valueEnd = str.indexOf(SEMICOLON, position);
				const rawValue = valueEnd === -1 ? str.slice(position) : str.slice(position, valueEnd);
				position += rawValue.length;
				const trimmedValue = rawValue.slice(0, rawValue.search(START_ENDING_WHITESPACE));
				if (trimmedValue === "") continue;
				parameterValue = trimmedValue;
			}
			if (parameterString !== "" && parameterString.search(NOT_HTTP_TOKEN_CODE_POINT) === -1 && parameterValue.search(NOT_HTTP_QUOTED_STRING_CODE_POINT) === -1 && paramsMap.has(parameterString) === false) paramsMap.set(parameterString, parameterValue);
			position++;
		}
		this.#data = paramsMap;
		this.#processed = true;
	}
};
const MIMEParamsStringify = MIMEParams$1.prototype.toString;
Object.defineProperty(MIMEParams$1.prototype, Symbol.iterator, {
	configurable: true,
	value: MIMEParams$1.prototype.entries,
	writable: true
});
Object.defineProperty(MIMEParams$1.prototype, "toJSON", {
	configurable: true,
	value: MIMEParamsStringify,
	writable: true
});
var MIMEType$1 = class {
	#type;
	#subtype;
	#parameters;
	constructor(string) {
		string = `${string}`;
		const data = parseTypeAndSubtype(string);
		this.#type = data[0];
		this.#subtype = data[1];
		this.#parameters = instantiateMimeParams(string.slice(data[2]));
	}
	get type() {
		return this.#type;
	}
	set type(v) {
		v = `${v}`;
		const invalidTypeIndex = v.search(NOT_HTTP_TOKEN_CODE_POINT);
		if (v.length === 0 || invalidTypeIndex !== -1) throw mimeError("type", v, invalidTypeIndex);
		this.#type = toASCIILower(v);
	}
	get subtype() {
		return this.#subtype;
	}
	set subtype(v) {
		v = `${v}`;
		const invalidSubtypeIndex = v.search(NOT_HTTP_TOKEN_CODE_POINT);
		if (v.length === 0 || invalidSubtypeIndex !== -1) throw mimeError("subtype", v, invalidSubtypeIndex);
		this.#subtype = toASCIILower(v);
	}
	get essence() {
		return `${this.#type}/${this.#subtype}`;
	}
	get params() {
		return this.#parameters;
	}
	toString() {
		let ret = `${this.#type}/${this.#subtype}`;
		const paramStr = MIMEParamsStringify.call(this.#parameters);
		if (paramStr.length) ret += `;${paramStr}`;
		return ret;
	}
};
Object.defineProperty(MIMEType$1.prototype, "toJSON", {
	configurable: true,
	value: MIMEType$1.prototype.toString,
	writable: true
});
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/callbacks.js
const promisifyCustom = Symbol.for("nodejs.util.promisify.custom");
function promisifyImpl(original) {
	validateFunction(original, "original");
	const custom = Reflect.get(original, promisify$1.custom);
	if (custom) {
		validateFunction(custom, "util.promisify.custom");
		return Object.defineProperty(custom, promisify$1.custom, {
			value: custom,
			configurable: true
		});
	}
	if (Object.prototype.toString.call(original) === "[object AsyncFunction]") throw deprecatedNodeApi("util.promisify(async function)", "call the promise-returning function directly");
	const invoke = original;
	function fn(...args) {
		return new Promise((resolve, reject) => {
			args.push((error, value) => {
				if (error) reject(error);
				else resolve(value);
			});
			Reflect.apply(invoke, this, args);
		});
	}
	Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
	Object.defineProperty(fn, promisify$1.custom, {
		value: fn,
		configurable: true
	});
	return Object.defineProperties(fn, Object.getOwnPropertyDescriptors(original));
}
const promisify$1 = Object.assign(promisifyImpl, { custom: promisifyCustom });
Object.defineProperty(promisify$1, "name", { value: "promisify" });
function callbackify$1(original) {
	validateFunction(original, "original");
	function callbackified(...args) {
		const callback = args.pop();
		validateFunction(callback, "last argument");
		const cb = callback.bind(this);
		Reflect.apply(original, this, args).then((value) => nextTick(cb, null, value), (reason) => nextTick(() => {
			if (!reason) {
				const error = codedError(/* @__PURE__ */ new Error("Promise was rejected with falsy value"), "ERR_FALSY_VALUE_REJECTION");
				Object.assign(error, { reason });
				reason = error;
			}
			cb(reason);
		}));
	}
	const descriptors = Object.getOwnPropertyDescriptors(original);
	if (typeof descriptors.length?.value === "number") descriptors.length.value++;
	if (typeof descriptors.name?.value === "string") descriptors.name.value += "Callbackified";
	Object.defineProperties(callbackified, descriptors);
	return callbackified;
}
function inherits$1(ctor, superCtor) {
	if (ctor === void 0 || ctor === null) throw invalidArgType("ctor", "Function", ctor);
	if (superCtor === void 0 || superCtor === null) throw invalidArgType("superCtor", "Function", superCtor);
	if (superCtor.prototype === void 0) throw invalidArgType("superCtor.prototype", "Object", void 0);
	Object.defineProperty(ctor, "super_", {
		value: superCtor,
		writable: true,
		configurable: true
	});
	Object.setPrototypeOf(ctor.prototype, superCtor.prototype);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/diff.js
const kOperations = {
	DELETE: -1,
	NOP: 0,
	INSERT: 1
};
function areLinesEqual(actual, expected, checkCommaDisparity) {
	if (actual === expected) return true;
	if (checkCommaDisparity) return actual + "," === expected || actual === expected + ",";
	return false;
}
function myersDiff(actual, expected, checkCommaDisparity = false) {
	const actualLength = actual.length;
	const expectedLength = expected.length;
	const max = actualLength + expectedLength;
	if (max > 2 ** 31 - 1) throw outOfRange("myersDiff input size", "< 2^31", max);
	const v = new Int32Array(2 * max + 1);
	const trace = [];
	for (let diffLevel = 0; diffLevel <= max; diffLevel++) {
		trace.push(new Int32Array(v));
		for (let diagonalIndex = -diffLevel; diagonalIndex <= diffLevel; diagonalIndex += 2) {
			const offset = diagonalIndex + max;
			const previousOffset = v[offset - 1];
			const nextOffset = v[offset + 1];
			let x = diagonalIndex === -diffLevel || diagonalIndex !== diffLevel && previousOffset < nextOffset ? nextOffset : previousOffset + 1;
			let y = x - diagonalIndex;
			while (x < actualLength && y < expectedLength && areLinesEqual(actual[x], expected[y], checkCommaDisparity)) {
				x++;
				y++;
			}
			v[offset] = x;
			if (x >= actualLength && y >= expectedLength) return backtrack(trace, actual, expected, checkCommaDisparity);
		}
	}
	throw new Error("Unreachable Myers diff state");
}
function backtrack(trace, actual, expected, checkCommaDisparity) {
	const actualLength = actual.length;
	const expectedLength = expected.length;
	const max = actualLength + expectedLength;
	let x = actualLength;
	let y = expectedLength;
	const result = [];
	for (let diffLevel = trace.length - 1; diffLevel >= 0; diffLevel--) {
		const v = trace[diffLevel];
		const diagonalIndex = x - y;
		const offset = diagonalIndex + max;
		let prevDiagonalIndex;
		if (diagonalIndex === -diffLevel || diagonalIndex !== diffLevel && v[offset - 1] < v[offset + 1]) prevDiagonalIndex = diagonalIndex + 1;
		else prevDiagonalIndex = diagonalIndex - 1;
		const prevX = v[prevDiagonalIndex + max];
		const prevY = prevX - prevDiagonalIndex;
		while (x > prevX && y > prevY) {
			const actualItem = actual[x - 1];
			const value = checkCommaDisparity && !actualItem.endsWith(",") ? expected[y - 1] : actualItem;
			result.push([kOperations.NOP, value]);
			x--;
			y--;
		}
		if (diffLevel > 0) {
			if (x > prevX) result.push([kOperations.INSERT, actual[--x]]);
			else result.push([kOperations.DELETE, expected[--y]]);
		}
	}
	return result;
}
function validateInput(value, name) {
	if (typeof value === "string") return;
	if (!Array.isArray(value)) throw invalidArgType(name, "string", value);
	for (let i = 0; i < value.length; i++) if (typeof value[i] !== "string") throw invalidArgType(`${name}[${i}]`, "string", value[i]);
}
function diff$1(actual, expected) {
	if (actual === expected) return [];
	validateInput(actual, "actual");
	validateInput(expected, "expected");
	if (actual.length + expected.length === 0) return [];
	return myersDiff(actual, expected).reverse();
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/parse-args-utils.js
/**
* Return the named property, but only if it is an own property.
* @returns The own property value, or undefined.
*/
function objectGetOwn(obj, prop) {
	if (Object.hasOwn(obj, prop)) return obj[prop];
}
/**
* Return the named options property, but only if it is an own property.
* @returns The own property value, or undefined.
*/
function optionsGetOwn(options, longOption, prop) {
	if (Object.hasOwn(options, longOption)) return objectGetOwn(options[longOption], prop);
}
/**
* Determines if the argument may be used as an option value.
* @example
* ```
* isOptionValue('V') // returns true
* isOptionValue('-v') // returns true (greedy)
* isOptionValue('--foo') // returns true (greedy)
* isOptionValue(undefined) // returns false
* ```
* @returns {boolean}
*/
function isOptionValue(value) {
	if (value == null) return false;
	return true;
}
/**
* Detect whether there is possible confusion and user may have omitted
* the option argument, like `--port --verbose` when `port` of type:string.
* In strict mode we throw errors if value is option-like.
* @returns {boolean}
*/
function isOptionLikeValue(value) {
	if (value == null) return false;
	return value.length > 1 && value.charAt(0) === "-";
}
/**
* Determines if `arg` is just a short option.
* @example '-f'
* @returns {boolean}
*/
function isLoneShortOption(arg) {
	return arg.length === 2 && arg.charAt(0) === "-" && arg.charAt(1) !== "-";
}
/**
* Determines if `arg` is a lone long option.
* @example
* ```
* isLoneLongOption('a') // returns false
* isLoneLongOption('-a') // returns false
* isLoneLongOption('--foo') // returns true
* isLoneLongOption('--foo=bar') // returns false
* ```
* @returns {boolean}
*/
function isLoneLongOption(arg) {
	return arg.length > 2 && arg.startsWith("--") && !arg.includes("=", 3);
}
/**
* Determines if `arg` is a long option and value in the same argument.
* @example
* ```
* isLongOptionAndValue('--foo') // returns false
* isLongOptionAndValue('--foo=bar') // returns true
* ```
* @returns {boolean}
*/
function isLongOptionAndValue(arg) {
	return arg.length > 2 && arg.startsWith("--") && arg.includes("=", 3);
}
/**
* Determines if `arg` is a short option group.
*
* See Guideline 5 of the [Open Group Utility Conventions](https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap12.html).
*   One or more options without option-arguments, followed by at most one
*   option that takes an option-argument, should be accepted when grouped
*   behind one '-' delimiter.
* @example
* ```
* isShortOptionGroup('-a', {}) // returns false
* isShortOptionGroup('-ab', {}) // returns true
* // -fb is an option and a value, not a short option group
* isShortOptionGroup('-fb', {
*   options: { f: { type: 'string' } }
* }) // returns false
* isShortOptionGroup('-bf', {
*   options: { f: { type: 'string' } }
* }) // returns true
* // -bfb is an edge case, return true and caller sorts it out
* isShortOptionGroup('-bfb', {
*   options: { f: { type: 'string' } }
* }) // returns true
* ```
* @returns {boolean}
*/
function isShortOptionGroup(arg, options) {
	if (arg.length <= 2) return false;
	if (arg.charAt(0) !== "-") return false;
	if (arg.charAt(1) === "-") return false;
	return optionsGetOwn(options, findLongOptionForShort(arg.charAt(1), options), "type") !== "string";
}
/**
* Determine if arg is a short string option followed by its value.
* @example
* ```
* isShortOptionAndValue('-a', {}); // returns false
* isShortOptionAndValue('-ab', {}); // returns false
* isShortOptionAndValue('-fFILE', {
*   options: { foo: { short: 'f', type: 'string' }}
* }) // returns true
* ```
* @returns {boolean}
*/
function isShortOptionAndValue(arg, options) {
	validateObject(options, "options");
	if (arg.length <= 2) return false;
	if (arg.charAt(0) !== "-") return false;
	if (arg.charAt(1) === "-") return false;
	return optionsGetOwn(options, findLongOptionForShort(arg.charAt(1), options), "type") === "string";
}
/**
* Find the long option associated with a short option. Looks for a configured
* `short` and returns the short option itself if a long option is not found.
* @example
* ```
* findLongOptionForShort('a', {}) // returns 'a'
* findLongOptionForShort('b', {
*   options: { bar: { short: 'b' } }
* }) // returns 'bar'
* ```
* @returns {boolean}
*/
function findLongOptionForShort(shortOption, options) {
	validateObject(options, "options");
	return Object.entries(options).find(({ 1: optionConfig }) => objectGetOwn(optionConfig, "short") === shortOption)?.[0] ?? shortOption;
}
/**
* Check if the given option includes a default value
* and that option has not been set by the input args.
* @param {string} longOption - long option name e.g. 'foo'
* @param {object} optionConfig - the option configuration properties
* @param {object} values - option values returned in `values` by parseArgs
* @returns {boolean}
*/
function useDefaultValueOption(longOption, optionConfig, values) {
	return objectGetOwn(optionConfig, "default") !== void 0 && values[longOption] === void 0;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/parse-args.js
function validateUnion(value, name, allowed) {
	if (!allowed.includes(value)) throw invalidArgType(name, `('${allowed.join("| ")}')`, value);
}
function invalidOption(message) {
	return codedError(new TypeError(message), "ERR_PARSE_ARGS_INVALID_OPTION_VALUE");
}
function unknownOption(option, allowPositionals) {
	const suffix = allowPositionals ? `. To specify a positional argument starting with a '-', place it at the end of the command after '--', as in '-- ${JSON.stringify(option)}` : "";
	return codedError(/* @__PURE__ */ new TypeError(`Unknown option '${option}'${suffix}`), "ERR_PARSE_ARGS_UNKNOWN_OPTION");
}
/**
* In strict mode, throw for possible usage errors like --foo --bar
* @param {object} token - from tokens as available from parseArgs
*/
function checkOptionLikeValue(token) {
	if (!token.inlineValue && isOptionLikeValue(token.value)) {
		const example = token.rawName.startsWith("--") ? `'${token.rawName}=-XYZ'` : `'--${token.name}=-XYZ' or '${token.rawName}-XYZ'`;
		throw invalidOption(`Option '${token.rawName}' argument is ambiguous.
Did you forget to specify the option argument for '${token.rawName}'?
To specify an option argument starting with a dash use ${example}.`);
	}
}
/**
* In strict mode, throw for usage errors.
* @param {object} config - from config passed to parseArgs
* @param {object} token - from tokens as available from parseArgs
*/
function checkOptionUsage(config, token) {
	let tokenName = token.name;
	if (!Object.hasOwn(config.options, tokenName)) {
		if (config.allowNegative && tokenName.startsWith("no-")) {
			tokenName = tokenName.slice(3);
			if (!Object.hasOwn(config.options, tokenName) || optionsGetOwn(config.options, tokenName, "type") !== "boolean") throw unknownOption(token.rawName, config.allowPositionals);
		} else throw unknownOption(token.rawName, config.allowPositionals);
	}
	const short = optionsGetOwn(config.options, tokenName, "short");
	const shortAndLong = `${short ? `-${short}, ` : ""}--${tokenName}`;
	const type = optionsGetOwn(config.options, tokenName, "type");
	if (type === "string" && typeof token.value !== "string") throw invalidOption(`Option '${shortAndLong} <value>' argument missing`);
	if (type === "boolean" && token.value != null) throw invalidOption(`Option '${shortAndLong}' does not take an argument`);
}
/**
* Store the option value in `values`.
* @param {object} token - from tokens as available from parseArgs
* @param {object} options - option configs, from parseArgs({ options })
* @param {object} values - option values returned in `values` by parseArgs
* @param {boolean} allowNegative - allow negative optinons if true
*/
function storeOption(token, options, values, allowNegative) {
	let longOption = token.name;
	let optionValue = token.value;
	if (longOption === "__proto__") return;
	if (allowNegative && longOption.startsWith("no-") && optionValue === void 0) {
		longOption = longOption.slice(3);
		token.name = longOption;
		optionValue = false;
	}
	const newValue = optionValue ?? true;
	if (optionsGetOwn(options, longOption, "multiple")) {
		if (values[longOption]) values[longOption].push(newValue);
		else values[longOption] = [newValue];
	} else values[longOption] = newValue;
}
/**
* Store the default option value in `values`.
* @param {string} longOption - long option name e.g. 'foo'
* @param {string
*         | boolean
*         | string[]
*         | boolean[]} optionValue - default value from option config
* @param {object} values - option values returned in `values` by parseArgs
*/
function storeDefaultOption(longOption, optionValue, values) {
	if (longOption === "__proto__") return;
	values[longOption] = optionValue;
}
/**
* Process args and turn into identified tokens:
* - option (along with value, if any)
* - positional
* - option-terminator
* @param {string[]} args - from parseArgs({ args }) or mainArgs
* @param {object} options - option configs, from parseArgs({ options })
* @returns Parsed argument tokens.
*/
function argsToTokens(args, options) {
	const tokens = [];
	let index = -1;
	let groupCount = 0;
	const remainingArgs = args.slice();
	while (remainingArgs.length > 0) {
		const arg = remainingArgs.shift();
		const nextArg = remainingArgs[0];
		if (groupCount > 0) groupCount--;
		else index++;
		if (arg === "--") {
			tokens.push({
				kind: "option-terminator",
				index
			});
			tokens.push(...remainingArgs.map((arg) => {
				return {
					kind: "positional",
					index: ++index,
					value: arg
				};
			}));
			break;
		}
		if (isLoneShortOption(arg)) {
			const longOption = findLongOptionForShort(arg.charAt(1), options);
			let value;
			let inlineValue;
			if (optionsGetOwn(options, longOption, "type") === "string" && isOptionValue(nextArg)) {
				value = remainingArgs.shift();
				inlineValue = false;
			}
			tokens.push({
				kind: "option",
				name: longOption,
				rawName: arg,
				index,
				value,
				inlineValue
			});
			if (value != null) ++index;
			continue;
		}
		if (isShortOptionGroup(arg, options)) {
			const expanded = [];
			for (let index = 1; index < arg.length; index++) {
				const shortOption = arg.charAt(index);
				if (optionsGetOwn(options, findLongOptionForShort(shortOption, options), "type") !== "string" || index === arg.length - 1) expanded.push(`-${shortOption}`);
				else {
					expanded.push(`-${arg.slice(index)}`);
					break;
				}
			}
			remainingArgs.unshift(...expanded);
			groupCount = expanded.length;
			continue;
		}
		if (isShortOptionAndValue(arg, options)) {
			const shortOption = arg.charAt(1);
			const longOption = findLongOptionForShort(shortOption, options);
			const value = arg.slice(2);
			tokens.push({
				kind: "option",
				name: longOption,
				rawName: `-${shortOption}`,
				index,
				value,
				inlineValue: true
			});
			continue;
		}
		if (isLoneLongOption(arg)) {
			const longOption = arg.slice(2);
			let value;
			let inlineValue;
			if (optionsGetOwn(options, longOption, "type") === "string" && isOptionValue(nextArg)) {
				value = remainingArgs.shift();
				inlineValue = false;
			}
			tokens.push({
				kind: "option",
				name: longOption,
				rawName: arg,
				index,
				value,
				inlineValue
			});
			if (value != null) ++index;
			continue;
		}
		if (isLongOptionAndValue(arg)) {
			const equalIndex = arg.indexOf("=");
			const longOption = arg.slice(2, equalIndex);
			const value = arg.slice(equalIndex + 1);
			tokens.push({
				kind: "option",
				name: longOption,
				rawName: `--${longOption}`,
				index,
				value,
				inlineValue: true
			});
			continue;
		}
		tokens.push({
			kind: "positional",
			index,
			value: arg
		});
	}
	return tokens;
}
function parseArgs$1(config = {}) {
	const args = objectGetOwn(config, "args");
	if (args == null) throw unsupportedNodeApi("util.parseArgs without args", "pass guest arguments explicitly");
	const strict = objectGetOwn(config, "strict") ?? true;
	const allowPositionals = objectGetOwn(config, "allowPositionals") ?? !strict;
	const returnTokens = objectGetOwn(config, "tokens") ?? false;
	const allowNegative = objectGetOwn(config, "allowNegative") ?? false;
	const options = objectGetOwn(config, "options") ?? Object.create(null);
	const parseConfig = {
		args,
		strict,
		options,
		allowPositionals,
		allowNegative
	};
	validateArray(args, "args");
	validateBoolean(strict, "strict");
	validateBoolean(allowPositionals, "allowPositionals");
	validateBoolean(returnTokens, "tokens");
	validateBoolean(allowNegative, "allowNegative");
	validateObject(options, "options");
	Object.entries(options).forEach(({ 0: longOption, 1: optionConfig }) => {
		validateObject(optionConfig, `options.${longOption}`);
		const optionType = objectGetOwn(optionConfig, "type");
		validateUnion(optionType, `options.${longOption}.type`, ["string", "boolean"]);
		if (Object.hasOwn(optionConfig, "short")) {
			const shortOption = optionConfig.short;
			validateString(shortOption, `options.${longOption}.short`);
			if (shortOption.length !== 1) throw invalidArgValue(`options.${longOption}.short`, shortOption, "must be a single character");
		}
		const multipleOption = objectGetOwn(optionConfig, "multiple");
		if (Object.hasOwn(optionConfig, "multiple")) validateBoolean(multipleOption, `options.${longOption}.multiple`);
		const defaultValue = objectGetOwn(optionConfig, "default");
		if (defaultValue !== void 0) {
			let validator;
			switch (optionType) {
				case "string":
					validator = multipleOption ? validateStringArray : validateString;
					break;
				case "boolean": validator = multipleOption ? validateBooleanArray : validateBoolean;
			}
			validator(defaultValue, `options.${longOption}.default`);
		}
	});
	const tokens = argsToTokens(args, options);
	const result = {
		values: Object.create(null),
		positionals: []
	};
	if (returnTokens) result.tokens = tokens;
	tokens.forEach((token) => {
		if (token.kind === "option") {
			if (strict) {
				checkOptionUsage(parseConfig, token);
				checkOptionLikeValue(token);
			}
			storeOption(token, options, result.values, parseConfig.allowNegative);
		} else if (token.kind === "positional") {
			if (!allowPositionals) throw codedError(/* @__PURE__ */ new TypeError(`Unexpected argument '${token.value}'. This command does not take positional arguments`), "ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL");
			result.positionals.push(token.value);
		}
	});
	Object.entries(options).forEach(({ 0: longOption, 1: optionConfig }) => {
		if (useDefaultValueOption(longOption, optionConfig, result.values)) storeDefaultOption(longOption, objectGetOwn(optionConfig, "default"), result.values);
	});
	return result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/parse-env.js
const trim = (value) => value.replace(/^[ \t\n]+|[ \t\n]+$/g, "");
function parseEnv$1(input) {
	if (typeof input !== "string") throw invalidArgType("content", "string", input);
	let content = trim(input.replaceAll("\r", ""));
	const entries = /* @__PURE__ */ new Map();
	while (content.length) {
		if (content[0] === "\n" || content[0] === "#") {
			const newline = content.indexOf("\n");
			content = newline === -1 ? "" : content.slice(newline + 1);
			continue;
		}
		const equal = content.search(/[=\n]/);
		if (equal === -1) break;
		if (content[equal] === "\n") {
			content = trim(content.slice(equal + 1));
			continue;
		}
		let key = trim(content.slice(0, equal));
		content = content.slice(equal + 1);
		if (!content.length || content[0] === "\n") {
			entries.set(key, "");
			continue;
		}
		content = trim(content);
		if (!key) continue;
		if (key.startsWith("export ")) key = trim(key.slice(7));
		if (!content.length) {
			entries.set(key, "");
			break;
		}
		const quote = content[0];
		if (quote === "\"" || quote === "'" || quote === "`") {
			const closing = content.indexOf(quote, 1);
			if (closing !== -1) {
				let value = content.slice(1, closing);
				if (quote === "\"") value = value.replaceAll("\\n", "\n");
				entries.set(key, value);
				const newline = content.indexOf("\n", closing + 1);
				content = newline === -1 ? "" : content.slice(newline + 1);
				continue;
			}
			const newline = content.indexOf("\n");
			entries.set(key, newline === -1 ? content : content.slice(0, newline));
			content = newline === -1 ? "" : content.slice(newline + 1);
		} else {
			const newline = content.indexOf("\n");
			let value = newline === -1 ? content : content.slice(0, newline);
			const hash = value.indexOf("#");
			if (hash !== -1) value = value.slice(0, hash);
			entries.set(key, trim(value));
			content = newline === -1 ? "" : content.slice(newline + 1);
		}
		content = trim(content);
	}
	entries.delete("__proto__");
	return Object.fromEntries(entries);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/inspect.js
const defaults = Object.seal({
	showHidden: false,
	depth: 2,
	colors: false,
	customInspect: true,
	showProxy: false,
	maxArrayLength: 100,
	maxStringLength: 1e4,
	breakLength: 80,
	compact: 3,
	sorted: false,
	getters: false,
	numericSeparator: false
});
function inspectImpl(value, options, depth, colors) {
	const opts = {
		...defaults,
		...typeof options === "boolean" ? { showHidden: options } : options
	};
	if (arguments.length > 2) opts.depth = depth;
	if (arguments.length > 3) opts.colors = colors;
	if (opts.showProxy) throw unsupportedNodeApi("util.inspect showProxy", "the engine does not expose proxy targets");
	return render(value, opts, [], /* @__PURE__ */ new Map(), 0);
}
const inspect$1 = Object.assign(inspectImpl, {
	custom: Symbol.for("nodejs.util.inspect.custom"),
	defaultOptions: defaults,
	colors: Object.create(null),
	styles: {
		special: "cyan",
		number: "yellow",
		bigint: "yellow",
		boolean: "yellow",
		undefined: "grey",
		null: "bold",
		string: "green",
		symbol: "green",
		date: "magenta",
		regexp: "red",
		module: "underline"
	}
});
Object.defineProperty(inspect$1, "name", { value: "inspect" });
Object.defineProperty(inspect$1, "defaultOptions", {
	enumerable: false,
	configurable: false,
	get: () => defaults,
	set: (options) => {
		validateObject(options, "options");
		Object.assign(defaults, options);
	}
});
function stylize(text, type, opts) {
	const codes = inspect$1.colors[inspect$1.styles[type]];
	return opts.colors && codes ? `\x1b[${codes[0]}m${text}\x1b[${codes[1]}m` : text;
}
function quote(value) {
	const mark = !value.includes("'") ? "'" : !value.includes("\"") ? "\"" : !value.includes("`") && !value.includes("${") ? "`" : "'";
	return mark + value.replace(/[\x00-\x1f\x7f-\x9f\\'"`]/g, (char) => {
		if (char === mark || char === "\\") return `\\${char}`;
		const names = {
			"\n": "\\n",
			"\r": "\\r",
			"	": "\\t",
			"\b": "\\b",
			"\f": "\\f",
			"\v": "\\v"
		};
		if (char in names) return names[char];
		return char.charCodeAt(0) < 32 || char.charCodeAt(0) >= 127 ? `\\x${char.charCodeAt(0).toString(16).padStart(2, "0")}` : char;
	}) + mark;
}
function numericString(value) {
	const raw = Object.is(value, -0) ? "-0" : String(value);
	if (raw.includes("e")) return raw;
	const [integer, fraction] = raw.split(".");
	return integer.replace(/\B(?=(\d{3})+(?!\d))/g, "_") + (fraction === void 0 ? "" : "." + fraction.replace(/(\d{3})(?=\d)/g, "$1_")) + (typeof value === "bigint" ? "n" : "");
}
const builtInObjects = new Set(Object.getOwnPropertyNames(globalThis).filter((name) => /^[A-Z][a-zA-Z0-9]+$/.test(name)));
function hasBuiltInToString(value) {
	const hasString = typeof Reflect.get(value, "toString") === "function";
	const hasPrimitive = typeof Reflect.get(value, Symbol.toPrimitive) === "function";
	if (!hasString && !hasPrimitive) return true;
	const ownsConversion = (object) => hasString && Object.hasOwn(object, "toString") || hasPrimitive && Object.hasOwn(object, Symbol.toPrimitive);
	if (ownsConversion(value)) return false;
	let pointer = Object.getPrototypeOf(value);
	while (pointer && !ownsConversion(pointer)) pointer = Object.getPrototypeOf(pointer);
	const descriptor = pointer && Object.getOwnPropertyDescriptor(pointer, "constructor");
	return !!descriptor && typeof descriptor.value === "function" && builtInObjects.has(descriptor.value.name);
}
function render(value, opts, ancestors, circular, level, propertyWidth = 0) {
	if (typeof value === "string") {
		const limit = opts.maxStringLength == null ? Infinity : Math.max(0, opts.maxStringLength);
		const text = quote(value.slice(0, limit));
		const extra = value.length > limit ? `... ${value.length - limit} more character${value.length - limit === 1 ? "" : "s"}` : "";
		return stylize(text, "string", opts) + extra;
	}
	if (value === null || typeof value !== "object" && typeof value !== "function") {
		let text = inspect$2(value, { colors: false });
		if (opts.numericSeparator && (typeof value === "number" || typeof value === "bigint")) text = numericString(value);
		return stylize(text, value === null ? "null" : typeof value, opts);
	}
	const object = value;
	if (opts.customInspect !== false) {
		const hook = Reflect.get(object, inspect$1.custom);
		if (typeof hook === "function" && hook !== inspect$1 && object !== Object.getPrototypeOf(object)?.constructor?.prototype) {
			const result = Reflect.apply(hook, object, [
				opts.depth == null ? null : opts.depth - level,
				{
					...opts,
					stylize: (text, type) => stylize(text, type, opts)
				},
				inspect$1
			]);
			if (result !== object) return typeof result === "string" ? result : render(result, opts, ancestors, circular, level);
		}
	}
	if (ancestors.includes(object)) {
		if (!circular.has(object)) circular.set(object, circular.size + 1);
		return stylize(`[Circular *${circular.get(object)}]`, "special", opts);
	}
	if (opts.depth !== null && level > (opts.depth ?? 2)) return stylize(`[${Array.isArray(value) ? "Array" : value.constructor?.name || "Object"}]`, "special", opts);
	if (value instanceof Date) return stylize(inspect$2(value, { colors: false }), "date", opts);
	if (value instanceof RegExp) return stylize(String(value), "regexp", opts);
	if (value instanceof Error) return inspect$2(value, opts);
	if (value instanceof Promise || value instanceof WeakMap || value instanceof WeakSet) {
		if (opts.showHidden) throw unsupportedNodeApi("util.inspect hidden engine state", "promise and weak collection contents are not exposed");
		return `${value.constructor.name} { <${value instanceof Promise ? "state unavailable" : "items unknown"}> }`;
	}
	ancestors.push(object);
	try {
		const child = (item, width = 0) => render(item, opts, ancestors, circular, level + 1, width);
		const parts = renderObject(object, opts, child);
		return typeof parts === "string" ? parts : layout(parts, opts, level, propertyWidth, circular.get(object));
	} finally {
		ancestors.pop();
	}
}
function renderProperty(object, key, opts, child) {
	const descriptor = Object.getOwnPropertyDescriptor(object, key);
	const label = typeof key === "symbol" ? `[${stylize(String(key), "symbol", opts)}]` : !descriptor.enumerable ? `[${key}]` : /^[A-Za-z_$][\w$]*$/.test(String(key)) ? String(key) : quote(String(key));
	let rendered;
	if ("value" in descriptor) rendered = child(descriptor.value, label.length + 2);
	else if (descriptor.get && (opts.getters === true || opts.getters === "get" && !descriptor.set || opts.getters === "set" && descriptor.set)) try {
		rendered = `[Getter${descriptor.set ? "/Setter" : ""}: ${child(Reflect.apply(descriptor.get, object, []))}]`;
	} catch (error) {
		rendered = `[Getter: <Inspection threw (${error instanceof Error ? error.message : String(error)})>]`;
	}
	else rendered = stylize(descriptor.get ? `[Getter${descriptor.set ? "/Setter" : ""}]` : "[Setter]", "special", opts);
	return `${label}: ${rendered}`;
}
function renderBoxed(value, keys, opts, property) {
	const intrinsic = isBooleanObject(value) ? Boolean.prototype.valueOf : isNumberObject(value) ? Number.prototype.valueOf : isStringObject(value) ? String.prototype.valueOf : isBigIntObject(value) ? BigInt.prototype.valueOf : Symbol.prototype.valueOf;
	const primitive = Reflect.apply(intrinsic, value, []);
	let prefix = `[${value.constructor.name}: ${render(primitive, {
		...opts,
		colors: false
	}, [], /* @__PURE__ */ new Map(), 0)}]`;
	const own = keys.filter((key) => !(typeof primitive === "string" && typeof key === "string" && (/^(0|[1-9]\d*)$/.test(key) || key === "length")));
	if (!own.length) return stylize(prefix, typeof primitive, opts);
	prefix += " ";
	return {
		prefix,
		entries: own.map(property)
	};
}
function renderArray(value, keys, opts, limit, child, property) {
	const array = value;
	const entries = [];
	let prefix = "";
	if (!Array.isArray(value)) prefix = `${value.constructor.name}(${array.length}) `;
	for (let i = 0; i < Math.min(array.length, limit); i++) if (!Object.hasOwn(value, i)) {
		let count = 1;
		while (i + count < Math.min(array.length, limit) && !Object.hasOwn(value, i + count)) count++;
		entries.push(stylize(`<${count} empty item${count === 1 ? "" : "s"}>`, "undefined", opts));
		i += count - 1;
	} else entries.push(child(array[i]));
	if (array.length > limit) entries.push(`... ${array.length - limit} more item${array.length - limit === 1 ? "" : "s"}`);
	for (const key of keys) if (typeof key !== "string" || !/^(0|[1-9]\d*)$/.test(key)) entries.push(property(key));
	return {
		prefix,
		entries,
		array: true
	};
}
function renderCollection(value, keys, opts, limit, child, property) {
	const entries = [];
	const prefix = `${value.constructor.name}(${value.size}) `;
	let i = 0;
	for (const entry of value) {
		if (i++ >= limit) break;
		if (value instanceof Map) {
			const pair = entry;
			entries.push(`${child(pair[0])} => ${child(pair[1])}`);
		} else entries.push(child(entry));
	}
	if (value.size > limit) entries.push(`... ${value.size - limit} more item${value.size - limit === 1 ? "" : "s"}`);
	if (opts.sorted) entries.sort(typeof opts.sorted === "function" ? opts.sorted : void 0);
	for (const key of keys) entries.push(property(key));
	return {
		prefix,
		entries
	};
}
function renderBuffer(value, keys, opts, limit, child, property) {
	const entries = [];
	const prefix = `${value.constructor.name} `;
	try {
		const bytes = new Uint8Array(value);
		let hex = Array.from(bytes.subarray(0, limit), (byte) => byte.toString(16).padStart(2, "0")).join(" ");
		if (bytes.length > limit) hex += ` ... ${bytes.length - limit} more byte${bytes.length - limit === 1 ? "" : "s"}`;
		entries.push(`${stylize("[Uint8Contents]", "special", opts)}: <${hex}>`);
	} catch {
		entries.push(stylize("(detached)", "special", opts));
	}
	entries.push(`${stylize("[byteLength]", "string", opts)}: ${child(value.byteLength)}`);
	for (const key of keys) entries.push(property(key));
	return {
		prefix,
		entries
	};
}
function renderView(value, keys, opts, child, property) {
	const entries = [];
	const prefix = "DataView ";
	entries.push(`${stylize("[byteLength]", "string", opts)}: ${child(value.byteLength)}`, `${stylize("[byteOffset]", "string", opts)}: ${child(value.byteOffset)}`, `${stylize("[buffer]", "string", opts)}: ${child(value.buffer, 10)}`);
	for (const key of keys) entries.push(property(key));
	return {
		prefix,
		entries
	};
}
function renderPlain(value, keys, opts, property) {
	const entries = [];
	let prefix = "";
	if (typeof value === "function") prefix = inspect$2(value, opts) + (keys.length ? " " : "");
	else if (Object.getPrototypeOf(value) === null) prefix = "[Object: null prototype] ";
	else if (value.constructor?.name && value.constructor.name !== "Object") prefix = `${value.constructor.name} `;
	if (opts.sorted) keys.sort(typeof opts.sorted === "function" ? (a, b) => opts.sorted(String(a), String(b)) : (a, b) => String(a).localeCompare(String(b)));
	for (const key of keys) entries.push(property(key));
	if (typeof value === "function" && !entries.length) return prefix;
	return {
		prefix,
		entries
	};
}
function renderObject(value, opts, child) {
	const limit = opts.maxArrayLength == null ? Infinity : Math.max(0, opts.maxArrayLength);
	const boxed = isBoxedPrimitive(value);
	const keys = opts.showHidden ? Reflect.ownKeys(value) : Reflect.ownKeys(value).filter((key) => Object.prototype.propertyIsEnumerable.call(value, key));
	const property = (key) => renderProperty(value, key, opts, child);
	if (boxed) return renderBoxed(value, keys, opts, property);
	if (Array.isArray(value) || ArrayBuffer.isView(value) && !(value instanceof DataView)) return renderArray(value, keys, opts, limit, child, property);
	if (value instanceof Map || value instanceof Set) return renderCollection(value, keys, opts, limit, child, property);
	if (value instanceof ArrayBuffer || typeof SharedArrayBuffer === "function" && value instanceof SharedArrayBuffer) return renderBuffer(value, keys, opts, limit, child, property);
	if (value instanceof DataView) return renderView(value, keys, opts, child, property);
	return renderPlain(value, keys, opts, property);
}
function layout({ prefix, entries, array }, opts, level, propertyWidth, id) {
	const open = array ? "[" : "{";
	const close = array ? "]" : "}";
	const single = entries.length ? `${prefix}${open} ${entries.join(", ")} ${close}` : `${prefix}${open}${close}`;
	const reference = id ? `<ref *${id}> ` : "";
	if (entries.length && (opts.compact === false || single.replace(/\x1b\[[0-9;]*m/g, "").length + level * 2 + propertyWidth > (opts.breakLength ?? 80))) {
		const indent = "  ".repeat(level + 1);
		return `${reference}${prefix}${open}\n${indent}${entries.join(`,\n${indent}`)}\n${"  ".repeat(level)}${close}`;
	}
	return reference + single;
}
function format$1(...args) {
	return formatWithOptions$1({}, ...args);
}
function formatWithOptions$1(options, ...args) {
	if (typeof options !== "object" || options === null) throw invalidArgType("inspectOptions", "Object", options);
	if (!args.length) return "";
	if (typeof args[0] !== "string") return args.map((v) => typeof v === "string" ? v : inspect$1(v, options)).join(" ");
	if (args.length === 1) return args[0];
	let index = 1;
	let text = args[0].replace(/%[sdifjoOc%]/g, (token) => {
		if (token === "%%") return "%";
		if (index >= args.length) return token;
		const value = args[index++];
		return formatSpecifier(token, value, options);
	});
	while (index < args.length) {
		const value = args[index++];
		text += ` ${typeof value === "string" ? value : inspect$1(value, options)}`;
	}
	return text;
}
function formatString(value, options) {
	if (typeof value === "object" && value !== null && hasBuiltInToString(value)) return inspect$1(value, {
		...options,
		colors: false,
		depth: 0,
		compact: 3
	});
	if (typeof value === "bigint" || typeof value === "number") return inspect$1(value, {
		colors: false,
		numericSeparator: options.numericSeparator
	});
	return String(value);
}
function formatNumber(token, value, options) {
	if (token !== "%f" && typeof value === "bigint") return inspect$1(value, {
		colors: false,
		numericSeparator: options.numericSeparator
	});
	if (typeof value === "symbol") return "NaN";
	const number = token === "%d" ? Number(value) : token === "%i" ? parseInt(String(value)) : parseFloat(String(value));
	return inspect$1(number, {
		colors: false,
		numericSeparator: options.numericSeparator
	});
}
function formatJson(value) {
	try {
		return JSON.stringify(value) ?? "undefined";
	} catch (error) {
		if (error instanceof TypeError && /circular|cyclic/i.test(error.message)) return "[Circular]";
		throw error;
	}
}
function formatSpecifier(token, value, options) {
	switch (token) {
		case "%c": return "";
		case "%s": return formatString(value, options);
		case "%d":
		case "%i":
		case "%f": return formatNumber(token, value, options);
		case "%j": return formatJson(value);
		default: return inspect$1(value, token === "%o" ? {
			...options,
			showHidden: true,
			depth: 4
		} : options);
	}
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/text.js
const colors = {
	reset: [0, 0],
	bold: [1, 22],
	dim: [2, 22],
	italic: [3, 23],
	underline: [4, 24],
	blink: [5, 25],
	inverse: [7, 27],
	hidden: [8, 28],
	strikethrough: [9, 29],
	doubleunderline: [21, 24],
	black: [30, 39],
	red: [31, 39],
	green: [32, 39],
	yellow: [33, 39],
	blue: [34, 39],
	magenta: [35, 39],
	cyan: [36, 39],
	white: [37, 39],
	bgBlack: [40, 49],
	bgRed: [41, 49],
	bgGreen: [42, 49],
	bgYellow: [43, 49],
	bgBlue: [44, 49],
	bgMagenta: [45, 49],
	bgCyan: [46, 49],
	bgWhite: [47, 49],
	framed: [51, 54],
	overlined: [53, 55],
	gray: [90, 39],
	redBright: [91, 39],
	greenBright: [92, 39],
	yellowBright: [93, 39],
	blueBright: [94, 39],
	magentaBright: [95, 39],
	cyanBright: [96, 39],
	whiteBright: [97, 39],
	bgGray: [100, 49],
	bgRedBright: [101, 49],
	bgGreenBright: [102, 49],
	bgYellowBright: [103, 49],
	bgBlueBright: [104, 49],
	bgMagentaBright: [105, 49],
	bgCyanBright: [106, 49],
	bgWhiteBright: [107, 49]
};
Object.setPrototypeOf(colors, null);
const ansi = /* @__PURE__ */ new RegExp("[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/\\#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/\\#&.:=?%@~_]*)*)?(?:\\u0007|\\u001B\\u005C|\\u009C))|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))", "g");
for (const [alias, canonical] of Object.entries({
	grey: "gray",
	blackBright: "gray",
	bgGrey: "bgGray",
	bgBlackBright: "bgGray",
	faint: "dim",
	swapcolors: "inverse",
	swapColors: "inverse",
	conceal: "hidden",
	strikeThrough: "strikethrough",
	crossedout: "strikethrough",
	crossedOut: "strikethrough",
	doubleUnderline: "doubleunderline"
})) Object.defineProperty(colors, alias, {
	enumerable: false,
	configurable: true,
	get: () => colors[canonical],
	set: (value) => {
		colors[canonical] = value;
	}
});
inspect$1.colors = colors;
function stripVTControlCharacters$1(str) {
	if (typeof str !== "string") throw invalidArgType("str", "string", str);
	return str.replace(ansi, "");
}
function toUSVString$1(input) {
	const text = `${input}`;
	if (typeof text.toWellFormed === "function") return text.toWellFormed();
	let result = "";
	for (let i = 0; i < text.length; i++) {
		const code = text.charCodeAt(i);
		if (code >= 55296 && code <= 56319) {
			const next = text.charCodeAt(i + 1);
			if (next >= 56320 && next <= 57343) {
				result += text[i] + text[++i];
				continue;
			}
			result += "�";
		} else result += code >= 56320 && code <= 57343 ? "�" : text[i];
	}
	return result;
}
function replaceClose(text, close, open, keepClose) {
	let start = 0, result = "";
	for (let index = text.indexOf(close); index !== -1; index = text.indexOf(close, start)) {
		const after = index + close.length;
		if (after >= text.length) break;
		result += text.slice(start, index) + (keepClose ? close + open : open);
		start = after;
	}
	return result + text.slice(start);
}
function styleText$1(format, text, options) {
	if (typeof text !== "string") throw invalidArgType("text", "string", text);
	if (options !== void 0) validateObject(options, "options");
	const validateStream = options?.validateStream ?? true;
	if (typeof validateStream !== "boolean") throw invalidArgType("options.validateStream", "boolean", validateStream);
	let skip = false;
	if (validateStream) {
		const stream = options?.stream;
		if (!stream) throw unsupportedNodeApi("util.styleText default stream", "supply a stream or validateStream: false");
		if (typeof stream !== "object" || !("write" in stream) && !("getReader" in stream) && !("getWriter" in stream)) throw invalidArgType("stream", [
			"ReadableStream",
			"WritableStream",
			"Stream"
		], stream);
		skip = !("isTTY" in stream && stream.isTTY === true);
	}
	let openCodes = "", closeCodes = "", processed = text;
	for (const key of Array.isArray(format) ? format : [format]) {
		if (key === "none") continue;
		let open, close, keep = false;
		if (typeof key === "string" && key.startsWith("#")) {
			if (!/^#(?:[a-f\d]{3}|[a-f\d]{6})$/i.test(key)) throw invalidArgValue("format", key, "must be a valid hex color (#RGB or #RRGGBB)");
			const hex = key.length === 4 ? key.slice(1).split("").map((c) => c + c).join("") : key.slice(1);
			open = `\x1b[38;2;${[
				0,
				2,
				4
			].map((i) => parseInt(hex.slice(i, i + 2), 16)).join(";")}m`;
			close = "\x1B[39m";
		} else {
			const codes = colors[key];
			if (!codes) throw invalidArgValue("format", key, `must be one of: ${Object.getOwnPropertyNames(colors).join(", ")}`);
			open = `\x1b[${codes[0]}m`;
			close = `\x1b[${codes[1]}m`;
			keep = codes[0] === 1 || codes[0] === 2;
		}
		openCodes += open;
		closeCodes = close + closeCodes;
		processed = replaceClose(processed, close, open, keep);
	}
	return skip ? text : openCodes + processed + closeCodes;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/aborted.js
let registry;
async function aborted$1(signal, resource) {
	validateAbortSignal(signal, "signal");
	if (signal === void 0) throw invalidArgType("signal", "AbortSignal", signal);
	if (resource === null || typeof resource !== "object" && typeof resource !== "function") throw invalidArgType("resource", "Object", resource);
	if (signal.aborted) return;
	if (typeof WeakRef !== "function" || typeof FinalizationRegistry !== "function") throw unsupportedNodeApi("util.aborted", "the engine must support weak resource lifetimes");
	registry ??= new FinalizationRegistry(({ signal, listener }) => {
		signal.deref()?.removeEventListener("abort", listener);
	});
	return new Promise((resolve) => {
		const token = {};
		const weakResource = new WeakRef(resource);
		const listener = () => {
			registry.unregister(token);
			if (weakResource.deref()) resolve();
		};
		registry.register(resource, {
			signal: new WeakRef(signal),
			listener
		}, token);
		signal.addEventListener("abort", listener, { once: true });
	});
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/unsupported.js
var unsupported_exports = /* @__PURE__ */ __exportAll({
	_errnoException: () => _errnoException$1,
	_exceptionWithHostPort: () => _exceptionWithHostPort$1,
	_extend: () => _extend$1,
	convertProcessSignalToExitCode: () => convertProcessSignalToExitCode,
	debug: () => debug$1,
	debuglog: () => debuglog$1,
	deprecate: () => deprecate$1,
	getCallSites: () => getCallSites$1,
	getSystemErrorMap: () => getSystemErrorMap$1,
	getSystemErrorMessage: () => getSystemErrorMessage$1,
	getSystemErrorName: () => getSystemErrorName$1,
	isArray: () => isArray$1,
	setTraceSigInt: () => setTraceSigInt$1,
	transferableAbortController: () => transferableAbortController$1,
	transferableAbortSignal: () => transferableAbortSignal$1
});
function debuglog$1(_section, _callback) {
	throw unsupportedNodeApi("util.debuglog", "Node debug environment and process logging are not available");
}
const debug$1 = debuglog$1;
function deprecate$1(_fn, _message, _code, _options) {
	throw unsupportedNodeApi("util.deprecate", "Node process warning policy is not available");
}
function getCallSites$1(_frameCount, _options) {
	throw unsupportedNodeApi("util.getCallSites", "native call sites and source maps are not exposed by component engines");
}
function getSystemErrorName$1(_error) {
	throw unsupportedNodeApi("util.getSystemErrorName", "host libuv errno tables are not available");
}
function getSystemErrorMessage$1(_error) {
	throw unsupportedNodeApi("util.getSystemErrorMessage", "host libuv errno tables are not available");
}
function getSystemErrorMap$1() {
	throw unsupportedNodeApi("util.getSystemErrorMap", "host libuv errno tables are not available");
}
function setTraceSigInt$1(_enable) {
	throw unsupportedNodeApi("util.setTraceSigInt", "components cannot install host process signal handlers");
}
function convertProcessSignalToExitCode(_signal) {
	throw unsupportedNodeApi("util.convertProcessSignalToExitCode", "host process signals are not available");
}
function transferableAbortController$1() {
	throw unsupportedNodeApi("util.transferableAbortController", "Node worker transfer hooks are not available");
}
function transferableAbortSignal$1(_signal) {
	throw unsupportedNodeApi("util.transferableAbortSignal", "Node worker transfer hooks are not available");
}
function _extend$1(_target, _source) {
	throw deprecatedNodeApi("util._extend", "Object.assign");
}
function isArray$1(_value) {
	throw deprecatedNodeApi("util.isArray", "Array.isArray");
}
function _errnoException$1(..._args) {
	throw deprecatedNodeApi("util._errnoException", "a public error API");
}
function _exceptionWithHostPort$1(..._args) {
	throw deprecatedNodeApi("util._exceptionWithHostPort", "a public error API");
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/util/index.js
const TextDecoder$1 = globalThis.TextDecoder ?? function TextDecoder() {
	throw unsupportedNodeApi("util.TextDecoder", "the engine does not provide TextDecoder");
};
const TextEncoder$1 = globalThis.TextEncoder ?? function TextEncoder() {
	throw unsupportedNodeApi("util.TextEncoder", "the engine does not provide TextEncoder");
};
var util_default = {
	...unsupported_exports,
	MIMEParams: MIMEParams$1,
	MIMEType: MIMEType$1,
	TextDecoder: TextDecoder$1,
	TextEncoder: TextEncoder$1,
	aborted: aborted$1,
	callbackify: callbackify$1,
	diff: diff$1,
	format: format$1,
	formatWithOptions: formatWithOptions$1,
	inherits: inherits$1,
	inspect: inspect$1,
	isDeepStrictEqual: isDeepStrictEqual$1,
	parseArgs: parseArgs$1,
	parseEnv: parseEnv$1,
	promisify: promisify$1,
	stripVTControlCharacters: stripVTControlCharacters$1,
	styleText: styleText$1,
	toUSVString: toUSVString$1,
	types: types$1
};
//#endregion
//#region src/util.mjs
function isArray(value) {
	return Array.isArray(value);
}
function deprecate(fn, message, code) {
	if (typeof fn !== "function") throw new TypeError("The \"fn\" argument must be of type function");
	let warned = false;
	function deprecated(...args) {
		if (!warned) {
			warned = true;
			const warning = new Error(message);
			warning.name = "DeprecationWarning";
			if (code) warning.code = code;
			console.warn(warning);
		}
		return Reflect.apply(fn, this, args);
	}
	Object.setPrototypeOf(deprecated, fn);
	Object.defineProperty(deprecated, "name", { value: fn.name });
	return Object.assign(deprecated, fn);
}
function debuglog() {
	return function debug() {};
}
const debug = debuglog;
const api = {
	...import_util.default,
	...util_default,
	isArray,
	deprecate,
	debuglog,
	debug
};
const { MIMEParams, MIMEType, TextDecoder, TextEncoder, _errnoException, _exceptionWithHostPort, _extend, aborted, callbackify, diff, format, formatWithOptions, getCallSites, getSystemErrorMap, getSystemErrorMessage, getSystemErrorName, inherits, inspect, isBoolean, isBuffer, isDate, isDeepStrictEqual, isError, isFunction, isNull, isNullOrUndefined, isNumber, isObject, isPrimitive, isRegExp, isString, isSymbol, isUndefined, parseArgs, parseEnv, promisify, setTraceSigInt, stripVTControlCharacters, styleText, toUSVString, transferableAbortController, transferableAbortSignal, types } = api;
//#endregion
export { MIMEParams, MIMEType, TextDecoder, TextEncoder, _errnoException, _exceptionWithHostPort, _extend, aborted, callbackify, debug, debuglog, api as default, deprecate, diff, format, formatWithOptions, getCallSites, getSystemErrorMap, getSystemErrorMessage, getSystemErrorName, inherits, inspect, isArray, isBoolean, isBuffer, isDate, isDeepStrictEqual, isError, isFunction, isNull, isNullOrUndefined, isNumber, isObject, isPrimitive, isRegExp, isString, isSymbol, isUndefined, parseArgs, parseEnv, promisify, setTraceSigInt, stripVTControlCharacters, styleText, toUSVString, transferableAbortController, transferableAbortSignal, types };
