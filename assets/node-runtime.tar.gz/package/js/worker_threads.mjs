import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as codedError, d as invalidArgType, v as unsupportedNodeApi } from "./chunks/core-DGqXzKN-.mjs";
import { n as denyThrow, t as adapterRequiredMessage } from "./chunks/deny-host-tjTl4Rxm.mjs";
import { m as import_events } from "./chunks/events-KhrHxd6b.mjs";
import { r as serializeHostError, t as callHost } from "./chunks/host-error-DahHjm1T.mjs";
import { n as decodeMessage, t as createMessageCodec } from "./chunks/structured-value-BynNDS9b.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads-host.js
var worker_threads_host_exports = /* @__PURE__ */ __exportAll({
	Worker: () => Worker$1,
	createWorker: () => createWorker,
	default: () => worker_threads_host_default
});
const required = denyThrow("ERR_JCO_WORKER_THREADS_ADAPTER_REQUIRED", adapterRequiredMessage("node:worker_threads"));
const createWorker = () => {
	try {
		return required();
	} catch (error) {
		return {
			tag: "err",
			val: serializeHostError(error)
		};
	}
};
/** Present the imported resource shape even though no resource can be created. */
var Worker$1 = class {
	constructor() {
		required();
	}
	postMessage(_value) {
		return required();
	}
	terminate() {
		return required();
	}
	setRef(_value) {
		return required();
	}
	info() {
		return required();
	}
	[Symbol.dispose]() {
		return required();
	}
};
var worker_threads_host_default = {
	Worker: Worker$1,
	createWorker
};
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads/environment.js
/**
* Adapted from nodejs/node lib/internal/worker.js, v24.20.0,
* 71b8b174857e25106d39b61a9e6f30d927da8b01 (MIT; see jco-std LICENSE).
* A factory replaces Node's per-isolate module state; snapshots cross WIT only
* when constructing a worker, not when setting or retrieving a value.
*/
function createEnvironmentData() {
	const values = /* @__PURE__ */ new Map();
	return {
		values,
		setEnvironmentData(key, value) {
			if (value === void 0) values.delete(key);
			else values.set(key, value);
		},
		getEnvironmentData(key) {
			return values.get(key);
		}
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads/errors.js
function fromHost(error) {
	const result = error.name === "TypeError" ? new TypeError(error.message) : error.name === "RangeError" ? new RangeError(error.message) : new Error(error.message);
	result.name = error.name;
	return error.code ? codedError(result, error.code) : result;
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads/unsupported.js
function unsupported(api) {
	throw unsupportedNodeApi(api, "Native message ports, shared memory, contexts and locks cannot cross the worker_threads component boundary");
}
/** No disconnected or inert ports are returned when native messaging is unavailable. */
var MessagePort$1 = class {
	constructor() {
		unsupported("new MessagePort()");
	}
	postMessage(_value, _transferList) {
		return unsupported("MessagePort.postMessage()");
	}
	start() {
		return unsupported("MessagePort.start()");
	}
	close(_callback) {
		return unsupported("MessagePort.close()");
	}
	ref() {
		return unsupported("MessagePort.ref()");
	}
	unref() {
		return unsupported("MessagePort.unref()");
	}
	hasRef() {
		return unsupported("MessagePort.hasRef()");
	}
	get onmessage() {
		return unsupported("MessagePort.onmessage");
	}
	set onmessage(_value) {
		unsupported("MessagePort.onmessage");
	}
	get onmessageerror() {
		return unsupported("MessagePort.onmessageerror");
	}
	set onmessageerror(_value) {
		unsupported("MessagePort.onmessageerror");
	}
};
var MessageChannel$1 = class {
	constructor() {
		unsupported("new MessageChannel()");
	}
};
var BroadcastChannel$1 = class {
	constructor(_name) {
		unsupported("new BroadcastChannel()");
	}
	get name() {
		return unsupported("BroadcastChannel.name");
	}
	close() {
		return unsupported("BroadcastChannel.close()");
	}
	postMessage(_value) {
		return unsupported("BroadcastChannel.postMessage()");
	}
	ref() {
		return unsupported("BroadcastChannel.ref()");
	}
	unref() {
		return unsupported("BroadcastChannel.unref()");
	}
	get onmessage() {
		return unsupported("BroadcastChannel.onmessage");
	}
	set onmessage(_value) {
		unsupported("BroadcastChannel.onmessage");
	}
	get onmessageerror() {
		return unsupported("BroadcastChannel.onmessageerror");
	}
	set onmessageerror(_value) {
		unsupported("BroadcastChannel.onmessageerror");
	}
};
function receiveMessageOnPort$1(_port) {
	return unsupported("worker_threads.receiveMessageOnPort()");
}
function moveMessagePortToContext$1(_port, _context) {
	return unsupported("worker_threads.moveMessagePortToContext()");
}
function postMessageToThread$1(_id, _value, _transferListOrTimeout, _timeout) {
	return unsupported("worker_threads.postMessageToThread()");
}
var LockManager = class {
	request(_name, _optionsOrCallback, _callback) {
		return unsupported("worker_threads.locks.request()");
	}
	query() {
		return unsupported("worker_threads.locks.query()");
	}
};
const locks$1 = new LockManager();
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads/core.js
/** Node 24.20's module contract, with native worker handles replaced by WIT resources. */
function createWorkerThreads(host) {
	const environment = createEnvironmentData();
	const codec = createMessageCodec();
	const listeners = /* @__PURE__ */ new Map();
	let nextListener = 1;
	class Listener {
		deliver;
		constructor(deliver) {
			this.deliver = deliver;
		}
		event(event) {
			this.deliver(event);
		}
		[Symbol.dispose]() {}
	}
	const workerThreadsCallbacks = {
		WorkerListener: Listener,
		takeWorkerListener(id) {
			const listener = listeners.get(id);
			listeners.delete(id);
			return listener;
		}
	};
	function noTransfers(transferList) {
		if (transferList === void 0) return;
		if (!Array.isArray(transferList)) throw invalidArgType("transferList", "Array", transferList);
		if (transferList.length) unsupported("worker_threads transferList");
	}
	const Emitter = import_events.EventEmitter;
	class Worker extends Emitter {
		#handle;
		#exitCode;
		#termination;
		#resolveTermination;
		constructor(filename, options = {}) {
			super();
			const filenameIsURL = typeof globalThis.URL === "function" && filename instanceof globalThis.URL;
			if (typeof filename !== "string" && !filenameIsURL) throw invalidArgType("filename", ["string", "URL"], filename);
			if (!options || typeof options !== "object" || Array.isArray(options)) throw invalidArgType("options", "Object", options);
			noTransfers(options.transferList);
			if (options.stdin || options.stdout || options.stderr) unsupported("Worker stdio redirection");
			if (typeof options.env === "symbol") unsupported("Worker SHARE_ENV");
			const encodedOptions = codec.encode({
				...options,
				filenameIsURL
			});
			const encodedEnvironment = codec.encode(environment.values);
			const id = nextListener++;
			listeners.set(id, new Listener((event) => this.#event(event)));
			try {
				this.#handle = callHost(() => host.createWorker(String(filename), encodedOptions, encodedEnvironment, id), fromHost);
			} catch (error) {
				listeners.delete(id);
				throw error;
			}
		}
		#event(event) {
			switch (event.tag) {
				case "online":
					this.emit("online");
					break;
				case "message":
					this.emit("message", decodeMessage(event.val));
					break;
				case "messageerror":
					this.emit("messageerror", fromHost(event.val));
					break;
				case "error":
					this.emit("error", fromHost(event.val));
					break;
				case "exit":
					this.#exitCode = event.val;
					this.#resolveTermination?.(event.val);
					try {
						this.emit("exit", event.val);
					} finally {
						this.#handle[Symbol.dispose]();
					}
			}
		}
		postMessage(value, transferList) {
			if (this.#exitCode !== void 0) return;
			noTransfers(transferList);
			const encoded = codec.encode(value);
			callHost(() => this.#handle.postMessage(encoded), fromHost);
		}
		terminate() {
			if (this.#termination) return this.#termination;
			if (this.#exitCode !== void 0) return Promise.resolve(this.#exitCode);
			this.#termination = new Promise((resolve) => {
				this.#resolveTermination = resolve;
			});
			this.#handle.terminate();
			return this.#termination;
		}
		ref() {
			if (this.#exitCode === void 0) this.#handle.setRef(true);
			return this;
		}
		unref() {
			if (this.#exitCode === void 0) this.#handle.setRef(false);
			return this;
		}
		get threadId() {
			return this.#exitCode === void 0 ? this.#handle.info().threadId : -1;
		}
		get threadName() {
			return this.#exitCode === void 0 ? this.#handle.info().threadName : null;
		}
		get resourceLimits() {
			return this.#exitCode === void 0 ? this.#handle.info().resourceLimits : {};
		}
		get stdin() {
			return unsupported("Worker.stdin");
		}
		get stdout() {
			return unsupported("Worker.stdout");
		}
		get stderr() {
			return unsupported("Worker.stderr");
		}
		get performance() {
			return unsupported("Worker.performance");
		}
		getHeapSnapshot(_options) {
			return unsupported("Worker.getHeapSnapshot()");
		}
		getHeapStatistics() {
			return unsupported("Worker.getHeapStatistics()");
		}
		cpuUsage(_previous) {
			return unsupported("Worker.cpuUsage()");
		}
		startCpuProfile(_options) {
			return unsupported("Worker.startCpuProfile()");
		}
		startHeapProfile(_options) {
			return unsupported("Worker.startHeapProfile()");
		}
		async [Symbol.asyncDispose]() {
			await this.terminate();
		}
	}
	return {
		workerThreads: {
			isInternalThread: false,
			isMainThread: true,
			MessagePort: MessagePort$1,
			MessageChannel: MessageChannel$1,
			markAsUncloneable: codec.markAsUncloneable,
			markAsUntransferable: codec.markAsUntransferable,
			isMarkedAsUntransferable: codec.isMarkedAsUntransferable,
			moveMessagePortToContext: moveMessagePortToContext$1,
			receiveMessageOnPort: receiveMessageOnPort$1,
			resourceLimits: {},
			postMessageToThread: postMessageToThread$1,
			threadId: 0,
			threadName: "",
			SHARE_ENV: Symbol.for("nodejs.worker_threads.SHARE_ENV"),
			Worker,
			parentPort: null,
			workerData: null,
			BroadcastChannel: BroadcastChannel$1,
			setEnvironmentData: environment.setEnvironmentData,
			getEnvironmentData: environment.getEnvironmentData,
			locks: locks$1
		},
		workerThreadsCallbacks
	};
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/worker-threads.js
const { workerThreads, workerThreadsCallbacks } = createWorkerThreads(worker_threads_host_exports);
const { isInternalThread, isMainThread, MessagePort, MessageChannel, markAsUncloneable, markAsUntransferable, isMarkedAsUntransferable, moveMessagePortToContext, receiveMessageOnPort, resourceLimits, postMessageToThread, threadId, threadName, SHARE_ENV, Worker, parentPort, workerData, BroadcastChannel, setEnvironmentData, getEnvironmentData, locks } = workerThreads;
//#endregion
export { BroadcastChannel, MessageChannel, MessagePort, SHARE_ENV, Worker, workerThreads as default, getEnvironmentData, isInternalThread, isMainThread, isMarkedAsUntransferable, locks, markAsUncloneable, markAsUntransferable, moveMessagePortToContext, parentPort, postMessageToThread, receiveMessageOnPort, resourceLimits, setEnvironmentData, threadId, threadName, workerData, workerThreadsCallbacks };
