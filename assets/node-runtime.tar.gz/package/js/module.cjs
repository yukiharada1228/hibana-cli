module.exports = require('./module.mjs').default;
