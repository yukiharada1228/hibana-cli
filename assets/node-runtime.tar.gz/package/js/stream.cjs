module.exports = require('./stream.mjs').default;
