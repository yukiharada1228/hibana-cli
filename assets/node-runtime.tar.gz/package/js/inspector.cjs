module.exports = require('./inspector.mjs').default;
