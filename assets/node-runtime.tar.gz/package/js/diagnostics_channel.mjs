import { r as __exportAll } from "./chunks/rolldown-runtime-7_rZTKki.mjs";
import { a as unsubscribe, i as subscribe, n as channel, r as hasSubscribers, t as Channel } from "./chunks/channel-tzh3-Au8.mjs";
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/diagnostics-channel/types.js
/** The sub-channel names a `TracingChannel` owns, in Node's order. */
const TRACING_EVENTS = [
	"start",
	"end",
	"asyncStart",
	"asyncEnd",
	"error"
];
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/diagnostics-channel/tracing.js
/**
* Node's `TracingChannel`: a group of channels describing one traced operation.
*
* Adapted from nodejs/node v24.19.0, commit
* cdc1b38d40cb567b7ad0b39c86addf830a0af0ae, lib/diagnostics_channel.js (MIT
* license). `traceSync`, `tracePromise`, and `traceCallback` keep the upstream
* publish order and context mutation; primordials, the native channel binding,
* and the subscriber fast path are dropped, and the surface is typed.
*/
/** Node names a tracing channel's sub-channels `tracing:<name>:<event>`. */
function subChannelName(name, event) {
	return `tracing:${name}:${event}`;
}
/**
* Node's `TracingChannel`: a group of channels describing one traced operation.
*
* `start`/`end` bracket the call, `error` reports a throw, and `asyncStart`/`asyncEnd` bracket the
* asynchronous portion of `tracePromise` and `traceCallback`.
*/
var TracingChannel = class {
	start;
	end;
	asyncStart;
	asyncEnd;
	error;
	constructor(name) {
		this.start = channel(subChannelName(name, "start"));
		this.end = channel(subChannelName(name, "end"));
		this.asyncStart = channel(subChannelName(name, "asyncStart"));
		this.asyncEnd = channel(subChannelName(name, "asyncEnd"));
		this.error = channel(subChannelName(name, "error"));
	}
	/** Whether any of the sub-channels has a subscriber. A getter, as Node has it. */
	get hasSubscribers() {
		return TRACING_EVENTS.some((event) => this[event].hasSubscribers);
	}
	subscribe(subscribers) {
		for (const event of TRACING_EVENTS) {
			const handler = subscribers[event];
			if (handler) this[event].subscribe(handler);
		}
	}
	unsubscribe(subscribers) {
		let removedAny = false;
		for (const event of TRACING_EVENTS) {
			const handler = subscribers[event];
			if (handler && this[event].unsubscribe(handler)) removedAny = true;
		}
		return removedAny;
	}
	/**
	* Trace a synchronous call.
	*
	* Publishes `start`, then `end` once the call returns -- and `error` before `end` if it throws,
	* matching the order Node emits.
	*/
	traceSync(fn, context = {}, thisArg, ...args) {
		return this.start.runStores(context, () => {
			try {
				const result = Reflect.apply(fn, thisArg, args);
				context.result = result;
				return result;
			} catch (error) {
				context.error = error;
				this.error.publish(context);
				throw error;
			} finally {
				this.end.publish(context);
			}
		});
	}
	/** Trace a promise-returning call, bracketing its asynchronous portion. */
	tracePromise(fn, context = {}, thisArg, ...args) {
		return this.start.runStores(context, () => {
			let promise;
			try {
				promise = Reflect.apply(fn, thisArg, args);
			} catch (error) {
				context.error = error;
				this.error.publish(context);
				throw error;
			} finally {
				this.end.publish(context);
			}
			return promise.then((result) => {
				context.result = result;
				this.asyncStart.publish(context);
				this.asyncEnd.publish(context);
				return result;
			}, (error) => {
				context.error = error;
				this.error.publish(context);
				this.asyncStart.publish(context);
				this.asyncEnd.publish(context);
				throw error;
			});
		});
	}
	/**
	* Trace a callback-taking call.
	*
	* The callback is wrapped in place at `position`, so the traced function still receives the
	* arguments it expects.
	*/
	traceCallback(fn, position = -1, context = {}, thisArg, ...args) {
		const callbackIndex = position >= 0 ? position : args.length - 1;
		const original = args[callbackIndex];
		if (typeof original === "function") {
			const wrapped = (...callbackArgs) => {
				const [error] = callbackArgs;
				this.asyncStart.publish(context);
				if (error) {
					context.error = error;
					this.error.publish(context);
				}
				try {
					return Reflect.apply(original, thisArg, callbackArgs);
				} finally {
					this.asyncEnd.publish(context);
				}
			};
			args[callbackIndex] = wrapped;
		}
		return this.start.runStores(context, () => {
			try {
				return Reflect.apply(fn, thisArg, args);
			} catch (error) {
				context.error = error;
				this.error.publish(context);
				throw error;
			} finally {
				this.end.publish(context);
			}
		});
	}
};
function tracingChannel(name) {
	return new TracingChannel(name);
}
//#endregion
//#region node_modules/@bytecodealliance/jco-std/dist/wasi/0.2.x/node/24.x.x/diagnostics-channel.js
var diagnostics_channel_default = /* @__PURE__ */ __exportAll({
	Channel: () => Channel,
	TracingChannel: () => TracingChannel,
	channel: () => channel,
	hasSubscribers: () => hasSubscribers,
	subscribe: () => subscribe,
	tracingChannel: () => tracingChannel,
	unsubscribe: () => unsubscribe
});
//#endregion
export { Channel, TracingChannel, channel, diagnostics_channel_default as default, hasSubscribers, subscribe, tracingChannel, unsubscribe };
