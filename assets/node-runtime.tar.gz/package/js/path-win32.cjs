module.exports = require('./path-win32.mjs').default;
