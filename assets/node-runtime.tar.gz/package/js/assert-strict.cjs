module.exports = require('./assert-strict.mjs').default;
