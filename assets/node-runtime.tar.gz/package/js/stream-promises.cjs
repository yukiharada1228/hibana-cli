module.exports = require('./stream-promises.mjs').default;
