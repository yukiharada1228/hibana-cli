module.exports = require('./buffer.mjs').default;
